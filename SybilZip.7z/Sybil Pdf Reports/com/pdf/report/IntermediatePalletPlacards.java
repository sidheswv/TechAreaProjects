package com.pdf.report;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;

import com.report.text.Document;
import com.report.text.DocumentException;
import com.report.text.Element;
import com.report.text.Font;
import com.report.text.FontFactory;
import com.report.text.PageSize;
import com.report.text.Phrase;
import com.report.text.pdf.PdfPCell;
import com.report.text.pdf.PdfPTable;
import com.report.text.pdf.PdfWriter;

import sybil.common.model.Magazine;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;

public class IntermediatePalletPlacards {
	
	public static String pkgsum = "TBA_PKG_SUM";
	public static String rollsumTableName = "TBA_ROLL_SUM";
	public static String magazineInf = "TBA_MAGAZINEINF";
	public static String sybMag = "TBA_SYB_MAGAZINE";
	public static String sybplant = "TBA_SYB_PLANT";
	
	private static Connection conn = null;
	private static ResultSet resultset = null;
	private static String magName = null;
	private static int magKey = 0;
	
	private static String instCd = null;
	
	private static String magCode = null;
	
	private static String issueNum = null;
	
	private static String plantId = null;
	
	private static String issueWeek = null;
	
	private static String issueDate = null;
	
	private static String plantName = null;
	
	private static void initialize(Magazine mag){
		magCode = mag.getMagCode().trim();
		issueNum = mag.getIssue().trim();
		plantId = mag.getPlant().toUpperCase().trim();
		issueWeek = mag.getWeek().trim();		
	}
	
	private static void open() {

		PreparedStatement setSqlId = null;
		Statement commitSqlId = null;
		String x = null;
		String db2owner = null;
		int i = 0;
		
		String userDb = sybil.common.util.PropertyBroker.getProperty("database.login","sybil");
		String pswdDb = sybil.common.util.PropertyBroker.getProperty("database.password","sybil");
		
		
		if( conn == null) {
			try {
				Class.forName(sybil.common.util.PropertyBroker.getProperty("database.driver", "Not Found"));
				conn = DriverManager.getConnection(sybil.common.util.PropertyBroker.getProperty("database.server", "Not Found"), userDb, pswdDb);

				//
				x = PropertyBroker.getProperty("database.driver", "Not Found").toLowerCase();
				i = x.indexOf("db2");
				if (!(i < 0)) {
					try {
						db2owner = PropertyBroker.getProperty("DB2OWNER","dtppsyup");
						setSqlId = conn.prepareStatement("set current sqlid = ?");
						setSqlId.setString(1, db2owner);
						setSqlId.execute();
						commitSqlId = conn.createStatement();
						commitSqlId.execute("commit");
					}
					catch (SQLException se) {
						if(se.getSQLState().equals("S1010")) {
						}
						else {
							LogWriter.writeLog(se);
							LogWriter.writeLog("Error: Set Current SqlId failed.");
							if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
								LogWriter.writeLog("Process terminating due to database/sql exception");
								System.exit(1);
							}
						}
					}
					catch (Exception e) {
						LogWriter.writeLog(e);
						LogWriter.writeLog("Error: Set Current SqlId failed.");
						if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
							LogWriter.writeLog("Process terminating due to database/sql exception");
							System.exit(1);
						}
					}
				}
			
			} 
			catch (Exception e) {
				sybil.common.util.LogWriter.writeLog(e);
				LogWriter.writeLog("Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
		
	return;
	}
	

	private static void getIssueDate(){
		
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT COVER_DATE FROM " + magazineInf + " WHERE PLANT = ? and MAG = ? and ISSUE = ? ";
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, plantId.toUpperCase());
		selectMag.setString(2, magCode.toLowerCase());
		selectMag.setString(3, issueNum);
		
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			issueDate  = rs.getString("COVER_DATE");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Issue Date error " + magCode);
		}finally {
		    if (rs != null) {
		        try {
		            rs.close();
		        } catch (SQLException e) { /* ignored */}
		    }
		    if (selectMag != null) {
		        try {
		        	selectMag.close();
		        } catch (SQLException e) { /* ignored */}
		    }
		}
		return ;
	}
	
    private static Hashtable getSackCnt(int mpalno){
		
		PreparedStatement getSack = null;
		ResultSet rs = null;
		Hashtable numbers = new Hashtable();
		
		String SQL = "SELECT COUNT(MTHR_PAL_NUM) AS SACKCNT, "
			    + "SUM(PKG_WGHT)                 AS SUMWGHT, "
			    + "SUM(COPY_CNT)                 AS SUMCPY,  "  
		    	+ "MIN(PAL_SACK_NUM)             AS MINSACK, "   
				+ "MAX(PAL_SACK_NUM)             AS MAXSACK, "   
				+ "MTHR_PAL_NUM"   
				+ " from " + pkgsum  +  " A " 
				+ "WHERE MAG_KY = ? "                       
				+ "AND INSTNC_CD = ? "                  
				+ "AND PLANT_ID = ? "                 
				+ "AND MAG_CD = ? "                    
				+ "AND ISS_NUM = ? "                   
				+ "AND ISS_WK_NUM = ? "                   
				+ "AND PAL_SACK_IND = 'S' "               
				+ "AND MTHR_PAL_NUM = ? "	                  
				+ "GROUP BY MTHR_PAL_NUM " ;
		
		try {
		getSack = conn.prepareStatement(SQL);
		getSack.setInt(1, magKey);
		getSack.setString(2, instCd.toUpperCase());
		getSack.setString(3, plantId.toUpperCase());
		getSack.setString(4, magCode.toUpperCase());
		getSack.setInt(5, toNum.toNumber(issueNum));
		getSack.setInt(6, toNum.toNumber(issueWeek));
		getSack.setInt(7,mpalno);
						
		rs = getSack.executeQuery();
		
		while (rs.next()){
			int sackctr = (int)rs.getInt("SACKCNT");
			int minctr = (int)rs.getInt("MINSACK");
			int maxctr = (int)rs.getInt("MAXSACK");
			double pkgwght = (double)rs.getDouble("SUMWGHT");
			int cpyctr = (int)rs.getInt("SUMCPY");

			numbers.put("sackcnt",Integer.valueOf(sackctr).toString());
			numbers.put("mincnt",Integer.valueOf(minctr).toString());
			numbers.put("maxcnt",Integer.valueOf(maxctr).toString());
			numbers.put("pkgwght",Double.valueOf(pkgwght));
			numbers.put("cpycnt",Integer.valueOf(cpyctr).toString());

		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("GetSack error " + magCode);
		}finally {
		    if (rs != null) {
		        try {
		            rs.close();
		        } catch (SQLException e) { /* ignored */}
		    }
		    if (getSack != null) {
		        try {
		        	getSack.close();
		        } catch (SQLException e) { /* ignored */}
		    }
		}
		return numbers;
	}

	      
	
	private static void getPlantName(){
		
		PreparedStatement selectPlant = null;
		ResultSet rs = null;
				
		String SQL = "SELECT NAME FROM " + sybplant + " WHERE PLANT_ID = ? ";
		
		try {
		selectPlant = conn.prepareStatement(SQL);
		selectPlant.setString(1, plantId);
		
		rs = selectPlant.executeQuery();
		
		while (rs.next()){
			plantName  = rs.getString("NAME");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Plant name error " + plantId);
		}finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectPlant != null) {
				try {
					selectPlant.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		return ;
	}
	
	private static void magazineKey(){
		
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT MAG_KEY, NAME  FROM " + sybMag + " WHERE MAG_CD = ? ";
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, magCode);
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			magKey  = (int)rs.getInt("MAG_KEY");
			magName = rs.getString("NAME");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Code Select error " + magCode);
		} finally {
				if (rs != null) {
					try {
						rs.close();
					} catch (SQLException e) { /* ignored */}
					}
				if (selectMag != null) {
					try {
						selectMag.close();
					} catch (SQLException e) { /* ignored */}
				}
		}
		return;
	}
	
	public synchronized static void createPDF(String jobId, String processType){
		
		PreparedStatement selectcopyCnt = null;
		boolean IntermediatePalletPlacards = true;
		boolean MotherPallet = false;
		Document ippCardsDoc = new Document(PageSize.LETTER.rotate(),-50,-50,30,0);
		
		int pageNo = 1;
		String savePalletNum = " ";
			
		
		String SQL = "SELECT A.MAG_KY, A.PLANT_ID, A.MAG_CD, A.ISS_NUM, A.ISS_WK_NUM, " 
				   + "A.ROLL_NUM, A.PAL_SACK_NUM, A.MTHR_PAL_NUM, A.PKG_WGHT, A.COPY_CNT, B.STAGE_DESC, "
				   + "C.GEO_CMB_NME, C.XSHEET_BV_NME, C.GEO_CAT_ID, C.GEO_CAT_NME, C.BRACE_ID, C.DROP_OFF_PT"
				   + " from " + pkgsum  +  " A, " 
				   + " (SELECT " +
				      " CASE WHEN COUNT(PAL_SACK_NUM) = 1 THEN " +      
				      " 'FULL PALLET' ELSE 'STAGED PALLET'  END AS STAGE_DESC " +       
				      " ,PAL_SACK_NUM, PAL_SACK_IND " +
				      "FROM " + pkgsum +
					  " WHERE MAG_KY = ? and INSTNC_CD = ? and PLANT_ID = ? and  MAG_CD = ? and ISS_NUM = ? and ISS_WK_NUM = ? AND (PAL_SACK_IND = 'P' OR (PAL_SACK_IND = 'S' AND MTHR_PAL_NUM > 0)) " +
					  " GROUP BY PAL_SACK_IND, PAL_SACK_NUM ) B, "
				   + rollsumTableName  + " C " 
				   + " WHERE A.MAG_KY = ? and A.INSTNC_CD = ? and A.PLANT_ID = ? and  A.MAG_CD = ? and A.ISS_NUM = ? and A.ISS_WK_NUM = ? and A.JOB_ID = ?"
				   + " AND  A.PAL_SACK_NUM = B.PAL_SACK_NUM AND  A.PAL_SACK_IND = B.PAL_SACK_IND AND  A.MAG_KY = C.MAG_KY AND A.INSTNC_CD = C.INSTNC_CD "       
				   + " AND  A.PLANT_ID = C.PLANT_ID AND A.MAG_CD = C.MAG_CD AND A.ISS_NUM = C.ISS_NUM AND  A.ISS_WK_NUM = C.ISS_WK_NUM "
				   + " AND  A.JOB_ID = C.JOB_ID AND  A.ROLL_NUM = C.ROLL_NUM " 
				   + " AND (A.PAL_SACK_IND = 'P' OR (A.PAL_SACK_IND = 'S' AND A.MTHR_PAL_NUM > 0))"
				   + " order by A.MTHR_PAL_NUM, A.ROLL_NUM, A.PAL_SACK_NUM " ;
//				   + " order by A.ROLL_NUM, A.PAL_SACK_NUM " ;
		
		LogWriter.writeLog(" Create PDF InstCd : " + instCd + " SQL " + SQL);
		
		
		try {
				
			Date toDay = new Date(); 
			SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, MMM d, yyyy, HH:mm a "); 
			
			PdfPTable outertable = new PdfPTable(1);
						
			PdfPCell dummyCell = new PdfPCell(new Phrase("",
					FontFactory.getFont(FontFactory.TIMES_ROMAN, 72, Font.BOLD,Color.black)));
			dummyCell.setBorderWidth(0);
			
			
			selectcopyCnt = conn.prepareStatement(SQL);
			selectcopyCnt.setInt(1, magKey);
			selectcopyCnt.setString(2, instCd);
			selectcopyCnt.setString(3, plantId);
			selectcopyCnt.setString(4, magCode);
			selectcopyCnt.setInt(5, toNum.toNumber(issueNum));
			selectcopyCnt.setInt(6, toNum.toNumber(issueWeek));
			selectcopyCnt.setInt(7, magKey);
			selectcopyCnt.setString(8, instCd);
			selectcopyCnt.setString(9, plantId);
			selectcopyCnt.setString(10, magCode);
			selectcopyCnt.setInt(11, toNum.toNumber(issueNum));
			selectcopyCnt.setInt(12, toNum.toNumber(issueWeek));
			selectcopyCnt.setString(13,jobId);
			
			resultset = selectcopyCnt.executeQuery();
			
			
			while (resultset.next()){
				
				IntermediatePalletPlacards = false;
								
				String rollNum = resultset.getString("ROLL_NUM");
				String palletNum = resultset.getString("PAL_SACK_NUM");
				String pkgWght = resultset.getString("PKG_WGHT");	
				String copyCount = resultset.getString("COPY_CNT");
				String stageDesc = resultset.getString("STAGE_DESC");
				String geoComboName = resultset.getString("GEO_CMB_NME");
				String bvName = resultset.getString("XSHEET_BV_NME");
				String geoCatId = resultset.getString("GEO_CAT_ID");
				String geoCatName = resultset.getString("GEO_CAT_NME");
				String braceId = resultset.getString("BRACE_ID");
				String dropOffPt = resultset.getString("DROP_OFF_PT");
				String mpalnum = resultset.getString("MTHR_PAL_NUM");
				int mpn = Integer.valueOf(mpalnum).intValue();
		
			if (mpn > 0) 
			{
				if (mpalnum.compareTo(savePalletNum)== 0)
				{
					MotherPallet = false;
				} else {
					MotherPallet = true;
					savePalletNum = mpalnum;
				}
			}	
				
			if (mpn == 0 || MotherPallet)
			{
				
			PdfPCell labelCell = new PdfPCell(new Phrase(stageDesc.trim(),
					FontFactory.getFont(FontFactory.TIMES_ROMAN, 72, Font.BOLD,Color.black)));
			labelCell.setBorderWidth(0);
			outertable.addCell(labelCell);
			
			for(int i=0;i<2;i++){
				outertable.addCell(dummyCell);}
			
			
			
			if (mpn == 0)
			{
				String cell2Info = "PALLET # " + palletNum;
				PdfPCell labelCell2 = new PdfPCell(new Phrase(cell2Info,
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 72, Font.BOLD,Color.black)));
				labelCell2.setBorderWidth(0);
				outertable.addCell(labelCell2);
			} else {
				
				String cell2Info = "PALLET # " + mpalnum;
				PdfPCell labelCell2 = new PdfPCell(new Phrase(cell2Info,
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 72, Font.BOLD,Color.black)));
				labelCell2.setBorderWidth(0);
				outertable.addCell(labelCell2);
			}
			
			for(int i=0;i<2;i++)outertable.addCell(dummyCell);
			String cell3Info =  "EDITION " + bvName;
			PdfPCell labelCell3 = new PdfPCell(new Phrase(cell3Info,
					FontFactory.getFont(FontFactory.TIMES_ROMAN, 72, Font.BOLD,Color.black)));
			labelCell3.setBorderWidth(0);
			outertable.addCell(labelCell3);
			
			for(int i=0;i<32;i++)outertable.addCell(dummyCell);
			
			String cell4Info = "MAGAZINE  : " + magName + "PUB. DATE : " + issueDate;
			PdfPCell labelCell4 = new PdfPCell(new Phrase(cell4Info,
					FontFactory.getFont(FontFactory.TIMES_ROMAN, 18, Font.BOLD,Color.black)));
			labelCell4.setBorderWidth(0);
			outertable.addCell(labelCell4);
			
			outertable.addCell(dummyCell);
			
			String cell5Info = "PLANT  : " + plantName.trim() ;
			PdfPCell labelCell5 = new PdfPCell(new Phrase(cell5Info,
					FontFactory.getFont(FontFactory.TIMES_ROMAN, 18, Font.BOLD,Color.black)));
			labelCell5.setBorderWidth(0);
			outertable.addCell(labelCell5);
			
			outertable.addCell(dummyCell);
			
			if (mpn == 0)
			{
				String cell6Info = "BRACE  " + braceId + " " + AddSpace.addSpace(" ", 5, ' ')  + " D.O.P. " + dropOffPt +  AddSpace.addSpace(" ", 5, ' ') + "WEIGHT   "+ pkgWght +AddSpace.addSpace(" ", 5, ' ') + " COPIES  " + copyCount;
				PdfPCell labelCell6 = new PdfPCell(new Phrase(cell6Info,
					FontFactory.getFont(FontFactory.TIMES_ROMAN, 18, Font.BOLD,Color.black)));
				labelCell6.setBorderWidth(0);
				outertable.addCell(labelCell6);
			} else {
				
				Hashtable newSackcnt = (Hashtable)getSackCnt(mpn);
 				Double totpkgwght = (Double) newSackcnt.get("pkgwght");
				String totcpycnt = (String) newSackcnt.get("cpycnt");
				
				String cell6Info = "BRACE  " + braceId + " " + AddSpace.addSpace(" ", 5, ' ')  + " D.O.P. " + dropOffPt +  AddSpace.addSpace(" ", 5, ' ') + "WEIGHT   "+ totpkgwght +AddSpace.addSpace(" ", 5, ' ') + " COPIES  " + totcpycnt;
				PdfPCell labelCell6 = new PdfPCell(new Phrase(cell6Info,
					FontFactory.getFont(FontFactory.TIMES_ROMAN, 18, Font.BOLD,Color.black)));
				labelCell6.setBorderWidth(0);
				outertable.addCell(labelCell6);
								
			}
			
			outertable.addCell(dummyCell);
			
			if (mpn > 0)
			{
				String cell7Info = "ROLL  " + AddSpace.addSpace(rollNum,3,'0') + AddSpace.addSpace(" ", 5, ' ')  + " GEO COMBO  " + "MX";
				PdfPCell labelCell7 = new PdfPCell(new Phrase(cell7Info,
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 18, Font.BOLD,Color.black)));
					labelCell7.setBorderWidth(0);
					outertable.addCell(labelCell7);
			} else {
			
				String cell7Info = "ROLL  " + AddSpace.addSpace(rollNum,3,'0') + AddSpace.addSpace(" ", 5, ' ')  + " GEO COMBO  " + geoComboName + AddSpace.addSpace(" ", 9, ' ') + geoCatName + " (" + geoCatId +")";
				PdfPCell labelCell7 = new PdfPCell(new Phrase(cell7Info,
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 18, Font.BOLD,Color.black)));
					labelCell7.setBorderWidth(0);
					outertable.addCell(labelCell7);
			}
						
			outertable.addCell(dummyCell);
			
			String cell8Info = "ISSUE  " + issueNum + " - " + issueWeek ;
			PdfPCell labelCell8 = new PdfPCell(new Phrase(cell8Info,
					FontFactory.getFont(FontFactory.TIMES_ROMAN, 18, Font.BOLD,Color.black)));
			labelCell8.setBorderWidth(0);
			outertable.addCell(labelCell8);
			
			if (mpn > 0)
			{
				outertable.addCell(dummyCell);
				
				Hashtable newSackcnt = (Hashtable)getSackCnt(mpn);
				String sackcnt = (String) newSackcnt.get("sackcnt");
				String minsack = (String) newSackcnt.get("mincnt");
				String maxsack = (String) newSackcnt.get("maxcnt");
				
				String cell9Info = "SACKS  " + sackcnt + "      " + minsack + "  -  " + maxsack;
				PdfPCell labelCell9 = new PdfPCell(new Phrase(cell9Info,
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 18, Font.BOLD,Color.black)));
				labelCell9.setBorderWidth(0);
				outertable.addCell(labelCell9);
			}
			
			String dateline = String.valueOf(dateFormat.format(toDay)) + " Page " + pageNo ;
			PdfPCell header0 = new PdfPCell(new Phrase(dateline,
					FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Font.NORMAL,Color.black)));
			header0.setHorizontalAlignment(Element.ALIGN_RIGHT);
			header0.setBorderWidth(0);
			outertable.addCell(header0);
			pageNo++;
							 
			}
			}
			
			if (IntermediatePalletPlacards){
				LogWriter.writeLog(" No Intermediate Pallet Placards " + processType );
			}else{
				String RptPath = sybil.common.util.PropertyBroker.getProperty("NewPDFReportsPath","Not found");
				
				String fileName = magCode.toLowerCase() + ".i" + issueNum + "." + plantId + ".OMS_Intermediate_Pallet_Placards." + issueWeek + "." + processType ;
				
				PdfWriter writer = PdfWriter.getInstance(ippCardsDoc,new FileOutputStream(RptPath + fileName + ".pdf"));
				
				writer.setViewerPreferences(PdfWriter.PageModeFullScreen);
				
				ippCardsDoc.open();
				
				ippCardsDoc.add(outertable);		
			}
				
		} 
		catch (SQLException se) {
			LogWriter.writeLog(se);
		}
		
		catch (DocumentException de) {
			System.err.println(de.getMessage());
		} catch (IOException ioe) {
			System.err.println(ioe.getMessage());
		}
		finally {
		    if (resultset != null) {
		        try {
		        	resultset.close();
		        } catch (SQLException e) { /* ignored */}
		    }
		    if (selectcopyCnt != null) {
		        try {
		        	selectcopyCnt.close();
		        } catch (SQLException e) { /* ignored */}
		    }
		}
		if (!IntermediatePalletPlacards)
		ippCardsDoc.close();
		return;
	}
	
	public synchronized static void createPlacardsReport(Magazine mag){
		
		PreparedStatement selectJobID = null;
		ResultSet rsJobId = null;

		open();
		
		initialize(mag); 
		
		String SQL = "Select distinct JOB_ID from  " + pkgsum
					+ " WHERE MAG_KY = ? and INSTNC_CD = ? and PLANT_ID = ? and MAG_CD = ? and ISS_NUM = ? and ISS_WK_NUM = ? ";
	
		magazineKey();
		
		getIssueDate();
		
		instCd = InstanceCd.getInstCd(magKey, toNum.toNumber(issueNum),toNum.toNumber(issueWeek));
		
		LogWriter.writeLog(" InstCd : " + instCd + " SQL " + SQL);
		
		getPlantName();

		try {
			selectJobID = conn.prepareStatement(SQL);
			selectJobID.setInt(1, magKey);
			selectJobID.setString(2, instCd);
			selectJobID.setString(3, plantId);
			selectJobID.setString(4, magCode);
			selectJobID.setInt(5, toNum.toNumber(issueNum));
			selectJobID.setInt(6, toNum.toNumber(issueWeek));
			rsJobId = selectJobID.executeQuery();
			
			while (rsJobId.next()) {

			String jobId = rsJobId.getString("JOB_ID");

			if (jobId.endsWith("U")) {
				createPDF(jobId, "USPS");
				LogWriter.writeLog(" USPS Intermediate Pallet Placards Report Generated  ");
			} else if (jobId.endsWith("F")) {
				createPDF(jobId, "FOREIGN");
				LogWriter.writeLog(" Foreign Intermediate Pallet Placards Report Generated  ");
			}
		}
		} 
		catch (SQLException se) {
			LogWriter.writeLog(se);
		} finally {
		    if (rsJobId != null) {
		        try {
		        	rsJobId.close();
		        } catch (SQLException e) { /* ignored */}
		    }
		    if (selectJobID != null) {
		        try {
		        	selectJobID.close();
		        } catch (SQLException e) { /* ignored */}
		    }
		}
		return;
	}
	

}
