package com.pdf.report;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import sybil.common.model.IssueCustomer;
import sybil.common.model.Magazine;
import sybil.common.persistence.ZipFilePersistent;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;
import sybil.common.util.StringFunctions;
import sybil.common.util.SybilIssueCustomerFileParser;
import sybil.common.util.SybilWarningException;


public class CustInfoInterface extends Thread{

	private static Magazine magazine = null;

	private static String destDir = null;
	
	private static ZipFile zf = null;
	private static InputStream zis = null;
	private static BufferedReader bfr = null;
	private static InputStreamReader isr = null;
//	private static InputStreamReader zipisr = null;
	
	public static String magCode = null;
	public static String plantId = null;
	public static String issueNum = null;
	public static String issueWeek = null;
	public static String deliveryType = null;
	public static String processType = null;
	public static String theDeliveryType = null;
	public static String dataType = null;
	
	public static String outputFileName = null;
	public static PrintWriter outputFile = null;
	
	public CustInfoInterface(Magazine mag){

		super();
		magazine = mag;
		magCode = mag.getMagCode().toUpperCase();
		plantId = mag.getPlant().toUpperCase();
		issueNum = mag.getIssue().toUpperCase();
		issueWeek = mag.getWeek().trim();
		deliveryType = mag.getDeliveryType().toUpperCase();
		processType = mag.getProcessType().toUpperCase();
		theDeliveryType = mag.getDeliveryType().toUpperCase();
		dataType = mag.getDataType().toUpperCase();
	}
	
	private synchronized void processCustInfodata() {
		
		File newFile;
		zf = null;
		zis = null;
		bfr = null;
		isr = null;
//		zipisr = null;
		
		File f = null;
		
		String interFaceFilePath = sybil.common.util.PropertyBroker.getProperty("NEW_IFF_PATH","Not found");
		String fileName = interFaceFilePath.concat(magCode.toUpperCase() + "." + issueNum + "." + plantId + ".CustInfo." + issueWeek + ".txt");


	try {
//		
		outputFileName = fileName.trim();
		
		f = new File(outputFileName);

		outputFile = new PrintWriter(new OutputStreamWriter(new FileOutputStream(f),"ASCII"));				

		String s1 = "Plant Code" + '\u0009' + "Magazine Code" + '\u0009' + "Issue Num" + '\u0009' + "Issue Week" + '\u0009' + "Roll Num" + '\u0009' + "Bundle Num" + '\u0009' + "Book Version " + '\u0009' + "Driver Code" + '\u0009' + "NAME" + '\u0009' + "ADDRESS" + '\u0009' + "ADDRESS 1" + '\u0009' + "CITY STATE ZIP" + '\u0009' + "COPY COUNT" +'\u0009' ;

		s1 = s1 + "\n";

		outputFile.print(s1);

//		
		
		destDir = PropertyBroker.getProperty("OLDFILEDIR","not Found");

		newFile = new File((destDir) + magazine.getFileName());
		
		try {
			zf = new ZipFile(newFile);
			java.util.Enumeration e = zf.entries();
		
			while (e.hasMoreElements()) {

				ZipEntry currZE = (ZipEntry) e.nextElement();
				String data = currZE.getName().toLowerCase().trim();
				zis = zf.getInputStream(currZE);
			 		
				if (PropertyBroker.getProperty("MVS", "false").equals("true")) {
					isr = new InputStreamReader(zis, "ASCII");
				}
				else {
					isr = new InputStreamReader(zis);
				}
				
				bfr = new java.io.BufferedReader(isr);
				
				boolean test =true ;
		
				try {
					 test = Float.valueOf(data).isNaN();
				    }
				catch(Exception ex) {
					continue;		  
		  		}

				if (!data.equals("9999")) {
					generateInterfaceFile(bfr);
				 }

				// Close the current entry of the zip file.
				try {
					bfr.close();
					zis.close();
					
				}
				catch (Exception ex) {
					LogWriter.writeLog(ex);
				}	
			} // while
		} // try
		catch (Exception ex) {
			LogWriter.writeLog(new Exception ("Error on zip file <" + newFile + ">"));
			if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
				LogWriter.writeLog("Process terminating due error");
				System.exit(1);
			}
		}
		
		outputFile.close();
		
		ZipFilePersistent zp = new ZipFilePersistent(outputFileName.substring(0,outputFileName.length()-3).concat("zip"));
		zp.addFile(f);
		zp.closeZipfile();
		
	} catch (Exception e1) {

		LogWriter.writeLog(e1);
		// log error and return false indicate failure
	}
	try {
			zf.close();
		}catch(Exception ioe){};

}
	
private static synchronized void generateInterfaceFile(BufferedReader rdr){
		
		
		String aRec = null;
		IssueCustomer rec = new IssueCustomer();	
		String copyCount = null;
		int copyCnt = 0;
		String sData = null;
		
			
			try {
				while (!((aRec = rdr.readLine()) == null)) {

					
					if( aRec.trim().length() == 0)
						continue;
						
					if (aRec.length() < 9) continue;
					SybilIssueCustomerFileParser syb = new SybilIssueCustomerFileParser();
					syb.parseString(aRec, rec);
				
					
					String palletSackIndicator = rec.getMagazineLabel().palletSackIndicator.toUpperCase();
					
					copyCount = rec.getMagazineLabel().SchoolCopyCount;
					copyCnt += Integer.parseInt(copyCount);
					
					if (palletSackIndicator.trim().equals(""))
						continue;
					else{
						
						String rollId = rec.getrollID();
						
						String CustName = new String(StringFunctions.fixSize(rec.getMagazineLabel().customerName.toUpperCase(),30,' ',StringFunctions.LEFT));
						
						String addLine2 = new String(StringFunctions.fixSize(rec.getMagazineLabel().addressLine2.toUpperCase(),30,' ',StringFunctions.LEFT));
						
						String addLine1 = new String(StringFunctions.fixSize(rec.getMagazineLabel().addressLine1.toUpperCase(),30,' ',StringFunctions.LEFT));
						
						String bundleNum = rec.getMagazineLabel().packageNumber;
						
						String driverCode = rec.getMagazineLabel().makeupCode.toUpperCase();
						
						String xSheetBv = rec.getMagazineLabel().editionCode.toUpperCase();
						
						String CityStateZip = rec.getMagazineLabel().city + " " + rec.getMagazineLabel().state + " " + rec.getMagazineLabel().USzipCode + "-" + rec.getMagazineLabel().zipPlus4;
						
						sData = plantId + '\u0009' + magCode + '\u0009' + issueNum + '\u0009' + issueWeek + '\u0009' + rollId + '\u0009' + bundleNum + '\u0009' + xSheetBv + '\u0009' + driverCode + '\u0009' + CustName + '\u0009' + addLine2 + '\u0009' + addLine1 + '\u0009' + CityStateZip + '\u0009' + copyCnt ; 
						
						sData = sData +"\n";
						
						copyCnt = 0;
						
						outputFile.print(sData);
						
					}
					
				}  // End of Read ....
		
			}	
			catch(Exception e){
				SybilWarningException warning = new SybilWarningException(magazine.getPrefix() + ": Error processing Custinfo file ");
				LogWriter.writeLog(warning);
				LogWriter.writeLog(e);
				
			}

	}

public void run() {
	processCustInfodata();
}
	
}
