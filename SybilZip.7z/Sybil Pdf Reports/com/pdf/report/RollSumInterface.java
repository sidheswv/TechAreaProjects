package com.pdf.report;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import sybil.common.model.Magazine;
import sybil.common.persistence.ZipFilePersistent;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;

public class RollSumInterface {
	public static String sybMag = "TBA_SYB_MAGAZINE";

	public static String magazineInf = "TBA_MAGAZINEINF";

	public static String rollSum = "TBA_ROLL_SUM";
	
	public static String intefaceCntl = "TBA_INTER_FILE_CNTL";

	private static Connection rSConn = null;
	
	private static void open() {

		PreparedStatement setSqlId = null;
		Statement commitSqlId = null;
		String x = null;
		String db2owner = null;
		int i = 0;
		
		String userDb = sybil.common.util.PropertyBroker.getProperty("database.login","sybil");
		String pswdDb = sybil.common.util.PropertyBroker.getProperty("database.password","sybil");
		
		
		if( rSConn == null) {
			try {
				Class.forName(sybil.common.util.PropertyBroker.getProperty("database.driver", "Not Found"));
				rSConn = DriverManager.getConnection(sybil.common.util.PropertyBroker.getProperty("database.server", "Not Found"), userDb, pswdDb);

				//
				x = PropertyBroker.getProperty("database.driver", "Not Found").toLowerCase();
				i = x.indexOf("db2");
				if (!(i < 0)) {
					try {
						db2owner = PropertyBroker.getProperty("DB2OWNER","dtppsyup");
						setSqlId = rSConn.prepareStatement("set current sqlid = ?");
						setSqlId.setString(1, db2owner);
						setSqlId.execute();
						commitSqlId = rSConn.createStatement();
						commitSqlId.execute("commit");
					}
					catch (SQLException se) {
						if(se.getSQLState().equals("S1010")) {
						}
						else {
							LogWriter.writeLog(se);
							LogWriter.writeLog("Error: Set Current SqlId failed.");
							if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
								LogWriter.writeLog("Process terminating due to database/sql exception");
								System.exit(1);
							}
						}
					}
					catch (Exception e) {
						LogWriter.writeLog(e);
						LogWriter.writeLog("Error: Set Current SqlId failed.");
						if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
							LogWriter.writeLog("Process terminating due to database/sql exception");
							System.exit(1);
						}
					}
				}
			
			} 
			catch (Exception e) {
				sybil.common.util.LogWriter.writeLog(e);
				LogWriter.writeLog("Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
		
	return;
	}
	
	
	public static void close() {
		
		if( rSConn != null) {		
			try { rSConn.close(); }catch(Exception sql ){};
			rSConn = null;
		}
		return;
	}
	
	private static int magazineKey(String magazineCode){
		
		int magKey = 0;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT MAG_KEY, NAME  FROM " + sybMag + " WHERE MAG_CD = ? ";
		LogWriter.writeLog("select from " + sybMag + "   "  + SQL);
		
		try {
		selectMag = rSConn.prepareStatement(SQL);
		selectMag.setString(1, magazineCode);
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			magKey  = (int)rs.getInt("MAG_KEY");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Code Select error " + magazineCode);
		}
		return magKey;
	}
	
	private static String getIssueDate(Magazine mag){
		
		String issueDate = null;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT COVER_DATE FROM " + magazineInf + " WHERE PLANT = ? and MAG = ? and ISSUE = ? ";
		
		try {
		selectMag = rSConn.prepareStatement(SQL);
		selectMag.setString(1, mag.getPlant().toUpperCase());
		selectMag.setString(2, mag.getMagCode().toLowerCase());
		selectMag.setString(3, mag.getIssue());
		
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			issueDate  = rs.getString("COVER_DATE");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Issue Date error " + mag.getMagCode());
		}
		return issueDate;
	}

public static synchronized void generateInterfaceFile(Magazine mag) {
		
		boolean interFaceFile = false;
		
		String plantCode = mag.getPlant().toUpperCase();
		String magCode = mag.getMagCode().toUpperCase();
		
		interFaceFile = getInterfaceFileStatus("RSM",plantCode,magCode);
		if (interFaceFile){
			generateInterfaceFilezip(mag);
			LogWriter.writeLog(" Roll Sum InterFace file Generated   ");
		}
		else{
			interFaceFile = getInterfaceFileStatus("RSM",plantCode,"XX");
			if (interFaceFile){
				generateInterfaceFilezip(mag);
				LogWriter.writeLog(" Roll Sum InterFace file Generated   ");
			}
		}
		
		interFaceFile = false;
		interFaceFile = getInterfaceFileStatus("RSO",plantCode,magCode);
		if (interFaceFile){
			copyRollsumZip(mag);
			LogWriter.writeLog(" Roll Sum InterFace file Generated   ");
		}
		else{
			interFaceFile = getInterfaceFileStatus("RSO",plantCode,"XX");
			if (interFaceFile){
				copyRollsumZip(mag);
				LogWriter.writeLog(" Roll Sum InterFace file Generated   ");
			}
		}
		return;
	}
	
	private synchronized static boolean getInterfaceFileStatus(String ifCd, String plantCode, String magCode) {
		
		PreparedStatement selectIFC = null;
		ResultSet rsRioIfc = null;
		boolean generateInterfaceFile = false;
		
		open();
		
		String SQL = "Select INTER_FILE_IND, INTER_FILE_DESC FROM  " + intefaceCntl
				+ " WHERE PLANT_ID = ? AND MAG_CD = ? AND INTER_FILE_CD = ? ";
		
		try {
			
			String ifcInd = null;
			selectIFC = rSConn.prepareStatement(SQL);
			selectIFC.setString(1, plantCode);
			selectIFC.setString(2, magCode);
			selectIFC.setString(3, ifCd);
			
			rsRioIfc = selectIFC.executeQuery();
			
			while (rsRioIfc.next()){
				ifcInd = rsRioIfc.getString("INTER_FILE_IND");
				if (ifcInd.equals("Y"))
					generateInterfaceFile = true;
				else
					generateInterfaceFile = false;
			}
			rsRioIfc.close();
		} 
		catch (SQLException se) {
			LogWriter.writeLog(se);
		}
		return generateInterfaceFile;
	}
	
	private synchronized static void copyRollsumZip(Magazine mag){
		
		
		Process p = null;
		
		String magCode = mag.getMagCode().trim();
		String issueNum = mag.getIssue().trim();
		String issueWeek = mag.getWeek().trim();
		String plantId = mag.getPlant().toUpperCase().trim();
		
				
		String fileName1 = magCode.toUpperCase() + "." + issueNum + "." + plantId + ".RollSum." + issueWeek + ".zip";
		String fileName2 = magCode.toLowerCase() + ".i" + issueNum + "." + plantId.toLowerCase() + ".rollsum.strip.reports." + issueWeek + ".zip";
		
		LogWriter.writeLog("File Name is --- " + fileName1);
		
		File copyTo = new File((sybil.common.util.PropertyBroker.getProperty("NEW_IFF_PATH")),fileName1); 
		File copyFrom = new File((sybil.common.util.PropertyBroker.getProperty("ProcessInputFileDir1")),fileName2);
		//File copyFrom1 = new File((sybil.common.util.PropertyBroker.getProperty("PlantReportFileDestination")),fileName2);
		
		if (copyTo.exists())
			copyTo.delete();
		
		try
		{
			if( p != null) {
				p.waitFor();
			}
			String xyz= " cp -p "  + copyFrom.getAbsolutePath() + " " + copyTo.getAbsolutePath();
			String [] cmd = {"sh","-c",xyz};
			p = java.lang.Runtime.getRuntime().exec(cmd);
			p.waitFor();
			int i = p.exitValue();
			if (i != 0) {
				LogWriter.writeLog("FileMover.fileCp ... Error: rc = " + i + " on <" + xyz + ">");
			}
		}
		catch (Exception e) {
				LogWriter.writeLog("Interface file copy ... Copy file exception: <" + copyFrom.getAbsolutePath() +
					"> to <" + copyTo.getAbsolutePath() + ">");
				LogWriter.writeLog(e);
		}
		
	}

	private synchronized static void generateInterfaceFilezip(Magazine mag) {
		
		PreparedStatement rollSumPS = null;
		ResultSet resultset = null;
				
		String magCode = mag.getMagCode().trim();
		String issueNum = mag.getIssue().trim();
		String issueWeek = mag.getWeek().trim();
		String plantId = mag.getPlant().toUpperCase().trim();
		
		String interFaceFilePath = sybil.common.util.PropertyBroker.getProperty("NEW_IFF_PATH","Not found");
		String fileName = interFaceFilePath.concat(magCode.toUpperCase() + "." + issueNum + "." + plantId + ".RollSum." + issueWeek + ".txt");
		
		LogWriter.writeLog("File Name is --- " + fileName);
		
		open();
		
		String rollSumInterfaceSql = " SELECT PLANT_ID, MAG_CD, ISS_NUM as ISSUE_NUM, ISS_WK_NUM as WEEK, JOB_ID, PAL_SACK_IND AS CNTNR_TYPE, ROLL_NUM as ROLLID, "
			+ " GEO_CMB_NME as GEOBV, BIND_GRP_MTH AS SELBIND, XSHEET_BV_NME as XSHEETBV, CARR_NME as CARRIER_DESC, BRACE_NME as DISPATCH_DESC, DEPART_DT as LEAVE_DT, DEPART_TIME as LEAVE_TIME, ARRVL_DT as ARRIVE_DT, ARRVL_TIME as ARRIVE_TIME, "
			+ " CNSOL_SUB_TYP as CUSTSUBTYPE, GEO_CAT_ID AS MARKET_ID, GEO_CAT_NME as MARKET_DESC, BRACE_ID as BRACE, DROP_OFF_PT as DOP, COPY_CNT as COPY_COUNT, LABEL_MTH, BIND_GRP_NME as BIND_GRP,  "
			+ " STAGED_TYP as STAGE_TYPE, STG_BNDGRP_NME as STAGE_BIND_GRP, GEO_CMB_NME_NEW as NEW_GEO_BV, VERSION_NUM as VERSION_ID, SCENARIO_KY as SCENARIO_ID "
			+ " FROM " + rollSum
			+ " WHERE  MAG_KY = ? AND INSTNC_CD = ? AND MAG_CD = ? AND PLANT_ID = ? AND ISS_NUM = ? AND ISS_WK_NUM = ? AND PAL_SACK_IND != ' '  "
			+ " ORDER BY PAL_SACK_IND, ROLL_NUM ";
		            
		int magKey = magazineKey(magCode);
		
		String issueDate = getIssueDate(mag);
		
		String instCd = InstanceCd.getInstCd(magKey, issueDate);
			
		String s = null;
		PrintWriter outputFile = null;
		File f = null;
		
		try {

			rollSumPS = rSConn.prepareStatement(rollSumInterfaceSql);
			rollSumPS.setInt(1, magKey);
			rollSumPS.setString(2, instCd);
			rollSumPS.setString(3, magCode);
			rollSumPS.setString(4, plantId);
			rollSumPS.setInt(5, toNum.toNumber(issueNum));
			rollSumPS.setInt(6, toNum.toNumber(issueWeek));
						
			resultset = rollSumPS.executeQuery();
				
			ResultSetMetaData rsmd = resultset.getMetaData();
			int colcount = rsmd.getColumnCount();

			String outputFileName = fileName.trim();
			
			f = new File(outputFileName);

			outputFile = new PrintWriter(new OutputStreamWriter(new FileOutputStream(f),"ASCII"));				

			String s1 = rsmd.getColumnName(1) + '\u0009';

			for(int colnames=2; colnames<=colcount; colnames++){
				s1 = s1 + rsmd.getColumnName(colnames) + '\u0009';
			}

			s1 = s1 + "\n";

			outputFile.print(s1);
				
			while (resultset.next()) {
				
				s = resultset.getString(1) + '\u0009';
					int i=2;
					for(; i<colcount; i++){
						s = s + resultset.getObject(i) + '\u0009';
					}
				s = s + resultset.getObject(i) ;
				s = s +"\n";
				outputFile.print(s);
			}
			resultset.close();
			rollSumPS.close();
			outputFile.close();

		ZipFilePersistent zp = new ZipFilePersistent(outputFileName.substring(0,outputFileName.length()-3).concat("zip"));
		zp.addFile(f);
		zp.closeZipfile();
		close();
			
		}
		catch (SQLException se) {
			se.printStackTrace();
			LogWriter.writeLog(se);
		}
		catch (Exception e) {
			e.printStackTrace();		
			LogWriter.writeLog(e);
		}finally{
			if(f.exists())
			f.delete();
		}
	}
}
