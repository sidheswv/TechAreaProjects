package com.pdf.report;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;


import sybil.common.model.Magazine;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;

import com.report.text.Document;
import com.report.text.DocumentException;
import com.report.text.Element;
import com.report.text.ExceptionConverter;
import com.report.text.Font;
import com.report.text.FontFactory;
import com.report.text.PageSize;
import com.report.text.Phrase;
import com.report.text.Rectangle;
import com.report.text.pdf.BaseFont;
import com.report.text.pdf.PdfContentByte;
import com.report.text.pdf.PdfPCell;
import com.report.text.pdf.PdfPTable;
import com.report.text.pdf.PdfPageEventHelper;
import com.report.text.pdf.PdfTemplate;
import com.report.text.pdf.PdfWriter;

public class ScheduledBind extends PdfPageEventHelper {	
	
	public static String pkgsum = "TBA_PKG_SUM";
	
	public static String cntnrInfo = "TBA_CNTNR_INFO";

	public static String rollsum = "TBA_ROLL_SUM";

	public static String magazineInf = "TBA_MAGAZINEINF";

	public static String sybMag = "TBA_SYB_MAGAZINE";

	public static String sybplant = "TBA_SYB_PLANT";

	public static String cnsolParm = "TBA_CNSOL_STYP_PARM";

	public static String pstlParm = "TBA_PSTL_PARM";
	
	public static String cntnrLvlParm = "TBA_CNTNR_LVL_PARM";

	private static Connection conn = null;
	
	private static int magKey = 0;
	
	private static String instCd = null;

	private static ResultSet resultset = null;

	private static String magName = null;
		
	private static final Font  TIMESNORAML_12 = FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.NORMAL,Color.black);
	
	private static final Font  TIMESBOLD_12 = FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,Color.black);
	
	private static final Font  TIMESBOLD_10 = FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Font.BOLD, Color.black);
	
	private static final Font  COURIERNORMAL_10 = FontFactory.getFont(FontFactory.COURIER, 12, Font.NORMAL,Color.black);
	
	private static String magCode = null;
	
	private static String issueNum = null;
	
	private static String plantId = null;
	
	private static String issueWeek = null;
	
	private static String issueDate = null;
	
	private static String plantName = null;
	
	protected PdfTemplate total;

	protected BaseFont helv;
	
	public void onOpenDocument(PdfWriter writer, Document document) {
		total = writer.getDirectContent().createTemplate(100, 100);
		total.setBoundingBox(new Rectangle(-10, -10, 80, 80));
		try {
			helv = BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI,BaseFont.NOT_EMBEDDED);
		} catch (Exception e) {
			throw new ExceptionConverter(e);
		}
	}
	
	public void onEndPage(PdfWriter writer, Document document) {
		PdfContentByte cb = writer.getDirectContent();
		cb.saveState();
		String text = "Page " + writer.getPageNumber() ;
		float textBase = document.top() - 20;
		cb.beginText();
		cb.setFontAndSize(helv, 10);
		
		cb.setTextMatrix(document.left()+ 780, textBase);
		cb.showText(text);
		cb.endText();
		
		cb.restoreState();
	}
	
	public void onCloseDocument(PdfWriter writer, Document document) {
		total.beginText();
		total.setFontAndSize(helv, 12);
		total.setTextMatrix(0, 0);
		total.showText(String.valueOf(writer.getPageNumber() - 1));
		total.endText();
	}
	
	private static void initialize(Magazine mag){
		magCode = mag.getMagCode().trim();
		issueNum = mag.getIssue().trim();
		plantId = mag.getPlant().toUpperCase().trim();
		issueWeek = mag.getWeek().trim();		
	}
	
	private static void open() {

		PreparedStatement setSqlId = null;
		Statement commitSqlId = null;
		String x = null;
		String db2owner = null;
		int i = 0;

		String userDb = sybil.common.util.PropertyBroker.getProperty(
				"database.login", "sybil");
		String pswdDb = sybil.common.util.PropertyBroker.getProperty(
				"database.password", "sybil");

		if (conn == null) {
			try {
				Class.forName(sybil.common.util.PropertyBroker.getProperty(
						"database.driver", "Not Found"));
				conn = DriverManager
						.getConnection(sybil.common.util.PropertyBroker
								.getProperty("database.server", "Not Found"),
								userDb, pswdDb);

				//
				x = PropertyBroker.getProperty("database.driver", "Not Found")
						.toLowerCase();
				i = x.indexOf("db2");
				if (!(i < 0)) {
					try {
						db2owner = PropertyBroker.getProperty("DB2OWNER",
								"dtppsyup");
						setSqlId = conn
								.prepareStatement("set current sqlid = ?");
						conn.setAutoCommit(false);						
						setSqlId.setString(1, db2owner);
						setSqlId.execute();
						commitSqlId = conn.createStatement();
						commitSqlId.execute("commit");
					} catch (SQLException se) {
						if (se.getSQLState().equals("S1010")) {
						} else {
							LogWriter.writeLog(se);
							LogWriter
									.writeLog("Error: Set Current SqlId failed.");
							if (PropertyBroker.getProperty(
									"AllowDatabaseErrors", "false").equals(
									"false")) {
								LogWriter
										.writeLog("Process terminating due to database/sql exception");
								System.exit(1);
							}
						}
					} catch (Exception e) {
						LogWriter.writeLog(e);
						LogWriter.writeLog("Error: Set Current SqlId failed.");
						if (PropertyBroker.getProperty("AllowDatabaseErrors",
								"false").equals("false")) {
							LogWriter
									.writeLog("Process terminating due to database/sql exception");
							System.exit(1);
						}
					}
				}

			} catch (Exception e) {
				sybil.common.util.LogWriter.writeLog(e);
				LogWriter
						.writeLog("Process terminating due to database/sql exception");
				System.exit(1);
			}
		}

		return;
	}
		

		private static void getIssueDate() {

		PreparedStatement selectMag = null;
		ResultSet rs = null;

		String SQL = "SELECT COVER_DATE FROM " + magazineInf
				+ " WHERE PLANT = ? and MAG = ? and ISSUE = ? ";

		try {
			
			selectMag = conn.prepareStatement(SQL);
			selectMag.setString(1, plantId.toUpperCase());
			selectMag.setString(2, magCode.toLowerCase());
			selectMag.setString(3, issueNum);

			rs = selectMag.executeQuery();

			while (rs.next()) {
				issueDate = rs.getString("COVER_DATE");
			}
		} catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Issue Date error " + magCode);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectMag != null) {
				try {
					selectMag.close();
				} catch (SQLException e) { /* ignored */}
			}
		}		
		return ;
	}

		private static void getPlantName() {

		PreparedStatement selectPlant = null;
		ResultSet rs = null;

		String SQL = "SELECT NAME FROM " + sybplant + " WHERE PLANT_ID = ? ";

		try {
			selectPlant = conn.prepareStatement(SQL);
			selectPlant.setString(1, plantId);

			rs = selectPlant.executeQuery();

			while (rs.next()) {
				plantName = rs.getString("NAME");
			}
		} catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Plant name error " + plantId);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectPlant != null) {
				try {
					selectPlant.close();
				} catch (SQLException e) { /* ignored */}
			}
		}		
		return;
	}
		
		private static void magazineKey() {


		PreparedStatement selectMag = null;
		ResultSet rs = null;

		String SQL = "SELECT MAG_KEY, NAME  FROM " + sybMag
				+ " WHERE MAG_CD = ? ";

		try {
			selectMag = conn.prepareStatement(SQL);
			selectMag.setString(1, magCode);
			rs = selectMag.executeQuery();

			while (rs.next()) {
				magKey = (int) rs.getInt("MAG_KEY");
				magName = rs.getString("NAME");
			}
		} catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Code Select error " + magCode);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectMag != null) {
				try {
					selectMag.close();
				} catch (SQLException e) { /* ignored */}
			}
		}	
		return ;
	}
		
		
		private static PdfPCell totBindGrphdr() {
			PdfPCell totBindGrpCell1 = null;
			try {
				int[] totBindGrpw = { 9, 9, 9, 5, 6, 6, 6 };
				PdfPTable totBindGrpable1 = new PdfPTable(7);
				totBindGrpable1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				totBindGrpable1.getDefaultCell().setBorder(Rectangle.NO_BORDER | Rectangle.BOTTOM);
				totBindGrpable1.getDefaultCell().setBorderWidthBottom(1);
				totBindGrpable1.getDefaultCell().setPaddingBottom(5);
				totBindGrpable1.setWidths(totBindGrpw);
				totBindGrpable1.addCell(new Phrase("Bind Group Totals", TIMESBOLD_10));
				totBindGrpable1.addCell(new Phrase("Copies", TIMESBOLD_10));
				totBindGrpable1.addCell(new Phrase("Packages", TIMESBOLD_10));					
				totBindGrpable1.addCell(new Phrase("Sacks", TIMESBOLD_10));
				totBindGrpable1.addCell(new Phrase("Airbox", TIMESBOLD_10));
				totBindGrpable1.addCell(new Phrase(" Staged Pallets", TIMESBOLD_10));					
				totBindGrpable1.addCell(new Phrase(" Non Staged Pallets", TIMESBOLD_10));					
						
				totBindGrpCell1 = new PdfPCell(totBindGrpable1);
				totBindGrpCell1.setHorizontalAlignment(Element.ALIGN_CENTER);
				totBindGrpCell1.setBorderWidth(0);

			} catch (Exception e) {
				System.err.println(e.getMessage());
			}
			return totBindGrpCell1;
		}
			
			private static PdfPCell totBracehdr() {
			PdfPCell totBraceCell1 = null;
			try {
				int[] totBracew = { 9, 9, 9, 5, 6, 6, 6 };
				PdfPTable totBraceable1 = new PdfPTable(7);
				totBraceable1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				totBraceable1.getDefaultCell().setBorder(Rectangle.NO_BORDER | Rectangle.BOTTOM);
				totBraceable1.getDefaultCell().setBorderWidthBottom(1);
				totBraceable1.getDefaultCell().setPaddingBottom(5);
				totBraceable1.setWidths(totBracew);
				totBraceable1.addCell(new Phrase("Brace Totals", TIMESBOLD_10));
				totBraceable1.addCell(new Phrase("Copies", TIMESBOLD_10));
				totBraceable1.addCell(new Phrase("Packages", TIMESBOLD_10));					
				totBraceable1.addCell(new Phrase("Sacks", TIMESBOLD_10));					
				totBraceable1.addCell(new Phrase("Airbox", TIMESBOLD_10));
				totBraceable1.addCell(new Phrase(" Staged Pallets", TIMESBOLD_10));					
				totBraceable1.addCell(new Phrase(" Non Staged Pallets", TIMESBOLD_10));
				
				totBraceCell1 = new PdfPCell(totBraceable1);
				totBraceCell1.setHorizontalAlignment(Element.ALIGN_CENTER);
				totBraceCell1.setBorderWidth(0);

			} catch (Exception e) {
				System.err.println(e.getMessage());
			}
			return totBraceCell1;
		}

			private static PdfPCell rptTothdr() {
				PdfPCell rptTotCell1 = null;
				try {
					int[] rptTotw = { 9, 9, 9, 5, 6, 6, 6 };
					PdfPTable rptTotable1 = new PdfPTable(7);
					rptTotable1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
					rptTotable1.getDefaultCell().setBorder(Rectangle.NO_BORDER | Rectangle.BOTTOM);
					rptTotable1.getDefaultCell().setBorderWidthBottom(1);
					rptTotable1.getDefaultCell().setPaddingBottom(5);
					rptTotable1.setWidths(rptTotw);
					rptTotable1.addCell(new Phrase("Plant Totals", TIMESBOLD_10));
					rptTotable1.addCell(new Phrase("Copies", TIMESBOLD_10));
					rptTotable1.addCell(new Phrase("Packages", TIMESBOLD_10));					
					rptTotable1.addCell(new Phrase("Sacks", TIMESBOLD_10));					
					rptTotable1.addCell(new Phrase("Airbox", TIMESBOLD_10));
					rptTotable1.addCell(new Phrase(" Staged Pallets", TIMESBOLD_10));					
					rptTotable1.addCell(new Phrase(" Non Staged Pallets", TIMESBOLD_10));
					
					rptTotCell1 = new PdfPCell(rptTotable1);
					rptTotCell1.setHorizontalAlignment(Element.ALIGN_CENTER);
					rptTotCell1.setBorderWidth(0);

				} catch (Exception e) {
					System.err.println(e.getMessage());
				}
				return rptTotCell1;
			}

		
		private synchronized static void createPDF(String jobId, String rptType){
	
		PreparedStatement selectcopyCnt = null;
		PdfPTable outertable = null;
		Document sbDoc = new Document(PageSize.LETTER.rotate(), -80, -80, 0, 0);
		
		boolean BindRpt = false;

		String saveBraceId = " ";
		
		String saveBindGrpName = " ";
		
		int bindPlabelCount = 0, bindSlabelCount = 0, bindAlabelCount = 0, bindPPkg = 0, bindSPkg = 0, bindAPkg = 0, bindGrpSack = 0, bindGrpAirbox = 0, bindGrpstaged = 0, bindGrpNonStaged = 0;
		int bracePlabelCount = 0, braceSlabelCount = 0, braceAlabelCount = 0, bracePPkg = 0, braceSPkg = 0, braceAPkg = 0, braceGrpSack = 0, braceGrpAirbox = 0, braceGrpstaged = 0, braceGrpNonStaged = 0;
		int plantTotPlabelCount = 0, plantTotSlabelCount = 0, plantTotAlabelCount = 0, plantTotPPkg = 0, plantTotSPkg = 0, plantTotAPkg = 0, plantTotGrpSack = 0, plantTotGrpAirbox = 0, plantTotGrpstaged = 0, plantTotGrpNonStaged = 0;
		
		String bvVersion = null;
		int [] tableh5w = {4,3,8,9,5,5,3,3,4,4,4,9};

		
		int pageLine = 0;
		boolean firstPage = true;

		
			
		String RptPath = sybil.common.util.PropertyBroker.getProperty("NewPDFReportsPath","Not found");
		String fileName = magCode.toLowerCase() + ".i" + issueNum + "." + plantId + ".OMS_Scheduled_Bind." + issueWeek + "." + rptType ;
		
		String deliveryType = rptType.trim() + " Delivery"; 
				
			open();
			
			String SQL =  " SELECT GSV.MAG_KY, GSV.PLANT_ID, GSV.MAG_CD, GSV.ISS_NUM, GSV.ISS_WK_NUM, GSV.ROLL_NUM,  "
						+ " GSV.PACKAGE_COUNT, GSV.LABEL_COUNT, GSV.NON_STAGED, GSV.STAGED, GSV.L_ZIP, GSV.H_ZIP, "
						+ " GSV.SACK, GSV.AIRBOXES, RLS.BRACE_ID, RLS.BIND_GRP_NME, RLS.BRACE_NME, RLS.CARR_NME, RLS.DEPART_DT, RLS.DEPART_TIME, "
						+ " RLS.GEO_CAT_ID, RLS.XSHEET_BV_NME, RLS.STAGED_TYP, RLS.STG_BNDGRP_NME, ROLL.GEO_NAME, MSV.TOT_STAGE  "
						+ " FROM ( "
							+ " SELECT A.MAG_KY, A.INSTNC_CD, A.PLANT_ID, A.MAG_CD, A.ISS_NUM, A.ISS_WK_NUM, A.ROLL_NUM, "
							+ " A.JOB_ID, MIN(A.LOW_ZIP)  AS L_ZIP, MAX(A.HIGH_ZIP) AS H_ZIP, SUM(D.NUM_OF_SACK) AS SACK, "
							+ "	SUM(D.NUM_OF_AIRBOXES) AS AIRBOXES,"
							+ " SUM(A.NUM_PKG)  AS PACKAGE_COUNT, SUM(A.COPY_CNT) AS LABEL_COUNT, SUM(C.NON_STAGE_PALLET) AS NON_STAGED, "
							+ " SUM(C.STAGE_PALLET)  AS STAGED "
							+ " FROM " +  pkgsum + "   A , "
								+ " (SELECT  MAG_KY, INSTNC_CD, PLANT_ID, MAG_CD, ISS_NUM, ISS_WK_NUM, JOB_ID, "
								+ " CASE WHEN PAL_SACK_IND = 'P' THEN  CASE WHEN COUNT(PAL_SACK_NUM) = 1 THEN 1 ELSE 0 END ELSE 0  END AS NON_STAGE_PALLET, "
								+ " CASE WHEN PAL_SACK_IND = 'P' THEN  CASE WHEN COUNT(PAL_SACK_NUM) = 1 THEN 0 ELSE 1 END ELSE 0  END AS STAGE_PALLET, "
								+ " PAL_SACK_NUM, PAL_SACK_IND "
								+ " FROM " +  pkgsum
								+ " WHERE MAG_KY  = ? AND INSTNC_CD  = ? AND PLANT_ID = ? AND MAG_CD = ? AND ISS_NUM  =  ? AND ISS_WK_NUM = ? "
								+ " GROUP BY  MAG_KY, INSTNC_CD, PLANT_ID, MAG_CD, ISS_NUM, ISS_WK_NUM, JOB_ID, PAL_SACK_IND, PAL_SACK_NUM )  C, "
								+ " (SELECT  MAG_KY, INSTNC_CD, PLANT_ID, MAG_CD, ISS_NUM, ISS_WK_NUM, JOB_ID, " 
								+ " CASE WHEN PAL_SACK_IND = 'S' THEN  COUNT (PAL_SACK_IND) ELSE 0 END NUM_OF_SACK, "
								+ " CASE WHEN PAL_SACK_IND = 'A'  THEN  COUNT (PAL_SACK_IND) ELSE 0 END NUM_OF_AIRBOXES, "
								+ " PAL_SACK_NUM, PAL_SACK_IND, ROLL_NUM "
								+ " FROM " +  pkgsum
								+ " WHERE MAG_KY  = ? AND INSTNC_CD  = ? AND PLANT_ID = ? AND MAG_CD = ? AND ISS_NUM  =  ? AND ISS_WK_NUM = ? "
								+ " GROUP BY  MAG_KY, INSTNC_CD, PLANT_ID, MAG_CD, ISS_NUM, ISS_WK_NUM, JOB_ID, PAL_SACK_IND, PAL_SACK_NUM, ROLL_NUM )  D "
							+ " WHERE A.MAG_KY  =  ? AND A.INSTNC_CD = ? AND A.PLANT_ID  = ? AND A.MAG_CD  = ? AND A.ISS_NUM  = ?  AND A.ISS_WK_NUM   = ? "
							+ " AND A.MAG_KY  = C.MAG_KY AND A.INSTNC_CD = C.INSTNC_CD AND A.PLANT_ID  = C.PLANT_ID AND A.MAG_CD  = C.MAG_CD AND A.ISS_NUM  = C.ISS_NUM "
							+ " AND A.ISS_WK_NUM  = C.ISS_WK_NUM AND A.JOB_ID  = C.JOB_ID AND A.PAL_SACK_IND = C.PAL_SACK_IND "
							+ " AND A.PAL_SACK_NUM = C.PAL_SACK_NUM "
							+ " AND A.MAG_KY  = D.MAG_KY AND A.INSTNC_CD = D.INSTNC_CD AND A.PLANT_ID  = D.PLANT_ID AND A.MAG_CD  = D.MAG_CD AND A.ISS_NUM  = D.ISS_NUM "
							+ " AND A.ISS_WK_NUM  = D.ISS_WK_NUM AND A.JOB_ID  = D.JOB_ID AND A.PAL_SACK_IND = D.PAL_SACK_IND "
							+ " AND A.PAL_SACK_NUM = D.PAL_SACK_NUM AND A.ROLL_NUM = D.ROLL_NUM "
							+ " GROUP BY A.MAG_KY, A.INSTNC_CD, A.PLANT_ID, A.MAG_CD, A.ISS_NUM, A.ISS_WK_NUM, A.ROLL_NUM, A.JOB_ID ) GSV, "
							+ " (SELECT  MAG_KY, INSTNC_CD, PLANT_ID, MAG_CD, ISS_NUM, ISS_WK_NUM, JOB_ID, ROLL_NUM, PAL_SACK_IND, "
							+ "  BRACE_ID, CASE WHEN GEO_CMB_NME_NEW = ' ' THEN  GEO_CMB_NME  ELSE GEO_CMB_NME_NEW  END AS GEO_NAME "
							+ " FROM " + rollsum
							+ " WHERE MAG_KY  = ? AND INSTNC_CD = ? AND PLANT_ID = ? AND MAG_CD = ? AND ISS_NUM  =  ?  AND ISS_WK_NUM = ? )  ROLL, "
							+ " (SELECT GSM.BRACE_ID, SUM(CASE WHEN GSM.TOT_STAGE  > 1 THEN 1 ELSE 0 END) AS TOT_STAGE "
							+ " FROM  ( " 
							+ " SELECT z.MAG_KY, Z.INSTNC_CD, z.PLANT_ID, z.MAG_CD, z.ISS_NUM, z.ISS_WK_NUM, z.JOB_ID, "
							+ " z.PAL_SACK_NUM, y.BRACE_ID, CASE WHEN z.PAL_SACK_IND = 'P' THEN COUNT(z.PAL_SACK_NUM) ELSE 0 END AS TOT_STAGE "
							+ " FROM " + pkgsum + " z, " + rollsum + " y "
							+ " WHERE Z.MAG_KY  = ? AND Z.INSTNC_CD = ? AND Z.PLANT_ID = ? AND Z.MAG_CD  = ? AND Z.ISS_NUM  =  ? AND Z.ISS_WK_NUM = ? " 
							+ " AND Z.MAG_KY = Y.MAG_KY AND Z.INSTNC_CD  = Y.INSTNC_CD AND Z.PLANT_ID = Y.PLANT_ID AND Z.MAG_CD = Y.MAG_CD AND Z.ISS_NUM  = Y.ISS_NUM "
							+ " AND Z.ISS_WK_NUM = Y.ISS_WK_NUM  AND Z.ROLL_NUM   = Y.ROLL_NUM "
							+ " GROUP BY Z.MAG_KY, Z.INSTNC_CD, Z.PLANT_ID, Z.MAG_CD, Z.ISS_NUM, Z.ISS_WK_NUM, Z.JOB_ID, Z.PAL_SACK_NUM, Z.PAL_SACK_IND, Y.BRACE_ID ) GSM "
							+ " GROUP BY GSM.BRACE_ID  ) MSV, "
						+ rollsum  +  " RLS "
						+ " WHERE RLS.MAG_KY  =  ? AND RLS.INSTNC_CD = ? AND RLS.PLANT_ID  = ? AND RLS.MAG_CD = ? AND RLS.ISS_NUM = ? AND RLS.ISS_WK_NUM  = ? "
						+ " AND RLS.JOB_ID = ?  AND RLS.MAG_KY  = GSV.MAG_KY AND RLS.INSTNC_CD  = GSV.INSTNC_CD AND RLS.PLANT_ID  = GSV.PLANT_ID AND RLS.MAG_CD  = GSV.MAG_CD "
						+ " AND RLS.ISS_NUM  = GSV.ISS_NUM AND RLS.ISS_WK_NUM  = GSV.ISS_WK_NUM AND RLS.ROLL_NUM  = GSV.ROLL_NUM "
						+ " AND RLS.JOB_ID  = GSV.JOB_ID AND RLS.MAG_KY  = ROLL.MAG_KY AND RLS.INSTNC_CD  = ROLL.INSTNC_CD AND RLS.PLANT_ID = ROLL.PLANT_ID "
						+ " AND RLS.MAG_CD  = ROLL.MAG_CD AND RLS.ISS_NUM = ROLL.ISS_NUM AND RLS.ISS_WK_NUM = ROLL.ISS_WK_NUM "
						+ " AND RLS.JOB_ID = ROLL.JOB_ID AND RLS.PAL_SACK_IND = ROLL.PAL_SACK_IND AND RLS.ROLL_NUM  = ROLL.ROLL_NUM "
						+ " AND RLS.BRACE_ID = MSV.BRACE_ID  ORDER BY RLS.BRACE_ID, GSV.ROLL_NUM " ;
						               
			// AND Z.JOB_ID = Y.JOB_ID
			//LogWriter.writeLog("select from  Plant Pallet :::  "  + SQL);			
		
		try {
		
			PdfWriter writer = PdfWriter.getInstance(sbDoc,new FileOutputStream(RptPath + fileName + ".pdf"));
			
			writer.setViewerPreferences(PdfWriter.PageModeFullScreen);
			writer.setPageEvent(new PlantPallet());

			
			PdfPCell dummyCell = new PdfPCell(new Phrase("",
					FontFactory.getFont(FontFactory.TIMES_ROMAN, 72, Font.BOLD,Color.black)));
			dummyCell.setBorderWidth(0);
						
			sbDoc.open();
			
			Date toDay = new Date(); 
			SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, MMM d, yyyy, HH:mm a "); 
			
			selectcopyCnt = conn.prepareStatement(SQL);
			selectcopyCnt.setInt(1, magKey);
			selectcopyCnt.setString(2, instCd);
			selectcopyCnt.setString(3, plantId);
			selectcopyCnt.setString(4, magCode);
			selectcopyCnt.setInt(5, toNum.toNumber(issueNum));
			selectcopyCnt.setInt(6, toNum.toNumber(issueWeek));
			selectcopyCnt.setInt(7, magKey);
			selectcopyCnt.setString(8, instCd);
			selectcopyCnt.setString(9, plantId);
			selectcopyCnt.setString(10, magCode);
			selectcopyCnt.setInt(11, toNum.toNumber(issueNum));
			selectcopyCnt.setInt(12, toNum.toNumber(issueWeek));
			selectcopyCnt.setInt(13, magKey);
			selectcopyCnt.setString(14, instCd);
			selectcopyCnt.setString(15, plantId);
			selectcopyCnt.setString(16, magCode);
			selectcopyCnt.setInt(17, toNum.toNumber(issueNum));
			selectcopyCnt.setInt(18, toNum.toNumber(issueWeek));
			selectcopyCnt.setInt(19, magKey);
			selectcopyCnt.setString(20, instCd);
			selectcopyCnt.setString(21, plantId);
			selectcopyCnt.setString(22, magCode);
			selectcopyCnt.setInt(23, toNum.toNumber(issueNum));
			selectcopyCnt.setInt(24, toNum.toNumber(issueWeek));
			selectcopyCnt.setInt(25, magKey);
			selectcopyCnt.setString(26, instCd);
			selectcopyCnt.setString(27, plantId);
			selectcopyCnt.setString(28, magCode);
			selectcopyCnt.setInt(29, toNum.toNumber(issueNum));
			selectcopyCnt.setInt(30, toNum.toNumber(issueWeek));
			selectcopyCnt.setInt(31, magKey);
			selectcopyCnt.setString(32, instCd);
			selectcopyCnt.setString(33, plantId);
			selectcopyCnt.setString(34, magCode);
			selectcopyCnt.setInt(35, toNum.toNumber(issueNum));
			selectcopyCnt.setInt(36, toNum.toNumber(issueWeek));
			selectcopyCnt.setString(37,jobId);
			
			resultset = selectcopyCnt.executeQuery();
			
			while (resultset.next()){	
	
				BindRpt = true;
				String rollNum = resultset.getString("ROLL_NUM");
				String numPkg = resultset.getString("PACKAGE_COUNT");
				String copyCount = resultset.getString("LABEL_COUNT");
				String nonStaged = resultset.getString("NON_STAGED");
				String staged = resultset.getString("STAGED");
				String lowZip = resultset.getString("L_ZIP");
				String highZip = resultset.getString("H_ZIP");
				String sackCount = resultset.getString("SACK");
				String airboxCount = resultset.getString("AIRBOXES");
				String braceId = resultset.getString("BRACE_ID");
				String bindGrpName = resultset.getString("BIND_GRP_NME").trim();
				String braceName = resultset.getString("BRACE_NME").trim();
				String carrName = resultset.getString("CARR_NME").trim();
				String departDate = resultset.getString("DEPART_DT") + " " + resultset.getString("DEPART_TIME");
				String geoCatId = resultset.getString("GEO_CAT_ID").trim();
				String bvName = resultset.getString("XSHEET_BV_NME");
				String stagedType = resultset.getString("STAGED_TYP");
				String stageBindGroupName = resultset.getString("STG_BNDGRP_NME").trim();
				String GeoComboName = resultset.getString("GEO_NAME").trim();	
				int totStagedPallet = Integer.valueOf(resultset.getString("TOT_STAGE")).intValue();
				
				String zipLtoH = lowZip.trim() + " - " + highZip.trim();
								
				if (geoCatId.trim().equals("MIXED")){
					bvVersion = GeoComboName + " - " + bvName.trim();
				}
				else {
					bvVersion = geoCatId.trim() + " - " + bvName.trim();
				}
								
				
				if (braceId.compareTo(saveBraceId)== 0){
					if (bindGrpName.compareTo(saveBindGrpName) == 0){
						
						PdfPTable detailTable = new PdfPTable(12);
						detailTable.setWidths(tableh5w);
						detailTable.getDefaultCell().setBorder(Rectangle.NO_BORDER );
						String rollNumDisp = AddSpace.addSpace(rollNum, 3, '0') + "";
						detailTable.addCell(new Phrase(rollNumDisp,COURIERNORMAL_10));
						detailTable.addCell(new Phrase(GeoComboName,COURIERNORMAL_10));
						detailTable.addCell(new Phrase(bvVersion,COURIERNORMAL_10));
						detailTable.addCell(new Phrase(zipLtoH,COURIERNORMAL_10));
						String copyCountDisp = AddSpace.addSpace(PlaceComma.placeComma(Integer.valueOf(copyCount).intValue()),7) + "";
						detailTable.addCell(new Phrase(copyCountDisp,COURIERNORMAL_10));
						String numPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(Integer.valueOf(numPkg).intValue()),5) + "";
						detailTable.addCell(new Phrase(numPkgDisp,COURIERNORMAL_10));
						detailTable.addCell(new Phrase(sackCount,COURIERNORMAL_10));
						detailTable.addCell(new Phrase(airboxCount,COURIERNORMAL_10));
						detailTable.addCell(new Phrase(staged,COURIERNORMAL_10));
						detailTable.addCell(new Phrase(nonStaged,COURIERNORMAL_10));
						detailTable.addCell(new Phrase(stagedType,COURIERNORMAL_10));
						detailTable.addCell(new Phrase(stageBindGroupName,COURIERNORMAL_10));
						
						PdfPCell detailCell = new PdfPCell(detailTable);
						detailCell.setBorderWidth(0);
						outertable.addCell(detailCell);pageLine++;
						
						if (stageBindGroupName.length() > 12)pageLine++;
						
						//if (pageLine >=29) pageLine = 0;
						
						if ((Integer.valueOf(sackCount).intValue() == 0) && (Integer.valueOf(airboxCount).intValue() == 0)){
							bindPlabelCount += Integer.valueOf(copyCount).intValue();
							bindPPkg += Integer.valueOf(numPkg).intValue();
						}
						else{
							if (Integer.valueOf(airboxCount).intValue() == 0) {
								bindSlabelCount += Integer.valueOf(copyCount).intValue();
								bindSPkg += Integer.valueOf(numPkg).intValue();
							}
							else {
								bindAlabelCount += Integer.valueOf(copyCount).intValue();
								bindAPkg += Integer.valueOf(numPkg).intValue();								
							}
						}
						if (totStagedPallet > 0){
							bindGrpstaged = totStagedPallet; 
						}
						
						bindGrpSack += Integer.valueOf(sackCount).intValue();
						bindGrpAirbox += Integer.valueOf(airboxCount).intValue();
						bindGrpNonStaged += Integer.valueOf(nonStaged).intValue();
							 
					}
					else{
						
						for(int z=0;z<4;z++) outertable.addCell(dummyCell);
						LogWriter.writeLog(" SB - Bind 0 --- PageLine 1  : " + pageLine);
						
						for(int z=0;z<4;z++) outertable.addCell(dummyCell);
						
						PdfPCell totBind = totBindGrphdr();
						outertable.addCell(totBind);
						
						int[] bindGrpw = { 9, 9, 9, 5, 6, 6, 6 };
						PdfPTable bindPalletTable = new PdfPTable(7);
						bindPalletTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						bindPalletTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						bindPalletTable.setWidths(bindGrpw);
						
						bindPalletTable.addCell(new Phrase("Pallets",TIMESBOLD_12));
						String bindTotCountDisp = AddSpace.addSpace(PlaceComma.placeComma(bindPlabelCount),7) + "";
						bindPalletTable.addCell(new Phrase(bindTotCountDisp,COURIERNORMAL_10));
						String bindTotNumPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(bindPPkg),5) + "";
						bindPalletTable.addCell(new Phrase(bindTotNumPkgDisp,COURIERNORMAL_10));
						bindPalletTable.addCell(new Phrase("",COURIERNORMAL_10));
						bindPalletTable.addCell(new Phrase("",COURIERNORMAL_10));
						bindPalletTable.addCell(new Phrase("",COURIERNORMAL_10));
						bindPalletTable.addCell(new Phrase("",COURIERNORMAL_10));
						
						PdfPCell bindPalletCell = new PdfPCell(bindPalletTable);
						bindPalletCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						bindPalletCell.setBorderWidth(0);
						outertable.addCell(bindPalletCell);
						
						PdfPTable bindSackTable = new PdfPTable(7);
						bindSackTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						bindSackTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						bindSackTable.setWidths(bindGrpw);
						bindSackTable.addCell(new Phrase("Sacks",TIMESBOLD_12));
						String bindSTotCountDisp = AddSpace.addSpace(PlaceComma.placeComma(bindSlabelCount),7) + "";
						bindSackTable.addCell(new Phrase(bindSTotCountDisp,COURIERNORMAL_10));
						String bindSTotNumPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(bindSPkg),5) + "";
						bindSackTable.addCell(new Phrase(bindSTotNumPkgDisp,COURIERNORMAL_10));
						String bindTotSackDisp = AddSpace.addSpace(PlaceComma.placeComma(bindGrpSack),5) + "";
						bindSackTable.addCell(new Phrase(bindTotSackDisp,COURIERNORMAL_10));
						bindSackTable.addCell(new Phrase(" ",COURIERNORMAL_10));
						bindSackTable.addCell(new Phrase(" ",COURIERNORMAL_10));
						bindSackTable.addCell(new Phrase(" ",COURIERNORMAL_10));
						
						PdfPCell bindSackCell = new PdfPCell(bindSackTable);
						bindSackCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						bindSackCell.setBorderWidth(0);
						outertable.addCell(bindSackCell);
//
						PdfPTable bindAirboxTable = new PdfPTable(7);
						bindAirboxTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						bindAirboxTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						bindAirboxTable.setWidths(bindGrpw);
						bindAirboxTable.addCell(new Phrase("Air Boxes",TIMESBOLD_12));
						String bindATotCountDisp = AddSpace.addSpace(PlaceComma.placeComma(bindAlabelCount),7) + "";
						bindAirboxTable.addCell(new Phrase(bindATotCountDisp,COURIERNORMAL_10));
						String bindATotNumPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(bindAPkg),5) + "";
						bindAirboxTable.addCell(new Phrase(bindATotNumPkgDisp,COURIERNORMAL_10));
						bindAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_10));
						String bindTotAirboxDisp = AddSpace.addSpace(PlaceComma.placeComma(bindGrpAirbox),5) + "";
						bindAirboxTable.addCell(new Phrase(bindTotAirboxDisp,COURIERNORMAL_10));
						bindAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_10));
						bindAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_10));
						
						PdfPCell bindAirboxCell = new PdfPCell(bindAirboxTable);
						bindAirboxCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						bindAirboxCell.setBorderWidth(0);
						outertable.addCell(bindAirboxCell);
//
						
						PdfPTable bindCombTable = new PdfPTable(7);
						bindCombTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						bindCombTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						bindCombTable.setWidths(bindGrpw);
						bindCombTable.addCell(new Phrase("Combined",TIMESBOLD_12));
						String bindCTotCountDisp = AddSpace.addSpace(PlaceComma.placeComma(bindSlabelCount + bindAlabelCount + bindPlabelCount),7) + "";
						bindCombTable.addCell(new Phrase(bindCTotCountDisp,COURIERNORMAL_10));
						String bindCTotNumPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(bindSPkg + bindAPkg + bindPPkg),5) + "";
						bindCombTable.addCell(new Phrase(bindCTotNumPkgDisp,COURIERNORMAL_10));
						bindCombTable.addCell(new Phrase(bindTotSackDisp,COURIERNORMAL_10));
						bindCombTable.addCell(new Phrase(bindTotAirboxDisp,COURIERNORMAL_10));
						String bindCstaged = bindGrpstaged + "";
						bindCombTable.addCell(new Phrase(bindCstaged,COURIERNORMAL_10));
						String bindCNonstaged = bindGrpNonStaged + "";
						bindCombTable.addCell(new Phrase(bindCNonstaged,COURIERNORMAL_10));
						
						PdfPCell bindCombCell = new PdfPCell(bindCombTable);
						bindCombCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						bindCombCell.setBorderWidth(0);
						outertable.addCell(bindCombCell);pageLine +=4;
						
						bracePlabelCount += bindPlabelCount;
						braceSlabelCount += bindSlabelCount;
						braceAlabelCount += bindAlabelCount;
						bracePPkg += bindPPkg;
						braceSPkg += bindSPkg;
						braceAPkg += bindAPkg;
						braceGrpSack += bindGrpSack;
						braceGrpAirbox += bindGrpAirbox;
						braceGrpstaged = bindGrpstaged;
						braceGrpNonStaged += bindGrpNonStaged;
						bindPlabelCount = 0; bindSlabelCount = 0; bindAlabelCount = 0; bindPPkg = 0; bindSPkg = 0; bindAPkg = 0; bindGrpSack = 0; bindGrpAirbox = 0; bindGrpstaged = 0; bindGrpNonStaged = 0;
					
						sbDoc.add(outertable);
						sbDoc.newPage();
						
						saveBindGrpName = bindGrpName;
						
						outertable = new PdfPTable(1);
						outertable.setHeaderRows(11);
							
						String dateHdr = String.valueOf(dateFormat.format(toDay)) + "Issue :"+ issueNum + " - " + issueWeek + "Cover :" + issueDate; 
						PdfPCell header0 = new PdfPCell(new Phrase(dateHdr,
								FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,Color.black)));
						header0.setBorderWidth(0);
						outertable.addCell(header0);
								
						
						PdfPCell cell1 = new PdfPCell(new Phrase(
									"Plant Scheduled Binding Report", FontFactory.getFont(FontFactory.TIMES_ROMAN, 18, Font.BOLD, Color.BLACK)));
						cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
						cell1.setBorderWidth(0);
						outertable.addCell(cell1);
							
						int [] tablew = {2,9,9,2,9,2,5};
						PdfPTable headertable1 = new PdfPTable(7);
						headertable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						headertable1.setWidths(tablew);
						headertable1.addCell(new Phrase("Plant :",TIMESBOLD_12));
						headertable1.addCell(new Phrase(plantName.trim(),TIMESNORAML_12));
						headertable1.addCell(new Phrase(magName.trim(),TIMESNORAML_12));
						headertable1.addCell(new Phrase("Issue :",TIMESBOLD_12));
						String issueDateDisp = issueDate + "   ("+ issueNum + " - " + issueWeek + ")";
						headertable1.addCell(new Phrase(issueDateDisp,TIMESNORAML_12));
						headertable1.addCell(new Phrase("",TIMESBOLD_12));
						headertable1.addCell(new Phrase(deliveryType,TIMESBOLD_12));
						
						PdfPCell headercell1 = new PdfPCell(headertable1);
						headercell1.setBorderWidth(0);
						outertable.addCell(headercell1);
						
						outertable.addCell(dummyCell);
						
						int [] tableh2w = {4,2,5,9,4,9,3,7};
						PdfPTable headertable2 = new PdfPTable(8);
						headertable2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						headertable2.setWidths(tableh2w);
						String braceDisp = AddSpace.addSpace(braceId, 3, '0')+ " ";
						headertable2.addCell(new Phrase("Brace:",TIMESBOLD_12));
						headertable2.addCell(new Phrase(braceDisp,TIMESNORAML_12));
						headertable2.addCell(new Phrase("",TIMESBOLD_12));
						headertable2.addCell(new Phrase("",TIMESNORAML_12));
						headertable2.addCell(new Phrase("Bind Group:",TIMESBOLD_12));
						headertable2.addCell(new Phrase(bindGrpName,TIMESNORAML_12));
						headertable2.addCell(new Phrase("",TIMESBOLD_12));
						headertable2.addCell(new Phrase("",TIMESNORAML_12));
						
						PdfPCell headercell2 = new PdfPCell(headertable2);
						headercell2.setBorderWidth(0);
						outertable.addCell(headercell2);
						
						int [] tableh3w = {9,9,2,9,9,2,4,7};
						PdfPTable headertable3 = new PdfPTable(8);
						headertable3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						headertable3.setWidths(tableh3w);
						headertable3.addCell(new Phrase("Leave Plant :",TIMESBOLD_12));
						headertable3.addCell(new Phrase(departDate,TIMESNORAML_12));
						headertable3.addCell(new Phrase("",TIMESBOLD_12));
						headertable3.addCell(new Phrase("Dispatch:",TIMESBOLD_12));
						headertable3.addCell(new Phrase(braceName,TIMESNORAML_12));
						headertable3.addCell(new Phrase("",TIMESNORAML_12));
						headertable3.addCell(new Phrase("Via :",TIMESBOLD_12));
						headertable3.addCell(new Phrase(carrName,TIMESNORAML_12));
						
						PdfPCell headercell3 = new PdfPCell(headertable3);
						headercell3.setBorderWidth(0);
						outertable.addCell(headercell3);
						
						outertable.addCell(dummyCell);
											
						for(int i = 0; i<2; i++)outertable.addCell(dummyCell);								
						
						
						PdfPTable inertable = new PdfPTable(12);
						inertable.setWidths(tableh5w);
						inertable.getDefaultCell().setBorder(Rectangle.NO_BORDER | Rectangle.BOTTOM);
						inertable.getDefaultCell().setBorderWidthBottom(2);
						inertable.getDefaultCell().setPaddingBottom(5);
						inertable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_BOTTOM);
						inertable.addCell(new Phrase("Roll Number",TIMESBOLD_12));
						inertable.addCell(new Phrase("Geo Name",TIMESBOLD_12));
						inertable.addCell(new Phrase("Book Version",TIMESBOLD_12));
						inertable.addCell(new Phrase("Zip Range",TIMESBOLD_12));
						inertable.addCell(new Phrase("Label Count",TIMESBOLD_12));
						inertable.addCell(new Phrase("Package Count",TIMESBOLD_12));
						inertable.addCell(new Phrase("Sacks",TIMESBOLD_12));
						inertable.addCell(new Phrase("Air Box",TIMESBOLD_12));
						inertable.addCell(new Phrase("Staged",TIMESBOLD_12));
						inertable.addCell(new Phrase("Pallets NonStg",TIMESBOLD_12));
						inertable.addCell(new Phrase("Stage Type",TIMESBOLD_12));
						inertable.addCell(new Phrase("Stage Bind Group",TIMESBOLD_12));
						
						PdfPCell cell9 = new PdfPCell(inertable);
						cell9.setBorderWidth(0);
						outertable.addCell(cell9);
						
						outertable.addCell(dummyCell);
						
						PdfPTable detailTable = new PdfPTable(12);
						detailTable.setWidths(tableh5w);
						detailTable.getDefaultCell().setBorder(Rectangle.NO_BORDER );
						String rollNumDisp = AddSpace.addSpace(rollNum, 3, '0') + "";
						detailTable.addCell(new Phrase(rollNumDisp,COURIERNORMAL_10));
						detailTable.addCell(new Phrase(GeoComboName,COURIERNORMAL_10));
						detailTable.addCell(new Phrase(bvVersion,COURIERNORMAL_10));
						detailTable.addCell(new Phrase(zipLtoH,COURIERNORMAL_10));
						String copyCountDisp = AddSpace.addSpace(PlaceComma.placeComma(Integer.valueOf(copyCount).intValue()),7) + "";
						detailTable.addCell(new Phrase(copyCountDisp,COURIERNORMAL_10));
						String numPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(Integer.valueOf(numPkg).intValue()),5) + "";
						detailTable.addCell(new Phrase(numPkgDisp,COURIERNORMAL_10));
						detailTable.addCell(new Phrase(sackCount,COURIERNORMAL_10));
						detailTable.addCell(new Phrase(airboxCount,COURIERNORMAL_10));
						detailTable.addCell(new Phrase(staged,COURIERNORMAL_10));
						detailTable.addCell(new Phrase(nonStaged,COURIERNORMAL_10));
						detailTable.addCell(new Phrase(stagedType,COURIERNORMAL_10));
						detailTable.addCell(new Phrase(stageBindGroupName,COURIERNORMAL_10));
						
						PdfPCell detailCell = new PdfPCell(detailTable);
						detailCell.setBorderWidth(0);
						outertable.addCell(detailCell);pageLine++;
						
						if (stageBindGroupName.length() > 12)pageLine++;
						
						if ((Integer.valueOf(sackCount).intValue() == 0) && (Integer.valueOf(airboxCount).intValue() == 0)){
							bindPlabelCount += Integer.valueOf(copyCount).intValue();
							bindPPkg += Integer.valueOf(numPkg).intValue();
						}
						else{
							if (Integer.valueOf(airboxCount).intValue() == 0) {
								bindSlabelCount += Integer.valueOf(copyCount).intValue();
								bindSPkg += Integer.valueOf(numPkg).intValue();
							}
							else {
								bindAlabelCount += Integer.valueOf(copyCount).intValue();
								bindAPkg += Integer.valueOf(numPkg).intValue();								
							}
						}
						
						if (totStagedPallet > 0){
							bindGrpstaged = totStagedPallet; 
						}
						
						bindGrpSack += Integer.valueOf(sackCount).intValue();
						bindGrpAirbox += Integer.valueOf(airboxCount).intValue();
						bindGrpNonStaged += Integer.valueOf(nonStaged).intValue();
							
					}
				}
				else{
					if (firstPage)
						firstPage = false;
					else{
						
						boolean newPage = false;
						LogWriter.writeLog(" SB - Bind 1 --- PageLine 1  : " + pageLine);
						
						for(int z=0;z<4;z++) outertable.addCell(dummyCell);
						
						PdfPCell totBind = totBindGrphdr();
						outertable.addCell(totBind);
						
						int[] bindGrpw = { 9, 9, 9, 5, 6, 6, 6 };
						PdfPTable bindPalletTable = new PdfPTable(7);
						bindPalletTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						bindPalletTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						bindPalletTable.setWidths(bindGrpw);
						
						bindPalletTable.addCell(new Phrase("Pallets",TIMESBOLD_12));
						String bindTotCountDisp = AddSpace.addSpace(PlaceComma.placeComma(bindPlabelCount),7) + "";
						bindPalletTable.addCell(new Phrase(bindTotCountDisp,COURIERNORMAL_10));
						String bindTotNumPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(bindPPkg),5) + "";
						bindPalletTable.addCell(new Phrase(bindTotNumPkgDisp,COURIERNORMAL_10));
						bindPalletTable.addCell(new Phrase("",COURIERNORMAL_10));
						bindPalletTable.addCell(new Phrase("",COURIERNORMAL_10));
						bindPalletTable.addCell(new Phrase("",COURIERNORMAL_10));
						bindPalletTable.addCell(new Phrase("",COURIERNORMAL_10));
						
						PdfPCell bindPalletCell = new PdfPCell(bindPalletTable);
						bindPalletCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						bindPalletCell.setBorderWidth(0);
						outertable.addCell(bindPalletCell);
						
						PdfPTable bindSackTable = new PdfPTable(7);
						bindSackTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						bindSackTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						bindSackTable.setWidths(bindGrpw);
						bindSackTable.addCell(new Phrase("Sacks",TIMESBOLD_12));
						String bindSTotCountDisp = AddSpace.addSpace(PlaceComma.placeComma(bindSlabelCount),7) + "";
						bindSackTable.addCell(new Phrase(bindSTotCountDisp,COURIERNORMAL_10));
						String bindSTotNumPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(bindSPkg),5) + "";
						bindSackTable.addCell(new Phrase(bindSTotNumPkgDisp,COURIERNORMAL_10));
						String bindTotSackDisp = AddSpace.addSpace(PlaceComma.placeComma(bindGrpSack),5) + "";
						bindSackTable.addCell(new Phrase(bindTotSackDisp,COURIERNORMAL_10));
						bindSackTable.addCell(new Phrase(" ",COURIERNORMAL_10));
						bindSackTable.addCell(new Phrase(" ",COURIERNORMAL_10));
						bindSackTable.addCell(new Phrase(" ",COURIERNORMAL_10));
						
						PdfPCell bindSackCell = new PdfPCell(bindSackTable);
						bindSackCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						bindSackCell.setBorderWidth(0);
						outertable.addCell(bindSackCell);

//
						PdfPTable bindAirboxTable = new PdfPTable(7);
						bindAirboxTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						bindAirboxTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						bindAirboxTable.setWidths(bindGrpw);
						bindAirboxTable.addCell(new Phrase("Air Boxes",TIMESBOLD_12));
						String bindATotCountDisp = AddSpace.addSpace(PlaceComma.placeComma(bindAlabelCount),7) + "";
						bindAirboxTable.addCell(new Phrase(bindATotCountDisp,COURIERNORMAL_10));
						String bindATotNumPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(bindAPkg),5) + "";
						bindAirboxTable.addCell(new Phrase(bindATotNumPkgDisp,COURIERNORMAL_10));
						bindAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_10));
						String bindTotAirboxDisp = AddSpace.addSpace(PlaceComma.placeComma(bindGrpAirbox),5) + "";
						bindAirboxTable.addCell(new Phrase(bindTotAirboxDisp,COURIERNORMAL_10));
						bindAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_10));
						bindAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_10));
						
						PdfPCell bindAirboxCell = new PdfPCell(bindAirboxTable);
						bindAirboxCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						bindAirboxCell.setBorderWidth(0);
						outertable.addCell(bindAirboxCell);
//
						
						PdfPTable bindCombTable = new PdfPTable(7);
						bindCombTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						bindCombTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						bindCombTable.setWidths(bindGrpw);
						bindCombTable.addCell(new Phrase("Combined",TIMESBOLD_12));
						String bindCTotCountDisp = AddSpace.addSpace(PlaceComma.placeComma(bindSlabelCount + bindAlabelCount + bindPlabelCount),7) + "";
						bindCombTable.addCell(new Phrase(bindCTotCountDisp,COURIERNORMAL_10));
						String bindCTotNumPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(bindSPkg + bindAPkg + bindPPkg),5) + "";
						bindCombTable.addCell(new Phrase(bindCTotNumPkgDisp,COURIERNORMAL_10));
						bindCombTable.addCell(new Phrase(bindTotSackDisp,COURIERNORMAL_10));
						bindCombTable.addCell(new Phrase(bindTotAirboxDisp,COURIERNORMAL_10));
						String bindCstaged = bindGrpstaged + "";
						bindCombTable.addCell(new Phrase(bindCstaged,COURIERNORMAL_10));
						String bindCNonstaged = bindGrpNonStaged + "";
						bindCombTable.addCell(new Phrase(bindCNonstaged,COURIERNORMAL_10));
						
						PdfPCell bindCombCell = new PdfPCell(bindCombTable);
						bindCombCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						bindCombCell.setBorderWidth(0);
						outertable.addCell(bindCombCell);pageLine +=4;
						
						bracePlabelCount += bindPlabelCount;
						braceSlabelCount += bindSlabelCount;
						braceAlabelCount += bindAlabelCount;
						bracePPkg += bindPPkg;
						braceSPkg += bindSPkg;
						braceAPkg += bindAPkg;
						braceGrpSack += bindGrpSack;
						braceGrpAirbox += bindGrpAirbox;
						braceGrpstaged = bindGrpstaged;
						braceGrpNonStaged += bindGrpNonStaged;
						bindPlabelCount = 0; bindSlabelCount = 0; bindAlabelCount = 0; bindPPkg = 0; bindSPkg = 0; bindAPkg = 0; bindGrpSack = 0; bindGrpAirbox = 0; bindGrpstaged = 0; bindGrpNonStaged = 0;
						
						LogWriter.writeLog(" SB - Bind 2 --- PageLine 1  : " + pageLine);
						
						for(int z=0;z<4;z++) outertable.addCell(dummyCell);
						
						PdfPCell totBrace = totBracehdr();
						outertable.addCell(totBrace);
						
						int[] BraceGrpw = { 9, 9, 9, 5, 6, 6, 6 };
						PdfPTable BracePalletTable = new PdfPTable(7);
						BracePalletTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						BracePalletTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						BracePalletTable.setWidths(BraceGrpw);
						
						BracePalletTable.addCell(new Phrase("Pallets",TIMESBOLD_12));
						String braceTotCountDisp = AddSpace.addSpace(PlaceComma.placeComma(bracePlabelCount),7) + "";
						BracePalletTable.addCell(new Phrase(braceTotCountDisp,COURIERNORMAL_10));
						String braceTotNumPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(bracePPkg),5) + "";
						BracePalletTable.addCell(new Phrase(braceTotNumPkgDisp,COURIERNORMAL_10));
						BracePalletTable.addCell(new Phrase(" ",COURIERNORMAL_10));
						BracePalletTable.addCell(new Phrase("",COURIERNORMAL_10));
						BracePalletTable.addCell(new Phrase("",COURIERNORMAL_10));
						BracePalletTable.addCell(new Phrase("",COURIERNORMAL_10));
						
						PdfPCell BracePalletCell = new PdfPCell(BracePalletTable);
						BracePalletCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						BracePalletCell.setBorderWidth(0);
						outertable.addCell(BracePalletCell);
						
						PdfPTable BraceSackTable = new PdfPTable(7);
						BraceSackTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						BraceSackTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						BraceSackTable.setWidths(BraceGrpw);
						BraceSackTable.addCell(new Phrase("Sacks",TIMESBOLD_12));
						String braceSTotCountDisp = AddSpace.addSpace(PlaceComma.placeComma(braceSlabelCount),7) + "";
						BraceSackTable.addCell(new Phrase(braceSTotCountDisp,COURIERNORMAL_10));
						String braceSTotNumPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(braceSPkg),5) + "";
						BraceSackTable.addCell(new Phrase(braceSTotNumPkgDisp,COURIERNORMAL_10));
						String braceTotSackDisp = AddSpace.addSpace(PlaceComma.placeComma(braceGrpSack),5) + "";
						BraceSackTable.addCell(new Phrase(braceTotSackDisp,COURIERNORMAL_10));
						BraceSackTable.addCell(new Phrase(" ",COURIERNORMAL_10));
						BraceSackTable.addCell(new Phrase(" ",COURIERNORMAL_10));
						BraceSackTable.addCell(new Phrase(" ",COURIERNORMAL_10));
						
						PdfPCell BraceSackCell = new PdfPCell(BraceSackTable);
						BraceSackCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						BraceSackCell.setBorderWidth(0);
						outertable.addCell(BraceSackCell);
//
						PdfPTable BraceAirboxTable = new PdfPTable(7);
						BraceAirboxTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						BraceAirboxTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						BraceAirboxTable.setWidths(BraceGrpw);
						BraceAirboxTable.addCell(new Phrase("Air Boxes",TIMESBOLD_12));
						String braceATotCountDisp = AddSpace.addSpace(PlaceComma.placeComma(braceAlabelCount),7) + "";
						BraceAirboxTable.addCell(new Phrase(braceATotCountDisp,COURIERNORMAL_10));
						String braceATotNumPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(braceAPkg),5) + "";
						BraceAirboxTable.addCell(new Phrase(braceATotNumPkgDisp,COURIERNORMAL_10));
						BraceAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_10));
						String braceTotAirboxDisp = AddSpace.addSpace(PlaceComma.placeComma(braceGrpAirbox),5) + "";
						BraceAirboxTable.addCell(new Phrase(braceTotAirboxDisp,COURIERNORMAL_10));
						BraceAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_10));
						BraceAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_10));
						
						PdfPCell BraceAirboxCell = new PdfPCell(BraceAirboxTable);
						BraceAirboxCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						BraceAirboxCell.setBorderWidth(0);
						outertable.addCell(BraceAirboxCell);
//						
						PdfPTable BraceCombTable = new PdfPTable(7);
						BraceCombTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						BraceCombTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						BraceCombTable.setWidths(BraceGrpw);
						BraceCombTable.addCell(new Phrase("Combined",TIMESBOLD_12));
						String braceCTotCountDisp = AddSpace.addSpace(PlaceComma.placeComma(braceSlabelCount + braceAlabelCount + bracePlabelCount),7) + "";
						BraceCombTable.addCell(new Phrase(braceCTotCountDisp,COURIERNORMAL_10));
						String braceCTotNumPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(braceSPkg+ braceAPkg+ bracePPkg),5) + "";
						BraceCombTable.addCell(new Phrase(braceCTotNumPkgDisp,COURIERNORMAL_10));
						BraceCombTable.addCell(new Phrase(braceTotSackDisp,COURIERNORMAL_10));
						BraceCombTable.addCell(new Phrase(braceTotAirboxDisp,COURIERNORMAL_10));
						String braceCstaged = braceGrpstaged + "";
						BraceCombTable.addCell(new Phrase(braceCstaged,COURIERNORMAL_10));
						String braceCNonstaged = braceGrpNonStaged + "";
						BraceCombTable.addCell(new Phrase(braceCNonstaged,COURIERNORMAL_10));
						
						PdfPCell BraceCombCell = new PdfPCell(BraceCombTable);
						BraceCombCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						BraceCombCell.setBorderWidth(0);
						outertable.addCell(BraceCombCell);pageLine +=4;
						sbDoc.newPage();
						
						plantTotPlabelCount += bracePlabelCount;
						plantTotSlabelCount += braceSlabelCount;
						plantTotAlabelCount += braceAlabelCount;
						plantTotPPkg += bracePPkg;
						plantTotSPkg += braceSPkg;
						plantTotAPkg += braceAPkg;
						plantTotGrpSack += braceGrpSack;
						plantTotGrpAirbox += braceGrpAirbox;
						plantTotGrpstaged += braceGrpstaged; 
						plantTotGrpNonStaged += braceGrpNonStaged;
						bracePlabelCount = 0; braceSlabelCount = 0; braceAlabelCount = 0; bracePPkg = 0; braceSPkg = 0; braceAPkg = 0; braceGrpSack = 0; braceGrpAirbox = 0; braceGrpstaged = 0; braceGrpNonStaged = 0;
						
						
						LogWriter.writeLog(" SB - Brace 3 --- PageLine 1  : " + pageLine);
						pageLine = 0;
						
						sbDoc.add(outertable);
					}
					
					saveBraceId = braceId;
					saveBindGrpName = bindGrpName;
					
					outertable = new PdfPTable(1);
					outertable.setHeaderRows(11);
						
					String dateHdr = String.valueOf(dateFormat.format(toDay)) + "Issue :"+ issueNum + " - " + issueWeek + "Cover :" + issueDate; 
					PdfPCell header0 = new PdfPCell(new Phrase(dateHdr,
							FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,Color.black)));
					header0.setBorderWidth(0);
					outertable.addCell(header0);
							
					
					PdfPCell cell1 = new PdfPCell(new Phrase(
								"Plant Scheduled Binding Report", FontFactory.getFont(FontFactory.TIMES_ROMAN, 18, Font.BOLD, Color.BLACK)));
					cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell1.setBorderWidth(0);
					outertable.addCell(cell1);
						
					int [] tablew = {2,9,9,2,9,2,5};
					PdfPTable headertable1 = new PdfPTable(7);
					headertable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
					headertable1.setWidths(tablew);
					headertable1.addCell(new Phrase("Plant :",TIMESBOLD_12));
					headertable1.addCell(new Phrase(plantName.trim(),TIMESNORAML_12));
					headertable1.addCell(new Phrase(magName.trim(),TIMESNORAML_12));
					headertable1.addCell(new Phrase("Issue :",TIMESBOLD_12));
					String issueDateDisp = issueDate + "   ("+ issueNum + " - " + issueWeek + ")";
					headertable1.addCell(new Phrase(issueDateDisp,TIMESNORAML_12));
					headertable1.addCell(new Phrase("",TIMESBOLD_12));
					headertable1.addCell(new Phrase(deliveryType,TIMESBOLD_12));
						
					PdfPCell headercell1 = new PdfPCell(headertable1);
					headercell1.setBorderWidth(0);
					outertable.addCell(headercell1);
					
					outertable.addCell(dummyCell);
					
					int [] tableh2w = {4,2,5,9,4,9,3,7};
					PdfPTable headertable2 = new PdfPTable(8);
					headertable2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
					headertable2.setWidths(tableh2w);
					String braceDisp = AddSpace.addSpace(braceId, 3, '0')+ " ";
					headertable2.addCell(new Phrase("Brace:",TIMESBOLD_12));
					headertable2.addCell(new Phrase(braceDisp,TIMESNORAML_12));
					headertable2.addCell(new Phrase("",TIMESBOLD_12));
					headertable2.addCell(new Phrase("",TIMESNORAML_12));
					headertable2.addCell(new Phrase("Bind Group:",TIMESBOLD_12));
					headertable2.addCell(new Phrase(bindGrpName,TIMESNORAML_12));
					headertable2.addCell(new Phrase("",TIMESBOLD_12));
					headertable2.addCell(new Phrase("",TIMESNORAML_12));
					
					PdfPCell headercell2 = new PdfPCell(headertable2);
					headercell2.setBorderWidth(0);
					outertable.addCell(headercell2);
					
					int [] tableh3w = {6,9,1,6,13,1,4,7};
					PdfPTable headertable3 = new PdfPTable(8);
					headertable3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
					headertable3.setWidths(tableh3w);
					headertable3.addCell(new Phrase("Leave Plant :",TIMESBOLD_12));
					headertable3.addCell(new Phrase(departDate,TIMESNORAML_12));
					headertable3.addCell(new Phrase("",TIMESBOLD_12));
					headertable3.addCell(new Phrase("Dispatch:",TIMESBOLD_12));
					headertable3.addCell(new Phrase(braceName,TIMESNORAML_12));
					headertable3.addCell(new Phrase("",TIMESNORAML_12));
					headertable3.addCell(new Phrase("Via :",TIMESBOLD_12));
					headertable3.addCell(new Phrase(carrName,TIMESNORAML_12));
					
					PdfPCell headercell3 = new PdfPCell(headertable3);
					headercell3.setBorderWidth(0);
					outertable.addCell(headercell3);
					
					outertable.addCell(dummyCell);
										
					for(int i = 0; i<2; i++)outertable.addCell(dummyCell);								
					
					
					PdfPTable inertable = new PdfPTable(12);
					inertable.setWidths(tableh5w);
					inertable.getDefaultCell().setBorder(Rectangle.NO_BORDER | Rectangle.BOTTOM);
					inertable.getDefaultCell().setBorderWidthBottom(2);
					inertable.getDefaultCell().setPaddingBottom(5);
					inertable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_BOTTOM);
					inertable.addCell(new Phrase("Roll Number",TIMESBOLD_12));
					inertable.addCell(new Phrase("Geo Name",TIMESBOLD_12));
					inertable.addCell(new Phrase("Book Version",TIMESBOLD_12));
					inertable.addCell(new Phrase("Zip Range",TIMESBOLD_12));
					inertable.addCell(new Phrase("Label Count",TIMESBOLD_12));
					inertable.addCell(new Phrase("Package Count",TIMESBOLD_12));
					inertable.addCell(new Phrase("Sacks",TIMESBOLD_12));
					inertable.addCell(new Phrase("Air Box",TIMESBOLD_12));
					inertable.addCell(new Phrase("Staged",TIMESBOLD_12));
					inertable.addCell(new Phrase("Pallets NonStg",TIMESBOLD_12));
					inertable.addCell(new Phrase("Stage Type",TIMESBOLD_12));
					inertable.addCell(new Phrase("Stage Bind Group",TIMESBOLD_12));
					
					PdfPCell cell9 = new PdfPCell(inertable);
					cell9.setBorderWidth(0);
					outertable.addCell(cell9);
					
					outertable.addCell(dummyCell);
					
					
					PdfPTable detailTable = new PdfPTable(12);
					detailTable.setWidths(tableh5w);
					detailTable.getDefaultCell().setBorder(Rectangle.NO_BORDER );
					String rollNumDisp = AddSpace.addSpace(rollNum, 3, '0') + "";
					detailTable.addCell(new Phrase(rollNumDisp,COURIERNORMAL_10));
					detailTable.addCell(new Phrase(GeoComboName,COURIERNORMAL_10));
					detailTable.addCell(new Phrase(bvVersion,COURIERNORMAL_10));
					detailTable.addCell(new Phrase(zipLtoH,COURIERNORMAL_10));
					String copyCountDisp = AddSpace.addSpace(PlaceComma.placeComma(Integer.valueOf(copyCount).intValue()),7) + "";
					detailTable.addCell(new Phrase(copyCountDisp,COURIERNORMAL_10));
					String numPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(Integer.valueOf(numPkg).intValue()),5) + "";
					detailTable.addCell(new Phrase(numPkgDisp,COURIERNORMAL_10));
					detailTable.addCell(new Phrase(sackCount,COURIERNORMAL_10));
					detailTable.addCell(new Phrase(airboxCount,COURIERNORMAL_10));
					detailTable.addCell(new Phrase(staged,COURIERNORMAL_10));
					detailTable.addCell(new Phrase(nonStaged,COURIERNORMAL_10));
					detailTable.addCell(new Phrase(stagedType,COURIERNORMAL_10));
					detailTable.addCell(new Phrase(stageBindGroupName,COURIERNORMAL_10));
					
					PdfPCell detailCell = new PdfPCell(detailTable);
					detailCell.setBorderWidth(0);
					outertable.addCell(detailCell);pageLine++;
					
					if (stageBindGroupName.length() > 12)pageLine++;
					
					if ((Integer.valueOf(sackCount).intValue() == 0) && (Integer.valueOf(airboxCount).intValue() == 0)){
						bindPlabelCount += Integer.valueOf(copyCount).intValue();
						bindPPkg += Integer.valueOf(numPkg).intValue();
					}
					else{
						if(Integer.valueOf(airboxCount).intValue() == 0) {
							bindSlabelCount += Integer.valueOf(copyCount).intValue();
							bindSPkg += Integer.valueOf(numPkg).intValue();
						}
						else {
							bindAlabelCount += Integer.valueOf(copyCount).intValue();
							bindAPkg += Integer.valueOf(numPkg).intValue();
						}
					}
					if (totStagedPallet > 0){
						bindGrpstaged = totStagedPallet; 
					}
					bindGrpSack += Integer.valueOf(sackCount).intValue();
					bindGrpAirbox += Integer.valueOf(airboxCount).intValue();
					bindGrpNonStaged += Integer.valueOf(nonStaged).intValue();
					
				
				}						
			
			}
			
			if (BindRpt){
				
				for(int z=0;z<4;z++) outertable.addCell(dummyCell);
				
				PdfPCell totBind = totBindGrphdr();
				outertable.addCell(totBind);
				
				int[] bindGrpw = { 9, 9, 9, 5, 6, 6, 6 };
				PdfPTable bindPalletTable = new PdfPTable(7);
				bindPalletTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				bindPalletTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				bindPalletTable.setWidths(bindGrpw);
				
				bindPalletTable.addCell(new Phrase("Pallets",TIMESBOLD_12));
				String bindTotCountDisp = AddSpace.addSpace(PlaceComma.placeComma(bindPlabelCount),7) + "";
				bindPalletTable.addCell(new Phrase(bindTotCountDisp,COURIERNORMAL_10));
				String bindTotNumPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(bindPPkg),5) + "";
				bindPalletTable.addCell(new Phrase(bindTotNumPkgDisp,COURIERNORMAL_10));
				bindPalletTable.addCell(new Phrase("",COURIERNORMAL_10));
				bindPalletTable.addCell(new Phrase("",COURIERNORMAL_10));
				bindPalletTable.addCell(new Phrase("",COURIERNORMAL_10));
				bindPalletTable.addCell(new Phrase("",COURIERNORMAL_10));
				
				PdfPCell bindPalletCell = new PdfPCell(bindPalletTable);
				bindPalletCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				bindPalletCell.setBorderWidth(0);
				outertable.addCell(bindPalletCell);
				
				PdfPTable bindSackTable = new PdfPTable(7);
				bindSackTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				bindSackTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				bindSackTable.setWidths(bindGrpw);
				bindSackTable.addCell(new Phrase("Sacks",TIMESBOLD_12));
				String bindSTotCountDisp = AddSpace.addSpace(PlaceComma.placeComma(bindSlabelCount),7) + "";
				bindSackTable.addCell(new Phrase(bindSTotCountDisp,COURIERNORMAL_10));
				String bindSTotNumPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(bindSPkg),5) + "";
				bindSackTable.addCell(new Phrase(bindSTotNumPkgDisp,COURIERNORMAL_10));
				String bindTotSackDisp = AddSpace.addSpace(PlaceComma.placeComma(bindGrpSack),5) + "";
				bindSackTable.addCell(new Phrase(bindTotSackDisp,COURIERNORMAL_10));
				bindSackTable.addCell(new Phrase(" ",COURIERNORMAL_10));
				bindSackTable.addCell(new Phrase(" ",COURIERNORMAL_10));
				bindSackTable.addCell(new Phrase(" ",COURIERNORMAL_10));
				
				PdfPCell bindSackCell = new PdfPCell(bindSackTable);
				bindSackCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				bindSackCell.setBorderWidth(0);
				outertable.addCell(bindSackCell);
//
				PdfPTable bindAirboxTable = new PdfPTable(7);
				bindAirboxTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				bindAirboxTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				bindAirboxTable.setWidths(bindGrpw);
				bindAirboxTable.addCell(new Phrase("Air Boxes",TIMESBOLD_12));
				String bindATotCountDisp = AddSpace.addSpace(PlaceComma.placeComma(bindAlabelCount),7) + "";
				bindAirboxTable.addCell(new Phrase(bindATotCountDisp,COURIERNORMAL_10));
				String bindATotNumPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(bindAPkg),5) + "";
				bindAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_10));
				bindAirboxTable.addCell(new Phrase(bindATotNumPkgDisp,COURIERNORMAL_10));
				String bindTotAirboxDisp = AddSpace.addSpace(PlaceComma.placeComma(bindGrpAirbox),5) + "";
				bindAirboxTable.addCell(new Phrase(bindTotAirboxDisp,COURIERNORMAL_10));
				bindAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_10));
				bindAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_10));
				
				PdfPCell bindAirboxCell = new PdfPCell(bindAirboxTable);
				bindAirboxCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				bindAirboxCell.setBorderWidth(0);
				outertable.addCell(bindAirboxCell);
//				
				PdfPTable bindCombTable = new PdfPTable(7);
				bindCombTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				bindCombTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				bindCombTable.setWidths(bindGrpw);
				bindCombTable.addCell(new Phrase("Combined",TIMESBOLD_12));
				String bindCTotCountDisp = AddSpace.addSpace(PlaceComma.placeComma(bindSlabelCount + bindAlabelCount + bindPlabelCount),7) + "";
				bindCombTable.addCell(new Phrase(bindCTotCountDisp,COURIERNORMAL_10));
				String bindCTotNumPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(bindSPkg + bindAPkg + bindPPkg),5) + "";
				bindCombTable.addCell(new Phrase(bindCTotNumPkgDisp,COURIERNORMAL_10));
				bindCombTable.addCell(new Phrase(bindTotSackDisp,COURIERNORMAL_10));
				bindCombTable.addCell(new Phrase(bindTotAirboxDisp,COURIERNORMAL_10));
				String bindCstaged = bindGrpstaged + "";
				bindCombTable.addCell(new Phrase(bindCstaged,COURIERNORMAL_10));
				String bindCNonstaged = bindGrpNonStaged + "";
				bindCombTable.addCell(new Phrase(bindCNonstaged,COURIERNORMAL_10));
				
				PdfPCell bindCombCell = new PdfPCell(bindCombTable);
				bindCombCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				bindCombCell.setBorderWidth(0);
				outertable.addCell(bindCombCell);pageLine +=4;
				
				bracePlabelCount += bindPlabelCount;
				braceSlabelCount += bindSlabelCount;
				braceAlabelCount += bindAlabelCount;
				bracePPkg += bindPPkg;
				braceSPkg += bindSPkg;
				braceAPkg += bindAPkg;
				braceGrpSack += bindGrpSack;
				braceGrpAirbox += bindGrpAirbox;
				braceGrpstaged = bindGrpstaged;
				braceGrpNonStaged += bindGrpNonStaged;
				bindPlabelCount = 0; bindSlabelCount = 0; bindAlabelCount = 0; bindPPkg = 0; bindSPkg = 0; bindAPkg = 0; bindGrpSack = 0; bindGrpAirbox = 0;bindGrpstaged = 0; bindGrpNonStaged = 0;
				
				for(int z=0;z<4;z++) outertable.addCell(dummyCell);
				
				PdfPCell totBrace = totBracehdr();
				outertable.addCell(totBrace);
				
				int[] BraceGrpw = { 9, 9, 9, 5, 6, 6, 6 };
				PdfPTable BracePalletTable = new PdfPTable(7);
				BracePalletTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				BracePalletTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				BracePalletTable.setWidths(BraceGrpw);
				
				BracePalletTable.addCell(new Phrase("Pallets",TIMESBOLD_12));
				String braceTotCountDisp = AddSpace.addSpace(PlaceComma.placeComma(bracePlabelCount),7) + "";
				BracePalletTable.addCell(new Phrase(braceTotCountDisp,COURIERNORMAL_10));
				String braceTotNumPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(bracePPkg),5) + "";
				BracePalletTable.addCell(new Phrase(braceTotNumPkgDisp,COURIERNORMAL_10));
				BracePalletTable.addCell(new Phrase("",COURIERNORMAL_10));
				BracePalletTable.addCell(new Phrase("",COURIERNORMAL_10));
				BracePalletTable.addCell(new Phrase("",COURIERNORMAL_10));
				BracePalletTable.addCell(new Phrase("",COURIERNORMAL_10));
				
				PdfPCell BracePalletCell = new PdfPCell(BracePalletTable);
				BracePalletCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				BracePalletCell.setBorderWidth(0);
				outertable.addCell(BracePalletCell);
				
				PdfPTable BraceSackTable = new PdfPTable(7);
				BraceSackTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				BraceSackTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				BraceSackTable.setWidths(BraceGrpw);
				BraceSackTable.addCell(new Phrase("Sacks",TIMESBOLD_12));
				String braceSTotCountDisp = AddSpace.addSpace(PlaceComma.placeComma(braceSlabelCount),7) + "";
				BraceSackTable.addCell(new Phrase(braceSTotCountDisp,COURIERNORMAL_10));
				String braceSTotNumPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(braceSPkg),5) + "";
				BraceSackTable.addCell(new Phrase(braceSTotNumPkgDisp,COURIERNORMAL_10));
				String braceTotSackDisp = AddSpace.addSpace(PlaceComma.placeComma(braceGrpSack),5) + "";
				BraceSackTable.addCell(new Phrase(braceTotSackDisp,COURIERNORMAL_10));
				BraceSackTable.addCell(new Phrase(" ",COURIERNORMAL_10));
				BraceSackTable.addCell(new Phrase(" ",COURIERNORMAL_10));
				BraceSackTable.addCell(new Phrase(" ",COURIERNORMAL_10));
				
				PdfPCell BraceSackCell = new PdfPCell(BraceSackTable);
				BraceSackCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				BraceSackCell.setBorderWidth(0);
				outertable.addCell(BraceSackCell);
//
				PdfPTable BraceAirboxTable = new PdfPTable(7);
				BraceAirboxTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				BraceAirboxTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				BraceAirboxTable.setWidths(BraceGrpw);
				BraceAirboxTable.addCell(new Phrase("Air Boxes",TIMESBOLD_12));
				String braceATotCountDisp = AddSpace.addSpace(PlaceComma.placeComma(braceAlabelCount),7) + "";
				BraceAirboxTable.addCell(new Phrase(braceATotCountDisp,COURIERNORMAL_10));
				String braceATotNumPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(braceAPkg),5) + "";
				BraceAirboxTable.addCell(new Phrase(braceATotNumPkgDisp,COURIERNORMAL_10));
				BraceAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_10));
				String braceTotAirboxDisp = AddSpace.addSpace(PlaceComma.placeComma(braceGrpAirbox),5) + "";
				BraceAirboxTable.addCell(new Phrase(braceTotAirboxDisp,COURIERNORMAL_10));
				BraceAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_10));
				BraceAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_10));
				
				PdfPCell BraceAirboxCell = new PdfPCell(BraceAirboxTable);
				BraceAirboxCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				BraceAirboxCell.setBorderWidth(0);
				outertable.addCell(BraceAirboxCell);
				
//				
				PdfPTable BraceCombTable = new PdfPTable(7);
				BraceCombTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				BraceCombTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				BraceCombTable.setWidths(BraceGrpw);
				BraceCombTable.addCell(new Phrase("Combined",TIMESBOLD_12));
				String braceCTotCountDisp = AddSpace.addSpace(PlaceComma.placeComma(braceSlabelCount + braceAlabelCount + bracePlabelCount),7) + "";
				BraceCombTable.addCell(new Phrase(braceCTotCountDisp,COURIERNORMAL_10));
				String braceCTotNumPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(braceSPkg + braceAPkg + bracePPkg),5) + "";
				BraceCombTable.addCell(new Phrase(braceCTotNumPkgDisp,COURIERNORMAL_10));
				BraceCombTable.addCell(new Phrase(braceTotSackDisp,COURIERNORMAL_10));
				BraceCombTable.addCell(new Phrase(braceTotAirboxDisp,COURIERNORMAL_10));
				String braceCstaged = braceGrpstaged + "";
				BraceCombTable.addCell(new Phrase(braceCstaged,COURIERNORMAL_10));
				String braceCNonstaged = braceGrpNonStaged + "";
				BraceCombTable.addCell(new Phrase(braceCNonstaged,COURIERNORMAL_10));
				
				PdfPCell BraceCombCell = new PdfPCell(BraceCombTable);
				BraceCombCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				BraceCombCell.setBorderWidth(0);
				outertable.addCell(BraceCombCell);pageLine +=4;
				sbDoc.newPage();
				
				plantTotPlabelCount += bracePlabelCount;
				plantTotSlabelCount += braceSlabelCount;
				plantTotAlabelCount += braceAlabelCount;
				plantTotPPkg += bracePPkg;
				plantTotSPkg += braceSPkg;
				plantTotAPkg += braceAPkg;
				plantTotGrpSack += braceGrpSack;
				plantTotGrpAirbox += braceGrpAirbox;
				plantTotGrpstaged += braceGrpstaged; 
				plantTotGrpNonStaged += braceGrpNonStaged;
				
				
				PdfPCell rptTot = rptTothdr();
				outertable.addCell(rptTot);
				
				PdfPTable plantPalletTable = new PdfPTable(7);
				plantPalletTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				plantPalletTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				plantPalletTable.setWidths(BraceGrpw);
				
				plantPalletTable.addCell(new Phrase("Pallets",TIMESBOLD_12));
				String plantTotCountDisp = AddSpace.addSpace(PlaceComma.placeComma(plantTotPlabelCount),7) + "";
				plantPalletTable.addCell(new Phrase(plantTotCountDisp,COURIERNORMAL_10));
				String plantTotNumPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(plantTotPPkg),5) + "";
				plantPalletTable.addCell(new Phrase(plantTotNumPkgDisp,COURIERNORMAL_10));
				plantPalletTable.addCell(new Phrase("",COURIERNORMAL_10));
				plantPalletTable.addCell(new Phrase("",COURIERNORMAL_10));
				plantPalletTable.addCell(new Phrase("",COURIERNORMAL_10));
				plantPalletTable.addCell(new Phrase("",COURIERNORMAL_10));
				
				PdfPCell plantPalletCell = new PdfPCell(plantPalletTable);
				plantPalletCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				plantPalletCell.setBorderWidth(0);
				outertable.addCell(plantPalletCell);
				
				PdfPTable plantSackTable = new PdfPTable(7);
				plantSackTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				plantSackTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				plantSackTable.setWidths(BraceGrpw);
				plantSackTable.addCell(new Phrase("Sacks",TIMESBOLD_12));
				String plantSTotCountDisp = AddSpace.addSpace(PlaceComma.placeComma(plantTotSlabelCount),7) + "";
				plantSackTable.addCell(new Phrase(plantSTotCountDisp,COURIERNORMAL_10));
				String plantSTotNumPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(plantTotSPkg),5) + "";
				plantSackTable.addCell(new Phrase(plantSTotNumPkgDisp,COURIERNORMAL_10));
				String plantTotSackDisp = AddSpace.addSpace(PlaceComma.placeComma(plantTotGrpSack),5) + "";
				plantSackTable.addCell(new Phrase(plantTotSackDisp,COURIERNORMAL_10));
				plantSackTable.addCell(new Phrase(" ",COURIERNORMAL_10));
				plantSackTable.addCell(new Phrase(" ",COURIERNORMAL_10));
				plantSackTable.addCell(new Phrase(" ",COURIERNORMAL_10));
				
				PdfPCell plantSackCell = new PdfPCell(plantSackTable);
				plantSackCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				plantSackCell.setBorderWidth(0);
				outertable.addCell(plantSackCell);
//
				PdfPTable plantAirboxTable = new PdfPTable(7);
				plantAirboxTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				plantAirboxTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				plantAirboxTable.setWidths(BraceGrpw);
				plantAirboxTable.addCell(new Phrase("Air Boxes",TIMESBOLD_12));
				String plantATotCountDisp = AddSpace.addSpace(PlaceComma.placeComma(plantTotAlabelCount),7) + "";
				plantAirboxTable.addCell(new Phrase(plantATotCountDisp,COURIERNORMAL_10));
				String plantATotNumPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(plantTotAPkg),5) + "";
				plantAirboxTable.addCell(new Phrase(plantATotNumPkgDisp,COURIERNORMAL_10));
				plantAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_10));
				String plantTotAirboxDisp = AddSpace.addSpace(PlaceComma.placeComma(plantTotGrpAirbox),5) + "";
				plantAirboxTable.addCell(new Phrase(plantTotAirboxDisp,COURIERNORMAL_10));
				plantAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_10));
				plantAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_10));
				
				PdfPCell plantAirboxCell = new PdfPCell(plantAirboxTable);
				plantAirboxCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				plantAirboxCell.setBorderWidth(0);
				outertable.addCell(plantAirboxCell);
				
//				
				PdfPTable plantCombTable = new PdfPTable(7);
				plantCombTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				plantCombTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				plantCombTable.setWidths(BraceGrpw);
				plantCombTable.addCell(new Phrase("Combined",TIMESBOLD_12));
				String plantCTotCountDisp = AddSpace.addSpace(PlaceComma.placeComma(plantTotSlabelCount + plantTotAlabelCount + plantTotPlabelCount),7) + "";
				plantCombTable.addCell(new Phrase(plantCTotCountDisp,COURIERNORMAL_10));
				String plantCTotNumPkgDisp = AddSpace.addSpace(PlaceComma.placeComma(plantTotSPkg + plantTotAPkg + plantTotPPkg),5) + "";
				plantCombTable.addCell(new Phrase(plantCTotNumPkgDisp,COURIERNORMAL_10));
				plantCombTable.addCell(new Phrase(plantTotSackDisp,COURIERNORMAL_10));
				plantCombTable.addCell(new Phrase(plantTotAirboxDisp,COURIERNORMAL_10));
				String plantCstaged = plantTotGrpstaged + "";
				plantCombTable.addCell(new Phrase(plantCstaged,COURIERNORMAL_10));
				String plantCNonstaged = plantTotGrpNonStaged + "";
				plantCombTable.addCell(new Phrase(plantCNonstaged,COURIERNORMAL_10));
				
				PdfPCell plantCombCell = new PdfPCell(plantCombTable);
				plantCombCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				plantCombCell.setBorderWidth(0);
				outertable.addCell(plantCombCell);pageLine +=4;

				
				
			}
			else {
				
			}
			
			sbDoc.add(outertable);
		}catch (SQLException se) {
			LogWriter.writeLog(se);
		}
		catch (DocumentException de) {
			System.err.println(de.getMessage());
		} catch (IOException ioe) {
			System.err.println(ioe.getMessage());
		} finally {
			if (resultset != null) {
				try {
					resultset.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectcopyCnt != null) {
				try {
					selectcopyCnt.close();
				} catch (SQLException e) { /* ignored */}
			}
		}	
		sbDoc.close();
	}
		
		public synchronized static void createScheduledBind(Magazine mag){
			
			
			try{
				Thread.sleep(3000);
			} catch( InterruptedException ie) {}
			
			PreparedStatement selectJobID = null;
			ResultSet rsJobId = null;

			open();
			
			initialize(mag); 
			
			String SQL = "Select distinct JOB_ID from  " + pkgsum
						+ " WHERE MAG_KY = ? and INSTNC_CD = ? and PLANT_ID = ? and MAG_CD = ? and ISS_NUM = ? and ISS_WK_NUM = ? ";
		
			magazineKey();
			
			getIssueDate();
			
			getPlantName();
			
			instCd = InstanceCd.getInstCd(magKey, issueDate);

			try {
				selectJobID = conn.prepareStatement(SQL);
				selectJobID.setInt(1, magKey);
				selectJobID.setString(2, instCd);
				selectJobID.setString(3, plantId);
				selectJobID.setString(4, magCode);
				selectJobID.setInt(5, toNum.toNumber(issueNum));
				selectJobID.setInt(6, toNum.toNumber(issueWeek));
				rsJobId = selectJobID.executeQuery();
				
				while (rsJobId.next()) {

				String jobId = rsJobId.getString("JOB_ID");

				if (jobId.endsWith("U")) {
					createPDF(jobId, "USPS");
					LogWriter.writeLog(" USPS Scheduled Bind Report Generated   ");
				} else if (jobId.endsWith("F")) {
					createPDF(jobId, "FOREIGN");
					LogWriter.writeLog(" Foreign Scheduled Bind Report Generated   ");
				}
			}
			} 
			catch (SQLException se) {
				LogWriter.writeLog(se);
			} finally {
				if (rsJobId != null) {
					try {
						rsJobId.close();
					} catch (SQLException e) { /* ignored */}
					}
				if (selectJobID != null) {
					try {
						selectJobID.close();
					} catch (SQLException e) { /* ignored */}
				}
			}	
			return;
		}
}