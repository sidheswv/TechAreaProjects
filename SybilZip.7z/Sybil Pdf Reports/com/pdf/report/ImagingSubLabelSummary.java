package com.pdf.report;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import sybil.common.model.Magazine;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;

import com.report.text.Document;
import com.report.text.DocumentException;
import com.report.text.Element;
import com.report.text.ExceptionConverter;
import com.report.text.Font;
import com.report.text.FontFactory;
import com.report.text.Phrase;
import com.report.text.Rectangle;
import com.report.text.pdf.BaseFont;
import com.report.text.pdf.PdfContentByte;
import com.report.text.pdf.PdfPCell;
import com.report.text.pdf.PdfPTable;
import com.report.text.pdf.PdfPageEventHelper;
import com.report.text.pdf.PdfTemplate;
import com.report.text.pdf.PdfWriter;

public class ImagingSubLabelSummary extends PdfPageEventHelper {
	
	public static String rollsumTableName = "TBA_ROLL_SUM";

	public static String magazineInf = "TBA_MAGAZINEINF";

	public static String sybMag = "TBA_SYB_MAGAZINE";

	private static Connection conn = null;

	private static ResultSet resultset = null;

	private static String magName = null;
	
	private static String instCd = null;

	private static Font TIMESROMAN_BOLD = FontFactory.getFont(
			FontFactory.TIMES_ROMAN, 12, Font.BOLD, Color.black);

	private static Font COURIER_NORMAL = FontFactory.getFont(
			FontFactory.COURIER, 12, Font.NORMAL, Color.black);

	protected PdfTemplate total;

	protected BaseFont helv;
 
 	public void onOpenDocument(PdfWriter writer, Document document) {
		total = writer.getDirectContent().createTemplate(100, 100);
		total.setBoundingBox(new Rectangle(-20, -20, 100, 100));
		try {
			helv = BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI,BaseFont.NOT_EMBEDDED);
		} catch (Exception e) {
			throw new ExceptionConverter(e);
		}
	}
 
	public void onEndPage(PdfWriter writer, Document document) {
		PdfContentByte cb = writer.getDirectContent();
		cb.saveState();
		String text = "Page " + writer.getPageNumber() + " of  ";
		float textBase = document.bottom() - 15;
		float textSize = helv.getWidthPoint(text, 9);
		float textCenter = document.right()/2;
		cb.beginText();
		cb.setFontAndSize(helv, 10);

		cb.setTextMatrix(textCenter, textBase);
		cb.showText(text);
		cb.endText();
		cb.addTemplate(total, textCenter + textSize, textBase);
		cb.restoreState();
	}
 	
	public void onCloseDocument(PdfWriter writer, Document document) {
		total.beginText();
		total.setFontAndSize(helv, 10);
		total.setTextMatrix(0, 0);
		total.showText(String.valueOf(writer.getPageNumber() - 1));
		total.endText();
	}
	
	private static void open() {

		PreparedStatement setSqlId = null;
		Statement commitSqlId = null;
		String x = null;
		String db2owner = null;
		int i = 0;
		
		String userDb = sybil.common.util.PropertyBroker.getProperty("database.login","sybil");
		String pswdDb = sybil.common.util.PropertyBroker.getProperty("database.password","sybil");
		
		
		if( conn == null) {
			try {
				Class.forName(sybil.common.util.PropertyBroker.getProperty("database.driver", "Not Found"));
				conn = DriverManager.getConnection(sybil.common.util.PropertyBroker.getProperty("database.server", "Not Found"), userDb, pswdDb);

				//
				x = PropertyBroker.getProperty("database.driver", "Not Found").toLowerCase();
				i = x.indexOf("db2");
				if (!(i < 0)) {
					try {
						db2owner = PropertyBroker.getProperty("DB2OWNER","dtppsyup");
						setSqlId = conn.prepareStatement("set current sqlid = ?");
						setSqlId.setString(1, db2owner);
						setSqlId.execute();
						commitSqlId = conn.createStatement();
						commitSqlId.execute("commit");
					}
					catch (SQLException se) {
						if(se.getSQLState().equals("S1010")) {
						}
						else {
							LogWriter.writeLog(se);
							LogWriter.writeLog("Error: Set Current SqlId failed.");
							if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
								LogWriter.writeLog("Process terminating due to database/sql exception");
								System.exit(1);
							}
						}
					}
					catch (Exception e) {
						LogWriter.writeLog(e);
						LogWriter.writeLog("Error: Set Current SqlId failed.");
						if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
							LogWriter.writeLog("Process terminating due to database/sql exception");
							System.exit(1);
						}
					}
				}
			
			} 
			catch (Exception e) {
				sybil.common.util.LogWriter.writeLog(e);
				LogWriter.writeLog("Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
		
	return;
	}
	

	private static String getIssueDate(Magazine mag){
		
		String issueDate = null;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT COVER_DATE FROM " + magazineInf + " WHERE PLANT = ? and MAG = ? and ISSUE = ? ";
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, mag.getPlant().toUpperCase());
		selectMag.setString(2, mag.getMagCode().toLowerCase());
		selectMag.setString(3, mag.getIssue());
		
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			issueDate  = rs.getString("COVER_DATE");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Issue Date error " + mag.getMagCode());
		} finally {
			if (resultset != null) {
				try {
					resultset.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectMag != null) {
				try {
					selectMag.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		return issueDate;
	}

	private static int magazineKey(String magazineCode){
		
		int magKey = 0;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT MAG_KEY, NAME  FROM " + sybMag + " WHERE MAG_CD = ? ";
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, magazineCode);
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			magKey  = (int)rs.getInt("MAG_KEY");
			magName = rs.getString("NAME");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Code Select error " + magazineCode);
		} finally {
			if (resultset != null) {
				try {
					resultset.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectMag != null) {
				try {
					selectMag.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		return magKey;
	}


	public synchronized static void CreateImagingSubLabel(Magazine mag,String jobId, String rptType){
		
		PreparedStatement selectcopyCnt = null;
		Document issDoc = new Document();
		boolean firstRow = true;
					
		int totalCopy = 0, rptRollCount = 0;
		
		int [] tablew = {6,3,6,3,6};
		
		String magCode = mag.getMagCode().trim();
		String issueNum = mag.getIssue().trim();
		String plantId = mag.getPlant().toUpperCase().trim();
		String issueWeek = mag.getWeek().trim();
		
		
		String RptPath = sybil.common.util.PropertyBroker.getProperty("NewPDFReportsPath","Not found");
		String fileName = magCode.toLowerCase() + ".i" + issueNum + "." + plantId + ".OMS_Imaging_Sub_Label_Summary." + issueWeek + "." + rptType;
		
		open();
		
		String SQL  = "SELECT LABEL_MTH, COUNT(*) AS TOT_ROLL_CNT, SUM(COPY_CNT) AS TOT_COPY_CNT " 
			    + " FROM  " + rollsumTableName  
			    + " WHERE  MAG_KY = ? and INSTNC_CD = ? AND MAG_CD = ? AND PLANT_ID = ? AND ISS_NUM = ? AND ISS_WK_NUM = ? AND JOB_ID = ? AND PAL_SACK_IND > ' '  "
			    + " GROUP BY LABEL_MTH ORDER BY LABEL_MTH " ;

		// CNSOL_SUB_TYP = 'SC'
		int magKey = magazineKey(magCode);
		
		String issueDate = getIssueDate(mag);
		
		try {
			
			PdfWriter writer = PdfWriter.getInstance(issDoc,				
					new FileOutputStream(RptPath + fileName + ".pdf"));
			

			writer.setViewerPreferences(PdfWriter.PageModeFullScreen);
			writer.setPageEvent(new ImagingSubLabelSummary());
			
			issDoc.open();
			
			Date toDay = new Date(); 
			SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, MMM d, yyyy, HH:mm a "); 
			
			
			PdfPTable outertable = new PdfPTable(1);
			outertable.setHeaderRows(4);
			
			PdfPCell header0 = new PdfPCell(new Phrase(String.valueOf(dateFormat.format(toDay)),
					FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,
							Color.black)));
			header0.setBorderWidth(0);
			outertable.addCell(header0);
			
			PdfPCell dummyCell = new PdfPCell(new Phrase("", FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
			dummyCell.setBorderWidth(0);
				
			outertable.setSplitLate(false);
			
			PdfPCell cell1 = new PdfPCell(new Phrase(
					"Imaging Subscriber Label Report", FontFactory.getFont(
							FontFactory.TIMES_ROMAN, 14, Font.NORMAL, Color.BLACK)));
			cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell1.setBorderWidth(0);
			outertable.addCell(cell1);

			PdfPCell cell2 = new PdfPCell(new Phrase(
					"Summary By Label Type", FontFactory.getFont(
							FontFactory.TIMES_ROMAN, 14, Font.NORMAL, Color.BLACK)));
			cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell2.setBorderWidth(0);
			outertable.addCell(cell2);

			
			for ( int G = 0; G <=2; G++){
				outertable.addCell(dummyCell);}
			
			selectcopyCnt = conn.prepareStatement(SQL);
			selectcopyCnt.setInt(1, magKey);
			selectcopyCnt.setString(2, instCd);
			selectcopyCnt.setString(3, magCode);
			selectcopyCnt.setString(4, plantId);
			selectcopyCnt.setInt(5, toNum.toNumber(issueNum));
			selectcopyCnt.setInt(6, toNum.toNumber(issueWeek));
			selectcopyCnt.setString(7, jobId.trim());
			
			resultset = selectcopyCnt.executeQuery();
			
			while (resultset.next()){
				
			if (firstRow) {
				
				String header1 = " Magazine :  " + magName  + "      " +  "JobId :   " + jobId + "    Issue : " + issueDate + "(" + issueNum + " - " + issueWeek + ")" ;
				PdfPCell magCell = new PdfPCell(new Phrase(header1,
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Font.BOLD,
								Color.black)));
				magCell.setBorderWidth(0);
				outertable.addCell(magCell);
				
				for ( int G = 0; G <=4; G++){
					outertable.addCell(dummyCell);}
				
				PdfPTable headertable1 = new PdfPTable(5);
				headertable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				headertable1.setWidths(tablew);
				headertable1.addCell(new Phrase("Label Type ",TIMESROMAN_BOLD));
				headertable1.addCell(new Phrase("",COURIER_NORMAL));
				headertable1.addCell(new Phrase("Total Rolls",TIMESROMAN_BOLD));
				headertable1.addCell(new Phrase("",COURIER_NORMAL));
				headertable1.addCell(new Phrase("Number of Copies",TIMESROMAN_BOLD));
				
				PdfPCell headercell1 = new PdfPCell(headertable1);
				headercell1.setBorderWidth(0);
				outertable.addCell(headercell1);
									
				firstRow = false;
				}				
		
			String labelType = resultset.getString("LABEL_MTH");
			String rollCount  = resultset.getString("TOT_ROLL_CNT");
			String copyCount = resultset.getString("TOT_COPY_CNT");
			
			PdfPTable detailTable = new PdfPTable(5);
			detailTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			detailTable.setWidths(tablew);
			detailTable.addCell(new Phrase(labelType,COURIER_NORMAL));
			detailTable.addCell(new Phrase("",COURIER_NORMAL));
			String rollCountDisp = AddSpace.addSpace(PlaceComma.placeComma((Integer.valueOf(rollCount)).intValue()),6) + " ";
			detailTable.addCell(new Phrase(rollCountDisp,COURIER_NORMAL));
			detailTable.addCell(new Phrase("",TIMESROMAN_BOLD));
			String totNumCopy = AddSpace.addSpace(PlaceComma.placeComma((Integer.valueOf(copyCount)).intValue()),9) + " ";
			detailTable.addCell(new Phrase(totNumCopy,COURIER_NORMAL));
			
			PdfPCell detailCell = new PdfPCell(detailTable);
			detailCell.setBorderWidth(0);
			outertable.addCell(detailCell);
			 
			totalCopy += (Integer.valueOf(copyCount)).intValue();
			rptRollCount += (Integer.valueOf(rollCount)).intValue();
			
			for ( int G = 0; G <=2; G++){
				outertable.addCell(dummyCell);}
				
			}
			
			PdfPTable totalTable = new PdfPTable(5);
			totalTable.getDefaultCell().setBorder(Rectangle.NO_BORDER | Rectangle.TOP);
			totalTable.setWidths(tablew);
			totalTable.addCell(new Phrase("TOTAL",TIMESROMAN_BOLD));
			totalTable.addCell(new Phrase("",COURIER_NORMAL));
			String rptTotRollCopy = AddSpace.addSpace(PlaceComma.placeComma(rptRollCount),6) + " "; 
			totalTable.addCell(new Phrase(rptTotRollCopy,COURIER_NORMAL));
			totalTable.addCell(new Phrase("",COURIER_NORMAL));
			String rptTotNumCopy = AddSpace.addSpace(PlaceComma.placeComma(totalCopy),9) + " ";
			totalTable.addCell(new Phrase(rptTotNumCopy,COURIER_NORMAL));
			
			PdfPCell totalCell = new PdfPCell(totalTable);
			totalCell.setBorderWidth(0);
			outertable.addCell(totalCell);
			
			issDoc.add(outertable);
		} 
		catch (SQLException se) {
			System.err.println(se.getMessage());
		}
	
		catch (DocumentException de) {
			System.err.println(de.getMessage());
		} catch (IOException ioe) {
			System.err.println(ioe.getMessage());
		} finally {
			if (resultset != null) {
				try {
					resultset.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectcopyCnt != null) {
				try {
					selectcopyCnt.close();
				} catch (SQLException e) { /* ignored */}
			}
		}

		issDoc.close();
	}

	public synchronized static void CreatePDF(Magazine mag){
		
		PreparedStatement selectJobID = null;
		ResultSet rsJobId = null;

		open();
		
		String magCode = mag.getMagCode().trim();
		String issueNum = mag.getIssue().trim();
		String plantId = mag.getPlant().toUpperCase().trim();
		String issueWeek = mag.getWeek().trim();
		 
		
		String SQL = "Select distinct JOB_ID from  " + rollsumTableName
					+ " WHERE MAG_KY = ? and INSTNC_CD = ? and PLANT_ID = ? and MAG_CD = ? and ISS_NUM = ? and ISS_WK_NUM = ? ";
	
		int magKey = magazineKey(magCode);
		
		instCd = InstanceCd.getInstCd(magKey, toNum.toNumber(issueNum), toNum.toNumber(issueWeek));
		
		
		try {
			selectJobID = conn.prepareStatement(SQL);
			selectJobID.setInt(1, magKey);
			selectJobID.setString(2, instCd);
			selectJobID.setString(3, plantId);
			selectJobID.setString(4, magCode);
			selectJobID.setInt(5, toNum.toNumber(issueNum));
			selectJobID.setInt(6, toNum.toNumber(issueWeek));
			rsJobId = selectJobID.executeQuery();
			
			while (rsJobId.next()) {

			String jobId = rsJobId.getString("JOB_ID");

			if (jobId.endsWith("U")) {
				CreateImagingSubLabel(mag,jobId, "USPS");
				LogWriter.writeLog("USPS Imaging Sub Label Summary Report Generated   ");
			} else if (jobId.endsWith("F")) {
				CreateImagingSubLabel(mag,jobId, "FOREIGN");
				LogWriter.writeLog(" Foreign Imaging Sub Label Summary Report Generated   ");
			} else if (jobId.endsWith(" ")){
				CreateImagingSubLabel(mag,jobId, "CANADIAN");
				LogWriter.writeLog(" CANADIAN Imaging Sub Label Summary Report Generated   ");
			}
		}
		} 
		catch (SQLException se) {
			LogWriter.writeLog(se);
		} finally {
			if (rsJobId != null) {
				try {
					rsJobId.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectJobID != null) {
				try {
					selectJobID.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		return;
	}
	
}
