package com.pdf.report;

public class RollPosition {
	String braceId;
	int rollNum;
	int rollPos;
	
	public RollPosition() {
		super();
		// TODO Auto-generated constructor stub
	}
	public RollPosition(String braceId, int rollNum, int rollPos ) {
		super();
		this.braceId = braceId;
		this.rollNum = rollNum;
		this.rollPos = rollPos;
	}
	public String getBraceId() {
		return braceId;
	}
	public void setBraceId(String braceId) {
		this.braceId = braceId;
	}
	public int getRollNum() {
		return rollNum;
	}
	public void setRollNum(int rollNum) {
		this.rollNum = rollNum;
	}
	public int getRollPos() {
		return rollPos;
	}
	public void setRollPos(int rollPos) {
		this.rollPos = rollPos;
	}
	
}
