package com.pdf.report;

import java.io.BufferedReader;
import java.io.EOFException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.StringTokenizer;

import sybil.common.model.Magazine;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;
import sybil.common.util.SybilWarningException;

public class FinalDriverCode  {
	
	public static String magInfo = "TBA_MAG_INFO";

	public static String sybMag = "TBA_SYB_MAGAZINE";

	public static String magazineInf = "TBA_MAGAZINEINF";

	public static String custBvTableName = "TBA_CUST_BV";

	private static Connection conn = null;

	
	private static void open() {

		PreparedStatement setSqlId = null;
		Statement commitSqlId = null;
		String x = null;
		String db2owner = null;
		int i = 0;
		
		String userDb = sybil.common.util.PropertyBroker.getProperty("database.login","sybil");
		String pswdDb = sybil.common.util.PropertyBroker.getProperty("database.password","sybil");
		
		
		if( conn == null) {
			try {
				Class.forName(sybil.common.util.PropertyBroker.getProperty("database.driver", "Not Found"));
				conn = DriverManager.getConnection(sybil.common.util.PropertyBroker.getProperty("database.server", "Not Found"), userDb, pswdDb);

				//
				x = PropertyBroker.getProperty("database.driver", "Not Found").toLowerCase();
				i = x.indexOf("db2");
				if (!(i < 0)) {
					try {
						db2owner = PropertyBroker.getProperty("DB2OWNER","dtppsyup");
						setSqlId = conn.prepareStatement("set current sqlid = ?");
						setSqlId.setString(1, db2owner);
						setSqlId.execute();
						commitSqlId = conn.createStatement();
						commitSqlId.execute("commit");
					}
					catch (SQLException se) {
						if(se.getSQLState().equals("S1010")) {
						}
						else {
							LogWriter.writeLog(se);
							LogWriter.writeLog("Error: Set Current SqlId failed.");
							if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
								LogWriter.writeLog("Process terminating due to database/sql exception");
								System.exit(1);
							}
						}
					}
					catch (Exception e) {
						LogWriter.writeLog(e);
						LogWriter.writeLog("Error: Set Current SqlId failed.");
						if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
							LogWriter.writeLog("Process terminating due to database/sql exception");
							System.exit(1);
						}
					}
				}
			
			} 
			catch (Exception e) {
				sybil.common.util.LogWriter.writeLog(e);
				LogWriter.writeLog("Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
		
	return;
	}
	
	
	public static void close() {
		
		if( conn != null) {		
			try { conn.close(); }catch(Exception sql ){};
			conn = null;
		}
		return;
	}
	
private static int magazineKey(String magazineCode){
		
		int magKey = 0;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT MAG_KEY, NAME  FROM " + sybMag + " WHERE MAG_CD = ? ";
		LogWriter.writeLog("select from " + sybMag + "   "  + SQL);
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, magazineCode);
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			magKey  = (int)rs.getInt("MAG_KEY");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Code Select error " + magazineCode);
		}
		return magKey;
	}

	
	public synchronized static boolean processFnlDriverCode(BufferedReader rdr, Magazine mag) {

		String rec = null;

		String magCode = mag.getMagCode().trim();
		String issueNum = mag.getIssue().trim();
		String plantId = mag.getPlant().toUpperCase().trim();
		String issueWeek = mag.getWeek().trim();
		
		PreparedStatement updateCbv;
		Statement st;
		
		int errorCtr = 0;
		String BookVersion = null;
		int FinalDriverCode = 0;
		int rowsupdate = 0;			
		boolean returnCode = false;

		open();
			
		String commitSQL = "commit";

		int magKey = magazineKey(magCode);
		
		String instCd = InstanceCd.getInstCd(magKey, toNum.toNumber(issueNum), toNum.toNumber(issueWeek));
		
		String updateSQL = "UPDATE " + custBvTableName +  " SET  FNL_DRIVER_CD = ? " +
		" WHERE MAG_KY = ? AND INSTNC_CD = ? AND PLANT_ID = ? AND  MAG_CD = ? AND ISS_NUM = ? AND ISS_WK_NUM = ?  " +
		" AND XSHEET_BV_NME = ? " ;
		
	
		int ctr = 0;
		
		try{
			
			updateCbv = conn.prepareStatement(updateSQL);
			
		while (!((rec = rdr.readLine()) == null)) {

				if( rec.trim().length() == 0)
					continue;

				if (rec.length() < 9) continue;
				
				String aString = null;
			
				StringTokenizer tokenizer = new StringTokenizer(rec, String.valueOf(","));
				if (tokenizer.countTokens() < 2) {
					LogWriter.writeLog("Error parsing PrographDC record. Expected 2 fields, found " + tokenizer.countTokens() + ":" + rec);
					BookVersion = ("000000");
					FinalDriverCode = (new Integer(0)).intValue();
				}

				// BookVersion	
				aString = tokenizer.nextToken().trim();
				try {
					BookVersion = (aString);
				} catch (NumberFormatException ex) {
					SybilWarningException e = new SybilWarningException
							("DatabaseFileLoader: Number conversion error caused by bookversion <" +
							aString + "> in CustBV record.");
						LogWriter.writeLog(e);	
					BookVersion = ("000	000");
				}

				// Final Driver Code
				aString = tokenizer.nextToken().trim();
				try {
					FinalDriverCode = (Integer.valueOf(aString)).intValue();			} catch (NumberFormatException ex) {
					SybilWarningException e = new SybilWarningException
							("DatabaseFileLoader: Number conversion error caused by copy count <" +
								aString + "> in CustBV record.");
					LogWriter.writeLog(e);
					FinalDriverCode = (new Integer(0)).intValue();
				}

				
				updateCbv.setInt(1, FinalDriverCode);
				updateCbv.setInt(2, magKey);
				updateCbv.setString(3, instCd);
				updateCbv.setString(4, plantId);
				updateCbv.setString(5, magCode);
				updateCbv.setInt(6, toNum.toNumber(issueNum));
				updateCbv.setInt(7, toNum.toNumber(issueWeek));	
				updateCbv.setString(8, BookVersion);
				

				try{	
					updateCbv.executeUpdate();
					ctr++;
				}
				catch(Exception e) {
					LogWriter.writeLog(e);
					errorCtr++;
					LogWriter.writeLog("PrographDriverCode: Error key ... " +  plantId + " " + 
						magCode + " " + issueNum + " " + issueWeek + " " + BookVersion);
				}
			}
		st = conn.createStatement();
		st.execute(commitSQL);
		updateCbv.close();
		st.close();
		LogWriter.writeLog(mag.getPrefix() + ": PrographDriverCode: Loaded <" + ctr + "> records. no of rows updated " + ctr );
		if (ctr > 0)
			returnCode = true;
		}
		
		catch (EOFException e){
					LogWriter.writeLog(e);
				}
		catch (Exception e){
			LogWriter.writeLog(e);
		}
		close();
		return returnCode;

	}


}
