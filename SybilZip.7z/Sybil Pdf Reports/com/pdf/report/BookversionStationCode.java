package com.pdf.report;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import sybil.common.model.Magazine;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;
import sybil.common.util.StringFunctions;

import com.report.text.Document;
import com.report.text.DocumentException;
import com.report.text.Element;
import com.report.text.ExceptionConverter;
import com.report.text.Font;
import com.report.text.FontFactory;
import com.report.text.PageSize;
import com.report.text.Phrase;
import com.report.text.Rectangle;
import com.report.text.pdf.BaseFont;
import com.report.text.pdf.PdfContentByte;
import com.report.text.pdf.PdfPCell;
import com.report.text.pdf.PdfPTable;
import com.report.text.pdf.PdfPageEventHelper;
import com.report.text.pdf.PdfTemplate;
import com.report.text.pdf.PdfWriter;

public class BookversionStationCode extends PdfPageEventHelper {
	
	public static String magInfo = "TBA_MAG_INFO";

	public static String sybMag = "TBA_SYB_MAGAZINE";

	public static String magazineInf = "TBA_MAGAZINEINF";

	public static String bookVersionStationCd = "TBA_BV_STATION_CD";
	
	public static String customerBookVersion = "TBA_CUST_BV";

	private static ResultSet resultset = null;

	private static String magName = null;

	private static Connection conn = null;

	protected PdfTemplate total;

	protected BaseFont helv;
 
 	public void onOpenDocument(PdfWriter writer, Document document) {
		total = writer.getDirectContent().createTemplate(100, 100);
		total.setBoundingBox(new Rectangle(-20, -20, 100, 100));
		try {
			helv = BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI,BaseFont.NOT_EMBEDDED);
		} catch (Exception e) {
			throw new ExceptionConverter(e);
		}
	}
 
	public void onEndPage(PdfWriter writer, Document document) {
		PdfContentByte cb = writer.getDirectContent();
		cb.saveState();
		String text = "Page " + writer.getPageNumber() + " of  ";
		float textBase = document.bottom() - 15;
		float textSize = helv.getWidthPoint(text, 9);
		float textCenter = document.right()/2;
		cb.beginText();
		cb.setFontAndSize(helv, 10);

		cb.setTextMatrix(textCenter, textBase);
		cb.showText(text);
		cb.endText();
		cb.addTemplate(total, textCenter + textSize, textBase);
		cb.restoreState();
	}
 
	
	public void onCloseDocument(PdfWriter writer, Document document) {
		total.beginText();
		total.setFontAndSize(helv, 10);
		total.setTextMatrix(0, 0);
		total.showText(String.valueOf(writer.getPageNumber() - 1));
		total.endText();
	}
	
	private static void open() {

		PreparedStatement setSqlId = null;
		Statement commitSqlId = null;
		String x = null;
		String db2owner = null;
		int i = 0;
		
		String userDb = sybil.common.util.PropertyBroker.getProperty("database.login","sybil");
		String pswdDb = sybil.common.util.PropertyBroker.getProperty("database.password","sybil");
		
		
		if( conn == null) {
			try {
				Class.forName(sybil.common.util.PropertyBroker.getProperty("database.driver", "Not Found"));
				conn = DriverManager.getConnection(sybil.common.util.PropertyBroker.getProperty("database.server", "Not Found"), userDb, pswdDb);

				x = PropertyBroker.getProperty("database.driver", "Not Found").toLowerCase();
				i = x.indexOf("db2");
				if (!(i < 0)) {
					try {
						db2owner = PropertyBroker.getProperty("DB2OWNER","dtppsyup");
						setSqlId = conn.prepareStatement("set current sqlid = ?");
						setSqlId.setString(1, db2owner);
						setSqlId.execute();
						commitSqlId = conn.createStatement();
						commitSqlId.execute("commit");
					}
					catch (SQLException se) {
						if(se.getSQLState().equals("S1010")) {
						}
						else {
							LogWriter.writeLog(se);
							LogWriter.writeLog("Error: Set Current SqlId failed.");
							if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
								LogWriter.writeLog("Process terminating due to database/sql exception");
								System.exit(1);
							}
						}
					}
					catch (Exception e) {
						LogWriter.writeLog(e);
						LogWriter.writeLog("Error: Set Current SqlId failed.");
						if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
							LogWriter.writeLog("Process terminating due to database/sql exception");
							System.exit(1);
						}
					}
				}
			
			} 
			catch (Exception e) {
				sybil.common.util.LogWriter.writeLog(e);
				LogWriter.writeLog("Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
		
	return;
	}
	
	
	public static void close() {
		
		if( conn != null) {		
			try { conn.close(); }catch(Exception sql ){};
			conn = null;
		}
		return;
	}
	
	private static int magazineKey(String magazineCode){
		
		int magKey = 0;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT MAG_KEY, NAME  FROM " + sybMag + " WHERE MAG_CD = ? ";
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, magazineCode);
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			magKey  = (int)rs.getInt("MAG_KEY");
			magName = rs.getString("NAME");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Code Select error " + magazineCode);
		}
		return magKey;
	}

	
	private static String getIssueDate(Magazine mag){
		
		String issueDate = null;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT COVER_DATE FROM " + magazineInf + " WHERE PLANT = ? and MAG = ? and ISSUE = ? ";
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, mag.getPlant().toUpperCase());
		selectMag.setString(2, mag.getMagCode().toLowerCase());
		selectMag.setString(3, mag.getIssue());
		
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			issueDate  = rs.getString("COVER_DATE");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Issue Date error " + mag.getMagCode());
		}
		return issueDate;
	}

	

	
	public static synchronized void CreateStationCodePDF(Magazine mag){
		
		PreparedStatement selectSationCd = null;

		Document defDvrCdeDoc = new Document(PageSize.LETTER,-50,-50,36,36);

		boolean firstRow = true;	
		boolean firstTime = true;

		String magCode = mag.getMagCode().trim();
		String issueNum = mag.getIssue().trim();
		String issueWeek = mag.getWeek().trim();
		String plantId = mag.getPlant().toUpperCase().trim();
		
		String RptPath = sybil.common.util.PropertyBroker.getProperty("NewPDFReportsPath","Not found");
		String fileName = magCode.toLowerCase() + ".i" + issueNum + "." + plantId + ".OMS_Station_Code." + issueWeek;
		
		open();
		
		String SQL = "SELECT CUS.PREM_DRIVER_CD, CUS.FNL_DRIVER_CD,STN.LEFT_STATION,STN.RIGHT_STATION FROM " +
        " (SELECT DISTINCT MAG_KY,INSTNC_CD,ISS_NUM,ISS_WK_NUM,TAMPA_PLANT_ID, PRELIM_DRVR_CD,LEFT_STATION,RIGHT_STATION" +
        "  FROM " + bookVersionStationCd +
        "  WHERE MAG_KY = ? AND INSTNC_CD = ? AND TAMPA_PLANT_ID = ? AND ISS_NUM = ? AND ISS_WK_NUM = ?) STN Inner Join " +
        " (SELECT DISTINCT PREM_DRIVER_CD, FNL_DRIVER_CD " +
        "  FROM " + customerBookVersion +
        "  WHERE  MAG_KY = ? AND INSTNC_CD = ? AND MAG_CD = ? AND PLANT_ID = ? AND ISS_NUM = ? AND ISS_WK_NUM = ?) CUS " +
        "  ON STN.PRELIM_DRVR_CD = CUS.PREM_DRIVER_CD";

	
		LogWriter.writeLog("SQL=" + SQL);
		
		int magKey = magazineKey(magCode);
		
		String issueDate = getIssueDate(mag);
		
		String instCd = InstanceCd.getInstCd(magKey, issueDate);
		
		String plantCd = mag.getPlant().toUpperCase();
		
		try {
			
			PdfWriter writer = PdfWriter.getInstance(defDvrCdeDoc,				
					new FileOutputStream(RptPath + fileName + ".pdf"));
			

			writer.setViewerPreferences(PdfWriter.PageModeFullScreen);
			writer.setPageEvent(new BookversionStationCode());
			
			defDvrCdeDoc.open();
			
			Date toDay = new Date(); 
			SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, MMM d, yyyy, HH:mm a "); 

      		PdfPTable outertable = new PdfPTable(1);
			outertable.setHeaderRows(9);
			
			PdfPCell header0 = new PdfPCell(new Phrase(String.valueOf(dateFormat.format(toDay)),
					FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,Color.black)));
			header0.setBorderWidth(0);
			outertable.addCell(header0);
			
			String issueHdr = "Issue :" + issueDate + "(" + issueNum + " - " + issueWeek +")";
			PdfPCell issueCell = new PdfPCell(new Phrase(issueHdr,
					FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,Color.black)));
			issueCell.setBorderWidth(0);
			outertable.addCell(issueCell);
			
			PdfPCell cell1 = new PdfPCell(new Phrase(
					"Station Code Report", FontFactory.getFont(FontFactory.COURIER, 15, Font.BOLD, Color.BLACK)));
			cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell1.setBorderWidth(0);
			outertable.addCell(cell1);
									
			PdfPCell dummyCell = new PdfPCell(new Phrase("", FontFactory.getFont(
								FontFactory.COURIER, 10, Font.BOLD, Color.black)));
			dummyCell.setBorderWidth(0);
			outertable.addCell(dummyCell);

			selectSationCd = conn.prepareStatement(SQL);
			selectSationCd.setInt(1, magKey);
			selectSationCd.setString(2, instCd);
			selectSationCd.setString(3, plantCd);
			selectSationCd.setInt(4, toNum.toNumber(issueNum));
			selectSationCd.setInt(5, toNum.toNumber(issueWeek));
			selectSationCd.setInt(6, magKey);
			selectSationCd.setString(7, instCd);
			selectSationCd.setString(8, mag.getMagCode().toUpperCase());
			selectSationCd.setString(9, plantCd);
			selectSationCd.setInt(10, toNum.toNumber(issueNum));
			selectSationCd.setInt(11, toNum.toNumber(issueWeek));


					
			resultset = selectSationCd.executeQuery();
			
			while (resultset.next()){
			
				String prelimDriverCd = (new StringBuilder(String.valueOf(StringFunctions.fixSize(resultset.getString("PREM_DRIVER_CD"), 4, '0', StringFunctions.RIGHT)))).append(" ").toString();
				String finalDriverCd = (new StringBuilder(String.valueOf(StringFunctions.fixSize(resultset.getString("FNL_DRIVER_CD"), 4, '0', StringFunctions.RIGHT)))).append(" ").toString();
				String leftStationCd = resultset.getString("LEFT_STATION");
				String rightStationCd = resultset.getString("RIGHT_STATION");
				
			if (firstRow) {
				
				String header1 = "Magazine : " + magName.trim() + "                   Plant : " + plantId + "                         Issue :" + issueNum + " - " + issueWeek  ;
				PdfPCell magCell = new PdfPCell(new Phrase(header1,
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,Color.black)));
				magCell.setBorderWidth(0);
				outertable.addCell(magCell);
									
				for ( int G = 0; G <=2; G++){
					PdfPCell dummyCell1 = new PdfPCell(new Phrase("", FontFactory.getFont(
									FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					dummyCell1.setBorderWidth(0);
					outertable.addCell(dummyCell1);}	
				
				PdfPTable inertable = new PdfPTable(4);
				inertable.addCell("Preliminary Driver Code");
				inertable.addCell("Final Driver Code");
				inertable.addCell("Left Station Code");
				inertable.addCell("Right Station Code");
				PdfPCell cell9 = new PdfPCell(inertable);
				cell9.setBorderWidth(0);
				cell9.setBackgroundColor(new Color(108, 253, 206));
				outertable.addCell(cell9);
				firstRow = false;
			}				
	
			     if (firstTime){
				     firstTime = false;	
	      		 }
			     
			     String detailInfo = prelimDriverCd + "    " + AddSpace.addSpace(finalDriverCd,15,' ') + "      " + AddSpace.addSpace(leftStationCd,10,' ') + "      " + AddSpace.addSpace(rightStationCd,13,' ') ; 
			     PdfPCell detailType = new PdfPCell(
							new Phrase(detailInfo, FontFactory.getFont(FontFactory.COURIER, 12, Font.NORMAL, Color.black)));
					detailType.setBorderWidth(0);
					outertable.addCell(detailType);
		} 
			
			defDvrCdeDoc.add(outertable);
				
		} 
		catch (SQLException se) {
			System.err.println(se.getMessage());
		}
	
		catch (DocumentException de) {
			System.err.println(de.getMessage());
		} catch (IOException ioe) {
			System.err.println(ioe.getMessage());
		}			
		defDvrCdeDoc.close();
		close();
		LogWriter.writeLog(" Bookversion Station Code Report Generated " );
		return;
	}


}
