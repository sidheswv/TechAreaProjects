package com.pdf.report;

public class NumofRolls {
	String braceId;
	int numOfRolls;
	
	public NumofRolls(String braceId, int numOfRolls) {
		super();
		this.braceId = braceId;
		this.numOfRolls = numOfRolls;
	}

	public String getBraceId() {
		return braceId;
	}

	public void setBraceId(String braceId) {
		this.braceId = braceId;
	}

	public int getNumOfRolls() {
		return numOfRolls;
	}

	public void setNumOfRolls(int numOfRolls) {
		this.numOfRolls = numOfRolls;
	}
	
}
