package com.pdf.report;

import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;

public class RptChmod {

	private static Process p = null;
	
	public static void pdfChmod() {
		
			try
			{
				if( p != null) {
					p.waitFor();
				}
								
				String [] cmd = {"sh","-c",PropertyBroker.getProperty("RunPdfChmodFile", "false")};
				LogWriter.writeLog("Rpt Chmod Command " +  cmd);
				p = java.lang.Runtime.getRuntime().exec(cmd);
				
				p.waitFor();
			} 
			catch (Exception e) 
			{
					LogWriter.writeLog("com.pdf.report.RptChmod  : pdfChmod ... RunPdfChmodFile property exception");
					LogWriter.writeLog(e);
			}	
		}
}
