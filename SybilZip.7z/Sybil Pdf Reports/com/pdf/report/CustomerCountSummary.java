package com.pdf.report;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import sybil.common.model.Magazine;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;

import com.report.text.Document;
import com.report.text.DocumentException;
import com.report.text.Element;
import com.report.text.ExceptionConverter;
import com.report.text.Font;
import com.report.text.FontFactory;
import com.report.text.Phrase;
import com.report.text.Rectangle;
import com.report.text.pdf.BaseFont;
import com.report.text.pdf.PdfContentByte;
import com.report.text.pdf.PdfPCell;
import com.report.text.pdf.PdfPTable;
import com.report.text.pdf.PdfPageEventHelper;
import com.report.text.pdf.PdfTemplate;
import com.report.text.pdf.PdfWriter;

public class CustomerCountSummary extends PdfPageEventHelper {

	public static String magInfo = "TBA_MAG_INFO";

	public static String sybMag = "TBA_SYB_MAGAZINE";

	public static String magazineInf = "TBA_MAGAZINEINF";

	private static ResultSet resultset = null;

	private static Connection conn = null;

	protected PdfTemplate total;

	protected BaseFont helv;
 
 	public void onOpenDocument(PdfWriter writer, Document document) {
		total = writer.getDirectContent().createTemplate(100, 100);
		total.setBoundingBox(new Rectangle(-20, -20, 100, 100));
		try {
			helv = BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI,BaseFont.NOT_EMBEDDED);
		} catch (Exception e) {
			throw new ExceptionConverter(e);
		}
	}
 
	public void onEndPage(PdfWriter writer, Document document) {
		PdfContentByte cb = writer.getDirectContent();
		cb.saveState();
		String text = "Page " + writer.getPageNumber() + " of  ";
		float textBase = document.bottom() - 15;
		float textSize = helv.getWidthPoint(text, 9);
		float textCenter = document.right()/2;
		cb.beginText();
		cb.setFontAndSize(helv, 10);

		cb.setTextMatrix(textCenter, textBase);
		cb.showText(text);
		cb.endText();
		cb.addTemplate(total, textCenter + textSize, textBase);
		cb.restoreState();
	}
 	
	public void onCloseDocument(PdfWriter writer, Document document) {
		total.beginText();
		total.setFontAndSize(helv, 10);
		total.setTextMatrix(0, 0);
		total.showText(String.valueOf(writer.getPageNumber() - 1));
		total.endText();
	}
	
	private static void open() {

		PreparedStatement setSqlId = null;
		Statement commitSqlId = null;
		String x = null;
		String db2owner = null;
		int i = 0;
		
		String userDb = sybil.common.util.PropertyBroker.getProperty("database.login","sybil");
		String pswdDb = sybil.common.util.PropertyBroker.getProperty("database.password","sybil");
		
		
		if( conn == null) {
			try {
				Class.forName(sybil.common.util.PropertyBroker.getProperty("database.driver", "Not Found"));
				conn = DriverManager.getConnection(sybil.common.util.PropertyBroker.getProperty("database.server", "Not Found"), userDb, pswdDb);

				//
				x = PropertyBroker.getProperty("database.driver", "Not Found").toLowerCase();
				i = x.indexOf("db2");
				if (!(i < 0)) {
					try {
						db2owner = PropertyBroker.getProperty("DB2OWNER","dtppsyup");
						setSqlId = conn.prepareStatement("set current sqlid = ?");
						setSqlId.setString(1, db2owner);
						setSqlId.execute();
						commitSqlId = conn.createStatement();
						commitSqlId.execute("commit");
					}
					catch (SQLException se) {
						if(se.getSQLState().equals("S1010")) {
						}
						else {
							LogWriter.writeLog(se);
							LogWriter.writeLog("Error: Set Current SqlId failed.");
							if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
								LogWriter.writeLog("Process terminating due to database/sql exception");
								System.exit(1);
							}
						}
					}
					catch (Exception e) {
						LogWriter.writeLog(e);
						LogWriter.writeLog("Error: Set Current SqlId failed.");
						if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
							LogWriter.writeLog("Process terminating due to database/sql exception");
							System.exit(1);
						}
					}
				}
			
			} 
			catch (Exception e) {
				sybil.common.util.LogWriter.writeLog(e);
				LogWriter.writeLog("Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
		
	return;
	}
	

	private static String getIssueDate(Magazine mag){
		
		String issueDate = null;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT COVER_DATE FROM " + magazineInf + " WHERE PLANT = ? and MAG = ? and ISSUE = ? ";
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, mag.getPlant().toUpperCase());
		selectMag.setString(2, mag.getMagCode().toLowerCase());
		selectMag.setString(3, mag.getIssue());
		
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			issueDate  = rs.getString("COVER_DATE");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Issue Date error " + mag.getMagCode());
		}  finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectMag != null) {
				try {
					selectMag.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		return issueDate;
	}

		
	public static synchronized void CreatePDF(Magazine mag) {
		
		
		PreparedStatement selectCCSCnt = null;
		Document ccDoc = new Document();
		boolean noCCCount = true;
		boolean firstRow = true;
		String magazineName = null;
		
		String magCode = mag.getMagCode().trim();
		String issueNum = mag.getIssue().trim();
		String plantId = mag.getPlant().toUpperCase().trim();
		String issueWeek = mag.getWeek().trim();		
		String dataType = mag.getDataType();
		
		String RptPath = sybil.common.util.PropertyBroker.getProperty("NewPDFReportsPath","Not found");
		String fileName = magCode.toLowerCase() + ".i" + issueNum + "." + plantId + ".Customer_Count_Summary." + issueWeek;
		
		open();
		
		String SQL = "Select MIA.ROLLID, MIA.COPY_CNT, SYM.NAME from "
			+ magInfo  +  "   MIA ," +  sybMag + "   SYM"
			+ " WHERE MIA.PLANT = ? and MIA.MAG = ? and MIA.ISSUE = ? and MIA.WEEK_NUM = ? and MIA.DATA_TYPE = ? and MIA.DELIVERY_TYPE = 'usps' and MIA.PROCESS_TYPE = 'strip' and MIA.MAG = SYM.MAG_CD " 
			+ "ORDER BY MIA.ROLLID";
		

		String issueDate = getIssueDate(mag);
		
		try {
		
			PdfWriter writer = PdfWriter.getInstance(ccDoc,				
					new FileOutputStream(RptPath + fileName + ".pdf"));
			
			writer.setViewerPreferences(PdfWriter.PageModeFullScreen);
			writer.setPageEvent(new CustomerCountSummary());
			
			ccDoc.open();
			
			Date toDay = new Date(); 
			SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, MMM d, yyyy, HH:mm a "); 
			
			
			PdfPTable outertable = new PdfPTable(1);
			outertable.setHeaderRows(5);
			
			PdfPCell header0 = new PdfPCell(new Phrase(String.valueOf(dateFormat.format(toDay)),
					FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,
							Color.black)));
			header0.setBorderWidth(0);
			outertable.addCell(header0);
							
			outertable.setSplitLate(false);
			
			PdfPCell cell1 = new PdfPCell(new Phrase("Customer Count Summary", FontFactory.getFont(FontFactory.TIMES_ROMAN, 24, Font.BOLD, Color.BLACK)));
			cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell1.setBorderWidth(0);
			outertable.addCell(cell1);		
			outertable.completeRow();
			
			selectCCSCnt = conn.prepareStatement(SQL);
			
			selectCCSCnt.setString(1, plantId);
			selectCCSCnt.setString(2, magCode);
			selectCCSCnt.setString(3, issueNum);
			selectCCSCnt.setString(4, issueWeek);
			selectCCSCnt.setString(5,dataType.trim());
			resultset = selectCCSCnt.executeQuery();
			
			
			while (resultset.next()){
				noCCCount = false;
			String RollNum  = resultset.getString("ROLLID");
			String copyCount = resultset.getString("COPY_CNT");
			magazineName = resultset.getString("NAME");
			
			if (firstRow){			
			String header1 = "Magazine  : " + magazineName + " " + "Plant : " + plantId ;
			PdfPCell magCell = new PdfPCell(new Phrase(header1,
					FontFactory.getFont(FontFactory.COURIER, 12, Font.NORMAL,Color.black)));
							
			magCell.setBorderWidth(0);
			outertable.addCell(magCell);
			
			String issueheader =  "Issue     : " +  issueDate + " (" + issueNum + " - " + issueWeek + ")";
			PdfPCell issueCell = new PdfPCell(new Phrase(issueheader,
					FontFactory.getFont(FontFactory.COURIER, 12, Font.NORMAL,Color.black)));
							
			issueCell.setBorderWidth(0);
			outertable.addCell(issueCell);
			
			String header2 = "          "  + "Rollid " + "              " + " Strip Copies";
			PdfPCell fileType = new PdfPCell(
					new Phrase(header2, FontFactory.getFont(
							FontFactory.COURIER, 12, Font.BOLD, Color.black)));
			
			fileType.setBackgroundColor(new Color(251, 101, 64));
			fileType.setBorderWidth(0);
			
			outertable.addCell(fileType);						
			outertable.setWidthPercentage(100);
			firstRow = false;
			}

			String detailInfo = "          " + RollNum  + "                  " +  AddSpace.addSpace(PlaceComma.placeComma(Integer.valueOf(copyCount).intValue()),9);
			PdfPCell detailType = new PdfPCell(
			new Phrase(detailInfo, FontFactory.getFont(
								FontFactory.COURIER, 12, Font.NORMAL, Color.black)));
//			detailType.setHorizontalAlignment(Element.ALIGN_RIGHT);	
			detailType.setBorderWidth(0);
				
			outertable.addCell(detailType);
			}
			if (noCCCount){
//			LogWriter.writeLog("	No records from the query  "  );
			String header1 = "Mag : " + mag.getMagCode() + " " + "Plant : " + plantId + " " + "Issue :" +  issueDate + " - " + issueNum + " - " + issueWeek;
			PdfPCell magCell = new PdfPCell(new Phrase(header1,
					FontFactory.getFont(FontFactory.COURIER, 12, Font.BOLD,
							Color.black)));
			magCell.setBorderWidth(0);
			outertable.addCell(magCell);
			
			String header2 = "    " + "Rollid " + "            " + " Strip Copies";
			PdfPCell fileType = new PdfPCell(
					new Phrase(header2, FontFactory.getFont(
							FontFactory.COURIER, 12, Font.BOLD, Color.black)));
			
			fileType.setBackgroundColor(new Color(251, 101, 64));
			fileType.setBorderWidth(0);
			outertable.addCell(fileType);						
			outertable.setWidthPercentage(100);
			
			for ( int G = 0; G <=2; G++){
				PdfPCell dummyCell = new PdfPCell(new Phrase("", FontFactory.getFont(
								FontFactory.COURIER, 10, Font.BOLD, Color.black)));
				dummyCell.setBorderWidth(0);
				outertable.addCell(dummyCell);}
			}
			ccDoc.add(outertable);
		}
		catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("	SQL Exception  "  );
		}
		 catch (DocumentException de) {
			System.err.println(de.getMessage());
			LogWriter.writeLog("	Document Exception  "  );
		} catch (IOException ioe) {
			System.err.println(ioe.getMessage());
			LogWriter.writeLog("	IO expection  "  );
		} finally {
			if (resultset != null) {
				try {
					resultset.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectCCSCnt != null) {
				try {
					selectCCSCnt.close();
				} catch (SQLException e) { /* ignored */}
			} 
		}
 
		ccDoc.close();
		LogWriter.writeLog("Customer Count Summary Report Generated "  );
		
		return;
	}


}
