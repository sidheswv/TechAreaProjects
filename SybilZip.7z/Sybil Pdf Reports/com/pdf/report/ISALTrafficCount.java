package com.pdf.report;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import sybil.common.model.Magazine;
import sybil.common.util.LogWriter;
import sybil.common.util.SybilWarningException;

import com.report.text.Document;
import com.report.text.DocumentException;
import com.report.text.Element;
import com.report.text.ExceptionConverter;
import com.report.text.Font;
import com.report.text.FontFactory;
import com.report.text.Phrase;
import com.report.text.Rectangle;
import com.report.text.pdf.BaseFont;
import com.report.text.pdf.PdfContentByte;
import com.report.text.pdf.PdfPCell;
import com.report.text.pdf.PdfPTable;
import com.report.text.pdf.PdfPageEventHelper;
import com.report.text.pdf.PdfTemplate;
import com.report.text.pdf.PdfWriter;

public class ISALTrafficCount extends PdfPageEventHelper {

	private static final int POS_ISAL_MAG = 0;

	private static final int POS_ISAL_COVER_DATE = 41;

	private static final int POS_ISAL_DEST_3DIG = 153;

	private static final int POS_ISAL_DEST_TRAF6 = 162;

	private static final int POS_ISAL_DEST = 169;

	private static final int POS_ISAL_DEST_CUST_COUNT = 200;
	
	protected PdfTemplate total;
	
 	protected BaseFont helv;
 
 	public void onOpenDocument(PdfWriter writer, Document document) {
		total = writer.getDirectContent().createTemplate(100, 100);
		total.setBoundingBox(new Rectangle(-20, -20, 100, 100));
		try {
			helv = BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI,BaseFont.NOT_EMBEDDED);
		} catch (Exception e) {
			throw new ExceptionConverter(e);
		}
	}
 
	public void onEndPage(PdfWriter writer, Document document) {
		PdfContentByte cb = writer.getDirectContent();
		cb.saveState();
		String text = "Page " + writer.getPageNumber() + " of  ";
		float textBase = document.bottom() - 15;
		float textSize = helv.getWidthPoint(text, 9);
		float textCenter = document.right()/2;
		cb.beginText();
		cb.setFontAndSize(helv, 10);

		cb.setTextMatrix(textCenter, textBase);
		cb.showText(text);
		cb.endText();
		cb.addTemplate(total, textCenter + textSize, textBase);
		cb.restoreState();
	}
 
	
	public void onCloseDocument(PdfWriter writer, Document document) {
		total.beginText();
		total.setFontAndSize(helv, 10);
		total.setTextMatrix(0, 0);
		total.showText(String.valueOf(writer.getPageNumber() - 1));
		total.endText();
	}


	public static synchronized void CreatePDF(BufferedReader rdr, Magazine mag){	
		
		Document isalDoc = new Document();
		String rec = null;
	
		boolean firstEntry = true, firstTime = true;
		int TotCusts = 0;
		int totalCopyCount = 0;
		String save3Dig = " ";
		
		String magCode = mag.getMagCode().trim();
		String issueNum = mag.getIssue().trim();
		String plantId = mag.getPlant().toUpperCase().trim();
		String issueWeek = mag.getWeek().trim();
		
		String RptPath = sybil.common.util.PropertyBroker.getProperty("NewPDFReportsPath","Not found");
		String fileName = magCode.toLowerCase() + ".i" + issueNum + "." + plantId + ".OMS_ISAL_Traffic_Count." + issueWeek;
		
		try {
		
			PdfWriter writer = PdfWriter.getInstance(isalDoc,				
					new FileOutputStream(RptPath + fileName + ".pdf"));
			
			writer.setViewerPreferences(PdfWriter.PageModeFullScreen);
			writer.setPageEvent(new ISALTrafficCount());
								
			isalDoc.open();
			
			Date toDay = new Date(); 
			SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, MMM d, yyyy, HH:mm a "); 
			
			
			PdfPTable outertable = new PdfPTable(1);
			outertable.setHeaderRows(5);
			
			PdfPCell header0 = new PdfPCell(new Phrase(String.valueOf(dateFormat.format(toDay)),
					FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,Color.black)));
			header0.setBorderWidth(0);
			outertable.addCell(header0);
			outertable.setSplitLate(false);
			
			PdfPCell title = new PdfPCell(new Phrase("ISAL Traffic Counts", FontFactory.getFont(FontFactory.TIMES_ROMAN, 14, Font.BOLD, Color.BLACK)));					
			title.setHorizontalAlignment(Element.ALIGN_CENTER);
			title.setBorderWidth(0);
			outertable.addCell(title);
			
			
			while (!((rec = rdr.readLine()) == null)) {
				
				if( rec.trim().length() == 0)
					continue;
					
				if (rec.length() < 9) continue;

				String aString = null;

				String magName = (rec.substring(POS_ISAL_MAG, POS_ISAL_MAG+25));
				String CoverDate = (rec.substring(POS_ISAL_COVER_DATE, POS_ISAL_COVER_DATE+10));
				String Dest3Dig = (rec.substring(POS_ISAL_DEST_3DIG, POS_ISAL_DEST_3DIG+3));
				String DestTraf6 = (rec.substring(POS_ISAL_DEST_TRAF6, POS_ISAL_DEST_TRAF6+6));
				String Dest = (rec.substring(POS_ISAL_DEST, POS_ISAL_DEST+30));
		
				aString = rec.substring(POS_ISAL_DEST_CUST_COUNT, POS_ISAL_DEST_CUST_COUNT+9);

				
				try {
					TotCusts = (Integer.valueOf(aString)).intValue();
				} catch (NumberFormatException ex) {
					SybilWarningException e = new SybilWarningException
							("MailDatLoader: Number conversion error caused by # custs <" +
								aString + "> in ISAL Rpt record.");
					LogWriter.writeLog(e);
				}
				
				if (firstEntry){
					firstEntry = false;				
					String header1 =  "Magazine    : " + magName.trim() + "           " + "Plant : " + plantId ;
					PdfPCell magCell = new PdfPCell(new Phrase(header1,FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Font.BOLD,Color.black)));
					magCell.setBorderWidth(0);
					outertable.addCell(magCell);
					
					String header01 = "Cover Date : " + CoverDate + "                        Issue : " + issueNum + " - " + issueWeek;
					PdfPCell issueCell = new PdfPCell(new Phrase(header01,FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Font.BOLD,Color.black)));
					issueCell.setBorderWidth(0);
					outertable.addCell(issueCell);
				
					String header2 = "Traffic Code " +  "          " + "Customer Count " +  "      " + " City/Country";
					PdfPCell fileType = new PdfPCell(new Phrase(header2, FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD, Color.black)));
					fileType.setBorderWidth(0);
					outertable.addCell(fileType);
					}
				
								
				if (Dest3Dig.compareTo(save3Dig) == 0 ){
				
				String detailInfo = DestTraf6  + "                               " + TotCusts + "                                 "  +  Dest;
				PdfPCell detailType = new PdfPCell(new Phrase(detailInfo, FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Font.NORMAL, Color.black)));				
				detailType.setBorderWidth(0);
				outertable.addCell(detailType);
				totalCopyCount += TotCusts;
				}
				else{	
					if (firstTime){
						firstTime = false;
					}
					else {
						
						for ( int s = 0; s <=1; s++){
						PdfPCell dummyCell = new PdfPCell(new Phrase("", FontFactory.getFont(
									FontFactory.COURIER, 10, Font.BOLD, Color.black)));
						dummyCell.setBorderWidth(0);
						outertable.addCell(dummyCell);}
						String totalInfo = save3Dig + " Total: " + "       " +  totalCopyCount;
						PdfPCell detailType = new PdfPCell(new Phrase(totalInfo, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));			
						detailType.setBorderWidth(0);
						outertable.addCell(detailType);
						totalCopyCount = 0;
						for ( int s = 0; s <=1; s++){
						PdfPCell dummyCell = new PdfPCell(new Phrase("", FontFactory.getFont(
									FontFactory.COURIER, 10, Font.BOLD, Color.black)));
						dummyCell.setBorderWidth(0);
						outertable.addCell(dummyCell);}
					}
					
				save3Dig = Dest3Dig;	
				
				totalCopyCount += TotCusts; 
				String detailInfo = DestTraf6  + "                               " + TotCusts + "                                 "  +  Dest;
				PdfPCell detailinfo = new PdfPCell(new Phrase(detailInfo, FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Font.NORMAL, Color.black)));				
				detailinfo.setBorderWidth(0);
				outertable.addCell(detailinfo);
				}			
			}
			
			isalDoc.add(outertable);
		} catch (DocumentException de) {
			System.err.println(de.getMessage());
		} catch (IOException ioe) {
			System.err.println(ioe.getMessage());
		}
 		
		isalDoc.close();
		
		return;
	}	

}
