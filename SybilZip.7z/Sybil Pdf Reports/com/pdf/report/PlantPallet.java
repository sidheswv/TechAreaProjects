package com.pdf.report;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import sybil.common.model.Magazine;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;

import com.report.text.Document;
import com.report.text.DocumentException;
import com.report.text.Element;
import com.report.text.ExceptionConverter;
import com.report.text.Font;
import com.report.text.FontFactory;
import com.report.text.PageSize;
import com.report.text.Phrase;
import com.report.text.Rectangle;
import com.report.text.pdf.BaseFont;
import com.report.text.pdf.PdfContentByte;
import com.report.text.pdf.PdfPCell;
import com.report.text.pdf.PdfPTable;
import com.report.text.pdf.PdfPageEventHelper;
import com.report.text.pdf.PdfTemplate;
import com.report.text.pdf.PdfWriter;


	public class PlantPallet extends PdfPageEventHelper {	
	
	public static String pkgsum = "TBA_PKG_SUM";
	
	public static String cntnrInfo = "TBA_CNTNR_INFO";

	public static String rollsum = "TBA_ROLL_SUM";

	public static String magazineInf = "TBA_MAGAZINEINF";

	public static String sybMag = "TBA_SYB_MAGAZINE";

	public static String sybplant = "TBA_SYB_PLANT";

	public static String cnsolParm = "TBA_CNSOL_STYP_PARM";

	public static String pstlParm = "TBA_PSTL_PARM";
	
	public static String cntnrLvlParm = "TBA_CNTNR_LVL_PARM";

	private static Connection conn = null;
	
	private static int magKey = 0;
	
	private static String instCd = null;

	private static ResultSet resultset = null;

	private static String magName = null;
	
	private static int [] cstTablew = {20,2,2,2,2,2,2,2};
		
	private static final Font  TIMESNORAML_12 = FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.NORMAL,Color.black);
	
	private static final Font  TIMESBOLD_12 = FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,Color.black);
	
	private static final Font  TIMESBOLD_10 = FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Font.BOLD, Color.black);
	
	private static final Font  COURIERNORMAL_12 = FontFactory.getFont(FontFactory.COURIER, 12, Font.NORMAL,Color.black);
	
	private static String magCode = null;
	
	private static String issueNum = null;
	
	private static String plantId = null;
	
	private static String issueWeek = null;
	
	private static String issueDate = null;
	
	private static String plantName = null;
	
	protected PdfTemplate total;

	protected BaseFont helv;
	
	public void onOpenDocument(PdfWriter writer, Document document) {
		total = writer.getDirectContent().createTemplate(100, 100);
		total.setBoundingBox(new Rectangle(-10, -10, 80, 80));
		try {
			helv = BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI,
					BaseFont.NOT_EMBEDDED);
		} catch (Exception e) {
			throw new ExceptionConverter(e);
		}
	}
	
	public void onEndPage(PdfWriter writer, Document document) {
		PdfContentByte cb = writer.getDirectContent();
		cb.saveState();
		String text = "Page " + writer.getPageNumber() ;
		float textBase = document.top() - 20;
		cb.beginText();
		cb.setFontAndSize(helv, 10);
		
		cb.setTextMatrix(document.left()+ 780, textBase);
		cb.showText(text);
		cb.endText();
		
		cb.restoreState();
	}
	
	public void onCloseDocument(PdfWriter writer, Document document) {
		total.beginText();
		total.setFontAndSize(helv, 12);
		total.setTextMatrix(0, 0);
		total.showText(String.valueOf(writer.getPageNumber() - 1));
		total.endText();
	}
	
	private static void initialize(Magazine mag){
		magCode = mag.getMagCode().trim();
		issueNum = mag.getIssue().trim();
		plantId = mag.getPlant().toUpperCase().trim();
		issueWeek = mag.getWeek().trim();		
	}
	
	private static void open() {

		PreparedStatement setSqlId = null;
		Statement commitSqlId = null;
		String x = null;
		String db2owner = null;
		int i = 0;

		String userDb = sybil.common.util.PropertyBroker.getProperty(
				"database.login", "sybil");
		String pswdDb = sybil.common.util.PropertyBroker.getProperty(
				"database.password", "sybil");

		if (conn == null) {
			try {
				Class.forName(sybil.common.util.PropertyBroker.getProperty(
						"database.driver", "Not Found"));
				conn = DriverManager
						.getConnection(sybil.common.util.PropertyBroker
								.getProperty("database.server", "Not Found"),
								userDb, pswdDb);

				//
				x = PropertyBroker.getProperty("database.driver", "Not Found")
						.toLowerCase();
				i = x.indexOf("db2");
				if (!(i < 0)) {
					try {
						db2owner = PropertyBroker.getProperty("DB2OWNER",
								"dtppsyup");
						setSqlId = conn
								.prepareStatement("set current sqlid = ?");
						conn.setAutoCommit(false);
						setSqlId.setString(1, db2owner);
						setSqlId.execute();
						commitSqlId = conn.createStatement();
						commitSqlId.execute("commit");
					} catch (SQLException se) {
						if (se.getSQLState().equals("S1010")) {
						} else {
							LogWriter.writeLog(se);
							LogWriter
									.writeLog("Error: Set Current SqlId failed.");
							if (PropertyBroker.getProperty(
									"AllowDatabaseErrors", "false").equals(
									"false")) {
								LogWriter
										.writeLog("Process terminating due to database/sql exception");
								System.exit(1);
							}
						}
					} catch (Exception e) {
						LogWriter.writeLog(e);
						LogWriter.writeLog("Error: Set Current SqlId failed.");
						if (PropertyBroker.getProperty("AllowDatabaseErrors",
								"false").equals("false")) {
							LogWriter
									.writeLog("Process terminating due to database/sql exception");
							System.exit(1);
						}
					}
				}

			} catch (Exception e) {
				sybil.common.util.LogWriter.writeLog(e);
				LogWriter
						.writeLog("Process terminating due to database/sql exception");
				System.exit(1);
			}
		}

		return;
	}
		

		private static String getIssueDate() {

		String issueDate = null;
		PreparedStatement selectMag = null;
		ResultSet rs = null;

		String SQL = "SELECT COVER_DATE FROM " + magazineInf
				+ " WHERE PLANT = ? and MAG = ? and ISSUE = ? ";

		try {
			
			selectMag = conn.prepareStatement(SQL);
			selectMag.setString(1, plantId.toUpperCase());
			selectMag.setString(2, magCode.toLowerCase());
			selectMag.setString(3, issueNum);

			rs = selectMag.executeQuery();

			while (rs.next()) {
				issueDate = rs.getString("COVER_DATE");
			}
		} catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Issue Date error " + magCode);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectMag != null) {
				try {
					selectMag.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		return issueDate;
	}

		private static String getPlantName(String plantId) {

		String plantName = null;
		PreparedStatement selectPlant = null;
		ResultSet rs = null;

		String SQL = "SELECT NAME FROM " + sybplant + " WHERE PLANT_ID = ? ";

		try {
			selectPlant = conn.prepareStatement(SQL);
			selectPlant.setString(1, plantId);

			rs = selectPlant.executeQuery();

			while (rs.next()) {
				plantName = rs.getString("NAME");
			}
		} catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Plant name error " + plantId);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectPlant != null) {
				try {
					selectPlant.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		return plantName;
	}
		
		private static int magazineKey(String magazineCode) {

		int magKey = 0;
		PreparedStatement selectMag = null;
		ResultSet rs = null;

		String SQL = "SELECT MAG_KEY, NAME  FROM " + sybMag
				+ " WHERE MAG_CD = ? ";

		try {
			selectMag = conn.prepareStatement(SQL);
			selectMag.setString(1, magazineCode);
			rs = selectMag.executeQuery();

			while (rs.next()) {
				magKey = (int) rs.getInt("MAG_KEY");
				magName = rs.getString("NAME");
			}
		} catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Code Select error " + magazineCode);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectMag != null) {
				try {
					selectMag.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		return magKey;
	}
		
	
		private static PdfPCell totDophdr() {

		PdfPCell totdopCell1 = null;
		try {
			int[] totdopw = { 7, 9, 9, 5, 6, 6, 6 };
			PdfPTable totdopable1 = new PdfPTable(7);
			totdopable1.getDefaultCell().setHorizontalAlignment(
					Element.ALIGN_CENTER);
			totdopable1.getDefaultCell().setBorder(
					Rectangle.NO_BORDER | Rectangle.BOTTOM);
			totdopable1.getDefaultCell().setBorderWidthBottom(1);
			totdopable1.getDefaultCell().setPaddingBottom(5);
			totdopable1.setWidths(totdopw);
			totdopable1.addCell(new Phrase("P.O.E / Drop-Off Total",TIMESBOLD_10));
			totdopable1.addCell(new Phrase("Copies", TIMESBOLD_10));
			totdopable1.addCell(new Phrase("Weight", TIMESBOLD_10));
			totdopable1.addCell(new Phrase("Packages", TIMESBOLD_10));
			totdopable1.addCell(new Phrase(" Full Pallets", TIMESBOLD_10));
			totdopable1.addCell(new Phrase("Top Pallets", TIMESBOLD_10));
			totdopable1.addCell(new Phrase("Total Containers", TIMESBOLD_10));

			totdopCell1 = new PdfPCell(totdopable1);
			totdopCell1.setHorizontalAlignment(Element.ALIGN_CENTER);
			totdopCell1.setBorderWidth(0);

		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return totdopCell1;
	}
		
		private static PdfPCell totBindGrphdr() {
		PdfPCell totBindGrpCell1 = null;
		try {
			int[] totBindGrpw = { 7, 9, 9, 5, 6, 6, 6 };
			PdfPTable totBindGrpable1 = new PdfPTable(7);
			totBindGrpable1.getDefaultCell().setHorizontalAlignment(
					Element.ALIGN_CENTER);
			totBindGrpable1.getDefaultCell().setBorder(
					Rectangle.NO_BORDER | Rectangle.BOTTOM);
			totBindGrpable1.getDefaultCell().setBorderWidthBottom(1);
			totBindGrpable1.getDefaultCell().setPaddingBottom(5);
			totBindGrpable1.setWidths(totBindGrpw);
			totBindGrpable1.addCell(new Phrase("Bind Group Totals", TIMESBOLD_10));
			totBindGrpable1.addCell(new Phrase("Copies", TIMESBOLD_10));
			totBindGrpable1.addCell(new Phrase("Weight", TIMESBOLD_10));					
			totBindGrpable1.addCell(new Phrase("Packages", TIMESBOLD_10));					
			totBindGrpable1.addCell(new Phrase(" Full Pallets", TIMESBOLD_10));					
			totBindGrpable1.addCell(new Phrase("Top Pallets", TIMESBOLD_10));					
			totBindGrpable1.addCell(new Phrase("Total Containers", TIMESBOLD_10));
					
			totBindGrpCell1 = new PdfPCell(totBindGrpable1);
			totBindGrpCell1.setHorizontalAlignment(Element.ALIGN_CENTER);
			totBindGrpCell1.setBorderWidth(0);

		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return totBindGrpCell1;
	}
		
		private static PdfPCell totBracehdr() {
		PdfPCell totBraceCell1 = null;
		try {
			int[] totBracew = { 7, 9, 9, 5, 6, 6, 6 };
			PdfPTable totBraceable1 = new PdfPTable(7);
			totBraceable1.getDefaultCell().setHorizontalAlignment(
					Element.ALIGN_CENTER);
			totBraceable1.getDefaultCell().setBorder(
					Rectangle.NO_BORDER | Rectangle.BOTTOM);
			totBraceable1.getDefaultCell().setBorderWidthBottom(1);
			totBraceable1.getDefaultCell().setPaddingBottom(5);
			totBraceable1.setWidths(totBracew);
			totBraceable1.addCell(new Phrase("Brace Totals", TIMESBOLD_10));
			totBraceable1.addCell(new Phrase("Copies", TIMESBOLD_10));
			totBraceable1.addCell(new Phrase("Weight", TIMESBOLD_10));
			totBraceable1.addCell(new Phrase("Packages", TIMESBOLD_10));
			totBraceable1.addCell(new Phrase(" Full Pallets", TIMESBOLD_10));
			totBraceable1.addCell(new Phrase("Top Pallets", TIMESBOLD_10));
			totBraceable1.addCell(new Phrase("Total Containers", TIMESBOLD_10));

			totBraceCell1 = new PdfPCell(totBraceable1);
			totBraceCell1.setHorizontalAlignment(Element.ALIGN_CENTER);
			totBraceCell1.setBorderWidth(0);

		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return totBraceCell1;
	}
		
		private static PdfPCell plantTotHdr() {
			PdfPCell totBraceCell1 = null;
			try {
				int[] totBracew = { 7, 9, 9, 5, 6, 6, 6 };
				PdfPTable totBraceable1 = new PdfPTable(7);
				totBraceable1.getDefaultCell().setHorizontalAlignment(
						Element.ALIGN_CENTER);
				totBraceable1.getDefaultCell().setBorder(
						Rectangle.NO_BORDER | Rectangle.BOTTOM);
				totBraceable1.getDefaultCell().setBorderWidthBottom(1);
				totBraceable1.getDefaultCell().setPaddingBottom(5);
				totBraceable1.setWidths(totBracew);
				totBraceable1.addCell(new Phrase("Plant Totals", TIMESBOLD_10));						
				totBraceable1.addCell(new Phrase("Copies", TIMESBOLD_10));						
				totBraceable1.addCell(new Phrase("Weight", TIMESBOLD_10));						
				totBraceable1.addCell(new Phrase("Packages", TIMESBOLD_10));						
				totBraceable1.addCell(new Phrase(" Full Pallets", TIMESBOLD_10));						
				totBraceable1.addCell(new Phrase("Top Pallets", TIMESBOLD_10));						
				totBraceable1.addCell(new Phrase("Total Containers", TIMESBOLD_10));

				totBraceCell1 = new PdfPCell(totBraceable1);
				totBraceCell1.setHorizontalAlignment(Element.ALIGN_CENTER);
				totBraceCell1.setBorderWidth(0);

			} catch (Exception e) {
				System.err.println(e.getMessage());
			}
			return totBraceCell1;
		}

		
		private synchronized static void createPDF(String jobId, String rptType){
	
		PreparedStatement selectcopyCnt = null;
		PdfPTable outertable = null;
		Document pprDoc = new Document(PageSize.LETTER.rotate(), -80, -80, 0, 0);
		boolean noPlantPallet = false;

		ArrayList pkgElemList = new ArrayList();

		PlantpkgElem pkgElm = new PlantpkgElem();

		NumberFormat nf = NumberFormat.getInstance(Locale.US);

		String saveBraceId = " ";
		String saveDropOffPt = " ";
		String saveCnsolType = " ";
		String saveBindGrpName = " ";
		String savePalletNum = " ";
		String savePalletInd = " ";
		String saveEntryPointLine = " ";
		String bvVersion = null;
		String saveBvVersion = " ";
		
		int pageLine = 0;

		int dopPackge = 0;
		int dopCopies = 0;
		int dopTop = 0;
		int dopFull = 0;
		int dopSackCopies = 0;
		int dopAirboxCopies = 0;
		double dopSackWght = 0;
		double dopAirboxWght = 0;
		double dopWeight = 0;
		int dopSakCont = 0;
		int dopAirboxCont = 0;
		String topFull = null;

		int bgtPalCopies = 0;
		int bgtPalPackage = 0;
		double bgtPalWeight = 0;
		int bgtSakCopies = 0;
		int bgtSakPackage = 0;
		double bgtSakWeight = 0;
		int bgtAirboxCopies = 0;
		int bgtAirboxPackage = 0;
		double bgtAirboxWeight = 0;
		int bgttop = 0;
		int bgtFull = 0;
		int bgtPalCont = 0;
		int bgtSakCont = 0;
		int bgtAirboxCont = 0;

		int bracePalCopies = 0;
		int bracePalPackage = 0;
		double bracePalWeight = 0;
		int braceSakCopies = 0;
		int braceSakPackage = 0;
		double braceSakWeight = 0;
		int braceAirboxCopies = 0;
		int braceAirboxPackage = 0;
		double braceAirboxWeight = 0;
		int braceTop = 0;
		int braceFull = 0;
		int bracePalCont = 0;
		int braceSakCont = 0;
		int braceAirboxCont = 0;
		
		int plantPalCopies = 0;
		int plantPalPackage = 0;
		double plantPalWeight = 0;
		int plantSakCopies = 0;
		int plantSakPackage = 0;
		double plantSakWeight = 0;
		int plantAirboxCopies = 0;
		int plantAirboxPackage = 0;
		double plantAirboxWeight = 0;
		int plantTop = 0;
		int plantFull = 0;
		int plantPalCont = 0;
		int plantSakCont = 0;
		int plantAirboxCont = 0;

		boolean grpByBv = true;	
		boolean firstRpt = true;

		int[] dopdispw = { 7, 9, 9, 5, 6, 6, 6 };

		int totCopyCnt = 0;
		double totpkgWght = 0.0;
		int totnumPkg = 0;
		int dopSackPackge = 0;
		int dopAirboxPackge = 0;

			
		String RptPath = sybil.common.util.PropertyBroker.getProperty("NewPDFReportsPath","Not found");
		String fileName = magCode.toLowerCase() + ".i" + issueNum + "." + plantId + ".OMS_Plant_Pallet." + issueWeek + "." + rptType ;
		
		String deliveryType = rptType.trim() + " Delivery"; 
				
			open();
			
			String SQL = " select A.MAG_KY, A.PLANT_ID, A.MAG_CD, A.ISS_NUM, A.ISS_WK_NUM, A.PAL_SACK_IND, A.PAL_SACK_NUM,  "
						+ "  A.PKG_NUM_LOW, A.PKG_NUM_HI, A.NUM_PKG, A.LOW_ZIP, A.HIGH_ZIP, B.GEO_CAT_ID, B.XSHEET_BV_NME,   "
						+ "  A.PKG_WGHT, A.COPY_CNT, A.ROLL_NUM, B.BRACE_ID, B.DROP_OFF_PT, B.BIND_GRP_NME, B.BRACE_NME, B.CARR_NME,	"
						+ "  B.DEPART_DT, B.DEPART_TIME, B.ARRVL_DT, B.ARRVL_TIME, C.DEST_LINE1, C.ENTRY_POINT_LINE, D.CNSOL_SUB_TYP_DESC,  "
						+ "  E.SHORT_NME, F.MIN_PAL_WT, F.MAX_PAL_WT, B.GEO_CMB_NME, B.GEO_CMB_NME_NEW, C.TRUCK_DISP_NUM "
						+ "  FROM  " + pkgsum + "   A ," + rollsum +  "   B  ," + cntnrInfo + "  C ," + cnsolParm + "  D ,"
						+ cntnrLvlParm +  " E ," + pstlParm + "   F "
						+ "  WHERE A.MAG_KY  =  ?  AND A.INSTNC_CD = ? AND A.PLANT_ID  = ?  AND A.MAG_CD  = ?  AND A.ISS_NUM  = ?  AND A.ISS_WK_NUM  = ?  AND A.JOB_ID = ? "
						+ "  AND A.MAG_KY  = B.MAG_KY AND A.INSTNC_CD = B.INSTNC_CD AND A.PLANT_ID  = B.PLANT_ID  AND A.MAG_CD  = B.MAG_CD AND A.ISS_NUM  = B.ISS_NUM  "
						+ "  AND A.ISS_WK_NUM  = B.ISS_WK_NUM  AND A.JOB_ID  = B.JOB_ID  AND A.ROLL_NUM  = B.ROLL_NUM  AND A.PAL_SACK_IND = B.PAL_SACK_IND "
						+ "  AND A.MAG_KY  = C.MAG_KY AND A.INSTNC_CD = C.INSTNC_CD AND A.PLANT_ID  = C.PLANT_ID  AND A.MAG_CD  = C.MAG_CD  AND A.ISS_NUM = C.ISS_NUM  "
						+ "  AND A.ISS_WK_NUM  = C.ISS_WK_NUM  AND A.JOB_ID  = C.JOB_ID  AND A.PAL_SACK_IND = C.CNTNR_TYP  AND A.PAL_SACK_NUM = C.CNTNR_ID  "
						+ "  AND B.CNSOL_SUB_TYP = D.CNSOL_SUB_TYP AND C.CNTNR_LVL = E.CNTNR_LVL "
						+ "  AND A.MAG_KY = F.MAG_KY AND A.INSTNC_CD = F.INSTNC_CD AND A.PLANT_ID = F.PLANT_ID AND A.MAG_CD = F.MAG_CD AND A.ISS_NUM = F.ISS_NUM  AND A.ISS_WK_NUM = F.ISS_WK_NUM "
			            + "  ORDER BY  C.TRUCK_DISP_NUM, C.ENTRY_POINT_LINE, B.BIND_GRP_NME, A.PAL_SACK_NUM, B.ROLL_NUM, A.PAL_SACK_IND, B.GEO_CMB_NME ";
			
			
			LogWriter.writeLog("select from  Plant Pallet :::  InstCd : " + instCd + " SQL " + SQL);
			//LogWriter.writeLog("select from  Plant Pallet :::  "  + SQL);			
		
		try {
		
			PdfWriter writer = PdfWriter.getInstance(pprDoc,new FileOutputStream(RptPath + fileName + ".pdf"));
			
			writer.setViewerPreferences(PdfWriter.PageModeFullScreen);
			writer.setPageEvent(new PlantPallet());

			
			PdfPCell dummyCell = new PdfPCell(new Phrase("",
					FontFactory.getFont(FontFactory.TIMES_ROMAN, 72, Font.BOLD,Color.black)));
			dummyCell.setBorderWidth(0);
						
			pprDoc.open();
			String savedLastPalletInd = "";
			
			Date toDay = new Date(); 
			SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, MMM d, yyyy, HH:mm a "); 
			
			selectcopyCnt = conn.prepareStatement(SQL);
			selectcopyCnt.setInt(1, magKey);
			selectcopyCnt.setString(2, instCd);
			selectcopyCnt.setString(3, plantId);
			selectcopyCnt.setString(4, magCode);
			selectcopyCnt.setInt(5, toNum.toNumber(issueNum));
			selectcopyCnt.setInt(6, toNum.toNumber(issueWeek));
			selectcopyCnt.setString(7,jobId);
			
			resultset = selectcopyCnt.executeQuery();
			
			while (resultset.next()){	
				
				noPlantPallet = true;
				String destLine1  = resultset.getString("DEST_LINE1").replaceAll("   ", " ").trim();
				String entryPointLine  = resultset.getString("ENTRY_POINT_LINE").trim();
				String cnsolSubType = resultset.getString("CNSOL_SUB_TYP_DESC").trim();
				String truckDispNum = resultset.getString("TRUCK_DISP_NUM").trim();
				
				String braceId = truckDispNum.substring(0, 4);
				String dropOffPt = truckDispNum.substring(4, 7);
				
				//LogWriter.writeLog("truckDispNum : " + truckDispNum + " braceId : " + braceId + " dropOffPt :  " + dropOffPt);
				//String braceId = resultset.getString("BRACE_ID");
				//String dropOffPt = resultset.getString("DROP_OFF_PT");
				
				String pstlLevel = resultset.getString("SHORT_NME").trim();
				String palletMin = resultset.getString("MIN_PAL_WT").trim();
				String palletMax = resultset.getString("MAX_PAL_WT").trim();
				
				String geoComboName = resultset.getString("GEO_CMB_NME").trim();
				String newGeoComboName = resultset.getString("GEO_CMB_NME_NEW").trim();
				
				String palletInd = resultset.getString("PAL_SACK_IND");
				savedLastPalletInd = palletInd;   //save the value
				String palletNum = resultset.getString("PAL_SACK_NUM");
				String pkgNumLow = resultset.getString("PKG_NUM_LOW");
				String pkgNumHi = resultset.getString("PKG_NUM_HI");
				String numPkg = resultset.getString("NUM_PKG");
				String lowZip = resultset.getString("LOW_ZIP");
				String highZip = resultset.getString("HIGH_ZIP");
				String geoCatId = resultset.getString("GEO_CAT_ID").trim();
				String bvName = resultset.getString("XSHEET_BV_NME");
				String rollNum = resultset.getString("ROLL_NUM");
				String pkgWght = resultset.getString("PKG_WGHT");	
				String copyCount = resultset.getString("COPY_CNT");
				
				String bindGrpName = resultset.getString("BIND_GRP_NME").trim();
				String braceName = resultset.getString("BRACE_NME").trim();
				String carrName = resultset.getString("CARR_NME").trim();
				String departDate = resultset.getString("DEPART_DT") + " " + resultset.getString("DEPART_TIME");
				String arrivalData = resultset.getString("ARRVL_DT") + " " + resultset.getString("ARRVL_TIME");
				
				
				String pkgNumLtoH = pkgNumLow.trim() + " - " + pkgNumHi.trim(); 
				String zipLtoH = lowZip.trim() + " - " + highZip.trim();
				
				
				if (geoCatId.trim().equals("MIXED")){
					if (newGeoComboName.equals(""))
						bvVersion = geoComboName.trim() + " - " + bvName.trim();
					else
						bvVersion = newGeoComboName.trim() + " - " + bvName.trim();
					if ((bvVersion.compareTo(saveBvVersion) == 0)) 
						grpByBv = true;
					else
						grpByBv = false;
				}
				else {
					grpByBv = true;
					bvVersion = geoCatId.trim() + " - " + bvName.trim();
				}
				
				/*if (palletInd.compareTo("S") == 0){
					grpByBv = true;
				}*/
				
				
				if (braceId.compareTo(saveBraceId)== 0){
					if (bindGrpName.compareTo(saveBindGrpName) == 0){
						if ((cnsolSubType.compareTo(saveCnsolType)== 0) && (dropOffPt.compareTo(saveDropOffPt) == 0) && (entryPointLine.compareTo(saveEntryPointLine) == 0) && grpByBv) {
							
							if (palletInd.compareTo("S") == 0){
								for(int a = 0; a < pkgElemList.size(); a++) {
									PlantpkgElem pkgElmDisp  = (PlantpkgElem)pkgElemList.get(a);
									if ( a == 0) {
										PlantpkgElem pkgLastElmDisp  = (PlantpkgElem)pkgElemList.get(pkgElemList.size()-1);
										topFull = "";
										if (savePalletInd.compareTo("P") == 0){
											dopPackge  += pkgLastElmDisp.getTotnumPkg();
											dopCopies  += pkgLastElmDisp.getTotCopyCnt();
											dopWeight  += pkgLastElmDisp.getTotpkgWght();
											if (pkgLastElmDisp.getTotpkgWght() < 1000){
												topFull = "TOP";
												dopTop += 1;
											}
											else {
												topFull = "FULL";
												dopFull += 1;
											}
										}
									String dataInfo = AddSpace.addSpace(pkgElmDisp.getPalletNum(),3,' ') + " " + AddSpace.addSpace(" ",3,' ') + AddSpace.fixSize(pkgElmDisp.getPstlLevel(), 4, ' ', AddSpace.LEFT) + " " +  AddSpace.fixSize(pkgElmDisp.getDestLine1(), 25, ' ', AddSpace.LEFT) + " " + AddSpace.addSpace(PlaceComma.placeComma((pkgLastElmDisp.getTotnumPkg())),3) + AddSpace.addSpace(" ",37,' ')+  AddSpace.addSpace(PlaceComma.placeComma((pkgLastElmDisp.getTotCopyCnt())),5) + AddSpace.addSpace(" ",1,' ') + AddSpace.addSpace(nf.format(pkgLastElmDisp.getTotpkgWght()),7,' ') + AddSpace.addSpace(" ",1,' ') +  AddSpace.addSpace(topFull, 3, ' '); 
									PdfPCell dataCell = new PdfPCell(new Phrase(dataInfo,COURIERNORMAL_12));
									dataCell.setBorderWidth(0);
									outertable.addCell(dataCell);pageLine++;
									}
									savePalletNum = palletNum;
									savePalletInd = palletInd;
									//String dataInfo1 = AddSpace.addSpace(" ",19,' ') + " " +  AddSpace.fixSize(pkgElmDisp.getPkgNumLtoH(),15,' ',AddSpace.LEFT) + AddSpace.addSpace(" ",3,' ') + AddSpace.addSpace(pkgElmDisp.getNumPkg(),3,' ') + AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(pkgElmDisp.getZipLtoH(),13,' ') + AddSpace.addSpace(" ",1,' ')+AddSpace.addSpace(pkgElmDisp.getBvVersion(),12,' ') + AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(pkgElmDisp.getRollNum(),3,'0') + " " + AddSpace.addSpace((PlaceComma.placeComma((Integer.valueOf(pkgElmDisp.getCopyCount())).intValue())),5) +AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(PlaceComma.placeStringComma(pkgElmDisp.getPkgWght()),7) ;
									String dataInfo1 = AddSpace.addSpace(" ",19,' ') + " " +  AddSpace.fixSize(pkgElmDisp.getPkgNumLtoH(),15,' ',AddSpace.LEFT) + AddSpace.addSpace(" ",3,' ') + AddSpace.addSpace(pkgElmDisp.getNumPkg(),3,' ') + AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(pkgElmDisp.getZipLtoH(),13,' ') + AddSpace.addSpace(" ",1,' ')+AddSpace.addSpace(pkgElmDisp.getBvVersion(),12,' ') + AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(pkgElmDisp.getRollNum(),3,'0') + " " + AddSpace.addSpace((PlaceComma.placeComma((Integer.valueOf(pkgElmDisp.getCopyCount())).intValue())),5)  ;
									PdfPCell dataCell1 = new PdfPCell(new Phrase(dataInfo1,COURIERNORMAL_12));
									dataCell1.setBorderWidth(0);
									outertable.addCell(dataCell1);pageLine++;
								}
								pkgElemList.clear();
								totCopyCnt = 0; totpkgWght = 0;totnumPkg = 0;
								dopSackCopies += Integer.valueOf(copyCount).intValue();
								dopSackWght += Double.valueOf(pkgWght).doubleValue();
								dopSakCont += 1;
								dopSackPackge += Integer.valueOf(numPkg).intValue();
								continue;
							}
							if (palletNum.compareTo(savePalletNum) == 0 ){
								
								if (palletInd.compareTo("A") == 0){
									dopAirboxCopies += Integer.valueOf(copyCount).intValue();
									dopAirboxWght += Double.valueOf(pkgWght).doubleValue();
									dopAirboxCont += 1;
									dopAirboxPackge += Integer.valueOf(numPkg).intValue();										
								}
								totCopyCnt += Integer.valueOf(copyCount).intValue();
								totpkgWght += Double.valueOf(pkgWght).doubleValue();
								totnumPkg  += Integer.valueOf(numPkg).intValue();
								pkgElm = new PlantpkgElem(pkgNumLtoH, zipLtoH, bvVersion, rollNum, palletNum, numPkg,copyCount,pkgWght,totCopyCnt,totpkgWght,totnumPkg,destLine1,pstlLevel);
								pkgElemList.add(pkgElm);
							}
							else{
								if (palletInd.compareTo("S") == 0){
									dopSackCopies += Integer.valueOf(copyCount).intValue();
									dopSackWght += Double.valueOf(pkgWght).doubleValue();
									dopSakCont += 1;
									dopSackPackge += Integer.valueOf(numPkg).intValue();
								}
								else{
								outertable.addCell(dummyCell);pageLine++;
								for(int a = 0; a < pkgElemList.size(); a++) {
									PlantpkgElem pkgElmDisp  = (PlantpkgElem)pkgElemList.get(a);
									if ( a == 0) {
										PlantpkgElem pkgLastElmDisp  = (PlantpkgElem)pkgElemList.get(pkgElemList.size()-1);
										topFull = "";
										if (savePalletInd.compareTo("P") == 0) {
											dopPackge  += pkgLastElmDisp.getTotnumPkg();
											dopCopies  += pkgLastElmDisp.getTotCopyCnt();
											dopWeight  += pkgLastElmDisp.getTotpkgWght();
											if (pkgLastElmDisp.getTotpkgWght() < 1000){
												topFull = "TOP";
												dopTop += 1;
											}
											else{
												topFull = "FULL";
												dopFull += 1;
											}									
										}
									String dataInfo = AddSpace.addSpace(pkgElmDisp.getPalletNum(),3,' ') + " " + AddSpace.addSpace(" ",3,' ') + AddSpace.fixSize(pkgElmDisp.getPstlLevel(), 4, ' ', AddSpace.LEFT) + " " + AddSpace.fixSize(pkgElmDisp.getDestLine1(), 25, ' ', AddSpace.LEFT) + " " + AddSpace.addSpace(PlaceComma.placeComma((pkgLastElmDisp.getTotnumPkg())),3) + AddSpace.addSpace(" ",37,' ')+  AddSpace.addSpace(PlaceComma.placeComma((pkgLastElmDisp.getTotCopyCnt())),5) +AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(nf.format(pkgLastElmDisp.getTotpkgWght()),7,' ') + AddSpace.addSpace(" ",1,' ') +  AddSpace.addSpace(topFull, 3, ' '); 
									PdfPCell dataCell = new PdfPCell(new Phrase(dataInfo,
											COURIERNORMAL_12));
									dataCell.setBorderWidth(0);
									outertable.addCell(dataCell);pageLine++;
									}
									savePalletNum = palletNum;
									savePalletInd = palletInd;
									//String dataInfo1 = AddSpace.addSpace(" ",19,' ') + " " +  AddSpace.fixSize(pkgElmDisp.getPkgNumLtoH(),15,' ',AddSpace.LEFT) + AddSpace.addSpace(" ",3,' ') + AddSpace.addSpace(pkgElmDisp.getNumPkg(),3,' ') + AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(pkgElmDisp.getZipLtoH(),13,' ') + AddSpace.addSpace(" ",1,' ')+AddSpace.addSpace(pkgElmDisp.getBvVersion(),12,' ') + AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(pkgElmDisp.getRollNum(),3,'0') + " " + AddSpace.addSpace((PlaceComma.placeComma((Integer.valueOf(pkgElmDisp.getCopyCount())).intValue())),5) +AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(PlaceComma.placeStringComma(pkgElmDisp.getPkgWght()),7) ;
									String dataInfo1 = AddSpace.addSpace(" ",19,' ') + " " +  AddSpace.fixSize(pkgElmDisp.getPkgNumLtoH(),15,' ',AddSpace.LEFT) + AddSpace.addSpace(" ",3,' ') + AddSpace.addSpace(pkgElmDisp.getNumPkg(),3,' ') + AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(pkgElmDisp.getZipLtoH(),13,' ') + AddSpace.addSpace(" ",1,' ')+AddSpace.addSpace(pkgElmDisp.getBvVersion(),12,' ') + AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(pkgElmDisp.getRollNum(),3,'0') + " " + AddSpace.addSpace((PlaceComma.placeComma((Integer.valueOf(pkgElmDisp.getCopyCount())).intValue())),5)  ;
									PdfPCell dataCell1 = new PdfPCell(new Phrase(dataInfo1,
										COURIERNORMAL_12));
									dataCell1.setBorderWidth(0);
									outertable.addCell(dataCell1);pageLine++;
								}
								pkgElemList.clear();
								if (palletInd.compareTo("A") == 0){
									dopAirboxCopies += Integer.valueOf(copyCount).intValue();
									dopAirboxWght += Double.valueOf(pkgWght).doubleValue();
									dopAirboxCont += 1;
									dopAirboxPackge += Integer.valueOf(numPkg).intValue();										
								}
								totCopyCnt = 0; totpkgWght = 0;totnumPkg = 0;
								totCopyCnt += Integer.valueOf(copyCount).intValue();
								totpkgWght += Double.valueOf(pkgWght).doubleValue();
								totnumPkg  += Integer.valueOf(numPkg).intValue();
								pkgElm = new PlantpkgElem(pkgNumLtoH, zipLtoH, bvVersion, rollNum, palletNum, numPkg,copyCount,pkgWght,totCopyCnt,totpkgWght,totnumPkg,destLine1,pstlLevel);
								pkgElemList.add(pkgElm);
								}
							}		
						}
						else{
							
							for(int a = 0; a < pkgElemList.size(); a++) {
								PlantpkgElem pkgElmDisp  = (PlantpkgElem)pkgElemList.get(a);
								if ( a == 0) {
									PlantpkgElem pkgLastElmDisp  = (PlantpkgElem)pkgElemList.get(pkgElemList.size()-1);
									topFull = "";
									if (savePalletInd.compareTo("P") == 0){
										dopPackge  += pkgLastElmDisp.getTotnumPkg();
										dopCopies  += pkgLastElmDisp.getTotCopyCnt();
										dopWeight  += pkgLastElmDisp.getTotpkgWght();
										if (pkgLastElmDisp.getTotpkgWght() < 1000){
											topFull = "TOP";dopTop += 1;
										}
										else {
											topFull = "FULL";dopFull += 1;
										}
									}
								String dataInfo = AddSpace.addSpace(pkgElmDisp.getPalletNum(),3,' ') + " " + AddSpace.addSpace(" ",3,' ') + AddSpace.fixSize(pkgElmDisp.getPstlLevel(), 4, ' ', AddSpace.LEFT) + " " + AddSpace.fixSize(pkgElmDisp.getDestLine1(), 25, ' ', AddSpace.LEFT) + " " + AddSpace.addSpace(PlaceComma.placeComma((pkgLastElmDisp.getTotnumPkg())),3) + AddSpace.addSpace(" ",37,' ')+  AddSpace.addSpace(PlaceComma.placeComma((pkgLastElmDisp.getTotCopyCnt())),5) +AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(nf.format(pkgLastElmDisp.getTotpkgWght()),7,' ') + AddSpace.addSpace(" ",1,' ') +  AddSpace.addSpace(topFull, 3, ' '); 
								PdfPCell dataCell = new PdfPCell(new Phrase(dataInfo,
										COURIERNORMAL_12));
								dataCell.setBorderWidth(0);
								outertable.addCell(dataCell);pageLine++;
								}
								savePalletNum = palletNum;
								savePalletInd = palletInd;
								//String dataInfo1 = AddSpace.addSpace(" ",19,' ') + " " +  AddSpace.fixSize(pkgElmDisp.getPkgNumLtoH(),15,' ',AddSpace.LEFT) + AddSpace.addSpace(" ",3,' ') + AddSpace.addSpace(pkgElmDisp.getNumPkg(),3,' ') + AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(pkgElmDisp.getZipLtoH(),13,' ') + AddSpace.addSpace(" ",1,' ')+AddSpace.addSpace(pkgElmDisp.getBvVersion(),12,' ') + AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(pkgElmDisp.getRollNum(),3,'0') + " " + AddSpace.addSpace((PlaceComma.placeComma((Integer.valueOf(pkgElmDisp.getCopyCount())).intValue())),5) +AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(PlaceComma.placeStringComma(pkgElmDisp.getPkgWght()),7) ;
								String dataInfo1 = AddSpace.addSpace(" ",19,' ') + " " +  AddSpace.fixSize(pkgElmDisp.getPkgNumLtoH(),15,' ',AddSpace.LEFT) + AddSpace.addSpace(" ",3,' ') + AddSpace.addSpace(pkgElmDisp.getNumPkg(),3,' ') + AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(pkgElmDisp.getZipLtoH(),13,' ') + AddSpace.addSpace(" ",1,' ')+AddSpace.addSpace(pkgElmDisp.getBvVersion(),12,' ') + AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(pkgElmDisp.getRollNum(),3,'0') + " " + AddSpace.addSpace((PlaceComma.placeComma((Integer.valueOf(pkgElmDisp.getCopyCount())).intValue())),5)  ;
								PdfPCell dataCell1 = new PdfPCell(new Phrase(dataInfo1,
									COURIERNORMAL_12));
								dataCell1.setBorderWidth(0);
								outertable.addCell(dataCell1);pageLine++;
							}
							pkgElemList.clear();
							for(int z=0;z<2;z++) { outertable.addCell(dummyCell); pageLine++;}
							
							LogWriter.writeLog(" POE --- 1 pageLine 1  : "  + pageLine);
							
							PdfPCell totdopCell1 = totDophdr();							
							outertable.addCell(totdopCell1);pageLine++;
							
							
							PdfPTable dopPalletTable = new PdfPTable(7);
							dopPalletTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
							dopPalletTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
							dopPalletTable.setWidths(dopdispw);
							
							String dopcopyCell = AddSpace.addSpace(PlaceComma.placeComma(dopCopies),7) + " "; 
							String dopWeightcell = AddSpace.addSpace(nf.format(dopWeight),7,' ') + " ";
							String dopPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(dopPackge),7) + " ";
							String dopTopCell = dopTop + " ";
							String dopFullCell = dopFull + " ";
							int totC = dopTop + dopFull;
							
							dopPalletTable.addCell(new Phrase("Pallets",TIMESBOLD_12));
							dopPalletTable.addCell(new Phrase(dopcopyCell,COURIERNORMAL_12));
							dopPalletTable.addCell(new Phrase(dopWeightcell,COURIERNORMAL_12));
							dopPalletTable.addCell(new Phrase(dopPackgeCell,COURIERNORMAL_12));
							dopPalletTable.addCell(new Phrase(dopFullCell,COURIERNORMAL_12));
							dopPalletTable.addCell(new Phrase(dopTopCell,COURIERNORMAL_12));
							dopPalletTable.addCell(new Phrase(Integer.toString(totC),COURIERNORMAL_12));
							
							PdfPCell dopPalletCell = new PdfPCell(dopPalletTable);
							dopPalletCell.setHorizontalAlignment(Element.ALIGN_CENTER);
							dopPalletCell.setBorderWidth(0);
							outertable.addCell(dopPalletCell);pageLine++;
							
							String dopSackcopyCell = AddSpace.addSpace(PlaceComma.placeComma(dopSackCopies),7) + " ";
							String dopSackWghtCell = AddSpace.addSpace(nf.format(dopSackWght),7,' ') + " ";
							String dopSackPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(dopSackPackge),7) + " ";
							
							PdfPTable dopSackTable = new PdfPTable(7);
							dopSackTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
							dopSackTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
							dopSackTable.setWidths(dopdispw);
							dopSackTable.addCell(new Phrase("Sacks",TIMESBOLD_12));
							dopSackTable.addCell(new Phrase(dopSackcopyCell,COURIERNORMAL_12));
							dopSackTable.addCell(new Phrase(dopSackWghtCell,COURIERNORMAL_12));
							dopSackTable.addCell(new Phrase(dopSackPackgeCell,COURIERNORMAL_12));
							dopSackTable.addCell(new Phrase(" ",COURIERNORMAL_12));
							dopSackTable.addCell(new Phrase(" ",COURIERNORMAL_12));
							dopSackTable.addCell(new Phrase(Integer.toString(dopSakCont),COURIERNORMAL_12));
							
							PdfPCell dopSackCell = new PdfPCell(dopSackTable);
							dopSackCell.setHorizontalAlignment(Element.ALIGN_CENTER);
							dopSackCell.setBorderWidth(0);
							outertable.addCell(dopSackCell);pageLine++;
//							
							String dopAirboxcopyCell = AddSpace.addSpace(PlaceComma.placeComma(dopAirboxCopies),7) + " ";
							String dopAirboxWghtCell = AddSpace.addSpace(nf.format(dopAirboxWght),7,' ') + " ";
							String dopAirboxPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(dopAirboxPackge),7) + " ";
							
							PdfPTable dopAirboxTable = new PdfPTable(7);
							dopAirboxTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
							dopAirboxTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
							dopAirboxTable.setWidths(dopdispw);
							dopAirboxTable.addCell(new Phrase("Air Boxes",TIMESBOLD_12));
							dopAirboxTable.addCell(new Phrase(dopAirboxcopyCell,COURIERNORMAL_12));
							dopAirboxTable.addCell(new Phrase(dopAirboxWghtCell,COURIERNORMAL_12));
							dopAirboxTable.addCell(new Phrase(dopAirboxPackgeCell,COURIERNORMAL_12));
							dopAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_12));
							dopAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_12));
							dopAirboxTable.addCell(new Phrase(Integer.toString(dopAirboxCont),COURIERNORMAL_12));
							
							PdfPCell dopAirboxCell = new PdfPCell(dopAirboxTable);
							dopAirboxCell.setHorizontalAlignment(Element.ALIGN_CENTER);
							dopAirboxCell.setBorderWidth(0);
							outertable.addCell(dopAirboxCell);pageLine++;
//
							int dopCombPackage = dopPackge + dopSackPackge + dopAirboxPackge;
							int dopCombCopies = dopCopies + dopSackCopies + dopAirboxCopies;
							double dopCombWght = dopWeight + dopSackWght + dopAirboxWght;
							int totcombCont = totC + dopSakCont + dopAirboxCont;
							String dopcombcopyCell = AddSpace.addSpace(PlaceComma.placeComma(dopCombCopies),7) + " ";
							String dopCombWghtCell = AddSpace.addSpace(nf.format(dopCombWght),7,' ') + " ";
							String dopCombPackgeCell = AddSpace.addSpace((PlaceComma.placeComma(dopCombPackage)),7) + " ";
							
							PdfPTable dopCombTable = new PdfPTable(7);
							dopCombTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
							dopCombTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
							dopCombTable.setWidths(dopdispw);
							dopCombTable.addCell(new Phrase("Combined",TIMESBOLD_12));
							dopCombTable.addCell(new Phrase(dopcombcopyCell,COURIERNORMAL_12));
							dopCombTable.addCell(new Phrase(dopCombWghtCell,COURIERNORMAL_12));
							dopCombTable.addCell(new Phrase(dopCombPackgeCell,COURIERNORMAL_12));
							dopCombTable.addCell(new Phrase(" ",COURIERNORMAL_12));
							dopCombTable.addCell(new Phrase(" ",COURIERNORMAL_12));
							dopCombTable.addCell(new Phrase(Integer.toString(totcombCont),COURIERNORMAL_12));
							
							PdfPCell dopCombCell = new PdfPCell(dopCombTable);
							dopCombCell.setHorizontalAlignment(Element.ALIGN_CENTER);
							dopCombCell.setBorderWidth(0);
							//pageLine+=4;  changed to pageLine++;
							outertable.addCell(dopCombCell);pageLine++;
							
							bgtPalCopies += dopCopies;
							bgtPalPackage += dopPackge;
							bgtPalWeight += dopWeight;
							bgtSakCopies += dopSackCopies;
							bgtSakPackage += dopSackPackge;
							bgtSakWeight += dopSackWght;
							bgtAirboxCopies += dopAirboxCopies;
							bgtAirboxPackage += dopAirboxPackge;
							bgtAirboxWeight += dopAirboxWght;
							bgttop += dopTop;
							bgtFull += dopFull;
							bgtPalCont += totC;
							bgtSakCont += dopSakCont;
							bgtAirboxCont += dopAirboxCont;
							
							dopPackge  = 0;
							dopCopies  = 0;
							dopWeight =0;
							dopTop = 0;
							dopFull = 0;
							dopSackCopies = 0;
							dopSackWght = 0;
							dopSackPackge = 0;dopSakCont=0;
							dopAirboxCopies = 0;
							dopAirboxWght = 0;
							dopAirboxPackge = 0;dopAirboxCont=0;
							dopCombPackage= 0;dopCombCopies=0;totcombCont=0;dopCombWght=0;
							
							if (palletInd.compareTo("S") == 0){
								dopSackCopies += Integer.valueOf(copyCount).intValue();
								dopSackWght += Double.valueOf(pkgWght).doubleValue();
								dopSakCont += 1;
								dopSackPackge += Integer.valueOf(numPkg).intValue();
							}
							else {
								if (palletInd.compareTo("A") == 0){
									dopAirboxCopies += Integer.valueOf(copyCount).intValue();
									dopAirboxWght += Double.valueOf(pkgWght).doubleValue();
									dopAirboxCont += 1;
									dopAirboxPackge += Integer.valueOf(numPkg).intValue();									
								}
								totCopyCnt = 0; totpkgWght = 0;totnumPkg = 0;
								totCopyCnt += Integer.valueOf(copyCount).intValue();
								totpkgWght += Double.valueOf(pkgWght).doubleValue();
								totnumPkg  += Integer.valueOf(numPkg).intValue();
								pkgElemList.clear();
								pkgElm = new PlantpkgElem(pkgNumLtoH, zipLtoH, bvVersion, rollNum, palletNum, numPkg,copyCount,pkgWght,totCopyCnt,totpkgWght,totnumPkg,destLine1,pstlLevel);
								pkgElemList.add(pkgElm);
							}
							
							saveCnsolType = cnsolSubType;
							saveDropOffPt = dropOffPt;
							saveEntryPointLine = entryPointLine;
							saveBvVersion = bvVersion;
							savePalletNum = palletNum;
							savePalletInd = palletInd;
							
							LogWriter.writeLog(" POE --- 2 pageLine 1  : "  + pageLine);
							pageLine = 0;
							
							pprDoc.add(outertable);
							pprDoc.newPage();
							
							outertable = new PdfPTable(1);
							outertable.setHeaderRows(14);

							String dateHdr = String.valueOf(dateFormat.format(toDay)) + "Issue :"+ issueNum + " - " + issueWeek + "Cover :" + issueDate; 
							PdfPCell header0 = new PdfPCell(new Phrase(dateHdr,
									FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,Color.black)));
							header0.setBorderWidth(0);
							outertable.addCell(header0);pageLine++;
						
							PdfPCell cell1 = new PdfPCell(new Phrase(
									"Plant Pallet / Sack Report", FontFactory.getFont(FontFactory.TIMES_ROMAN, 24, Font.BOLD, Color.BLACK)));
							cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
							cell1.setBorderWidth(0);
							outertable.addCell(cell1);pageLine++;
							
							int [] tablew = {2,9,9,2,5,5};
							PdfPTable headertable1 = new PdfPTable(6);
							headertable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
							headertable1.setWidths(tablew);
							headertable1.addCell(new Phrase("Plant :",TIMESBOLD_12));
							headertable1.addCell(new Phrase(plantName.trim(),TIMESNORAML_12));
							headertable1.addCell(new Phrase(magName.trim(),TIMESNORAML_12));
							headertable1.addCell(new Phrase("Issue :",TIMESBOLD_12));
							String issueDateDisp = issueDate + "   ("+ issueNum + " - " + issueWeek + ")";
							headertable1.addCell(new Phrase(issueDateDisp,TIMESNORAML_12));
							headertable1.addCell(new Phrase(deliveryType,TIMESBOLD_12));
							
							PdfPCell headercell1 = new PdfPCell(headertable1);
							headercell1.setBorderWidth(0);
							outertable.addCell(headercell1);pageLine++;
							
							outertable.addCell(dummyCell);pageLine++;
							
							int [] tableh2w = {9,3,1,3,1,9};
							PdfPTable headertable2 = new PdfPTable(6);
							headertable2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
							headertable2.setWidths(tableh2w);
							headertable2.addCell(new Phrase("Pallet Parameters (Lbs)",TIMESBOLD_12));
							headertable2.addCell(new Phrase("Pallet Min:",TIMESBOLD_12));
							headertable2.addCell(new Phrase(palletMin,TIMESNORAML_12));
							headertable2.addCell(new Phrase("Pallet Max:",TIMESBOLD_12));
							headertable2.addCell(new Phrase(palletMax,TIMESNORAML_12));
							headertable2.addCell(new Phrase("Top Pallet < 1000 Lbs",TIMESBOLD_12));
							
							PdfPCell headercell2 = new PdfPCell(headertable2);
							headercell2.setBorderWidth(0);
							outertable.addCell(headercell2);pageLine++;
							
							outertable.addCell(dummyCell);pageLine++;
							
							
							int [] tableh3w = {3,2,4,9,4,9,2,7};
							PdfPTable headertable3 = new PdfPTable(8);
							headertable3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
							headertable3.setWidths(tableh3w);
							String braceDisp = AddSpace.addSpace(braceId, 3, '0')+ " ";
							headertable3.addCell(new Phrase("Brace:",TIMESBOLD_12));
							headertable3.addCell(new Phrase(braceDisp,TIMESNORAML_12));
							headertable3.addCell(new Phrase("Leave Plant :",TIMESBOLD_12));
							headertable3.addCell(new Phrase(departDate,TIMESNORAML_12));
							headertable3.addCell(new Phrase("Dispatch:",TIMESBOLD_12));
							headertable3.addCell(new Phrase(braceName,TIMESNORAML_12));
							headertable3.addCell(new Phrase("Via :",TIMESBOLD_12));
							headertable3.addCell(new Phrase(carrName,TIMESNORAML_12));
							
							PdfPCell headercell3 = new PdfPCell(headertable3);
							headercell3.setBorderWidth(0);
							outertable.addCell(headercell3);pageLine++;
							
							outertable.addCell(dummyCell);pageLine++;
							
							int [] tableh4w = {4,2,5,9,4,9,3,7};
							PdfPTable headertable4 = new PdfPTable(8);
							headertable4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
							headertable4.setWidths(tableh4w);
							headertable4.addCell(new Phrase("Drop-Off:",TIMESBOLD_12));
							headertable4.addCell(new Phrase(dropOffPt,TIMESNORAML_12));
							headertable4.addCell(new Phrase("Bind Group:",TIMESBOLD_12));
							headertable4.addCell(new Phrase(bindGrpName,TIMESNORAML_12));
							headertable4.addCell(new Phrase("P.O.E.:",TIMESBOLD_12));
							headertable4.addCell(new Phrase(entryPointLine,TIMESNORAML_12));
							headertable4.addCell(new Phrase("Arrives:",TIMESBOLD_12));
							headertable4.addCell(new Phrase(arrivalData,TIMESNORAML_12));
							
							PdfPCell headercell4 = new PdfPCell(headertable4);
							headercell4.setBorderWidth(0);
							outertable.addCell(headercell4);pageLine++;
							
							for(int i = 0; i<2; i++) {outertable.addCell(dummyCell);pageLine++;}								
							
							int [] tableh5w = {3,2,4,5,4,5,3,3,3,3,3};
							PdfPTable inertable = new PdfPTable(11);
							inertable.setWidths(tableh5w);
							inertable.getDefaultCell().setBorder(Rectangle.NO_BORDER | Rectangle.BOTTOM);
							inertable.getDefaultCell().setBorderWidthBottom(2);
							inertable.getDefaultCell().setPaddingBottom(5);
							inertable.addCell(new Phrase("Pallet Number",TIMESBOLD_12));
							inertable.addCell(new Phrase("Level",TIMESBOLD_12));
							inertable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_BOTTOM);
							inertable.addCell(new Phrase("Pallet Destination",TIMESBOLD_12));
							inertable.addCell(new Phrase("Package Range",TIMESBOLD_12));
							inertable.addCell(new Phrase("Package Count",TIMESBOLD_12));
							inertable.addCell(new Phrase("Zip Range",TIMESBOLD_12));
							inertable.addCell(new Phrase("Book Version",TIMESBOLD_12));
							inertable.addCell(new Phrase("Roll Number",TIMESBOLD_12));
							inertable.addCell(new Phrase("Label Count",TIMESBOLD_12));
							inertable.addCell(new Phrase("Pallet Weight",TIMESBOLD_12));
							inertable.addCell(new Phrase("Top/Full Pallet",TIMESBOLD_12));
							
							PdfPCell cell9 = new PdfPCell(inertable);
							cell9.setBorderWidth(0);
							outertable.addCell(cell9);pageLine++;
							
							PdfPTable cstHeaderTable = new PdfPTable(8);
							cstHeaderTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
							cstHeaderTable.setWidths(cstTablew);
							cstHeaderTable.addCell(new Phrase(cnsolSubType,TIMESBOLD_12));
							for(int m=0; m<7;m++)
								cstHeaderTable.addCell(new Phrase("",TIMESBOLD_12));
									
							PdfPCell cstHeaderCell = new PdfPCell(cstHeaderTable);
							cstHeaderCell.setBorderWidth(0);
							outertable.addCell(cstHeaderCell);pageLine++;
							
							outertable.addCell(dummyCell);pageLine++;
							
						}
					}
					else{
						boolean newPage = false;
						for(int a = 0; a < pkgElemList.size(); a++) {
							PlantpkgElem pkgElmDisp  = (PlantpkgElem)pkgElemList.get(a);
							if ( a == 0) {
								PlantpkgElem pkgLastElmDisp  = (PlantpkgElem)pkgElemList.get(pkgElemList.size()-1);
								topFull = "";
								if (savePalletInd.compareTo("P") == 0){
									dopPackge  += pkgLastElmDisp.getTotnumPkg();
									dopCopies  += pkgLastElmDisp.getTotCopyCnt();
									dopWeight  += pkgLastElmDisp.getTotpkgWght();
									if (pkgLastElmDisp.getTotpkgWght() < 1000){
										topFull = "TOP";dopTop += 1;
									}
									else {
										topFull = "FULL";dopFull += 1;
									}
								}
							String dataInfo = AddSpace.addSpace(pkgElmDisp.getPalletNum(),3,' ') + " " + AddSpace.addSpace(" ",3,' ') + AddSpace.fixSize(pkgElmDisp.getPstlLevel(), 4, ' ', AddSpace.LEFT) + " "  + AddSpace.fixSize(pkgElmDisp.getDestLine1(), 25, ' ', AddSpace.LEFT) + " " + AddSpace.addSpace(PlaceComma.placeComma((pkgLastElmDisp.getTotnumPkg())),3) + AddSpace.addSpace(" ",37,' ')+  AddSpace.addSpace(PlaceComma.placeComma((pkgLastElmDisp.getTotCopyCnt())),5) +AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(nf.format(pkgLastElmDisp.getTotpkgWght()),7,' ') + AddSpace.addSpace(" ",1,' ') +  AddSpace.addSpace(topFull, 3, ' '); 
							PdfPCell dataCell = new PdfPCell(new Phrase(dataInfo,
									COURIERNORMAL_12));
							dataCell.setBorderWidth(0);
							outertable.addCell(dataCell);pageLine++;
							}
							savePalletNum = palletNum;
							savePalletInd = palletInd;
							//String dataInfo1 = AddSpace.addSpace(" ",19,' ') + " " +  AddSpace.fixSize(pkgElmDisp.getPkgNumLtoH(),15,' ',AddSpace.LEFT) + AddSpace.addSpace(" ",3,' ') + AddSpace.addSpace(pkgElmDisp.getNumPkg(),3,' ') + AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(pkgElmDisp.getZipLtoH(),13,' ') + AddSpace.addSpace(" ",1,' ')+AddSpace.addSpace(pkgElmDisp.getBvVersion(),12,' ') + AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(pkgElmDisp.getRollNum(),3,'0') + " " + AddSpace.addSpace((PlaceComma.placeComma((Integer.valueOf(pkgElmDisp.getCopyCount())).intValue())),5) +AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(PlaceComma.placeStringComma(pkgElmDisp.getPkgWght()),7) ;
							String dataInfo1 = AddSpace.addSpace(" ",19,' ') + " " +  AddSpace.fixSize(pkgElmDisp.getPkgNumLtoH(),15,' ',AddSpace.LEFT) + AddSpace.addSpace(" ",3,' ') + AddSpace.addSpace(pkgElmDisp.getNumPkg(),3,' ') + AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(pkgElmDisp.getZipLtoH(),13,' ') + AddSpace.addSpace(" ",1,' ')+AddSpace.addSpace(pkgElmDisp.getBvVersion(),12,' ') + AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(pkgElmDisp.getRollNum(),3,'0') + " " + AddSpace.addSpace((PlaceComma.placeComma((Integer.valueOf(pkgElmDisp.getCopyCount())).intValue())),5)  ;
							PdfPCell dataCell1 = new PdfPCell(new Phrase(dataInfo1,
								COURIERNORMAL_12));
							dataCell1.setBorderWidth(0);
							outertable.addCell(dataCell1);pageLine++;
						}
						pkgElemList.clear();
						
						outertable.addCell(dummyCell);pageLine++;
						
						LogWriter.writeLog(" BIND  --- 1 pageLine 1  : "  + pageLine);
											
						for(int z=0;z<2;z++) {outertable.addCell(dummyCell);pageLine++;}
						PdfPCell totdopCell1 = totDophdr();							
						outertable.addCell(totdopCell1);pageLine++;
						
						PdfPTable dopPalletTable = new PdfPTable(7);
						dopPalletTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						dopPalletTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						dopPalletTable.setWidths(dopdispw);
						
						String dopcopyCell = AddSpace.addSpace(PlaceComma.placeComma(dopCopies),7) + " "; 
						String dopWeightcell = AddSpace.addSpace(nf.format(dopWeight),7,' ') + " ";
						String dopPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(dopPackge),7) + " ";
						String dopTopCell = dopTop + " ";
						String dopFullCell = dopFull + " ";
						int totC = dopTop + dopFull;
						
						dopPalletTable.addCell(new Phrase("Pallets",TIMESBOLD_12));
						dopPalletTable.addCell(new Phrase(dopcopyCell,COURIERNORMAL_12));
						dopPalletTable.addCell(new Phrase(dopWeightcell,COURIERNORMAL_12));
						dopPalletTable.addCell(new Phrase(dopPackgeCell,COURIERNORMAL_12));
						dopPalletTable.addCell(new Phrase(dopFullCell,COURIERNORMAL_12));
						dopPalletTable.addCell(new Phrase(dopTopCell,COURIERNORMAL_12));
						dopPalletTable.addCell(new Phrase(Integer.toString(totC),COURIERNORMAL_12));
						
						PdfPCell dopPalletCell = new PdfPCell(dopPalletTable);
						dopPalletCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						dopPalletCell.setBorderWidth(0);
						outertable.addCell(dopPalletCell);pageLine++;
						
						String dopSackcopyCell = AddSpace.addSpace(PlaceComma.placeComma(dopSackCopies),7) + " ";
						String dopSackWghtCell = AddSpace.addSpace(nf.format(dopSackWght),7,' ') + " ";
						String dopSackPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(dopSackPackge),7) + " ";
						
						PdfPTable dopSackTable = new PdfPTable(7);
						dopSackTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						dopSackTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						dopSackTable.setWidths(dopdispw);
						dopSackTable.addCell(new Phrase("Sacks",TIMESBOLD_12));
						dopSackTable.addCell(new Phrase(dopSackcopyCell,COURIERNORMAL_12));
						dopSackTable.addCell(new Phrase(dopSackWghtCell,COURIERNORMAL_12));
						dopSackTable.addCell(new Phrase(dopSackPackgeCell,COURIERNORMAL_12));
						dopSackTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						dopSackTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						dopSackTable.addCell(new Phrase(Integer.toString(dopSakCont),COURIERNORMAL_12));
						
						PdfPCell dopSackCell = new PdfPCell(dopSackTable);
						dopSackCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						dopSackCell.setBorderWidth(0);
						outertable.addCell(dopSackCell);pageLine++;
//
						String dopAirboxcopyCell = AddSpace.addSpace(PlaceComma.placeComma(dopAirboxCopies),7) + " ";
						String dopAirboxWghtCell = AddSpace.addSpace(nf.format(dopAirboxWght),7,' ') + " ";
						String dopAirboxPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(dopAirboxPackge),7) + " ";
						
						PdfPTable dopAirboxTable = new PdfPTable(7);
						dopAirboxTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						dopAirboxTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						dopAirboxTable.setWidths(dopdispw);
						dopAirboxTable.addCell(new Phrase("Air Boxes",TIMESBOLD_12));
						dopAirboxTable.addCell(new Phrase(dopAirboxcopyCell,COURIERNORMAL_12));
						dopAirboxTable.addCell(new Phrase(dopAirboxWghtCell,COURIERNORMAL_12));
						dopAirboxTable.addCell(new Phrase(dopAirboxPackgeCell,COURIERNORMAL_12));
						dopAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						dopAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						dopAirboxTable.addCell(new Phrase(Integer.toString(dopAirboxCont),COURIERNORMAL_12));
						
						PdfPCell dopAirboxCell = new PdfPCell(dopAirboxTable);
						dopAirboxCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						dopAirboxCell.setBorderWidth(0);
						outertable.addCell(dopAirboxCell);pageLine++;
//						
						int dopCombPackage = dopPackge + dopSackPackge + dopAirboxPackge;
						int dopCombCopies = dopCopies + dopSackCopies + dopAirboxCopies;
						double dopCombWght = dopWeight + dopSackWght + dopAirboxWght;
						int totcombCont = totC + dopSakCont + dopAirboxCont;
						String dopcombcopyCell = AddSpace.addSpace(PlaceComma.placeComma(dopCombCopies),7) + " ";
						String dopCombWghtCell = AddSpace.addSpace(nf.format(dopCombWght),7,' ') + " ";
						String dopCombPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(dopCombPackage),7) + " ";
						
						PdfPTable dopCombTable = new PdfPTable(7);
						dopCombTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						dopCombTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						dopCombTable.setWidths(dopdispw);
						dopCombTable.addCell(new Phrase("Combined",TIMESBOLD_12));
						dopCombTable.addCell(new Phrase(dopcombcopyCell,COURIERNORMAL_12));
						dopCombTable.addCell(new Phrase(dopCombWghtCell,COURIERNORMAL_12));
						dopCombTable.addCell(new Phrase(dopCombPackgeCell,COURIERNORMAL_12));
						dopCombTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						dopCombTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						dopCombTable.addCell(new Phrase(Integer.toString(totcombCont),COURIERNORMAL_12));
						
						PdfPCell dopCombCell = new PdfPCell(dopCombTable);
						dopCombCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						dopCombCell.setBorderWidth(0);
						//pageLine+=4;  changed to pageLine++;
						outertable.addCell(dopCombCell);pageLine++;
						
						bgtPalCopies += dopCopies;
						bgtPalPackage += dopPackge;
						bgtPalWeight += dopWeight;
						bgtSakCopies += dopSackCopies;
						bgtSakPackage += dopSackPackge;
						bgtSakWeight += dopSackWght;
						bgtAirboxCopies += dopAirboxCopies;
						bgtAirboxPackage += dopAirboxPackge;
						bgtAirboxWeight += dopAirboxWght;
						bgttop += dopTop;
						bgtFull += dopFull;
						bgtPalCont += totC;
						bgtSakCont += dopSakCont;
						bgtAirboxCont += dopAirboxCont;
						
						dopPackge  = 0;
						dopCopies  = 0;
						dopWeight =0;
						dopTop = 0;
						dopFull = 0;
						dopSackCopies = 0;
						dopSackWght = 0;
						dopSackPackge = 0;dopSakCont=0;
						dopAirboxCopies = 0;
						dopAirboxWght = 0;
						dopAirboxPackge = 0;dopAirboxCont=0;
						dopCombPackage= 0;dopCombCopies=0;totcombCont=0;dopCombWght=0;
						
						LogWriter.writeLog(" BIND  --- 2 pageLine 1  : "  + pageLine);
						
						for(int z=0;z<2;z++) {outertable.addCell(dummyCell);pageLine++;}
						PdfPCell totBindGrpCell1 = totBindGrphdr();							
						outertable.addCell(totBindGrpCell1);pageLine++;
						
						//   Binding Group start
						
						PdfPTable bgtPalletTable = new PdfPTable(7);
						bgtPalletTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						bgtPalletTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						bgtPalletTable.setWidths(dopdispw);
						
						String bgtcopyCell = AddSpace.addSpace(PlaceComma.placeComma(bgtPalCopies),7) + " "; 
						String bgtWeightcell = AddSpace.addSpace(nf.format(bgtPalWeight),7,' ') + " ";
						String bgtPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(bgtPalPackage),7) + " ";
						
						
						bgtPalletTable.addCell(new Phrase("Pallets",TIMESBOLD_12));
						bgtPalletTable.addCell(new Phrase(bgtcopyCell,COURIERNORMAL_12));
						bgtPalletTable.addCell(new Phrase(bgtWeightcell,COURIERNORMAL_12));
						bgtPalletTable.addCell(new Phrase(bgtPackgeCell,COURIERNORMAL_12));
						bgtPalletTable.addCell(new Phrase(Integer.toString(bgtFull),COURIERNORMAL_12));
						bgtPalletTable.addCell(new Phrase(Integer.toString(bgttop),COURIERNORMAL_12));
						bgtPalletTable.addCell(new Phrase(Integer.toString(bgtPalCont),COURIERNORMAL_12));
						
						PdfPCell bgtPalletCell = new PdfPCell(bgtPalletTable);
						bgtPalletCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						bgtPalletCell.setBorderWidth(0);
						outertable.addCell(bgtPalletCell);pageLine++;
						
						String bgtSackcopyCell = AddSpace.addSpace(PlaceComma.placeComma(bgtSakCopies),7) + " ";
						String bgtSackWghtCell = AddSpace.addSpace(nf.format(bgtSakWeight),7,' ') + " ";
						String bgtSackPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(bgtSakPackage),7) + " ";
						
						PdfPTable bgtSackTable = new PdfPTable(7);
						bgtSackTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						bgtSackTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						bgtSackTable.setWidths(dopdispw);
						bgtSackTable.addCell(new Phrase("Sacks",TIMESBOLD_12));
						bgtSackTable.addCell(new Phrase(bgtSackcopyCell,COURIERNORMAL_12));
						bgtSackTable.addCell(new Phrase(bgtSackWghtCell,COURIERNORMAL_12));
						bgtSackTable.addCell(new Phrase(bgtSackPackgeCell,COURIERNORMAL_12));
						bgtSackTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						bgtSackTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						bgtSackTable.addCell(new Phrase(Integer.toString(bgtSakCont),COURIERNORMAL_12));
						
						PdfPCell bgtSackCell = new PdfPCell(bgtSackTable);
						bgtSackCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						bgtSackCell.setBorderWidth(0);
						outertable.addCell(bgtSackCell);pageLine++;
//
						String bgtAirboxcopyCell = AddSpace.addSpace(PlaceComma.placeComma(bgtAirboxCopies),7) + " ";
						String bgtAirboxWghtCell = AddSpace.addSpace(nf.format(bgtAirboxWeight),7,' ') + " ";
						String bgtAirboxPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(bgtAirboxPackage),7) + " ";
						
						PdfPTable bgtAirboxTable = new PdfPTable(7);
						bgtAirboxTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						bgtAirboxTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						bgtAirboxTable.setWidths(dopdispw);
						bgtAirboxTable.addCell(new Phrase("Air Boxes",TIMESBOLD_12));
						bgtAirboxTable.addCell(new Phrase(bgtAirboxcopyCell,COURIERNORMAL_12));
						bgtAirboxTable.addCell(new Phrase(bgtAirboxWghtCell,COURIERNORMAL_12));
						bgtAirboxTable.addCell(new Phrase(bgtAirboxPackgeCell,COURIERNORMAL_12));
						bgtAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						bgtAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						bgtAirboxTable.addCell(new Phrase(Integer.toString(bgtAirboxCont),COURIERNORMAL_12));
						
						PdfPCell bgtAirboxCell = new PdfPCell(bgtAirboxTable);
						bgtAirboxCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						bgtAirboxCell.setBorderWidth(0);
						outertable.addCell(bgtAirboxCell);pageLine++;
//
						int bgtCombCopies = bgtPalCopies + bgtSakCopies + bgtAirboxCopies;
						int bgtCombPackage = bgtPalPackage + bgtSakPackage + bgtAirboxPackage;
						double bgtCombWght = bgtPalWeight + bgtSakWeight + bgtAirboxWeight;
						int bgtcombCont = bgtPalCont + bgtSakCont + bgtAirboxCont;
						String bgtcombcopyCell = AddSpace.addSpace(PlaceComma.placeComma(bgtCombCopies),7) + " ";
						String bgtCombWghtCell = AddSpace.addSpace(nf.format(bgtCombWght),7,' ') + " ";
						String bgtcombPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(bgtCombPackage),7) + " ";
						
						PdfPTable bgtCombTable = new PdfPTable(7);
						bgtCombTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						bgtCombTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						bgtCombTable.setWidths(dopdispw);
						bgtCombTable.addCell(new Phrase("Combined",TIMESBOLD_12));
						bgtCombTable.addCell(new Phrase(bgtcombcopyCell,COURIERNORMAL_12));
						bgtCombTable.addCell(new Phrase(bgtCombWghtCell,COURIERNORMAL_12));
						bgtCombTable.addCell(new Phrase(bgtcombPackgeCell,COURIERNORMAL_12));
						bgtCombTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						bgtCombTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						bgtCombTable.addCell(new Phrase(Integer.toString(bgtcombCont),COURIERNORMAL_12));
						
						PdfPCell bgtCombCell = new PdfPCell(bgtCombTable);
						bgtCombCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						bgtCombCell.setBorderWidth(0);
						//pageLine+=4;  changed to pageLine++;
						outertable.addCell(bgtCombCell);pageLine++;
						
						bracePalCopies += bgtPalCopies;
						bracePalPackage += bgtPalPackage;
						bracePalWeight += bgtPalWeight;
						braceSakCopies += bgtSakCopies;
						braceSakPackage += bgtSakPackage;
						braceSakWeight += bgtSakWeight;
						braceAirboxCopies += bgtAirboxCopies;
						braceAirboxPackage += bgtAirboxPackage;
						braceAirboxWeight += bgtAirboxWeight;
						braceTop += bgttop;
						braceFull += bgtFull;
						bracePalCont += bgtPalCont;
						braceSakCont += bgtSakCont;
						braceAirboxCont += bgtAirboxCont;

						
						bgtPalCopies = 0;
						bgtPalPackage = 0;
						bgtPalWeight = 0;
						bgtSakCopies = 0;
						bgtSakPackage = 0;
						bgtSakWeight = 0;
						bgtAirboxCopies = 0;
						bgtAirboxPackage = 0;
						bgtAirboxWeight = 0;
						bgttop = 0;
						bgtFull = 0;
						bgtPalCont = 0;
						bgtSakCont = 0;
						bgtAirboxCont = 0;
						
						//   Binding Group End 
						
						
						if (palletInd.compareTo("S") == 0){
							dopSackCopies += Integer.valueOf(copyCount).intValue();
							dopSackWght += Double.valueOf(pkgWght).doubleValue();
							dopSakCont += 1;
							dopSackPackge += Integer.valueOf(numPkg).intValue();
						}
						else {
							if (palletInd.compareTo("A") == 0){
								dopAirboxCopies += Integer.valueOf(copyCount).intValue();
								dopAirboxWght += Double.valueOf(pkgWght).doubleValue();
								dopAirboxCont += 1;
								dopAirboxPackge += Integer.valueOf(numPkg).intValue();								
							}
							totCopyCnt = 0; totpkgWght = 0;totnumPkg = 0;
							totCopyCnt += Integer.valueOf(copyCount).intValue();
							totpkgWght += Double.valueOf(pkgWght).doubleValue();
							totnumPkg  += Integer.valueOf(numPkg).intValue();
							pkgElemList.clear();
							pkgElm = new PlantpkgElem(pkgNumLtoH, zipLtoH, bvVersion, rollNum, palletNum, numPkg,copyCount,pkgWght,totCopyCnt,totpkgWght,totnumPkg,destLine1,pstlLevel);
							pkgElemList.add(pkgElm);
						}
						
						saveCnsolType = cnsolSubType;
						saveDropOffPt = dropOffPt;
						saveEntryPointLine = entryPointLine;
						saveBvVersion = bvVersion;
						saveBindGrpName = bindGrpName;
						savePalletNum = palletNum;
						savePalletInd = palletInd;
						
						
						LogWriter.writeLog(" BIND  --- 3 pageLine 1  : "  + pageLine);
						pageLine = 0;
						
						pprDoc.add(outertable);
						pprDoc.newPage();
						
						outertable = new PdfPTable(1);
						outertable.setHeaderRows(14);
						
						String dateHdr = String.valueOf(dateFormat.format(toDay)) + "Issue :"+ issueNum + " - " + issueWeek + "Cover :" + issueDate; 
						PdfPCell header0 = new PdfPCell(new Phrase(dateHdr,
								FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,Color.black)));
						header0.setBorderWidth(0);
						outertable.addCell(header0);pageLine++;
							
					
						PdfPCell cell1 = new PdfPCell(new Phrase(
								"Plant Pallet / Sack Report", FontFactory.getFont(FontFactory.TIMES_ROMAN, 24, Font.BOLD, Color.BLACK)));
						cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
						cell1.setBorderWidth(0);
						outertable.addCell(cell1);pageLine++;
						
						int [] tablew = {2,9,9,2,5,5};
						PdfPTable headertable1 = new PdfPTable(6);
						headertable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						headertable1.setWidths(tablew);
						headertable1.addCell(new Phrase("Plant :",TIMESBOLD_12));
						headertable1.addCell(new Phrase(plantName.trim(),TIMESNORAML_12));
						headertable1.addCell(new Phrase(magName.trim(),TIMESNORAML_12));
						headertable1.addCell(new Phrase("Issue :",TIMESBOLD_12));
						String issueDateDisp = issueDate + "   ("+ issueNum + " - " + issueWeek + ")";
						headertable1.addCell(new Phrase(issueDateDisp,TIMESNORAML_12));
						headertable1.addCell(new Phrase(deliveryType,TIMESBOLD_12));
						
						PdfPCell headercell1 = new PdfPCell(headertable1);
						headercell1.setBorderWidth(0);
						outertable.addCell(headercell1);pageLine++;
						
						outertable.addCell(dummyCell);pageLine++;
						
						int [] tableh2w = {9,3,1,3,1,9};
						PdfPTable headertable2 = new PdfPTable(6);
						headertable2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						headertable2.setWidths(tableh2w);
						headertable2.addCell(new Phrase("Pallet Parameters (Lbs)",TIMESBOLD_12));
						headertable2.addCell(new Phrase("Pallet Min:",TIMESBOLD_12));
						headertable2.addCell(new Phrase(palletMin,TIMESNORAML_12));
						headertable2.addCell(new Phrase("Pallet Max:",TIMESBOLD_12));
						headertable2.addCell(new Phrase(palletMax,TIMESNORAML_12));
						headertable2.addCell(new Phrase("Top Pallet < 1000 Lbs",TIMESBOLD_12));
						
						PdfPCell headercell2 = new PdfPCell(headertable2);
						headercell2.setBorderWidth(0);
						outertable.addCell(headercell2);pageLine++;
						
						outertable.addCell(dummyCell);pageLine++;
						
						
						int [] tableh3w = {3,2,4,9,4,9,2,7};
						PdfPTable headertable3 = new PdfPTable(8);
						headertable3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						headertable3.setWidths(tableh3w);
						String braceDisp = AddSpace.addSpace(braceId, 3, '0')+ " ";
						headertable3.addCell(new Phrase("Brace:",TIMESBOLD_12));
						headertable3.addCell(new Phrase(braceDisp,TIMESNORAML_12));
						headertable3.addCell(new Phrase("Leave Plant :",TIMESBOLD_12));
						headertable3.addCell(new Phrase(departDate,TIMESNORAML_12));
						headertable3.addCell(new Phrase("Dispatch:",TIMESBOLD_12));
						headertable3.addCell(new Phrase(braceName,TIMESNORAML_12));
						headertable3.addCell(new Phrase("Via :",TIMESBOLD_12));
						headertable3.addCell(new Phrase(carrName,TIMESNORAML_12));
						
						PdfPCell headercell3 = new PdfPCell(headertable3);
						headercell3.setBorderWidth(0);
						outertable.addCell(headercell3);pageLine++;
						
						outertable.addCell(dummyCell);pageLine++;
						
						int [] tableh4w = {4,2,5,9,4,9,3,7};
						PdfPTable headertable4 = new PdfPTable(8);
						headertable4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						headertable4.setWidths(tableh4w);
						headertable4.addCell(new Phrase("Drop-Off:",TIMESBOLD_12));
						headertable4.addCell(new Phrase(dropOffPt,TIMESNORAML_12));
						headertable4.addCell(new Phrase("Bind Group:",TIMESBOLD_12));
						headertable4.addCell(new Phrase(bindGrpName,TIMESNORAML_12));
						headertable4.addCell(new Phrase("P.O.E.:",TIMESBOLD_12));
						headertable4.addCell(new Phrase(entryPointLine,TIMESNORAML_12));
						headertable4.addCell(new Phrase("Arrives:",TIMESBOLD_12));
						headertable4.addCell(new Phrase(arrivalData,TIMESNORAML_12));
						
						PdfPCell headercell4 = new PdfPCell(headertable4);
						headercell4.setBorderWidth(0);
						outertable.addCell(headercell4);pageLine++;
						
						for(int i = 0; i<2; i++) {outertable.addCell(dummyCell);pageLine++;}								
						
						int [] tableh5w = {3,2,4,5,4,5,3,3,3,3,3};
						PdfPTable inertable = new PdfPTable(11);
						inertable.setWidths(tableh5w);
						inertable.getDefaultCell().setBorder(Rectangle.NO_BORDER | Rectangle.BOTTOM);
						inertable.getDefaultCell().setBorderWidthBottom(2);
						inertable.getDefaultCell().setPaddingBottom(5);
						inertable.addCell(new Phrase("Pallet Number",TIMESBOLD_12));
						inertable.addCell(new Phrase("Level",TIMESBOLD_12));
						inertable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_BOTTOM);
						inertable.addCell(new Phrase("Pallet Destination",TIMESBOLD_12));
						inertable.addCell(new Phrase("Package Range",TIMESBOLD_12));
						inertable.addCell(new Phrase("Package Count",TIMESBOLD_12));
						inertable.addCell(new Phrase("Zip Range",TIMESBOLD_12));
						inertable.addCell(new Phrase("Book Version",TIMESBOLD_12));
						inertable.addCell(new Phrase("Roll Number",TIMESBOLD_12));
						inertable.addCell(new Phrase("Label Count",TIMESBOLD_12));
						inertable.addCell(new Phrase("Pallet Weight",TIMESBOLD_12));
						inertable.addCell(new Phrase("Top/Full Pallet",TIMESBOLD_12));
						
						PdfPCell cell9 = new PdfPCell(inertable);
						cell9.setBorderWidth(0);
						outertable.addCell(cell9);pageLine++;
						
						PdfPTable cstHeaderTable = new PdfPTable(8);
						cstHeaderTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						cstHeaderTable.setWidths(cstTablew);
						cstHeaderTable.addCell(new Phrase(cnsolSubType,TIMESBOLD_12));
						for(int m=0; m<7;m++)
							cstHeaderTable.addCell(new Phrase("",TIMESBOLD_12));
								
						PdfPCell cstHeaderCell = new PdfPCell(cstHeaderTable);
						cstHeaderCell.setBorderWidth(0);
						outertable.addCell(cstHeaderCell);pageLine++;
						
						outertable.addCell(dummyCell);pageLine++;
						
					}
				}else{
					
					for(int a = 0; a < pkgElemList.size(); a++) {
						PlantpkgElem pkgElmDisp  = (PlantpkgElem)pkgElemList.get(a);
						if ( a == 0) {
							PlantpkgElem pkgLastElmDisp  = (PlantpkgElem)pkgElemList.get(pkgElemList.size()-1);
							topFull = "";
							if (savePalletInd.compareTo("P") == 0){
								dopPackge  += pkgLastElmDisp.getTotnumPkg();
								dopCopies  += pkgLastElmDisp.getTotCopyCnt();
								dopWeight  += pkgLastElmDisp.getTotpkgWght();
								if (pkgLastElmDisp.getTotpkgWght() < 1000){
									topFull = "TOP";dopTop += 1;
								}
								else {
									topFull = "FULL";dopFull += 1;
								}
							}
						String dataInfo = AddSpace.addSpace(pkgElmDisp.getPalletNum(),3,' ') + " " + AddSpace.addSpace(" ",3,' ') + AddSpace.fixSize(pkgElmDisp.getPstlLevel(), 4, ' ', AddSpace.LEFT) + " "  + AddSpace.fixSize(pkgElmDisp.getDestLine1(), 25, ' ', AddSpace.LEFT) + " " + AddSpace.addSpace(PlaceComma.placeComma((pkgLastElmDisp.getTotnumPkg())),3) + AddSpace.addSpace(" ",37,' ')+  AddSpace.addSpace(PlaceComma.placeComma((pkgLastElmDisp.getTotCopyCnt())),5) +AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(nf.format(pkgLastElmDisp.getTotpkgWght()),7,' ') + AddSpace.addSpace(" ",1,' ') +  AddSpace.addSpace(topFull, 3, ' '); 
						PdfPCell dataCell = new PdfPCell(new Phrase(dataInfo,
								COURIERNORMAL_12));
						dataCell.setBorderWidth(0);
						outertable.addCell(dataCell);pageLine++;
						}
						savePalletNum = palletNum;
						savePalletInd = palletInd;
						//String dataInfo1 = AddSpace.addSpace(" ",19,' ') + " " +  AddSpace.fixSize(pkgElmDisp.getPkgNumLtoH(),15,' ',AddSpace.LEFT) + AddSpace.addSpace(" ",3,' ') + AddSpace.addSpace(pkgElmDisp.getNumPkg(),3,' ') + AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(pkgElmDisp.getZipLtoH(),13,' ') + AddSpace.addSpace(" ",1,' ')+AddSpace.addSpace(pkgElmDisp.getBvVersion(),12,' ') + AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(pkgElmDisp.getRollNum(),3,'0') + " " + AddSpace.addSpace((PlaceComma.placeComma((Integer.valueOf(pkgElmDisp.getCopyCount())).intValue())),5) +AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(PlaceComma.placeStringComma(pkgElmDisp.getPkgWght()),7) ;
						String dataInfo1 = AddSpace.addSpace(" ",19,' ') + " " +  AddSpace.fixSize(pkgElmDisp.getPkgNumLtoH(),15,' ',AddSpace.LEFT) + AddSpace.addSpace(" ",3,' ') + AddSpace.addSpace(pkgElmDisp.getNumPkg(),3,' ') + AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(pkgElmDisp.getZipLtoH(),13,' ') + AddSpace.addSpace(" ",1,' ')+AddSpace.addSpace(pkgElmDisp.getBvVersion(),12,' ') + AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(pkgElmDisp.getRollNum(),3,'0') + " " + AddSpace.addSpace((PlaceComma.placeComma((Integer.valueOf(pkgElmDisp.getCopyCount())).intValue())),5)  ;
						PdfPCell dataCell1 = new PdfPCell(new Phrase(dataInfo1,
							COURIERNORMAL_12));
						dataCell1.setBorderWidth(0);
						outertable.addCell(dataCell1);pageLine++;
					}
					pkgElemList.clear();
					saveCnsolType = cnsolSubType;
					saveDropOffPt = dropOffPt;
					saveEntryPointLine = entryPointLine;
					saveBvVersion = bvVersion;
					saveBindGrpName = bindGrpName;
					saveBraceId = braceId;
					savePalletNum = palletNum;
					savePalletInd = palletInd;
					
					if (firstRpt)
						firstRpt = false;
					else{
						boolean newPage = false;
						LogWriter.writeLog(" Brace  --- 1 pageLine 1  : "  + pageLine);
						
						for(int z=0;z<2;z++) {outertable.addCell(dummyCell);pageLine++;}
						PdfPCell totdopCell1 = totDophdr();							
						outertable.addCell(totdopCell1);pageLine++;
						
						PdfPTable dopPalletTable = new PdfPTable(7);
						dopPalletTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						dopPalletTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						dopPalletTable.setWidths(dopdispw);
						
						String dopcopyCell = AddSpace.addSpace(PlaceComma.placeComma(dopCopies),7) + " "; 
						String dopWeightcell = AddSpace.addSpace(nf.format(dopWeight),7,' ') + " ";
						String dopPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(dopPackge),7) + " ";
						String dopTopCell = dopTop + " ";
						String dopFullCell = dopFull + " ";
						int totC = dopTop + dopFull;
						
						dopPalletTable.addCell(new Phrase("Pallets",TIMESBOLD_12));
						dopPalletTable.addCell(new Phrase(dopcopyCell,COURIERNORMAL_12));
						dopPalletTable.addCell(new Phrase(dopWeightcell,COURIERNORMAL_12));
						dopPalletTable.addCell(new Phrase(dopPackgeCell,COURIERNORMAL_12));
						dopPalletTable.addCell(new Phrase(dopFullCell,COURIERNORMAL_12));
						dopPalletTable.addCell(new Phrase(dopTopCell,COURIERNORMAL_12));
						dopPalletTable.addCell(new Phrase(Integer.toString(totC),COURIERNORMAL_12));
						
						PdfPCell dopPalletCell = new PdfPCell(dopPalletTable);
						dopPalletCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						dopPalletCell.setBorderWidth(0);
						outertable.addCell(dopPalletCell);pageLine++;
						
						String dopSackcopyCell = AddSpace.addSpace(PlaceComma.placeComma(dopSackCopies),7) + " ";
						String dopSackWghtCell = AddSpace.addSpace(nf.format(dopSackWght),7,' ') + " ";
						String dopSackPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(dopSackPackge),7) + " ";
						
						PdfPTable dopSackTable = new PdfPTable(7);
						dopSackTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						dopSackTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						dopSackTable.setWidths(dopdispw);
						dopSackTable.addCell(new Phrase("Sacks",TIMESBOLD_12));
						dopSackTable.addCell(new Phrase(dopSackcopyCell,COURIERNORMAL_12));
						dopSackTable.addCell(new Phrase(dopSackWghtCell,COURIERNORMAL_12));
						dopSackTable.addCell(new Phrase(dopSackPackgeCell,COURIERNORMAL_12));
						dopSackTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						dopSackTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						dopSackTable.addCell(new Phrase(Integer.toString(dopSakCont),COURIERNORMAL_12));
						
						PdfPCell dopSackCell = new PdfPCell(dopSackTable);
						dopSackCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						dopSackCell.setBorderWidth(0);
						outertable.addCell(dopSackCell);pageLine++;
//
						String dopAirboxcopyCell = AddSpace.addSpace(PlaceComma.placeComma(dopAirboxCopies),7) + " ";
						String dopAirboxWghtCell = AddSpace.addSpace(nf.format(dopAirboxWght),7,' ') + " ";
						String dopAirboxPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(dopAirboxPackge),7) + " ";
						
						PdfPTable dopAirboxTable = new PdfPTable(7);
						dopAirboxTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						dopAirboxTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						dopAirboxTable.setWidths(dopdispw);
						dopAirboxTable.addCell(new Phrase("Air Boxes",TIMESBOLD_12));
						dopAirboxTable.addCell(new Phrase(dopAirboxcopyCell,COURIERNORMAL_12));
						dopAirboxTable.addCell(new Phrase(dopAirboxWghtCell,COURIERNORMAL_12));
						dopAirboxTable.addCell(new Phrase(dopAirboxPackgeCell,COURIERNORMAL_12));
						dopAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						dopAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						dopAirboxTable.addCell(new Phrase(Integer.toString(dopAirboxCont),COURIERNORMAL_12));
						
						PdfPCell dopAirboxCell = new PdfPCell(dopAirboxTable);
						dopAirboxCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						dopAirboxCell.setBorderWidth(0);
						outertable.addCell(dopAirboxCell);pageLine++;
						
//						
						int dopCombPackage = dopPackge + dopSackPackge + dopAirboxPackge;
						int dopCombCopies = dopCopies + dopSackCopies + dopAirboxCopies;
						double dopCombWght = dopWeight + dopSackWght + dopAirboxWght;
						int totcombCont = totC + dopSakCont + dopAirboxCont;
						String dopcombcopyCell = AddSpace.addSpace(PlaceComma.placeComma(dopCombCopies),7) + " ";
						String dopCombWghtCell = AddSpace.addSpace(nf.format(dopCombWght),7,' ') + " ";
						String dopCombPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(dopCombPackage),7) + " ";
						
						PdfPTable dopCombTable = new PdfPTable(7);
						dopCombTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						dopCombTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						dopCombTable.setWidths(dopdispw);
						dopCombTable.addCell(new Phrase("Combined",TIMESBOLD_12));
						dopCombTable.addCell(new Phrase(dopcombcopyCell,COURIERNORMAL_12));
						dopCombTable.addCell(new Phrase(dopCombWghtCell,COURIERNORMAL_12));
						dopCombTable.addCell(new Phrase(dopCombPackgeCell,COURIERNORMAL_12));
						dopCombTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						dopCombTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						dopCombTable.addCell(new Phrase(Integer.toString(totcombCont),COURIERNORMAL_12));
						
						PdfPCell dopCombCell = new PdfPCell(dopCombTable);
						dopCombCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						dopCombCell.setBorderWidth(0);
						//pageLine+=4;  changed to pageLine++;
						outertable.addCell(dopCombCell);pageLine++;
						
						bgtPalCopies += dopCopies;
						bgtPalPackage += dopPackge;
						bgtPalWeight += dopWeight;
						bgtSakCopies += dopSackCopies;
						bgtSakPackage += dopSackPackge;
						bgtSakWeight += dopSackWght;
						bgtAirboxCopies += dopAirboxCopies;
						bgtAirboxPackage += dopAirboxPackge;
						bgtAirboxWeight += dopAirboxWght;
						bgttop += dopTop;
						bgtFull += dopFull;
						bgtPalCont += totC;
						bgtSakCont += dopSakCont;
						bgtAirboxCont += dopAirboxCont;
						
						dopPackge  = 0;
						dopCopies  = 0;
						dopWeight =0;
						dopTop = 0;
						dopFull = 0;
						dopSackCopies = 0;
						dopSackWght = 0;
						dopSackPackge = 0;dopSakCont=0;
						dopAirboxCopies = 0;
						dopAirboxWght = 0;
						dopAirboxPackge = 0;dopAirboxCont=0;
						dopCombPackage= 0;dopCombCopies=0;totcombCont=0;dopCombWght=0;
						
						LogWriter.writeLog(" Brace  --- 2 pageLine 1  : "  + pageLine);
						
						for(int z=0;z<2;z++) {outertable.addCell(dummyCell);pageLine++;}
						PdfPCell totBindGrpCell1 = totBindGrphdr();							
						outertable.addCell(totBindGrpCell1);pageLine++;
						
						//	Binding Group start
						
						PdfPTable bgtPalletTable = new PdfPTable(7);
						bgtPalletTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						bgtPalletTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						bgtPalletTable.setWidths(dopdispw);
						
						String bgtcopyCell = AddSpace.addSpace(PlaceComma.placeComma(bgtPalCopies),7) + " "; 
						String bgtWeightcell = AddSpace.addSpace(nf.format(bgtPalWeight),7,' ') + " ";
						String bgtPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(bgtPalPackage),7) + " ";
						
						
						bgtPalletTable.addCell(new Phrase("Pallets",TIMESBOLD_12));
						bgtPalletTable.addCell(new Phrase(bgtcopyCell,COURIERNORMAL_12));
						bgtPalletTable.addCell(new Phrase(bgtWeightcell,COURIERNORMAL_12));
						bgtPalletTable.addCell(new Phrase(bgtPackgeCell,COURIERNORMAL_12));
						bgtPalletTable.addCell(new Phrase(Integer.toString(bgtFull),COURIERNORMAL_12));
						bgtPalletTable.addCell(new Phrase(Integer.toString(bgttop),COURIERNORMAL_12));
						bgtPalletTable.addCell(new Phrase(Integer.toString(bgtPalCont),COURIERNORMAL_12));
						
						PdfPCell bgtPalletCell = new PdfPCell(bgtPalletTable);
						bgtPalletCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						bgtPalletCell.setBorderWidth(0);
						outertable.addCell(bgtPalletCell);pageLine++;
						
						String bgtSackcopyCell = AddSpace.addSpace(PlaceComma.placeComma(bgtSakCopies),7) + " ";
						String bgtSackWghtCell = AddSpace.addSpace(nf.format(bgtSakWeight),7,' ') + " ";
						String bgtSackPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(bgtSakPackage),7) + " ";
						
						PdfPTable bgtSackTable = new PdfPTable(7);
						bgtSackTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						bgtSackTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						bgtSackTable.setWidths(dopdispw);
						bgtSackTable.addCell(new Phrase("Sacks",TIMESBOLD_12));
						bgtSackTable.addCell(new Phrase(bgtSackcopyCell,COURIERNORMAL_12));
						bgtSackTable.addCell(new Phrase(bgtSackWghtCell,COURIERNORMAL_12));
						bgtSackTable.addCell(new Phrase(bgtSackPackgeCell,COURIERNORMAL_12));
						bgtSackTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						bgtSackTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						bgtSackTable.addCell(new Phrase(Integer.toString(bgtSakCont),COURIERNORMAL_12));
						
						PdfPCell bgtSackCell = new PdfPCell(bgtSackTable);
						bgtSackCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						bgtSackCell.setBorderWidth(0);
						outertable.addCell(bgtSackCell);pageLine++;
//
						String bgtAirboxcopyCell = AddSpace.addSpace(PlaceComma.placeComma(bgtAirboxCopies),7) + " ";
						String bgtAirboxWghtCell = AddSpace.addSpace(nf.format(bgtAirboxWeight),7,' ') + " ";
						String bgtAirboxPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(bgtAirboxPackage),7) + " ";

						PdfPTable bgtAirboxTable = new PdfPTable(7);
						bgtAirboxTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						bgtAirboxTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						bgtAirboxTable.setWidths(dopdispw);
						bgtAirboxTable.addCell(new Phrase("Air Boxes",TIMESBOLD_12));
						bgtAirboxTable.addCell(new Phrase(bgtAirboxcopyCell,COURIERNORMAL_12));
						bgtAirboxTable.addCell(new Phrase(bgtAirboxWghtCell,COURIERNORMAL_12));
						bgtAirboxTable.addCell(new Phrase(bgtAirboxPackgeCell,COURIERNORMAL_12));
						bgtAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						bgtAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						bgtAirboxTable.addCell(new Phrase(Integer.toString(bgtAirboxCont),COURIERNORMAL_12));
						
						PdfPCell bgtAirboxCell = new PdfPCell(bgtAirboxTable);
						bgtAirboxCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						bgtAirboxCell.setBorderWidth(0);
						outertable.addCell(bgtAirboxCell);pageLine++;
						
//						
						int bgtCombCopies = bgtPalCopies + bgtSakCopies + bgtAirboxCopies;
						int bgtCombPackage = bgtPalPackage + bgtSakPackage + bgtAirboxPackage;
						double bgtCombWght = bgtPalWeight + bgtSakWeight + bgtAirboxWeight;
						int bgtcombCont = bgtPalCont + bgtSakCont + bgtAirboxCont;
						String bgtcombcopyCell = AddSpace.addSpace(PlaceComma.placeComma(bgtCombCopies),7) + " ";
						String bgtCombWghtCell = AddSpace.addSpace(nf.format(bgtCombWght),7,' ') + " ";
						String bgtCombPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(bgtCombPackage),7) + " ";
						
						PdfPTable bgtCombTable = new PdfPTable(7);
						bgtCombTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						bgtCombTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						bgtCombTable.setWidths(dopdispw);
						bgtCombTable.addCell(new Phrase("Combined",TIMESBOLD_12));
						bgtCombTable.addCell(new Phrase(bgtcombcopyCell,COURIERNORMAL_12));
						bgtCombTable.addCell(new Phrase(bgtCombWghtCell,COURIERNORMAL_12));
						bgtCombTable.addCell(new Phrase(bgtCombPackgeCell,COURIERNORMAL_12));
						bgtCombTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						bgtCombTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						bgtCombTable.addCell(new Phrase(Integer.toString(bgtcombCont),COURIERNORMAL_12));
						
						PdfPCell bgtCombCell = new PdfPCell(bgtCombTable);
						bgtCombCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						bgtCombCell.setBorderWidth(0);
						//pageLine+=4;  changed to pageLine++;
						outertable.addCell(bgtCombCell);pageLine++;
						
						bracePalCopies += bgtPalCopies;
						bracePalPackage += bgtPalPackage;
						bracePalWeight += bgtPalWeight;
						braceSakCopies += bgtSakCopies;
						braceSakPackage += bgtSakPackage;
						braceSakWeight += bgtSakWeight;
						braceAirboxCopies += bgtAirboxCopies;
						braceAirboxPackage += bgtAirboxPackage;
						braceAirboxWeight += bgtAirboxWeight;
						braceTop += bgttop;
						braceFull += bgtFull;
						bracePalCont += bgtPalCont;
						braceSakCont += bgtSakCont;
						braceAirboxCont += bgtAirboxCont;
						
						
						bgtPalCopies = 0;
						bgtPalPackage = 0;
						bgtPalWeight = 0;
						bgtSakCopies = 0;
						bgtSakPackage = 0;
						bgtSakWeight = 0;
						bgtAirboxCopies = 0;
						bgtAirboxPackage = 0;
						bgtAirboxWeight = 0;
						bgttop = 0;
						bgtFull = 0;
						bgtPalCont = 0;
						bgtSakCont = 0;
						bgtAirboxCont = 0;
						
						//   Binding Group End
						
						LogWriter.writeLog(" Brace  --- 3 pageLine 1  : "  + pageLine);
						
						for(int z=0;z<2;z++) {outertable.addCell(dummyCell);pageLine++;}
						PdfPCell totBraceCell1 = totBracehdr();							
						outertable.addCell(totBraceCell1);pageLine++;
						
						//	Brace start
						
						PdfPTable bracePalletTable = new PdfPTable(7);
						bracePalletTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						bracePalletTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						bracePalletTable.setWidths(dopdispw);
						
						String bracecopyCell = AddSpace.addSpace(PlaceComma.placeComma(bracePalCopies),7) + " "; 
						String braceWeightcell = AddSpace.addSpace(nf.format(bracePalWeight),7,' ') + " ";
						String bracePackgeCell = AddSpace.addSpace(PlaceComma.placeComma(bracePalPackage),7) + " ";
						
						bracePalletTable.addCell(new Phrase("Pallets",TIMESBOLD_12));
						bracePalletTable.addCell(new Phrase(bracecopyCell,COURIERNORMAL_12));
						bracePalletTable.addCell(new Phrase(braceWeightcell,COURIERNORMAL_12));
						bracePalletTable.addCell(new Phrase(bracePackgeCell,COURIERNORMAL_12));
						bracePalletTable.addCell(new Phrase(Integer.toString(braceFull),COURIERNORMAL_12));
						bracePalletTable.addCell(new Phrase(Integer.toString(braceTop),COURIERNORMAL_12));
						bracePalletTable.addCell(new Phrase(Integer.toString(bracePalCont),COURIERNORMAL_12));
						
						PdfPCell bracePalletCell = new PdfPCell(bracePalletTable);
						bracePalletCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						bracePalletCell.setBorderWidth(0);
						outertable.addCell(bracePalletCell);pageLine++;
						
						String braceSackcopyCell = AddSpace.addSpace(PlaceComma.placeComma(braceSakCopies),7) + " ";
						String braceSackWghtCell = AddSpace.addSpace(nf.format(braceSakWeight),7,' ') + " ";
						String braceSackPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(braceSakPackage),7) + " ";
						
						PdfPTable braceSackTable = new PdfPTable(7);
						braceSackTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						braceSackTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						braceSackTable.setWidths(dopdispw);
						braceSackTable.addCell(new Phrase("Sacks",TIMESBOLD_12));
						braceSackTable.addCell(new Phrase(braceSackcopyCell,COURIERNORMAL_12));
						braceSackTable.addCell(new Phrase(braceSackWghtCell,COURIERNORMAL_12));
						braceSackTable.addCell(new Phrase(braceSackPackgeCell,COURIERNORMAL_12));
						braceSackTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						braceSackTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						braceSackTable.addCell(new Phrase(Integer.toString(braceSakCont),COURIERNORMAL_12));
						
						PdfPCell braceSackCell = new PdfPCell(braceSackTable);
						braceSackCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						braceSackCell.setBorderWidth(0);
						outertable.addCell(braceSackCell);pageLine++;
//
						String braceAirboxcopyCell = AddSpace.addSpace(PlaceComma.placeComma(braceAirboxCopies),7) + " ";
						String braceAirboxWghtCell = AddSpace.addSpace(nf.format(braceAirboxWeight),7,' ') + " ";
						String braceAirboxPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(braceAirboxPackage),7) + " ";
						
						PdfPTable braceAirboxTable = new PdfPTable(7);
						braceAirboxTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						braceAirboxTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						braceAirboxTable.setWidths(dopdispw);
						braceAirboxTable.addCell(new Phrase("Air Boxes",TIMESBOLD_12));
						braceAirboxTable.addCell(new Phrase(braceAirboxcopyCell,COURIERNORMAL_12));
						braceAirboxTable.addCell(new Phrase(braceAirboxWghtCell,COURIERNORMAL_12));
						braceAirboxTable.addCell(new Phrase(braceAirboxPackgeCell,COURIERNORMAL_12));
						braceAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						braceAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						braceAirboxTable.addCell(new Phrase(Integer.toString(braceAirboxCont),COURIERNORMAL_12));
						
						PdfPCell braceAirboxCell = new PdfPCell(braceAirboxTable);
						braceAirboxCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						braceAirboxCell.setBorderWidth(0);
						outertable.addCell(braceAirboxCell);pageLine++;
						
//
						int braceCombCopies = bracePalCopies + braceSakCopies + braceAirboxCopies;
						int braceCombPackage = bracePalPackage + braceSakPackage + braceAirboxPackage;
						double braceCombWght = bracePalWeight + braceSakWeight + braceAirboxWeight;
						int bracecombCont = bracePalCont + braceSakCont + braceAirboxCont;
						String bracecombcopyCell = AddSpace.addSpace(PlaceComma.placeComma(braceCombCopies),7) + " ";
						String braceCombWghtCell = AddSpace.addSpace(nf.format(braceCombWght),7,' ') + " ";
						String braceCombPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(braceCombPackage),7) + " ";
						
						PdfPTable braceCombTable = new PdfPTable(7);
						braceCombTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						braceCombTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
						braceCombTable.setWidths(dopdispw);
						braceCombTable.addCell(new Phrase("Combined",TIMESBOLD_12));
						braceCombTable.addCell(new Phrase(bracecombcopyCell,COURIERNORMAL_12));
						braceCombTable.addCell(new Phrase(braceCombWghtCell,COURIERNORMAL_12));
						braceCombTable.addCell(new Phrase(braceCombPackgeCell,COURIERNORMAL_12));
						braceCombTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						braceCombTable.addCell(new Phrase(" ",COURIERNORMAL_12));
						braceCombTable.addCell(new Phrase(Integer.toString(bracecombCont),COURIERNORMAL_12));
						
						PdfPCell braceCombCell = new PdfPCell(braceCombTable);
						braceCombCell.setHorizontalAlignment(Element.ALIGN_CENTER);
						braceCombCell.setBorderWidth(0);
						//pageLine+=4;  changed to pageLine++;
						outertable.addCell(braceCombCell);pageLine++;
						pprDoc.newPage();
						plantPalCopies += bracePalCopies;
						plantPalPackage += bracePalPackage;
						plantPalWeight += bracePalWeight;
						plantSakCopies += braceSakCopies;
						plantSakPackage += braceSakPackage;
						plantSakWeight += braceSakWeight;
						plantAirboxCopies += braceAirboxCopies;
						plantAirboxPackage += braceAirboxPackage;
						plantAirboxWeight += braceAirboxWeight;
						plantTop += braceTop;
						plantFull += braceFull;
						plantPalCont += bracePalCont;
						plantSakCont += braceSakCont;
						plantAirboxCont += braceAirboxCont;

						
						bracePalCopies = 0;
						bracePalPackage = 0;
						bracePalWeight = 0;
						braceSakCopies = 0;
						braceSakPackage = 0;
						braceSakWeight = 0;
						braceAirboxCopies = 0;
						braceAirboxPackage = 0;
						braceAirboxWeight = 0;
						braceTop = 0;
						braceFull = 0;
						bracePalCont = 0;
						braceSakCont = 0;
						braceAirboxCont = 0;

						// Brace End
						LogWriter.writeLog(" Brace  --- 4 pageLine 1  : "  + pageLine);
						pageLine = 0;
						
						pprDoc.add(outertable);
					}	

					
					outertable = new PdfPTable(1);
					outertable.setHeaderRows(14);
					
					String dateHdr = String.valueOf(dateFormat.format(toDay)) + "Issue :"+ issueNum + " - " + issueWeek + "Cover :" + issueDate; 
					PdfPCell header0 = new PdfPCell(new Phrase(dateHdr,
							FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,Color.black)));
					header0.setBorderWidth(0);
					outertable.addCell(header0);pageLine++;
						
				
					PdfPCell cell1 = new PdfPCell(new Phrase(
							"Plant Pallet / Sack Report", FontFactory.getFont(FontFactory.TIMES_ROMAN, 24, Font.BOLD, Color.BLACK)));
					cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell1.setBorderWidth(0);
					outertable.addCell(cell1);pageLine++;
					
					int [] tablew = {2,9,9,2,5,5};
					PdfPTable headertable1 = new PdfPTable(6);
					headertable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
					headertable1.setWidths(tablew);
					headertable1.addCell(new Phrase("Plant :",TIMESBOLD_12));
					headertable1.addCell(new Phrase(plantName.trim(),TIMESNORAML_12));
					headertable1.addCell(new Phrase(magName.trim(),TIMESNORAML_12));
					headertable1.addCell(new Phrase("Issue :",TIMESBOLD_12));
					String issueDateDisp = issueDate + "   ("+ issueNum + " - " + issueWeek + ")";
					headertable1.addCell(new Phrase(issueDateDisp,TIMESNORAML_12));
					headertable1.addCell(new Phrase(deliveryType,TIMESBOLD_12));
					
					PdfPCell headercell1 = new PdfPCell(headertable1);
					headercell1.setBorderWidth(0);
					outertable.addCell(headercell1);pageLine++;
					
					outertable.addCell(dummyCell);pageLine++;
					
					int [] tableh2w = {9,3,1,3,1,9};
					PdfPTable headertable2 = new PdfPTable(6);
					headertable2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
					headertable2.setWidths(tableh2w);
					headertable2.addCell(new Phrase("Pallet Parameters (Lbs)",TIMESBOLD_12));
					headertable2.addCell(new Phrase("Pallet Min:",TIMESBOLD_12));
					headertable2.addCell(new Phrase(palletMin,TIMESNORAML_12));
					headertable2.addCell(new Phrase("Pallet Max:",TIMESBOLD_12));
					headertable2.addCell(new Phrase(palletMax,TIMESNORAML_12));
					headertable2.addCell(new Phrase("Top Pallet < 1000 Lbs",TIMESBOLD_12));
					
					PdfPCell headercell2 = new PdfPCell(headertable2);
					headercell2.setBorderWidth(0);
					outertable.addCell(headercell2);pageLine++;
					
					outertable.addCell(dummyCell);pageLine++;
					
					
					int [] tableh3w = {3,2,4,9,4,9,2,7};
					PdfPTable headertable3 = new PdfPTable(8);
					headertable3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
					headertable3.setWidths(tableh3w);
					String braceDisp = AddSpace.addSpace(braceId, 3, '0')+ " ";
					headertable3.addCell(new Phrase("Brace:",TIMESBOLD_12));
					headertable3.addCell(new Phrase(braceDisp,TIMESNORAML_12));
					headertable3.addCell(new Phrase("Leave Plant :",TIMESBOLD_12));
					headertable3.addCell(new Phrase(departDate,TIMESNORAML_12));
					headertable3.addCell(new Phrase("Dispatch:",TIMESBOLD_12));
					headertable3.addCell(new Phrase(braceName,TIMESNORAML_12));
					headertable3.addCell(new Phrase("Via :",TIMESBOLD_12));
					headertable3.addCell(new Phrase(carrName,TIMESNORAML_12));
					
					PdfPCell headercell3 = new PdfPCell(headertable3);
					headercell3.setBorderWidth(0);
					outertable.addCell(headercell3);pageLine++;
					
					outertable.addCell(dummyCell);pageLine++;
					
					int [] tableh4w = {4,2,5,9,4,9,3,7};
					PdfPTable headertable4 = new PdfPTable(8);
					headertable4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
					headertable4.setWidths(tableh4w);
					headertable4.addCell(new Phrase("Drop-Off:",TIMESBOLD_12));
					headertable4.addCell(new Phrase(dropOffPt,TIMESNORAML_12));
					headertable4.addCell(new Phrase("Bind Group:",TIMESBOLD_12));
					headertable4.addCell(new Phrase(bindGrpName,TIMESNORAML_12));
					headertable4.addCell(new Phrase("P.O.E.:",TIMESBOLD_12));
					headertable4.addCell(new Phrase(entryPointLine,TIMESNORAML_12));
					headertable4.addCell(new Phrase("Arrives:",TIMESBOLD_12));
					headertable4.addCell(new Phrase(arrivalData,TIMESNORAML_12));
					
					PdfPCell headercell4 = new PdfPCell(headertable4);
					headercell4.setBorderWidth(0);
					outertable.addCell(headercell4);pageLine++;
					
					for(int i = 0; i<2; i++){outertable.addCell(dummyCell);pageLine++;}								
					
					int [] tableh5w = {3,2,4,5,4,5,3,3,3,3,3};
					PdfPTable inertable = new PdfPTable(11);
					inertable.setWidths(tableh5w);
					inertable.getDefaultCell().setBorder(Rectangle.NO_BORDER | Rectangle.BOTTOM);
					inertable.getDefaultCell().setBorderWidthBottom(2);
					inertable.getDefaultCell().setPaddingBottom(5);
					inertable.addCell(new Phrase("Pallet Number",TIMESBOLD_12));
					inertable.addCell(new Phrase("Level",TIMESBOLD_12));
					inertable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_BOTTOM);
					inertable.addCell(new Phrase("Pallet Destination",TIMESBOLD_12));
					inertable.addCell(new Phrase("Package Range",TIMESBOLD_12));
					inertable.addCell(new Phrase("Package Count",TIMESBOLD_12));
					inertable.addCell(new Phrase("Zip Range",TIMESBOLD_12));
					inertable.addCell(new Phrase("Book Version",TIMESBOLD_12));
					inertable.addCell(new Phrase("Roll Number",TIMESBOLD_12));
					inertable.addCell(new Phrase("Label Count",TIMESBOLD_12));
					inertable.addCell(new Phrase("Pallet Weight",TIMESBOLD_12));
					inertable.addCell(new Phrase("Top/Full Pallet",TIMESBOLD_12));
					
					PdfPCell cell9 = new PdfPCell(inertable);
					cell9.setBorderWidth(0);
					outertable.addCell(cell9);pageLine++;
					
					PdfPTable cstHeaderTable = new PdfPTable(8);
					cstHeaderTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
					cstHeaderTable.setWidths(cstTablew);
					cstHeaderTable.addCell(new Phrase(cnsolSubType,TIMESBOLD_12));
					for(int m=0; m<7;m++)
						cstHeaderTable.addCell(new Phrase("",TIMESBOLD_12));
							
					PdfPCell cstHeaderCell = new PdfPCell(cstHeaderTable);
					cstHeaderCell.setBorderWidth(0);
					outertable.addCell(cstHeaderCell);pageLine++;
					
					outertable.addCell(dummyCell);pageLine++;
					
					//cnsolSubType
					
					pkgElemList.clear(); 
					
					
					if (palletInd.compareTo("S") == 0){
						dopSackCopies += Integer.valueOf(copyCount).intValue();
						dopSackWght += Double.valueOf(pkgWght).doubleValue();
						dopSakCont += 1;
						dopSackPackge += Integer.valueOf(numPkg).intValue();
					}
					else{
						if (palletInd.compareTo("A") == 0){
							dopAirboxCopies += Integer.valueOf(copyCount).intValue();
							dopAirboxWght += Double.valueOf(pkgWght).doubleValue();
							dopAirboxCont += 1;
							dopAirboxPackge += Integer.valueOf(numPkg).intValue();							
						}
						totCopyCnt = 0; totpkgWght = 0;totnumPkg = 0;
						totCopyCnt += Integer.valueOf(copyCount).intValue();
						totpkgWght += Double.valueOf(pkgWght).doubleValue();
						totnumPkg  += Integer.valueOf(numPkg).intValue();
						pkgElm = new PlantpkgElem(pkgNumLtoH, zipLtoH, bvVersion, rollNum, palletNum, numPkg,copyCount,pkgWght,totCopyCnt,totpkgWght,totnumPkg,destLine1,pstlLevel);
						pkgElemList.add(pkgElm);	
					}
					
					//dopTotList.add(arg0)
					
				}
				
				
			}

			if (noPlantPallet) {
			for(int a = 0; a < pkgElemList.size(); a++) {
				PlantpkgElem pkgElmDisp  = (PlantpkgElem)pkgElemList.get(a);
				if ( a == 0) {
					PlantpkgElem pkgLastElmDisp  = (PlantpkgElem)pkgElemList.get(pkgElemList.size()-1);
					topFull = "";
					if(savedLastPalletInd.equals("P")) {
						dopPackge  += pkgLastElmDisp.getTotnumPkg();
						dopCopies  += pkgLastElmDisp.getTotCopyCnt();
						dopWeight  += pkgLastElmDisp.getTotpkgWght();
						if (pkgLastElmDisp.getTotpkgWght() < 1000){
							topFull = "TOP";dopTop += 1;
						}
						else {
							topFull = "FULL";dopFull += 1;
						}
					}
				String dataInfo = AddSpace.addSpace(pkgElmDisp.getPalletNum(),3,' ') + " " + AddSpace.addSpace(" ",3,' ') + AddSpace.fixSize(pkgElmDisp.getPstlLevel(), 4, ' ', AddSpace.LEFT) + " " + AddSpace.fixSize(pkgElmDisp.getDestLine1(), 25, ' ', AddSpace.LEFT) + " " + AddSpace.addSpace(PlaceComma.placeComma((pkgLastElmDisp.getTotnumPkg())),3) + AddSpace.addSpace(" ",37,' ')+  AddSpace.addSpace(PlaceComma.placeComma((pkgLastElmDisp.getTotCopyCnt())),5) +AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(nf.format(pkgLastElmDisp.getTotpkgWght()),7,' ') + AddSpace.addSpace(" ",1,' ') +  AddSpace.addSpace(topFull, 3, ' '); 
				PdfPCell dataCell = new PdfPCell(new Phrase(dataInfo,
						COURIERNORMAL_12));
				dataCell.setBorderWidth(0);
				outertable.addCell(dataCell);pageLine++;
				}
				//String dataInfo1 = AddSpace.addSpace(" ",19,' ') + " " +  AddSpace.fixSize(pkgElmDisp.getPkgNumLtoH(),15,' ',AddSpace.LEFT) + AddSpace.addSpace(" ",3,' ') + AddSpace.addSpace(pkgElmDisp.getNumPkg(),3,' ') + AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(pkgElmDisp.getZipLtoH(),13,' ') + AddSpace.addSpace(" ",1,' ')+AddSpace.addSpace(pkgElmDisp.getBvVersion(),12,' ') + AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(pkgElmDisp.getRollNum(),3,'0') + " " + AddSpace.addSpace((PlaceComma.placeComma((Integer.valueOf(pkgElmDisp.getCopyCount())).intValue())),5) +AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(PlaceComma.placeStringComma(pkgElmDisp.getPkgWght()),7) ;
				String dataInfo1 = AddSpace.addSpace(" ",19,' ') + " " +  AddSpace.fixSize(pkgElmDisp.getPkgNumLtoH(),15,' ',AddSpace.LEFT) + AddSpace.addSpace(" ",3,' ') + AddSpace.addSpace(pkgElmDisp.getNumPkg(),3,' ') + AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(pkgElmDisp.getZipLtoH(),13,' ') + AddSpace.addSpace(" ",1,' ')+AddSpace.addSpace(pkgElmDisp.getBvVersion(),12,' ') + AddSpace.addSpace(" ",1,' ')+ AddSpace.addSpace(pkgElmDisp.getRollNum(),3,'0') + " " + AddSpace.addSpace((PlaceComma.placeComma((Integer.valueOf(pkgElmDisp.getCopyCount())).intValue())),5)  ;
				PdfPCell dataCell1 = new PdfPCell(new Phrase(dataInfo1,
					COURIERNORMAL_12));
				dataCell1.setBorderWidth(0);
				outertable.addCell(dataCell1);pageLine++;
				//pkgElemList.clear();
			}
			
			for(int z=0;z<2;z++) {outertable.addCell(dummyCell);pageLine++;}
			PdfPCell totdopCell1 = totDophdr();							
			outertable.addCell(totdopCell1);pageLine++;
			
			PdfPTable dopPalletTable = new PdfPTable(7);
			dopPalletTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			dopPalletTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			dopPalletTable.setWidths(dopdispw);
			
			String dopcopyCell = AddSpace.addSpace(PlaceComma.placeComma(dopCopies),7) + " "; 
			String dopWeightcell = AddSpace.addSpace(nf.format(dopWeight),7,' ') + " ";
			String dopPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(dopPackge),7) + " ";
			String dopTopCell = dopTop + " ";
			String dopFullCell = dopFull + " ";
			int totC = dopTop + dopFull;
			
			dopPalletTable.addCell(new Phrase("Pallets",TIMESBOLD_12));
			dopPalletTable.addCell(new Phrase(dopcopyCell,COURIERNORMAL_12));
			dopPalletTable.addCell(new Phrase(dopWeightcell,COURIERNORMAL_12));
			dopPalletTable.addCell(new Phrase(dopPackgeCell,COURIERNORMAL_12));
			dopPalletTable.addCell(new Phrase(dopFullCell,COURIERNORMAL_12));
			dopPalletTable.addCell(new Phrase(dopTopCell,COURIERNORMAL_12));
			dopPalletTable.addCell(new Phrase(Integer.toString(totC),COURIERNORMAL_12));
			
			PdfPCell dopPalletCell = new PdfPCell(dopPalletTable);
			dopPalletCell.setHorizontalAlignment(Element.ALIGN_CENTER);
			dopPalletCell.setBorderWidth(0);
			outertable.addCell(dopPalletCell);pageLine++;
			
			String dopSackcopyCell = AddSpace.addSpace(PlaceComma.placeComma(dopSackCopies),7) + " ";
			String dopSackWghtCell = AddSpace.addSpace(nf.format(dopSackWght),7,' ') + " ";
			String dopSackPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(dopSackPackge),7) + " ";
			
			PdfPTable dopSackTable = new PdfPTable(7);
			dopSackTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			dopSackTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			dopSackTable.setWidths(dopdispw);
			dopSackTable.addCell(new Phrase("Sacks",TIMESBOLD_12));
			dopSackTable.addCell(new Phrase(dopSackcopyCell,COURIERNORMAL_12));
			dopSackTable.addCell(new Phrase(dopSackWghtCell,COURIERNORMAL_12));
			dopSackTable.addCell(new Phrase(dopSackPackgeCell,COURIERNORMAL_12));
			dopSackTable.addCell(new Phrase(" ",COURIERNORMAL_12));
			dopSackTable.addCell(new Phrase(" ",COURIERNORMAL_12));
			dopSackTable.addCell(new Phrase(Integer.toString(dopSakCont),COURIERNORMAL_12));
			
			PdfPCell dopSackCell = new PdfPCell(dopSackTable);
			dopSackCell.setHorizontalAlignment(Element.ALIGN_CENTER);
			dopSackCell.setBorderWidth(0);
			outertable.addCell(dopSackCell);pageLine++;
//
			
			String dopAirboxcopyCell = AddSpace.addSpace(PlaceComma.placeComma(dopAirboxCopies),7) + " ";
			String dopAirboxWghtCell = AddSpace.addSpace(nf.format(dopAirboxWght),7,' ') + " ";
			String dopAirboxPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(dopAirboxPackge),7) + " ";
			
			PdfPTable dopAirboxTable = new PdfPTable(7);
			dopAirboxTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			dopAirboxTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			dopAirboxTable.setWidths(dopdispw);
			dopAirboxTable.addCell(new Phrase("Air Boxes",TIMESBOLD_12));
			dopAirboxTable.addCell(new Phrase(dopAirboxcopyCell,COURIERNORMAL_12));
			dopAirboxTable.addCell(new Phrase(dopAirboxWghtCell,COURIERNORMAL_12));
			dopAirboxTable.addCell(new Phrase(dopAirboxPackgeCell,COURIERNORMAL_12));
			dopAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_12));
			dopAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_12));
			dopAirboxTable.addCell(new Phrase(Integer.toString(dopAirboxCont),COURIERNORMAL_12));
			
			PdfPCell dopAirboxCell = new PdfPCell(dopAirboxTable);
			dopAirboxCell.setHorizontalAlignment(Element.ALIGN_CENTER);
			dopAirboxCell.setBorderWidth(0);
			outertable.addCell(dopAirboxCell);pageLine++;
//			
			int dopCombPackage = dopPackge + dopSackPackge + dopAirboxPackge;
			int dopCombCopies = dopCopies + dopSackCopies + dopAirboxCopies;
			double dopCombWght = dopWeight + dopSackWght + dopAirboxWght;
			int totcombCont = totC + dopSakCont + dopAirboxCont;
			String dopcombcopyCell = AddSpace.addSpace(PlaceComma.placeComma(dopCombCopies),7) + " ";
			String dopCombWghtCell = AddSpace.addSpace(nf.format(dopCombWght),7,' ') + " ";
			String dopCombPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(dopCombPackage),7) + " ";
			
			PdfPTable dopCombTable = new PdfPTable(7);
			dopCombTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			dopCombTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			dopCombTable.setWidths(dopdispw);
			dopCombTable.addCell(new Phrase("Combined",TIMESBOLD_12));
			dopCombTable.addCell(new Phrase(dopcombcopyCell,COURIERNORMAL_12));
			dopCombTable.addCell(new Phrase(dopCombWghtCell,COURIERNORMAL_12));
			dopCombTable.addCell(new Phrase(dopCombPackgeCell,COURIERNORMAL_12));
			dopCombTable.addCell(new Phrase(" ",COURIERNORMAL_12));
			dopCombTable.addCell(new Phrase(" ",COURIERNORMAL_12));
			dopCombTable.addCell(new Phrase(Integer.toString(totcombCont),COURIERNORMAL_12));
			
			PdfPCell dopCombCell = new PdfPCell(dopCombTable);
			dopCombCell.setHorizontalAlignment(Element.ALIGN_CENTER);
			dopCombCell.setBorderWidth(0);
			//pageLine+=4;  changed to pageLine++;
			outertable.addCell(dopCombCell);pageLine++;
			
			bgtPalCopies += dopCopies;
			bgtPalPackage += dopPackge;
			bgtPalWeight += dopWeight;
			bgtSakCopies += dopSackCopies;
			bgtSakPackage += dopSackPackge;
			bgtSakWeight += dopSackWght;
			bgtAirboxCopies += dopAirboxCopies;
			bgtAirboxPackage += dopAirboxPackge;
			bgtAirboxWeight += dopAirboxWght;
			bgttop += dopTop;
			bgtFull += dopFull;
			bgtPalCont += totC;
			bgtSakCont += dopSakCont;
			bgtAirboxCont += dopAirboxCont;
			
			dopPackge  = 0;
			dopCopies  = 0;
			dopWeight =0;
			dopTop = 0;
			dopFull = 0;
			dopSackCopies = 0;
			dopSackWght = 0;
			dopSackPackge = 0;dopSakCont=0;
			dopAirboxCopies = 0;
			dopAirboxWght = 0;
			dopAirboxPackge = 0;dopAirboxCont=0;
			dopCombPackage= 0;dopCombCopies=0;totcombCont=0;dopCombWght=0;
	
			for(int z=0;z<2;z++) {outertable.addCell(dummyCell);pageLine++;}
			PdfPCell totBindGrpCell1 = totBindGrphdr();							
			outertable.addCell(totBindGrpCell1);pageLine++;
			
			//	Binding Group start
			
			PdfPTable bgtPalletTable = new PdfPTable(7);
			bgtPalletTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			bgtPalletTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			bgtPalletTable.setWidths(dopdispw);
			
			String bgtcopyCell = AddSpace.addSpace(PlaceComma.placeComma(bgtPalCopies),7) + " "; 
			String bgtWeightcell = AddSpace.addSpace(nf.format(bgtPalWeight),7,' ') + " ";
			String bgtPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(bgtPalPackage),7) + " ";
			
			
			bgtPalletTable.addCell(new Phrase("Pallets",TIMESBOLD_12));
			bgtPalletTable.addCell(new Phrase(bgtcopyCell,COURIERNORMAL_12));
			bgtPalletTable.addCell(new Phrase(bgtWeightcell,COURIERNORMAL_12));
			bgtPalletTable.addCell(new Phrase(bgtPackgeCell,COURIERNORMAL_12));
			bgtPalletTable.addCell(new Phrase(Integer.toString(bgtFull),COURIERNORMAL_12));
			bgtPalletTable.addCell(new Phrase(Integer.toString(bgttop),COURIERNORMAL_12));
			bgtPalletTable.addCell(new Phrase(Integer.toString(bgtPalCont),COURIERNORMAL_12));
			
			PdfPCell bgtPalletCell = new PdfPCell(bgtPalletTable);
			bgtPalletCell.setHorizontalAlignment(Element.ALIGN_CENTER);
			bgtPalletCell.setBorderWidth(0);
			outertable.addCell(bgtPalletCell);pageLine++;
			
			String bgtSackcopyCell = AddSpace.addSpace(PlaceComma.placeComma(bgtSakCopies),7) + " ";
			String bgtSackWghtCell = AddSpace.addSpace(nf.format(bgtSakWeight),7,' ') + " ";
			String bgtSackPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(bgtSakPackage),7) + " ";
			
			PdfPTable bgtSackTable = new PdfPTable(7);
			bgtSackTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			bgtSackTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			bgtSackTable.setWidths(dopdispw);
			bgtSackTable.addCell(new Phrase("Sacks",TIMESBOLD_12));
			bgtSackTable.addCell(new Phrase(bgtSackcopyCell,COURIERNORMAL_12));
			bgtSackTable.addCell(new Phrase(bgtSackWghtCell,COURIERNORMAL_12));
			bgtSackTable.addCell(new Phrase(bgtSackPackgeCell,COURIERNORMAL_12));
			bgtSackTable.addCell(new Phrase(" ",COURIERNORMAL_12));
			bgtSackTable.addCell(new Phrase(" ",COURIERNORMAL_12));
			bgtSackTable.addCell(new Phrase(Integer.toString(bgtSakCont),COURIERNORMAL_12));
			
			PdfPCell bgtSackCell = new PdfPCell(bgtSackTable);
			bgtSackCell.setHorizontalAlignment(Element.ALIGN_CENTER);
			bgtSackCell.setBorderWidth(0);
			outertable.addCell(bgtSackCell);pageLine++;
//
			String bgtAirboxcopyCell = AddSpace.addSpace(PlaceComma.placeComma(bgtAirboxCopies),7) + " ";
			String bgtAirboxWghtCell = AddSpace.addSpace(nf.format(bgtAirboxWeight),7,' ') + " ";
			String bgtAirboxPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(bgtAirboxPackage),7) + " ";
			
			PdfPTable bgtAirboxTable = new PdfPTable(7);
			bgtAirboxTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			bgtAirboxTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			bgtAirboxTable.setWidths(dopdispw);
			bgtAirboxTable.addCell(new Phrase("Air Boxes",TIMESBOLD_12));
			bgtAirboxTable.addCell(new Phrase(bgtAirboxcopyCell,COURIERNORMAL_12));
			bgtAirboxTable.addCell(new Phrase(bgtAirboxWghtCell,COURIERNORMAL_12));
			bgtAirboxTable.addCell(new Phrase(bgtAirboxPackgeCell,COURIERNORMAL_12));
			bgtAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_12));
			bgtAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_12));
			bgtAirboxTable.addCell(new Phrase(Integer.toString(bgtAirboxCont),COURIERNORMAL_12));
			
			PdfPCell bgtAirboxCell = new PdfPCell(bgtAirboxTable);
			bgtAirboxCell.setHorizontalAlignment(Element.ALIGN_CENTER);
			bgtAirboxCell.setBorderWidth(0);
			outertable.addCell(bgtAirboxCell);pageLine++;
			
//			
			int bgtCombCopies = bgtPalCopies + bgtSakCopies + bgtAirboxCopies;
			int bgtCombPackage = bgtPalPackage + bgtSakPackage + bgtAirboxPackage;
			double bgtCombWght = bgtPalWeight + bgtSakWeight + bgtAirboxWeight;
			int bgtcombCont = bgtPalCont + bgtSakCont + bgtAirboxCont;
			String bgtcombcopyCell = AddSpace.addSpace(PlaceComma.placeComma(bgtCombCopies),7) + " ";
			String bgtCombWghtCell = AddSpace.addSpace(nf.format(bgtCombWght),7,' ') + " ";
			String bgtCombPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(bgtCombPackage),7) + " ";
			
			PdfPTable bgtCombTable = new PdfPTable(7);
			bgtCombTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			bgtCombTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			bgtCombTable.setWidths(dopdispw);
			bgtCombTable.addCell(new Phrase("Combined",TIMESBOLD_12));
			bgtCombTable.addCell(new Phrase(bgtcombcopyCell,COURIERNORMAL_12));
			bgtCombTable.addCell(new Phrase(bgtCombWghtCell,COURIERNORMAL_12));
			bgtCombTable.addCell(new Phrase(bgtCombPackgeCell,COURIERNORMAL_12));
			bgtCombTable.addCell(new Phrase(" ",COURIERNORMAL_12));
			bgtCombTable.addCell(new Phrase(" ",COURIERNORMAL_12));
			bgtCombTable.addCell(new Phrase(Integer.toString(bgtcombCont),COURIERNORMAL_12));
			
			PdfPCell bgtCombCell = new PdfPCell(bgtCombTable);
			bgtCombCell.setHorizontalAlignment(Element.ALIGN_CENTER);
			bgtCombCell.setBorderWidth(0);
			//pageLine+=4;  changed to pageLine++;
			outertable.addCell(bgtCombCell);pageLine++;
			
			bracePalCopies += bgtPalCopies;
			bracePalPackage += bgtPalPackage;
			bracePalWeight += bgtPalWeight;
			braceSakCopies += bgtSakCopies;
			braceSakPackage += bgtSakPackage;
			braceSakWeight += bgtSakWeight;
			braceAirboxCopies += bgtAirboxCopies;
			braceAirboxPackage += bgtAirboxPackage;
			braceAirboxWeight += bgtAirboxWeight;
			braceTop += bgttop;
			braceFull += bgtFull;
			bracePalCont += bgtPalCont;
			braceSakCont += bgtSakCont;
			braceAirboxCont += bgtAirboxCont;
			
			
			bgtPalCopies = 0;
			bgtPalPackage = 0;
			bgtPalWeight = 0;
			bgtSakCopies = 0;
			bgtSakPackage = 0;
			bgtSakWeight = 0;
			bgtAirboxCopies = 0;
			bgtAirboxPackage = 0;
			bgtAirboxWeight = 0;
			bgttop = 0;
			bgtFull = 0;
			bgtPalCont = 0;
			bgtSakCont = 0;
			bgtAirboxCont = 0;
			
			//   Binding Group End
			
			for(int z=0;z<2;z++) {outertable.addCell(dummyCell);pageLine++;}
			PdfPCell totBraceCell1 = totBracehdr();							
			outertable.addCell(totBraceCell1);pageLine++;
			
			//	Brace start
			
			PdfPTable bracePalletTable = new PdfPTable(7);
			bracePalletTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			bracePalletTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			bracePalletTable.setWidths(dopdispw);
			
			String bracecopyCell = AddSpace.addSpace(PlaceComma.placeComma(bracePalCopies),7) + " "; 
			String braceWeightcell = AddSpace.addSpace(nf.format(bracePalWeight),7,' ') + " ";
			String bracePackgeCell = AddSpace.addSpace(PlaceComma.placeComma(bracePalPackage),7) + " ";
			
			bracePalletTable.addCell(new Phrase("Pallets",TIMESBOLD_12));
			bracePalletTable.addCell(new Phrase(bracecopyCell,COURIERNORMAL_12));
			bracePalletTable.addCell(new Phrase(braceWeightcell,COURIERNORMAL_12));
			bracePalletTable.addCell(new Phrase(bracePackgeCell,COURIERNORMAL_12));
			bracePalletTable.addCell(new Phrase(Integer.toString(braceFull),COURIERNORMAL_12));
			bracePalletTable.addCell(new Phrase(Integer.toString(braceTop),COURIERNORMAL_12));
			bracePalletTable.addCell(new Phrase(Integer.toString(bracePalCont),COURIERNORMAL_12));
			
			PdfPCell bracePalletCell = new PdfPCell(bracePalletTable);
			bracePalletCell.setHorizontalAlignment(Element.ALIGN_CENTER);
			bracePalletCell.setBorderWidth(0);
			outertable.addCell(bracePalletCell);pageLine++;
			
			String braceSackcopyCell = AddSpace.addSpace(PlaceComma.placeComma(braceSakCopies),7) + " ";
			String braceSackWghtCell = AddSpace.addSpace(nf.format(braceSakWeight),7,' ') + " ";
			String braceSackPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(braceSakPackage),7) + " ";
			
			PdfPTable braceSackTable = new PdfPTable(7);
			braceSackTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			braceSackTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			braceSackTable.setWidths(dopdispw);
			braceSackTable.addCell(new Phrase("Sacks",TIMESBOLD_12));
			braceSackTable.addCell(new Phrase(braceSackcopyCell,COURIERNORMAL_12));
			braceSackTable.addCell(new Phrase(braceSackWghtCell,COURIERNORMAL_12));
			braceSackTable.addCell(new Phrase(braceSackPackgeCell,COURIERNORMAL_12));
			braceSackTable.addCell(new Phrase(" ",COURIERNORMAL_12));
			braceSackTable.addCell(new Phrase(" ",COURIERNORMAL_12));
			braceSackTable.addCell(new Phrase(Integer.toString(braceSakCont),COURIERNORMAL_12));
			
			PdfPCell braceSackCell = new PdfPCell(braceSackTable);
			braceSackCell.setHorizontalAlignment(Element.ALIGN_CENTER);
			braceSackCell.setBorderWidth(0);
			outertable.addCell(braceSackCell);pageLine++;
//
			String braceAirboxcopyCell = AddSpace.addSpace(PlaceComma.placeComma(braceAirboxCopies),7) + " ";
			String braceAirboxWghtCell = AddSpace.addSpace(nf.format(braceAirboxWeight),7,' ') + " ";
			String braceAirboxPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(braceAirboxPackage),7) + " ";
			
			PdfPTable braceAirboxTable = new PdfPTable(7);
			braceAirboxTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			braceAirboxTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			braceAirboxTable.setWidths(dopdispw);
			braceAirboxTable.addCell(new Phrase("Air Boxes",TIMESBOLD_12));
			braceAirboxTable.addCell(new Phrase(braceAirboxcopyCell,COURIERNORMAL_12));
			braceAirboxTable.addCell(new Phrase(braceAirboxWghtCell,COURIERNORMAL_12));
			braceAirboxTable.addCell(new Phrase(braceAirboxPackgeCell,COURIERNORMAL_12));
			braceAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_12));
			braceAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_12));
			braceAirboxTable.addCell(new Phrase(Integer.toString(braceAirboxCont),COURIERNORMAL_12));
			
			PdfPCell braceAirboxCell = new PdfPCell(braceAirboxTable);
			braceAirboxCell.setHorizontalAlignment(Element.ALIGN_CENTER);
			braceAirboxCell.setBorderWidth(0);
			outertable.addCell(braceAirboxCell);pageLine++;
			
//			
			int braceCombCopies = bracePalCopies + braceSakCopies + braceAirboxCopies;
			int braceCombPackage = bracePalPackage + braceSakPackage + braceAirboxPackage;
			double braceCombWght = bracePalWeight + braceSakWeight + braceAirboxWeight;
			int bracecombCont = bracePalCont + braceSakCont + braceAirboxCont;
			String bracecombcopyCell = AddSpace.addSpace(PlaceComma.placeComma(braceCombCopies),7) + " ";
			String braceCombWghtCell = AddSpace.addSpace(nf.format(braceCombWght),7,' ') + " ";
			String braceCombPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(braceCombPackage),7) + " ";
			
			PdfPTable braceCombTable = new PdfPTable(7);
			braceCombTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			braceCombTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			braceCombTable.setWidths(dopdispw);
			braceCombTable.addCell(new Phrase("Combined",TIMESBOLD_12));
			braceCombTable.addCell(new Phrase(bracecombcopyCell,COURIERNORMAL_12));
			braceCombTable.addCell(new Phrase(braceCombWghtCell,COURIERNORMAL_12));
			braceCombTable.addCell(new Phrase(braceCombPackgeCell,COURIERNORMAL_12));
			braceCombTable.addCell(new Phrase(" ",COURIERNORMAL_12));
			braceCombTable.addCell(new Phrase(" ",COURIERNORMAL_12));
			braceCombTable.addCell(new Phrase(Integer.toString(bracecombCont),COURIERNORMAL_12));
			
			PdfPCell braceCombCell = new PdfPCell(braceCombTable);
			braceCombCell.setHorizontalAlignment(Element.ALIGN_CENTER);
			braceCombCell.setBorderWidth(0);
			//pageLine+=4;  changed to pageLine++;
			outertable.addCell(braceCombCell);pageLine++;
			pprDoc.newPage();
			
			plantPalCopies += bracePalCopies;
			plantPalPackage += bracePalPackage;
			plantPalWeight += bracePalWeight;
			plantSakCopies += braceSakCopies;
			plantSakPackage += braceSakPackage;
			plantSakWeight += braceSakWeight;
			plantAirboxCopies += braceAirboxCopies;
			plantAirboxPackage += braceAirboxPackage;
			plantAirboxWeight += braceAirboxWeight;
			plantTop += braceTop;
			plantFull += braceFull;
			plantPalCont += bracePalCont;
			plantSakCont += braceSakCont;
			
			bracePalCopies = 0;
			bracePalPackage = 0;
			bracePalWeight = 0;
			braceSakCopies = 0;
			braceSakPackage = 0;
			braceSakWeight = 0;
			braceAirboxCopies = 0;
			braceAirboxPackage = 0;
			braceAirboxWeight = 0;
			braceTop = 0;
			braceFull = 0;
			bracePalCont = 0;
			braceSakCont = 0;
			braceAirboxCont = 0;

			// Brace End
			
			for(int z=0;z<2;z++) {outertable.addCell(dummyCell);pageLine++;}
			PdfPCell planttotCell = plantTotHdr();							
			outertable.addCell(planttotCell);pageLine++;
			
			PdfPTable plantPalletTable = new PdfPTable(7);
			plantPalletTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			plantPalletTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			plantPalletTable.setWidths(dopdispw);
			
			String plantcopyCell = AddSpace.addSpace(PlaceComma.placeComma(plantPalCopies),7) + " "; 
			String plantWeightcell = AddSpace.addSpace(nf.format(plantPalWeight),7,' ') + " ";
			String plantPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(plantPalPackage),7) + " ";
			
			plantPalletTable.addCell(new Phrase("Pallets",TIMESBOLD_12));
			plantPalletTable.addCell(new Phrase(plantcopyCell,COURIERNORMAL_12));
			plantPalletTable.addCell(new Phrase(plantWeightcell,COURIERNORMAL_12));
			plantPalletTable.addCell(new Phrase(plantPackgeCell,COURIERNORMAL_12));
			plantPalletTable.addCell(new Phrase(Integer.toString(plantFull),COURIERNORMAL_12));
			plantPalletTable.addCell(new Phrase(Integer.toString(plantTop),COURIERNORMAL_12));
			plantPalletTable.addCell(new Phrase(Integer.toString(plantPalCont),COURIERNORMAL_12));
			
			PdfPCell plantPalletCell = new PdfPCell(plantPalletTable);
			plantPalletCell.setHorizontalAlignment(Element.ALIGN_CENTER);
			plantPalletCell.setBorderWidth(0);
			outertable.addCell(plantPalletCell);pageLine++;
			
			String plantSackcopyCell = AddSpace.addSpace(PlaceComma.placeComma(plantSakCopies),7) + " ";
			String plantSackWghtCell = AddSpace.addSpace(nf.format(plantSakWeight),7,' ') + " ";
			String plantSackPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(plantSakPackage),7) + " ";
			
			PdfPTable plantSackTable = new PdfPTable(7);
			plantSackTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			plantSackTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			plantSackTable.setWidths(dopdispw);
			plantSackTable.addCell(new Phrase("Sacks",TIMESBOLD_12));
			plantSackTable.addCell(new Phrase(plantSackcopyCell,COURIERNORMAL_12));
			plantSackTable.addCell(new Phrase(plantSackWghtCell,COURIERNORMAL_12));
			plantSackTable.addCell(new Phrase(plantSackPackgeCell,COURIERNORMAL_12));
			plantSackTable.addCell(new Phrase(" ",COURIERNORMAL_12));
			plantSackTable.addCell(new Phrase(" ",COURIERNORMAL_12));
			plantSackTable.addCell(new Phrase(Integer.toString(plantSakCont),COURIERNORMAL_12));
			
			PdfPCell plantSackCell = new PdfPCell(plantSackTable);
			plantSackCell.setHorizontalAlignment(Element.ALIGN_CENTER);
			plantSackCell.setBorderWidth(0);
			outertable.addCell(plantSackCell);pageLine++;
//					
			String plantAirboxcopyCell = AddSpace.addSpace(PlaceComma.placeComma(plantAirboxCopies),7) + " ";
			String plantAirboxWghtCell = AddSpace.addSpace(nf.format(plantAirboxWeight),7,' ') + " ";
			String plantAirboxPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(plantAirboxPackage),7) + " ";
			
			PdfPTable plantAirboxTable = new PdfPTable(7);
			plantAirboxTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			plantAirboxTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			plantAirboxTable.setWidths(dopdispw);
			plantAirboxTable.addCell(new Phrase("Air Boxes",TIMESBOLD_12));
			plantAirboxTable.addCell(new Phrase(plantAirboxcopyCell,COURIERNORMAL_12));
			plantAirboxTable.addCell(new Phrase(plantAirboxWghtCell,COURIERNORMAL_12));
			plantAirboxTable.addCell(new Phrase(plantAirboxPackgeCell,COURIERNORMAL_12));
			plantAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_12));
			plantAirboxTable.addCell(new Phrase(" ",COURIERNORMAL_12));
			plantAirboxTable.addCell(new Phrase(Integer.toString(plantAirboxCont),COURIERNORMAL_12));
			
			PdfPCell plantAirboxCell = new PdfPCell(plantAirboxTable);
			plantAirboxCell.setHorizontalAlignment(Element.ALIGN_CENTER);
			plantAirboxCell.setBorderWidth(0);
			outertable.addCell(plantAirboxCell);pageLine++;
//			
			int plantCombCopies = plantPalCopies + plantSakCopies + plantAirboxCopies;
			int plantCombPackage = plantPalPackage + plantSakPackage + plantAirboxPackage;
			double plantCombWght = plantPalWeight + plantSakWeight + plantAirboxWeight;
			int plantcombCont = plantPalCont + plantSakCont + plantAirboxCont;
			String plantcombcopyCell = AddSpace.addSpace(PlaceComma.placeComma(plantCombCopies),7) + " ";
			String plantCombWghtCell = AddSpace.addSpace(nf.format(plantCombWght),7,' ') + " ";
			String plantCombPackgeCell = AddSpace.addSpace(PlaceComma.placeComma(plantCombPackage),7) + " ";
			
			PdfPTable plantCombTable = new PdfPTable(7);
			plantCombTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			plantCombTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			plantCombTable.setWidths(dopdispw);
			plantCombTable.addCell(new Phrase("Combined",TIMESBOLD_12));
			plantCombTable.addCell(new Phrase(plantcombcopyCell,COURIERNORMAL_12));
			plantCombTable.addCell(new Phrase(plantCombWghtCell,COURIERNORMAL_12));
			plantCombTable.addCell(new Phrase(plantCombPackgeCell,COURIERNORMAL_12));
			plantCombTable.addCell(new Phrase(" ",COURIERNORMAL_12));
			plantCombTable.addCell(new Phrase(" ",COURIERNORMAL_12));
			plantCombTable.addCell(new Phrase(Integer.toString(plantcombCont),COURIERNORMAL_12));
			
			PdfPCell plantCombCell = new PdfPCell(plantCombTable);
			plantCombCell.setHorizontalAlignment(Element.ALIGN_CENTER);
			plantCombCell.setBorderWidth(0);
			outertable.addCell(plantCombCell);pageLine++;

			}
			else {
				LogWriter.writeLog("No Reports ");
				
				outertable = new PdfPTable(1);
				outertable.setHeaderRows(5);
				
				String dateHdr = String.valueOf(dateFormat.format(toDay)) + "Issue :"+ issueNum + " - " + issueWeek + "Cover :" + issueDate; 
				PdfPCell header0 = new PdfPCell(new Phrase(dateHdr,
						FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,Color.black)));
				header0.setBorderWidth(0);
				outertable.addCell(header0);pageLine++;
					
			
				PdfPCell cell1 = new PdfPCell(new Phrase(
						"Plant Pallet / Sack Report", FontFactory.getFont(FontFactory.TIMES_ROMAN, 24, Font.BOLD, Color.BLACK)));
				cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell1.setBorderWidth(0);
				outertable.addCell(cell1);pageLine++;
				
				int [] tablew = {2,9,9,2,5,5};
				PdfPTable headertable1 = new PdfPTable(6);
				headertable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				headertable1.setWidths(tablew);
				headertable1.addCell(new Phrase("Plant :",TIMESBOLD_12));
				headertable1.addCell(new Phrase(plantName.trim(),TIMESNORAML_12));
				headertable1.addCell(new Phrase(magName.trim(),TIMESNORAML_12));
				headertable1.addCell(new Phrase("Issue :",TIMESBOLD_12));
				String issueDateDisp = issueDate + "   ("+ issueNum + " - " + issueWeek + ")";
				headertable1.addCell(new Phrase(issueDateDisp,TIMESNORAML_12));
				headertable1.addCell(new Phrase(deliveryType,TIMESBOLD_12));
				
				PdfPCell headercell1 = new PdfPCell(headertable1);
				headercell1.setBorderWidth(0);
				outertable.addCell(headercell1);pageLine++;
				
				for (int i=0;i<5;i++){outertable.addCell(dummyCell);pageLine++;}
				
			}
			
			pprDoc.add(outertable);
		}catch (SQLException se) {
			LogWriter.writeLog(se);
		}
		catch (DocumentException de) {
			System.err.println(de.getMessage());
		} catch (IOException ioe) {
			System.err.println(ioe.getMessage());
		} finally {
			if (resultset != null) {
				try {
					resultset.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectcopyCnt != null) {
				try {
					selectcopyCnt.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		pprDoc.close();
	}
		
		public synchronized static void createPlantPalletReport(Magazine mag){
			
			PreparedStatement selectJobID = null;
			ResultSet rsJobId = null;

			open();
			
			initialize(mag); 
			
			String SQL = "Select distinct JOB_ID from  " + pkgsum
						+ " WHERE MAG_KY = ? and INSTNC_CD = ? and PLANT_ID = ? and MAG_CD = ? and ISS_NUM = ? and ISS_WK_NUM = ? ";
		
			magKey = magazineKey(magCode);
			
			issueDate = getIssueDate();
			
			plantName = getPlantName(plantId);
			
			instCd = InstanceCd.getInstCd(magKey, issueDate);

			try {
				selectJobID = conn.prepareStatement(SQL);
				selectJobID.setInt(1, magKey);
				selectJobID.setString(2, instCd);
				selectJobID.setString(3, plantId);
				selectJobID.setString(4, magCode);
				selectJobID.setInt(5, toNum.toNumber(issueNum));
				selectJobID.setInt(6, toNum.toNumber(issueWeek));
				rsJobId = selectJobID.executeQuery();
				
				while (rsJobId.next()) {

				String jobId = rsJobId.getString("JOB_ID");

				if (jobId.endsWith("U")) {
					createPDF(jobId, "USPS");
					LogWriter.writeLog("Plant Pallet / Sack  USPS Report Generated   ");
				} else if (jobId.endsWith("F")) {
					createPDF(jobId, "FOREIGN");
					LogWriter.writeLog("Plant Pallet / Sack  Foreign Report Generated   ");
				}
			}
			} 
			catch (SQLException se) {
				LogWriter.writeLog(se);
			} finally {
				if (rsJobId != null) {
					try {
						rsJobId.close();
					} catch (SQLException e) { /* ignored */}
					}
				if (selectJobID != null) {
					try {
						selectJobID.close();
					} catch (SQLException e) { /* ignored */}
				}
			}
			return;
		}
}