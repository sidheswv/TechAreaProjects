package com.pdf.report;

public class PlantpkgElem {

	String pkgNumLtoH = null;  
	String zipLtoH = null;  
	String bvVersion = null;
	String rollNum = null;
	String palletNum = null;
	String numPkg = null;
	String copyCount = null;
	String pkgWght = null;
	int totCopyCnt = 0;
	double totpkgWght = 0.0;
	int totnumPkg = 0;
	String destLine1 = null;
	String pstlLevel = null;
	
	public PlantpkgElem() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PlantpkgElem(String pkgNumLtoH, String zipLtoH, String bvVersion,
			String rollNum, String palletNum, String numPkg, String copyCount,
			String pkgWght, int totCopyCnt, double totpkgWght, int totnumPkg,
			String destLine1, String pstlLevel) {
		super();
		this.pkgNumLtoH = pkgNumLtoH;
		this.zipLtoH = zipLtoH;
		this.bvVersion = bvVersion;
		this.rollNum = rollNum;
		this.palletNum = palletNum;
		this.numPkg = numPkg;
		this.copyCount = copyCount;
		this.pkgWght = pkgWght;
		this.totCopyCnt = totCopyCnt;
		this.totpkgWght = totpkgWght;
		this.totnumPkg = totnumPkg;
		this.destLine1 = destLine1;
		this.pstlLevel = pstlLevel;
	}
	public String getBvVersion() {
		return bvVersion;
	}
	public void setBvVersion(String bvVersion) {
		this.bvVersion = bvVersion;
	}
	public String getNumPkg() {
		return numPkg;
	}
	public void setNumPkg(String numPkg) {
		this.numPkg = numPkg;
	}
	public String getPalletNum() {
		return palletNum;
	}
	public void setPalletNum(String palletNum) {
		this.palletNum = palletNum;
	}
	public String getPkgNumLtoH() {
		return pkgNumLtoH;
	}
	public void setPkgNumLtoH(String pkgNumLtoH) {
		this.pkgNumLtoH = pkgNumLtoH;
	}
	public String getRollNum() {
		return rollNum;
	}
	public void setRollNum(String rollNum) {
		this.rollNum = rollNum;
	}
	public String getZipLtoH() {
		return zipLtoH;
	}
	public void setZipLtoH(String zipLtoH) {
		this.zipLtoH = zipLtoH;
	}
	public String getCopyCount() {
		return copyCount;
	}
	public void setCopyCount(String copyCount) {
		this.copyCount = copyCount;
	}
	public String getPkgWght() {
		return pkgWght;
	}
	public void setPkgWght(String pkgWght) {
		this.pkgWght = pkgWght;
	}
	public int getTotCopyCnt() {
		return totCopyCnt;
	}
	public void setTotCopyCnt(int totCopyCnt) {
		this.totCopyCnt = totCopyCnt;
	}
	public double getTotpkgWght() {
		return totpkgWght;
	}
	public void setTotpkgWght(double totpkgWght) {
		this.totpkgWght = totpkgWght;
	}
	public int getTotnumPkg() {
		return totnumPkg;
	}
	public void setTotnumPkg(int totnumPkg) {
		this.totnumPkg = totnumPkg;
	}
	public String getDestLine1() {
		return destLine1;
	}
	public void setDestLine1(String destLine1) {
		this.destLine1 = destLine1;
	}
	public String getPstlLevel() {
		return pstlLevel;
	}
	public void setPstlLevel(String pstlLevel) {
		this.pstlLevel = pstlLevel;
	}
	
}
