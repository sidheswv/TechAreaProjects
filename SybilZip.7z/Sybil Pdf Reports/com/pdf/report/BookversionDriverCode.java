package com.pdf.report;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import sybil.common.model.Magazine;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;

import com.report.text.Document;
import com.report.text.DocumentException;
import com.report.text.Element;
import com.report.text.ExceptionConverter;
import com.report.text.Font;
import com.report.text.FontFactory;
import com.report.text.PageSize;
import com.report.text.Phrase;
import com.report.text.Rectangle;
import com.report.text.pdf.BaseFont;
import com.report.text.pdf.PdfContentByte;
import com.report.text.pdf.PdfPCell;
import com.report.text.pdf.PdfPTable;
import com.report.text.pdf.PdfPageEventHelper;
import com.report.text.pdf.PdfTemplate;
import com.report.text.pdf.PdfWriter;

public class BookversionDriverCode extends PdfPageEventHelper {
	
	public static String magInfo = "TBA_MAG_INFO";

	public static String sybMag = "TBA_SYB_MAGAZINE";

	public static String magazineInf = "TBA_MAGAZINEINF";

	public static String custBvTableName = "TBA_CUST_BV";

	private static ResultSet resultset = null;

	private static String magName = null;

	private static Connection conn = null;

	protected PdfTemplate total;

	protected BaseFont helv;
 
 	public void onOpenDocument(PdfWriter writer, Document document) {
		total = writer.getDirectContent().createTemplate(100, 100);
		total.setBoundingBox(new Rectangle(-20, -20, 100, 100));
		try {
			helv = BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI,BaseFont.NOT_EMBEDDED);
		} catch (Exception e) {
			throw new ExceptionConverter(e);
		}
	}
 
	public void onEndPage(PdfWriter writer, Document document) {
		PdfContentByte cb = writer.getDirectContent();
		cb.saveState();
		String text = "Page " + writer.getPageNumber() + " of  ";
		float textBase = document.bottom() - 15;
		float textSize = helv.getWidthPoint(text, 9);
		float textCenter = document.right()/2;
		cb.beginText();
		cb.setFontAndSize(helv, 10);

		cb.setTextMatrix(textCenter, textBase);
		cb.showText(text);
		cb.endText();
		cb.addTemplate(total, textCenter + textSize, textBase);
		cb.restoreState();
	}
 
	
	public void onCloseDocument(PdfWriter writer, Document document) {
		total.beginText();
		total.setFontAndSize(helv, 10);
		total.setTextMatrix(0, 0);
		total.showText(String.valueOf(writer.getPageNumber() - 1));
		total.endText();
	}
	
	private static void open() {

		PreparedStatement setSqlId = null;
		Statement commitSqlId = null;
		String x = null;
		String db2owner = null;
		int i = 0;
		
		String userDb = sybil.common.util.PropertyBroker.getProperty("database.login","sybil");
		String pswdDb = sybil.common.util.PropertyBroker.getProperty("database.password","sybil");
		
		
		if( conn == null) {
			try {
				Class.forName(sybil.common.util.PropertyBroker.getProperty("database.driver", "Not Found"));
				conn = DriverManager.getConnection(sybil.common.util.PropertyBroker.getProperty("database.server", "Not Found"), userDb, pswdDb);

				//
				x = PropertyBroker.getProperty("database.driver", "Not Found").toLowerCase();
				i = x.indexOf("db2");
				if (!(i < 0)) {
					try {
						db2owner = PropertyBroker.getProperty("DB2OWNER","dtppsyup");
						setSqlId = conn.prepareStatement("set current sqlid = ?");
						setSqlId.setString(1, db2owner);
						setSqlId.execute();
						commitSqlId = conn.createStatement();
						commitSqlId.execute("commit");
					}
					catch (SQLException se) {
						if(se.getSQLState().equals("S1010")) {
						}
						else {
							LogWriter.writeLog(se);
							LogWriter.writeLog("Error: Set Current SqlId failed.");
							if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
								LogWriter.writeLog("Process terminating due to database/sql exception");
								System.exit(1);
							}
						}
					}
					catch (Exception e) {
						LogWriter.writeLog(e);
						LogWriter.writeLog("Error: Set Current SqlId failed.");
						if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
							LogWriter.writeLog("Process terminating due to database/sql exception");
							System.exit(1);
						}
					}
				}
			
			} 
			catch (Exception e) {
				sybil.common.util.LogWriter.writeLog(e);
				LogWriter.writeLog("Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
		
	return;
	}
	
	
	public static void close() {
		
		if( conn != null) {		
			try { conn.close(); }catch(Exception sql ){};
			conn = null;
		}
		return;
	}
	
	private static int magazineKey(String magazineCode){
		
		int magKey = 0;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT MAG_KEY, NAME  FROM " + sybMag + " WHERE MAG_CD = ? ";
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, magazineCode);
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			magKey  = (int)rs.getInt("MAG_KEY");
			magName = rs.getString("NAME");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Code Select error " + magazineCode);
		}
		return magKey;
	}

	
	private static String getIssueDate(Magazine mag){
		
		String issueDate = null;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT COVER_DATE FROM " + magazineInf + " WHERE PLANT = ? and MAG = ? and ISSUE = ? ";
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, mag.getPlant().toUpperCase());
		selectMag.setString(2, mag.getMagCode().toLowerCase());
		selectMag.setString(3, mag.getIssue());
		
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			issueDate  = rs.getString("COVER_DATE");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Issue Date error " + mag.getMagCode());
		}
		return issueDate;
	}

	
	private static int testRollNestFact(Magazine mag, int magKey, String bvName, String prmDrcd){
		
		int testrollNest = 0;
		PreparedStatement selectnestFact = null;
		PreparedStatement updateNc = null;
		int testrowupdate = 0;
		ResultSet rs = null;
		String magCode = mag.getMagCode().trim();
		String issueNum = mag.getIssue().trim();
		String issueWeek = mag.getWeek().trim();
		String plantId = mag.getPlant().toUpperCase().trim();
				
		String SQL  = "SELECT  distinct ROLL_NUM,  NEST_COPY_CNT FROM  " + custBvTableName                  
	        + " WHERE  MAG_KY = ? AND MAG_CD = ? AND PLANT_ID = ? AND ISS_NUM = ? AND ISS_WK_NUM = ? " +
	        		" AND XSHEET_BV_NME = ? AND PREM_DRIVER_CD = ?  ORDER BY  ROLL_NUM FETCH FIRST 3 ROWS ONLY ";
		
		String updateSQL = "UPDATE " + custBvTableName +  " SET  NEST_COPY_CNT = ? " +
		" WHERE MAG_KY = ? AND PLANT_ID = ? AND  MAG_CD = ? AND ISS_NUM = ? AND ISS_WK_NUM = ?  " +
		" AND XSHEET_BV_NME = ? and ROLL_NUM = 9999 " ;
		

		try {
			
			selectnestFact = conn.prepareStatement(SQL);
			selectnestFact.setInt(1, magKey);
			selectnestFact.setString(2, magCode);
			selectnestFact.setString(3, plantId);
			selectnestFact.setInt(4, toNum.toNumber(issueNum));
			selectnestFact.setInt(5, toNum.toNumber(issueWeek));
			selectnestFact.setString(6, bvName);
			selectnestFact.setInt(7, toNum.toNumber(prmDrcd));
			
			rs = selectnestFact.executeQuery();
		
		while (rs.next()){
			
				testrollNest  = (int)rs.getInt("NEST_COPY_CNT");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Test roll nesting factor select error " + testrollNest);
		}
		
		try{
			
			updateNc = conn.prepareStatement(updateSQL);
			updateNc.setInt(1, testrollNest);
			updateNc.setInt(2, magKey);
			updateNc.setString(3, plantId);
			updateNc.setString(4, magCode);
			updateNc.setInt(5, toNum.toNumber(issueNum));
			updateNc.setInt(6, toNum.toNumber(issueWeek));	
			updateNc.setString(7, bvName);
			
			testrowupdate = updateNc.executeUpdate();
			
		}catch(SQLException se) {
			LogWriter.writeLog(se);
		}
		
		LogWriter.writeLog("Test Roll Nesting Copy updated " + bvName + "  " + testrollNest  + "  " +  testrowupdate);
		return testrollNest;
	}


	
	public static synchronized void CreateDriverCodePDF(Magazine mag){
		
		PreparedStatement selectcopyCnt = null;
		PreparedStatement bookVersionPS = null;
		Document defDvrCdeDoc = new Document(PageSize.LETTER,-50,-50,36,36);
		String saveRollNum = "  ";
		boolean firstRow = true;	
		boolean firstTime = true;
		String nestCntDisp = null;
		int nestCnt = 0;
		int nestedCopy = 0;
		int rollTotal = 0;
		int rptTotal = 0;
		

		String magCode = mag.getMagCode().trim();
		String issueNum = mag.getIssue().trim();
		String issueWeek = mag.getWeek().trim();
		String plantId = mag.getPlant().toUpperCase().trim();
		
		String RptPath = sybil.common.util.PropertyBroker.getProperty("NewPDFReportsPath","Not found");
		String fileName = magCode.toLowerCase() + ".i" + issueNum + "." + plantId + ".OMS_Driver_Code." + issueWeek;
		
		open();
		
		String bookVersionTotal = " SELECT XSHEET_BV_NME, PREM_DRIVER_CD, NEST_COPY_CNT, SUM(COPY_CNT) as BV_COPY_CNT, SUM(COPY_CNT) * NEST_COPY_CNT as TOT_COPY_CNT " 
								  + " FROM " + custBvTableName
								  + " WHERE  MAG_KY = ? AND INSTNC_CD = ? AND MAG_CD = ? AND PLANT_ID = ? AND ISS_NUM = ? AND ISS_WK_NUM = ?  "
								  + " GROUP BY XSHEET_BV_NME, PREM_DRIVER_CD, NEST_COPY_CNT  ";
		            
		String SQL  = "SELECT CUS.ROLL_NUM, CASE WHEN B.CAT_ID = 0 THEN 'MIXED' ELSE CUS.GEO_CAT_ID END AS CAT_ID , " 
			+ " CUS.XSHEET_BV_NME, CUS.PREM_DRIVER_CD, CUS.FNL_DRIVER_CD, CUS.COPY_CNT, CUS.NEST_COPY_CNT "
		    + " FROM  " + custBvTableName + " CUS ," 
		    + " ( SELECT ROLL_NUM, CASE WHEN COUNT(DISTINCT GEO_CAT_ID) > 1 THEN 0 ELSE 1 END AS CAT_ID "
		    + " FROM  " + custBvTableName
		    + " WHERE  MAG_KY = ? AND INSTNC_CD = ? AND MAG_CD = ? AND PLANT_ID = ? AND ISS_NUM = ? AND ISS_WK_NUM = ? GROUP BY ROLL_NUM ) B "
	        + " WHERE  CUS.MAG_KY = ? AND CUS.INSTNC_CD = ? AND CUS.MAG_CD = ? AND CUS.PLANT_ID = ? AND CUS.ISS_NUM = ? AND CUS.ISS_WK_NUM = ?  "
	        + " and CUS.ROLL_NUM = B.ROLL_NUM "
	        + " ORDER BY CUS.ROLL_NUM, CUS.XSHEET_BV_NME  ";
		
		int magKey = magazineKey(magCode);
		
		String issueDate = getIssueDate(mag);
		
		String instCd = InstanceCd.getInstCd(magKey, issueDate);
		
		try {
			
			PdfWriter writer = PdfWriter.getInstance(defDvrCdeDoc,				
					new FileOutputStream(RptPath + fileName + ".pdf"));
			

			writer.setViewerPreferences(PdfWriter.PageModeFullScreen);
			writer.setPageEvent(new BookversionDriverCode());
			
			defDvrCdeDoc.open();
			
			Date toDay = new Date(); 
			SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, MMM d, yyyy, HH:mm a "); 

      		PdfPTable outertable = new PdfPTable(1);
			outertable.setHeaderRows(9);
			
			PdfPCell header0 = new PdfPCell(new Phrase(String.valueOf(dateFormat.format(toDay)),
					FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,Color.black)));
			header0.setBorderWidth(0);
			outertable.addCell(header0);
			
			String issueHdr = "Issue :" + issueDate + "(" + issueNum + " - " + issueWeek +")";
			PdfPCell issueCell = new PdfPCell(new Phrase(issueHdr,
					FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,Color.black)));
			issueCell.setBorderWidth(0);
			outertable.addCell(issueCell);
			
			PdfPCell cell1 = new PdfPCell(new Phrase(
					"Driver Code Report", FontFactory.getFont(FontFactory.COURIER, 15, Font.BOLD, Color.BLACK)));
			cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell1.setBorderWidth(0);
			outertable.addCell(cell1);
									
			PdfPCell dummyCell = new PdfPCell(new Phrase("", FontFactory.getFont(
								FontFactory.COURIER, 10, Font.BOLD, Color.black)));
			dummyCell.setBorderWidth(0);
			outertable.addCell(dummyCell);

			selectcopyCnt = conn.prepareStatement(SQL);
			selectcopyCnt.setInt(1, magKey);
			selectcopyCnt.setString(2, instCd);
			selectcopyCnt.setString(3, magCode);
			selectcopyCnt.setString(4, plantId);
			selectcopyCnt.setInt(5, toNum.toNumber(issueNum));
			selectcopyCnt.setInt(6, toNum.toNumber(issueWeek));
			selectcopyCnt.setInt(7, magKey);
			selectcopyCnt.setString(8, instCd);
			selectcopyCnt.setString(9, magCode);
			selectcopyCnt.setString(10, plantId);
			selectcopyCnt.setInt(11, toNum.toNumber(issueNum));
			selectcopyCnt.setInt(12, toNum.toNumber(issueWeek));
					
			resultset = selectcopyCnt.executeQuery();
			
			while (resultset.next()){
			
				String rollNum = resultset.getString("ROLL_NUM");
 				String geoCatId  = resultset.getString("CAT_ID");
				String xsheetBvName = resultset.getString("XSHEET_BV_NME");
				String premDRCD = resultset.getString("PREM_DRIVER_CD");
				String fnlDRCD = resultset.getString("FNL_DRIVER_CD");
				String copyCnt = resultset.getString("COPY_CNT");
				String nestFactor = resultset.getString("NEST_COPY_CNT");
				
				
				if ( nestFactor != " " )
					nestCnt = Integer.valueOf(nestFactor).intValue();
				
				if (Integer.valueOf(rollNum).intValue() == 9999 && magKey == 11 && nestCnt == 1){
					nestCnt = testRollNestFact(mag,magKey,xsheetBvName,premDRCD);
				}
				
				if ((nestCnt == 1 ) && (magKey != 11)) {
					nestedCopy = toNum.toNumber(copyCnt) * 1;
					nestCntDisp = " ";
				}	
				else{
					nestedCopy = toNum.toNumber(copyCnt) * nestCnt;
					nestCntDisp = Integer.toString(nestCnt);
				}
					
				if (Integer.valueOf(fnlDRCD).intValue() == 0){
					fnlDRCD = " ";
				}
				
			if (firstRow) {
				
				String header1 = "Magazine : " + magName.trim() + "                   Plant : " + plantId + "                         Issue :" + issueNum + " - " + issueWeek  ;
				PdfPCell magCell = new PdfPCell(new Phrase(header1,
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,Color.black)));
				magCell.setBorderWidth(0);
				outertable.addCell(magCell);
									
				for ( int G = 0; G <=2; G++){
					PdfPCell dummyCell1 = new PdfPCell(new Phrase("", FontFactory.getFont(
									FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					dummyCell1.setBorderWidth(0);
					outertable.addCell(dummyCell1);}	
				
				PdfPTable inertable = new PdfPTable(8);
				inertable.addCell("Roll Id");
				inertable.addCell("Market Id");
				inertable.addCell("Book Version");
				inertable.addCell("Prelim Drcd");
				inertable.addCell("Final DRCD");
				inertable.addCell("GTRF Count");
				inertable.addCell("Nesting Factor");
				inertable.addCell("Total Copies");
				PdfPCell cell9 = new PdfPCell(inertable);
				cell9.setBorderWidth(0);
				cell9.setBackgroundColor(new Color(108, 253, 206));
				outertable.addCell(cell9);
				firstRow = false;
			}				
			
			if (rollNum.compareTo(saveRollNum) == 0){
				
				rollNum = " ";
				geoCatId = " ";
				String detailInfo = AddSpace.addSpace(rollNum,3,' ')  + "      " + AddSpace.addSpace(geoCatId,5,' ') + "    " + xsheetBvName + "     " + AddSpace.addSpace(premDRCD,4,' ') + "    " + AddSpace.addSpace(fnlDRCD,4,' ') + "    "+  AddSpace.addSpace(PlaceComma.placeComma((Integer.valueOf(copyCnt)).intValue()),6) + "    " + AddSpace.addSpace(nestCntDisp,4,' ') + "     " +  AddSpace.addSpace(PlaceComma.placeComma(nestedCopy),6);
				PdfPCell detailType = new PdfPCell(
						new Phrase(detailInfo, FontFactory.getFont(FontFactory.COURIER, 12, Font.NORMAL, Color.black)));
				detailType.setBorderWidth(0);
				outertable.addCell(detailType);
				rollTotal += nestedCopy;
				
			} 
			else {	
			     if (firstTime){
				     firstTime = false;	
	      		 }
			     else{   	 
			    	 for ( int G = 0; G <4; G++) outertable.addCell(dummyCell);
			    	 String totalRoll = AddSpace.addSpace("Roll",175,' ') + "  " + AddSpace.addSpace(saveRollNum,3,'0') +  "  Total : " + AddSpace.addSpace(PlaceComma.placeComma(rollTotal),9);
					 PdfPCell rollTotType = new PdfPCell(
					 	new Phrase(totalRoll, FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Font.BOLD, Color.black)));		
					 rollTotType.setBorderWidth(0);
					 outertable.addCell(rollTotType);
					 for ( int G = 0; G <2; G++) outertable.addCell(dummyCell);
					 rptTotal += rollTotal;
					 rollTotal = 0;
			     }			
			     
			     saveRollNum = rollNum;
			     String detailInfo = AddSpace.addSpace(rollNum,3,'0')  + "      " + AddSpace.addSpace(geoCatId,5,' ') + "    " + xsheetBvName + "     " + AddSpace.addSpace(premDRCD,4,' ') + "    " + AddSpace.addSpace(fnlDRCD,4,' ') + "    "+  AddSpace.addSpace(PlaceComma.placeComma((Integer.valueOf(copyCnt)).intValue()),6) + "    " + AddSpace.addSpace(nestCntDisp,4,' ') + "     " +  AddSpace.addSpace(PlaceComma.placeComma(nestedCopy),6); 
			     PdfPCell detailType = new PdfPCell(
							new Phrase(detailInfo, FontFactory.getFont(FontFactory.COURIER, 12, Font.NORMAL, Color.black)));
					detailType.setBorderWidth(0);
					outertable.addCell(detailType);
				rollTotal += nestedCopy;
			     
			}
		} 
			
			String totalRoll = AddSpace.addSpace("Roll",175,' ') + "  " + AddSpace.addSpace(saveRollNum,3,'0') +  "  Total : " + AddSpace.addSpace(PlaceComma.placeComma(rollTotal),9);
			 PdfPCell rollTotType = new PdfPCell(
			 	new Phrase(totalRoll, FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Font.BOLD, Color.black)));		
			 rollTotType.setBorderWidth(0);
			 outertable.addCell(rollTotType);
			 rptTotal += rollTotal;
			 
			 if (magCode.compareTo("TK") == 0){
				 resultset = null;
				 bookVersionPS = conn.prepareStatement(bookVersionTotal);
				 bookVersionPS.setInt(1, magKey);
				 bookVersionPS.setString(2, instCd);
				 bookVersionPS.setString(3, magCode);
				 bookVersionPS.setString(4, plantId);
				 bookVersionPS.setInt(5, toNum.toNumber(issueNum));
				 bookVersionPS.setInt(6, toNum.toNumber(issueWeek));
							
				 resultset = bookVersionPS.executeQuery();
				 while (resultset.next()){
					 
					 String xsheetBvName = resultset.getString("XSHEET_BV_NME");
					 String premDRCD = resultset.getString("PREM_DRIVER_CD");
					 //String fnlDRCD = resultset.getString("FNL_DRIVER_CD");
					 String totCopyCnt = resultset.getString("TOT_COPY_CNT");
					 String copyCnt = resultset.getString("BV_COPY_CNT");
					 String nestFactor = resultset.getString("NEST_COPY_CNT");
					 String bookVersionTotInfo = AddSpace.addSpace("",3,' ')  + "      " + AddSpace.addSpace("",3,' ') + "      " + xsheetBvName + "     " + AddSpace.addSpace(premDRCD,4,' ') + "    " + AddSpace.addSpace("",4,' ') + "    "+  AddSpace.addSpace(PlaceComma.placeComma((Integer.valueOf(copyCnt)).intValue()),6) + "    " + AddSpace.addSpace(nestFactor,4,' ') + "  " +  AddSpace.addSpace(PlaceComma.placeComma((Integer.valueOf(totCopyCnt)).intValue()),9);
						PdfPCell bkverCell = new PdfPCell(
								new Phrase(bookVersionTotInfo, FontFactory.getFont(FontFactory.COURIER, 12, Font.NORMAL, Color.black)));
						bkverCell.setBorderWidth(0);
						outertable.addCell(bkverCell);
					 
				 }
				 
			 }
			 String rptTotalRoll = AddSpace.addSpace("Report Total : ",185,' ') + "       " + AddSpace.addSpace(PlaceComma.placeComma(rptTotal),9);
			 PdfPCell rptRollTotType = new PdfPCell(
			 	new Phrase(rptTotalRoll, FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Font.BOLD, Color.black)));		
			 rptRollTotType.setBorderWidth(0);
			 outertable.addCell(rptRollTotType);

			defDvrCdeDoc.add(outertable);
				
		} 
		catch (SQLException se) {
			System.err.println(se.getMessage());
		}
	
		catch (DocumentException de) {
			System.err.println(de.getMessage());
		} catch (IOException ioe) {
			System.err.println(ioe.getMessage());
		}			
		defDvrCdeDoc.close();
		close();
		LogWriter.writeLog(" Bookversion Driver Code Report Generated " );
		return;
	}


}
