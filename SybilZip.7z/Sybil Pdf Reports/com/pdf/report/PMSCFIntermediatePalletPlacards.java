package com.pdf.report;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.report.text.Document;
import com.report.text.DocumentException;
import com.report.text.Element;
import com.report.text.Font;
import com.report.text.FontFactory;
import com.report.text.PageSize;
import com.report.text.Phrase;
import com.report.text.pdf.PdfPCell;
import com.report.text.pdf.PdfPTable;
import com.report.text.pdf.PdfWriter;

import sybil.common.model.Magazine;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;

public class PMSCFIntermediatePalletPlacards {
	
	public static String pkgsum = "TBA_PKG_SUM";
	public static String rollsumTableName = "TBA_ROLL_SUM";
	public static String magazineInf = "TBA_MAGAZINEINF";
	public static String sybMag = "TBA_SYB_MAGAZINE";
	public static String sybplant = "TBA_SYB_PLANT";
	
	private static Connection conn = null;
	private static ResultSet resultset = null;
	private static String magName = null;
	private static int magKey = 0;
	
	private static String instCd = null;
	
	private static String magCode = null;
	
	private static String issueNum = null;
	
	private static String plantId = null;
	
	private static String issueWeek = null;
	
	private static String issueDate = null;
	
	private static String plantName = null;
	
	private static void initialize(Magazine mag){
		magCode = mag.getMagCode().trim();
		issueNum = mag.getIssue().trim();
		plantId = mag.getPlant().toUpperCase().trim();
		issueWeek = mag.getWeek().trim();		
	}
	
	private static void open() {

		PreparedStatement setSqlId = null;
		Statement commitSqlId = null;
		String x = null;
		String db2owner = null;
		int i = 0;
		
		String userDb = sybil.common.util.PropertyBroker.getProperty("database.login","sybil");
		String pswdDb = sybil.common.util.PropertyBroker.getProperty("database.password","sybil");
		
		
		if( conn == null) {
			try {
				Class.forName(sybil.common.util.PropertyBroker.getProperty("database.driver", "Not Found"));
				conn = DriverManager.getConnection(sybil.common.util.PropertyBroker.getProperty("database.server", "Not Found"), userDb, pswdDb);

				//
				x = PropertyBroker.getProperty("database.driver", "Not Found").toLowerCase();
				i = x.indexOf("db2");
				if (!(i < 0)) {
					try {
						db2owner = PropertyBroker.getProperty("DB2OWNER","dtppsyup");
						setSqlId = conn.prepareStatement("set current sqlid = ?");
						setSqlId.setString(1, db2owner);
						setSqlId.execute();
						commitSqlId = conn.createStatement();
						commitSqlId.execute("commit");
					}
					catch (SQLException se) {
						if(se.getSQLState().equals("S1010")) {
						}
						else {
							LogWriter.writeLog(se);
							LogWriter.writeLog("Error: Set Current SqlId failed.");
							if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
								LogWriter.writeLog("Process terminating due to database/sql exception");
								System.exit(1);
							}
						}
					}
					catch (Exception e) {
						LogWriter.writeLog(e);
						LogWriter.writeLog("Error: Set Current SqlId failed.");
						if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
							LogWriter.writeLog("Process terminating due to database/sql exception");
							System.exit(1);
						}
					}
				}
			
			} 
			catch (Exception e) {
				sybil.common.util.LogWriter.writeLog(e);
				LogWriter.writeLog("Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
		
	return;
	}
	

	private static void getIssueDate(){
		
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT COVER_DATE FROM " + magazineInf + " WHERE PLANT = ? and MAG = ? and ISSUE = ? ";
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, plantId.toUpperCase());
		selectMag.setString(2, magCode.toLowerCase());
		selectMag.setString(3, issueNum);
		
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			issueDate  = rs.getString("COVER_DATE");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Issue Date error " + magCode);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectMag != null) {
				try {
					selectMag.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		return ;
	}

	private static void getPlantName(){
		
		PreparedStatement selectPlant = null;
		ResultSet rs = null;
				
		String SQL = "SELECT NAME FROM " + sybplant + " WHERE PLANT_ID = ? ";
		
		try {
		selectPlant = conn.prepareStatement(SQL);
		selectPlant.setString(1, plantId);
		
		rs = selectPlant.executeQuery();
		
		while (rs.next()){
			plantName  = rs.getString("NAME");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Plant name error " + plantId);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectPlant != null) {
				try {
					selectPlant.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		return ;
	}
	
	private static void magazineKey(){
		
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT MAG_KEY, NAME  FROM " + sybMag + " WHERE MAG_CD = ? ";
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, magCode);
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			magKey  = (int)rs.getInt("MAG_KEY");
			magName = rs.getString("NAME");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Code Select error " + magCode);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectMag != null) {
				try {
					selectMag.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		return;
	}
	
	public synchronized static void createPDF(String jobId, String processType){
		
		PreparedStatement selectcopyCnt = null;
		boolean IntermediatePalletPlacards = true;
		Document ippCardsDoc = new Document(PageSize.LETTER.rotate(),-50,-50,30,0);
		
		int pageNo = 1;
			
		
		String SQL = "SELECT A.MAG_KY, A.PLANT_ID, A.MAG_CD, A.ISS_NUM, A.ISS_WK_NUM, A.PAL_LVL, " 
				   + "A.ROLL_NUM, A.PAL_SACK_NUM, A.PKG_WGHT, A.COPY_CNT, B.STAGE_DESC, "
				   + "C.GEO_CMB_NME, C.XSHEET_BV_NME, C.GEO_CAT_ID, C.GEO_CAT_NME, C.BRACE_ID, C.DROP_OFF_PT"
				   + " from " + pkgsum  +  " A, " 
				   + " (SELECT " +
				      " CASE WHEN COUNT(PAL_SACK_NUM) = 1 THEN " +      
				      " 'FULL PALLET' ELSE 'STAGED PALLET'  END AS STAGE_DESC " +       
				      " ,PAL_SACK_NUM, PAL_SACK_IND " +
				      "FROM " + pkgsum +
					  " WHERE MAG_KY = ? and INSTNC_CD = ? and PLANT_ID = ? and  MAG_CD = ? and ISS_NUM = ? and ISS_WK_NUM = ? AND PAL_SACK_IND = 'P' " +
					  " GROUP BY PAL_SACK_IND, PAL_SACK_NUM ) B, "
				   + rollsumTableName  + " C " 
				   + " WHERE A.MAG_KY = ? and A.INSTNC_CD = ? and A.PLANT_ID = ? and  A.MAG_CD = ? and A.ISS_NUM = ? and A.ISS_WK_NUM = ? and A.JOB_ID = ?"
				   + " AND  A.PAL_SACK_NUM = B.PAL_SACK_NUM AND  A.PAL_SACK_IND = B.PAL_SACK_IND AND  A.MAG_KY = C.MAG_KY AND A.INSTNC_CD = C.INSTNC_CD "       
				   + " AND  A.PLANT_ID = C.PLANT_ID AND A.MAG_CD = C.MAG_CD AND A.ISS_NUM = C.ISS_NUM AND  A.ISS_WK_NUM = C.ISS_WK_NUM "
				   + " AND  A.JOB_ID = C.JOB_ID AND  A.ROLL_NUM = C.ROLL_NUM "
				   + " order by A.ROLL_NUM, A.PAL_SACK_NUM " ;
		
		LogWriter.writeLog(" Create PDF InstCd : " + instCd + " SQL " + SQL);
		
		
		try {
				
			Date toDay = new Date(); 
			SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, MMM d, yyyy, HH:mm a "); 
			
			PdfPTable outertable = new PdfPTable(1);
						
			PdfPCell dummyCell = new PdfPCell(new Phrase("",
					FontFactory.getFont(FontFactory.TIMES_ROMAN, 72, Font.BOLD,Color.black)));
			dummyCell.setBorderWidth(0);
			
			
			selectcopyCnt = conn.prepareStatement(SQL);
			selectcopyCnt.setInt(1, magKey);
			selectcopyCnt.setString(2, instCd);
			selectcopyCnt.setString(3, plantId);
			selectcopyCnt.setString(4, magCode);
			selectcopyCnt.setInt(5, toNum.toNumber(issueNum));
			selectcopyCnt.setInt(6, toNum.toNumber(issueWeek));
			selectcopyCnt.setInt(7, magKey);
			selectcopyCnt.setString(8, instCd);
			selectcopyCnt.setString(9, plantId);
			selectcopyCnt.setString(10, magCode);
			selectcopyCnt.setInt(11, toNum.toNumber(issueNum));
			selectcopyCnt.setInt(12, toNum.toNumber(issueWeek));
			selectcopyCnt.setString(13,jobId);
			
			resultset = selectcopyCnt.executeQuery();
			
			
			while (resultset.next()){
				
				String rollNum = resultset.getString("ROLL_NUM");
				String palletNum = resultset.getString("PAL_SACK_NUM");
				String pkgWght = resultset.getString("PKG_WGHT");	
				String copyCount = resultset.getString("COPY_CNT");
				String stageDesc = resultset.getString("STAGE_DESC");
				String geoComboName = resultset.getString("GEO_CMB_NME");
				String bvName = resultset.getString("XSHEET_BV_NME");
				String geoCatId = resultset.getString("GEO_CAT_ID");
				String geoCatName = resultset.getString("GEO_CAT_NME");
				String braceId = resultset.getString("BRACE_ID");
				String dropOffPt = resultset.getString("DROP_OFF_PT");
				String palLvl = resultset.getString("PAL_LVL");
				
			
			if (palLvl.equals("84")){
				
				IntermediatePalletPlacards = false;
				
				stageDesc = "MAIL ON TOUR 1";
				PdfPCell labelCella = new PdfPCell(new Phrase(stageDesc.trim(),
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 72, Font.BOLD,Color.black)));
				labelCella.setHorizontalAlignment(Element.ALIGN_CENTER);
				labelCella.setBorderWidth(0);
				outertable.addCell(labelCella);
				
				for(int i=0;i<2;i++){
					outertable.addCell(dummyCell);}
				
				String cell2Infoa = "PALLET # " + palletNum;
				PdfPCell labelCell2a = new PdfPCell(new Phrase(cell2Infoa,
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 72, Font.BOLD,Color.black)));
				labelCell2a.setHorizontalAlignment(Element.ALIGN_CENTER);
				labelCell2a.setBorderWidth(0);
				outertable.addCell(labelCell2a);
				
				for(int i=0;i<14;i++){outertable.addCell(dummyCell);}
				
				String cell3Infoa =  "PROCESS";
				PdfPCell labelCell3a = new PdfPCell(new Phrase(cell3Infoa,
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 72, Font.BOLD,Color.black)));
				labelCell3a.setHorizontalAlignment(Element.ALIGN_CENTER);
				labelCell3a.setBorderWidth(0);
				outertable.addCell(labelCell3a);
				
				for(int i=0;i<2;i++){outertable.addCell(dummyCell);}
				
				String cell3Infoa2 =  "WITH PRIORITY";
				PdfPCell labelCell3a2 = new PdfPCell(new Phrase(cell3Infoa2,
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 72, Font.BOLD,Color.black)));
				labelCell3a2.setHorizontalAlignment(Element.ALIGN_CENTER);
				labelCell3a2.setBorderWidth(0);
				outertable.addCell(labelCell3a2);
				
				for(int i=0;i<32;i++)outertable.addCell(dummyCell);
				
				String cell4Infoa = "";
				PdfPCell labelCell4a = new PdfPCell(new Phrase(cell4Infoa,
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 18, Font.BOLD,Color.black)));
				labelCell4a.setHorizontalAlignment(Element.ALIGN_CENTER);
				labelCell4a.setBorderWidth(0);
				outertable.addCell(labelCell4a);
				
				outertable.addCell(dummyCell);
				
				String cell5Infoa = "";
				PdfPCell labelCell5a = new PdfPCell(new Phrase(cell5Infoa,
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 18, Font.BOLD,Color.black)));
				labelCell5a.setHorizontalAlignment(Element.ALIGN_CENTER);
				labelCell5a.setBorderWidth(0);
				outertable.addCell(labelCell5a);
				
				outertable.addCell(dummyCell);
				
				String cell6Infoa = "";
				PdfPCell labelCell6a = new PdfPCell(new Phrase(cell6Infoa,
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 18, Font.BOLD,Color.black)));
				labelCell6a.setHorizontalAlignment(Element.ALIGN_CENTER);
				labelCell6a.setBorderWidth(0);
				outertable.addCell(labelCell6a);
				
				outertable.addCell(dummyCell);
				
				String cell7Infoa = "";
				PdfPCell labelCell7a = new PdfPCell(new Phrase(cell7Infoa,
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 18, Font.BOLD,Color.black)));
				labelCell7a.setHorizontalAlignment(Element.ALIGN_CENTER);
				labelCell7a.setBorderWidth(0);
				outertable.addCell(labelCell7a);
				
				
				outertable.addCell(dummyCell);
				
				String cell8Infoa = "";
				PdfPCell labelCell8a = new PdfPCell(new Phrase(cell8Infoa,
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 18, Font.BOLD,Color.black)));
				labelCell8a.setHorizontalAlignment(Element.ALIGN_CENTER);
				labelCell8a.setBorderWidth(0);
				outertable.addCell(labelCell8a);
				
				
				String datelinea = String.valueOf(dateFormat.format(toDay)) + " Page " + pageNo ;
				PdfPCell header0a = new PdfPCell(new Phrase(datelinea,
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Font.NORMAL,Color.black)));
				header0a.setHorizontalAlignment(Element.ALIGN_RIGHT);
				header0a.setBorderWidth(0);
				outertable.addCell(header0a);
				pageNo++;
				}
			
			}
			
			if (IntermediatePalletPlacards){
				LogWriter.writeLog(" No Intermediate Pallet Placards " + processType );
			}else{
				String RptPath = sybil.common.util.PropertyBroker.getProperty("NewPDFReportsPath","Not found");
				
				String fileName = magCode.toLowerCase() + ".i" + issueNum + "." + plantId + ".OMS_PMSCF_Intermediate_Pallet_Placards." + issueWeek + "." + processType ;
				
				PdfWriter writer = PdfWriter.getInstance(ippCardsDoc,new FileOutputStream(RptPath + fileName + ".pdf"));
				
				writer.setViewerPreferences(PdfWriter.PageModeFullScreen);
				
				ippCardsDoc.open();
				
				ippCardsDoc.add(outertable);		
			}
				
		} 
		catch (SQLException se) {
			LogWriter.writeLog(se);
		}
		
		catch (DocumentException de) {
			System.err.println(de.getMessage());
		} catch (IOException ioe) {
			System.err.println(ioe.getMessage());
		} finally {
			if (resultset != null) {
				try {
					resultset.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectcopyCnt != null) {
				try {
					selectcopyCnt.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		if (!IntermediatePalletPlacards)
		ippCardsDoc.close();
		return;
	}
	
	public synchronized static void createPlacardsReport(Magazine mag){
		
		PreparedStatement selectJobID = null;
		ResultSet rsJobId = null;

		open();
		
		initialize(mag); 
		
		String SQL = "Select distinct JOB_ID from  " + pkgsum
					+ " WHERE MAG_KY = ? and INSTNC_CD = ? and PLANT_ID = ? and MAG_CD = ? and ISS_NUM = ? and ISS_WK_NUM = ? ";
	
		magazineKey();
		
		getIssueDate();
		
		instCd = InstanceCd.getInstCd(magKey, toNum.toNumber(issueNum),toNum.toNumber(issueWeek));
		
		LogWriter.writeLog(" InstCd : " + instCd + " SQL " + SQL);
		
		getPlantName();

		try {
			selectJobID = conn.prepareStatement(SQL);
			selectJobID.setInt(1, magKey);
			selectJobID.setString(2, instCd);
			selectJobID.setString(3, plantId);
			selectJobID.setString(4, magCode);
			selectJobID.setInt(5, toNum.toNumber(issueNum));
			selectJobID.setInt(6, toNum.toNumber(issueWeek));
			rsJobId = selectJobID.executeQuery();
			
			while (rsJobId.next()) {

			String jobId = rsJobId.getString("JOB_ID");

			if (jobId.endsWith("U")) {
				createPDF(jobId, "USPS");
				LogWriter.writeLog(" USPS PMSCF Intermediate Pallet Placards Report Generated  ");
			} else if (jobId.endsWith("F")) {
				createPDF(jobId, "FOREIGN");
				LogWriter.writeLog(" Foreign PMSCF Intermediate Pallet Placards Report Generated  ");
			}
		}
		} 
		catch (SQLException se) {
			LogWriter.writeLog(se);
		}  finally {
			if (rsJobId != null) {
				try {
					rsJobId.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectJobID != null) {
				try {
					selectJobID.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		return;
	}
	

}
