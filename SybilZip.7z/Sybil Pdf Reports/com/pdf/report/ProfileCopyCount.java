package com.pdf.report;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import sybil.common.model.Magazine;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;

import com.report.text.Document;
import com.report.text.DocumentException;
import com.report.text.Element;
import com.report.text.ExceptionConverter;
import com.report.text.Font;
import com.report.text.FontFactory;
import com.report.text.PageSize;
import com.report.text.Phrase;
import com.report.text.Rectangle;
import com.report.text.pdf.BaseFont;
import com.report.text.pdf.PdfContentByte;
import com.report.text.pdf.PdfPCell;
import com.report.text.pdf.PdfPTable;
import com.report.text.pdf.PdfPageEventHelper;
import com.report.text.pdf.PdfTemplate;
import com.report.text.pdf.PdfWriter;



public class ProfileCopyCount extends PdfPageEventHelper {

	public static String magInfo = "TBA_MAG_INFO";
	public static String magazineInf = "TBA_MAGAZINEINF";
	public static String sybMag = "TBA_SYB_MAGAZINE";
	
	private static Connection conn = null;
	private static ResultSet resultset = null;
	private static String magName = null;
	
	protected PdfTemplate total;
 	protected BaseFont helv;
 
 	public void onOpenDocument(PdfWriter writer, Document document) {
		total = writer.getDirectContent().createTemplate(100, 100);
		total.setBoundingBox(new Rectangle(-20, -20, 100, 100));
		try {
			helv = BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI,BaseFont.NOT_EMBEDDED);
		} catch (Exception e) {
			throw new ExceptionConverter(e);
		}
	}
 
	public void onEndPage(PdfWriter writer, Document document) {
		PdfContentByte cb = writer.getDirectContent();
		cb.saveState();
		String text = "Page " + writer.getPageNumber() + " of  ";
		float textBase = document.bottom() - 15;
		float textSize = helv.getWidthPoint(text, 9);
		float textCenter = document.right()/2;
		cb.beginText();
		cb.setFontAndSize(helv, 10);

		cb.setTextMatrix(textCenter, textBase);
		cb.showText(text);
		cb.endText();
		cb.addTemplate(total, textCenter + textSize, textBase);
		cb.restoreState();
	}
 	
	public void onCloseDocument(PdfWriter writer, Document document) {
		total.beginText();
		total.setFontAndSize(helv, 10);
		total.setTextMatrix(0, 0);
		total.showText(String.valueOf(writer.getPageNumber() - 1));
		total.endText();
	}
	
	private static void open() {

		PreparedStatement setSqlId = null;
		Statement commitSqlId = null;
		String x = null;
		String db2owner = null;
		int i = 0;
		
		String userDb = sybil.common.util.PropertyBroker.getProperty("database.login","sybil");
		String pswdDb = sybil.common.util.PropertyBroker.getProperty("database.password","sybil");
		
		
		if( conn == null) {
			try {
				Class.forName(sybil.common.util.PropertyBroker.getProperty("database.driver", "Not Found"));
				conn = DriverManager.getConnection(sybil.common.util.PropertyBroker.getProperty("database.server", "Not Found"), userDb, pswdDb);

				//
				x = PropertyBroker.getProperty("database.driver", "Not Found").toLowerCase();
				i = x.indexOf("db2");
				if (!(i < 0)) {
					try {
						db2owner = PropertyBroker.getProperty("DB2OWNER","dtppsyup");
						setSqlId = conn.prepareStatement("set current sqlid = ?");
						setSqlId.setString(1, db2owner);
						setSqlId.execute();
						commitSqlId = conn.createStatement();
						commitSqlId.execute("commit");
					}
					catch (SQLException se) {
						if(se.getSQLState().equals("S1010")) {
						}
						else {
							LogWriter.writeLog(se);
							LogWriter.writeLog("Error: Set Current SqlId failed.");
							if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
								LogWriter.writeLog("Process terminating due to database/sql exception");
								System.exit(1);
							}
						}
					}
					catch (Exception e) {
						LogWriter.writeLog(e);
						LogWriter.writeLog("Error: Set Current SqlId failed.");
						if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
							LogWriter.writeLog("Process terminating due to database/sql exception");
							System.exit(1);
						}
					}
				}
			
			} 
			catch (Exception e) {
				sybil.common.util.LogWriter.writeLog(e);
				LogWriter.writeLog("Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
		
	return;
	}
	

	private static String getIssueDate(Magazine mag){
		
		String issueDate = null;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT COVER_DATE FROM " + magazineInf + " WHERE PLANT = ? and MAG = ? and ISSUE = ? ";
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, mag.getPlant().toUpperCase());
		selectMag.setString(2, mag.getMagCode().toLowerCase());
		selectMag.setString(3, mag.getIssue());
		
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			issueDate  = rs.getString("COVER_DATE");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Issue Date error " + mag.getMagCode());
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectMag != null) {
				try {
					selectMag.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		return issueDate;
	}

	private static int magazineKey(String magazineCode){
		
		int magKey = 0;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT MAG_KEY, NAME  FROM " + sybMag + " WHERE MAG_CD = ? ";
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, magazineCode);
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			magKey  = (int)rs.getInt("MAG_KEY");
			magName = rs.getString("NAME");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Code Select error " + magazineCode);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectMag != null) {
				try {
					selectMag.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		return magKey;
	}

	
	public synchronized static void createPDF(Magazine mag){
		
		PreparedStatement selectcopyCnt = null;
		Document pccDoc = new Document(PageSize.LETTER,-20,-20,30,30);
		
		boolean firstRow = true;
		boolean noLORCount = true;
		boolean firstTime = true;
		String savedeliveryType = "  ";
		int totalCopy = 0;
		int rptTotal = 0;
		int ctr = 1;
		
		String magCode = mag.getMagCode().trim();
		String issueNum = mag.getIssue().trim();
		String plantId = mag.getPlant().toUpperCase().trim();
		String issueWeek = mag.getWeek().trim();
		
		String RptPath = sybil.common.util.PropertyBroker.getProperty("NewPDFReportsPath","Not found");
		String fileName = magCode.toLowerCase() + ".i" + issueNum + "." + plantId + ".Profile_Copy_Count." + issueWeek; 
			
		open();
		
		String SQL = "Select PLANT, MAG, ISSUE, WEEK_NUM, DELIVERY_TYPE, PROCESS_TYPE, DATA_TYPE, ROLLID, LOR_COPY_CNT from "
					+ magInfo
					+ " WHERE PLANT = ? and MAG = ? and ISSUE = ? and WEEK_NUM = ? and LOR_COPY_CNT > 0 and DATA_TYPE = 'cust' ";
		
		LogWriter.writeLog("Select TBA_MAG_INFO query in PCC PDF " + SQL);
		String issueDate = getIssueDate(mag);
		int magKey = magazineKey(magCode);
		LogWriter.writeLog(" Magazine Key is " + magKey);
		
		try {
			
			
			PdfWriter writer = PdfWriter.getInstance(pccDoc,				
					new FileOutputStream(RptPath + fileName + ".pdf"));
			
			writer.setViewerPreferences(PdfWriter.PageModeFullScreen);
			writer.setPageEvent(new ProfileCopyCount());
			
			pccDoc.open();
			
			Date toDay = new Date(); 
			SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, MMM d, yyyy, HH:mm a "); 
			
			PdfPTable outertable = new PdfPTable(1);
			outertable.setHeaderRows(5);
			
			PdfPCell header0 = new PdfPCell(new Phrase(String.valueOf(dateFormat.format(toDay)),
					FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,
							Color.black)));
			header0.setBorderWidth(0);
			outertable.addCell(header0);
			outertable.setSplitLate(false);
			
			PdfPCell cell0 = new PdfPCell(new Phrase("Profile Copy Count Report", FontFactory.getFont(
							FontFactory.COURIER, 15, Font.BOLD, Color.BLUE)));
			cell0.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell0.setBorderWidth(0);
			outertable.addCell(cell0);
			
			String header1 = "Magazine  : " + magName + " " + "Plant : " + plantId ;
			String issueheader =  "Issue     : " +  issueDate + " (" + issueNum + " - " + issueWeek + ")";
			String header2 = " Filetype " +  "  " + AddSpace.addSpace(" ", 27, ' ' ) + "Rollid " + "      " + "       " + " Copy Count";
			
			selectcopyCnt = conn.prepareStatement(SQL);
			selectcopyCnt.setString(1, plantId);
			selectcopyCnt.setString(2, magCode);
			selectcopyCnt.setString(3, issueNum);
			selectcopyCnt.setString(4, issueWeek);
			resultset = selectcopyCnt.executeQuery();
			
			while (resultset.next()){
				noLORCount = false;	
			if (firstRow) {
				
				PdfPCell magCell = new PdfPCell(new Phrase(header1,
						FontFactory.getFont(FontFactory.COURIER, 12, Font.NORMAL,Color.black)));
				magCell.setBorderWidth(0);
				outertable.addCell(magCell);
				
				PdfPCell issueCell = new PdfPCell(new Phrase(issueheader,
						FontFactory.getFont(FontFactory.COURIER, 12, Font.NORMAL,Color.black)));				
				issueCell.setBorderWidth(0);
				outertable.addCell(issueCell);
				
				PdfPCell cellThree = new PdfPCell(new Phrase(header2, FontFactory.getFont(
						FontFactory.COURIER, 12, Font.BOLD, Color.black)));
				cellThree.setBackgroundColor(new Color(192, 253, 171));
				cellThree.setBorderWidth(0);
				outertable.addCell(cellThree);
				firstRow = false;
			}
		
			String dType = resultset.getString("DELIVERY_TYPE").trim();
			String pType    = resultset.getString("PROCESS_TYPE").trim();
			String weekNum  = resultset.getString("WEEK_NUM").trim();
			String RollNum  = resultset.getString("ROLLID");
			String copyCount = resultset.getString("LOR_COPY_CNT");
			String deliveryType = resultset.getString("DELIVERY_TYPE");
			
			String Filetype = dType.concat(pType).concat("cust").concat(weekNum);
			if (Filetype.length() < 15)
				Filetype.concat(" ");
		
			if (deliveryType.compareTo(savedeliveryType) == 0){
		
				if ( ctr == 41 )ctr=1;
				else	
					Filetype = " ";
				String detailInfo = AddSpace.addSpace(Filetype, 16, ' ')  +  "                        " + RollNum  + "                  " +  PlaceComma.placeComma((Integer.valueOf(copyCount)).intValue());
				PdfPCell detailCell = new PdfPCell(new Phrase(detailInfo, FontFactory.getFont(
								FontFactory.COURIER, 12, Font.NORMAL, Color.black)));				
				detailCell.setBorderWidth(0);
				outertable.addCell(detailCell);ctr++;
				totalCopy += (Integer.valueOf(copyCount)).intValue();
			}
			else {
				savedeliveryType = deliveryType;
				if (firstTime){
					firstTime = false;	
				}
				else{
					String totalInfo = AddSpace.addSpace("TOTAL",30,' ')+ " " + AddSpace.addSpace(" ",30,' ') + AddSpace.addSpace(totalCopy) ;
					PdfPCell TotalCell = new PdfPCell(	new Phrase(totalInfo, FontFactory.getFont(FontFactory.COURIER, 12, Font.NORMAL, Color.black)));
					TotalCell.setBorderWidth(0);
					outertable.addCell(TotalCell);ctr++;
					rptTotal += totalCopy;
					totalCopy = 0;
				}
				
				totalCopy += (Integer.valueOf(copyCount)).intValue();
				String detailInfo1 = AddSpace.addSpace(Filetype, 16, ' ')  +  "  " + AddSpace.addSpace(" ",21, ' ')  + RollNum  + "                  " +  PlaceComma.placeComma((Integer.valueOf(copyCount)).intValue());
				PdfPCell detailcellOne = new PdfPCell(new Phrase(detailInfo1, FontFactory.getFont(
								FontFactory.COURIER, 12, Font.NORMAL, Color.black)));
				detailcellOne.setBorderWidth(0);
				outertable.addCell(detailcellOne);ctr++;
			}
			
			}
			
			if (noLORCount) {		
				
				PdfPCell cellTwo = new PdfPCell(new Phrase(header1,	FontFactory.getFont(
					FontFactory.COURIER, 12, Font.BOLD,Color.black)));
				cellTwo.setBorderWidth(0);
				outertable.addCell(cellTwo);

				PdfPCell cellThree = new PdfPCell(new Phrase(header2, FontFactory.getFont(
					FontFactory.COURIER, 12, Font.BOLD, Color.black)));
				cellThree.setBackgroundColor(new Color(192, 253, 171));
				cellThree.setBorderWidth(0);
				outertable.addCell(cellThree);
				for ( int G = 0; G <=2; G++){
					PdfPCell dummyCell = new PdfPCell(new Phrase("", FontFactory.getFont(
									FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					dummyCell.setBorderWidth(0);
					outertable.addCell(dummyCell);}
			}
			else {
				rptTotal += totalCopy;
				String totalFileType = AddSpace.addSpace("TOTAL",30,' ')+ " " + AddSpace.addSpace(" ",28,' ') + AddSpace.addSpace(totalCopy) ;
				PdfPCell detailType = new PdfPCell(new Phrase(totalFileType, FontFactory.getFont(
								FontFactory.COURIER, 12, Font.NORMAL, Color.black)));
				detailType.setBorderWidth(0);
				outertable.addCell(detailType);
				
				String rpttotal = "        TOTAL                               " + rptTotal ;
				PdfPCell rptTotCell = new PdfPCell(new Phrase(rpttotal, FontFactory.getFont(
								FontFactory.COURIER, 12, Font.NORMAL, Color.black)));
				rptTotCell.setBorderWidth(0);
				outertable.addCell(rptTotCell);
			}
			pccDoc.add(outertable);
			
		} 
		catch (SQLException se) {
			LogWriter.writeLog(se);
		}
		
		catch (DocumentException de) {
			System.err.println(de.getMessage());
		} catch (IOException ioe) {
			System.err.println(ioe.getMessage());
		} finally {
			if (resultset != null) {
				try {
					resultset.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectcopyCnt != null) {
				try {
					selectcopyCnt.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		pccDoc.close();
		RptChmod.pdfChmod();
		LogWriter.writeLog("Profile Copy Count Report Generated " );
		return;
	}
}
