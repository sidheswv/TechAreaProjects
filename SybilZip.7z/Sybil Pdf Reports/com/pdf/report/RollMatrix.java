package com.pdf.report;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

import sybil.common.model.Magazine;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;

import com.report.text.Document;
import com.report.text.DocumentException;
import com.report.text.Element;
import com.report.text.ExceptionConverter;
import com.report.text.Font;
import com.report.text.FontFactory;
import com.report.text.PageSize;
import com.report.text.Phrase;
import com.report.text.Rectangle;
import com.report.text.pdf.BaseFont;
import com.report.text.pdf.PdfContentByte;
import com.report.text.pdf.PdfPCell;
import com.report.text.pdf.PdfPTable;
import com.report.text.pdf.PdfPageEventHelper;
import com.report.text.pdf.PdfTemplate;
import com.report.text.pdf.PdfWriter;

	public class RollMatrix  extends PdfPageEventHelper {

	public static String pkgsum = "TBA_PKG_SUM";

	public static String rollsumTableName = "TBA_ROLL_SUM";

	public static String magazineInf = "TBA_MAGAZINEINF";

	public static String sybMag = "TBA_SYB_MAGAZINE";

	public static String sybplant = "TBA_SYB_PLANT";

	public static String magInfo = "TBA_MAG_INFO";
	
	private static Vector rollVec = null;
	
	private static Vector rollsPerBrace = null;
	
	private static Vector PallRoll = null;
	
	private static int [] pos = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
	
	private static int [] tableh3w = {6,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5};
	
	private static final Font COURIER_NORMAL_NINE = FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,Color.black);
	
	private static final Font  TIMESBOLD_12 = FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,Color.black);
	
	private static final Font  TIMESNORAML_12 = FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.NORMAL,Color.black);
	
	private static final int DRAWLRT = Rectangle.LEFT | Rectangle.TOP | Rectangle.RIGHT;
	
	private static Connection conn = null;
	
	private static String magName = null;
	
	private static String plantName = null;
	
	private static int magKey = 0;
	
	private static String instCd = null;
	
	private static String magCode = null;
	
	private static String issueNum = null;
	
	private static String plantId = null;
	
	private static String issueWeek = null;
	
	private static String issueDate = null;
	
	protected PdfTemplate total;

	protected BaseFont helv;
	
	public void onOpenDocument(PdfWriter writer, Document document) {
		total = writer.getDirectContent().createTemplate(100, 100);
		total.setBoundingBox(new Rectangle(-10, -10, 80, 80));
		try {
			helv = BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI,BaseFont.NOT_EMBEDDED);
		} catch (Exception e) {
			throw new ExceptionConverter(e);
		}
	}
	
	public void onEndPage(PdfWriter writer, Document document) {
		PdfContentByte cb = writer.getDirectContent();
		cb.saveState();
		String text = "Page " + writer.getPageNumber() ;
		float textBase = document.top() - 20;
		cb.beginText();
		cb.setFontAndSize(helv, 10);
		
		cb.setTextMatrix(document.left()+ 780, textBase);
		cb.showText(text);
		cb.endText();
		
		cb.restoreState();
	}
	
	public void onCloseDocument(PdfWriter writer, Document document) {
		total.beginText();
		total.setFontAndSize(helv, 12);
		total.setTextMatrix(0, 0);
		total.showText(String.valueOf(writer.getPageNumber() - 1));
		total.endText();
	}
	
	private static void initialize(Magazine mag){
		magCode = mag.getMagCode().trim();
		issueNum = mag.getIssue().trim();
		plantId = mag.getPlant().toUpperCase().trim();
		issueWeek = mag.getWeek().trim();		
	}
	
	private static void open() {

		PreparedStatement setSqlId = null;
		Statement commitSqlId = null;
		String x = null;
		String db2owner = null;
		int i = 0;
		
		String userDb = sybil.common.util.PropertyBroker.getProperty("database.login","sybil");
		String pswdDb = sybil.common.util.PropertyBroker.getProperty("database.password","sybil");
		
		
		if( conn == null) {
			try {
				Class.forName(sybil.common.util.PropertyBroker.getProperty("database.driver", "Not Found"));
				conn = DriverManager.getConnection(sybil.common.util.PropertyBroker.getProperty("database.server", "Not Found"), userDb, pswdDb);

				//
				x = PropertyBroker.getProperty("database.driver", "Not Found").toLowerCase();
				i = x.indexOf("db2");
				if (!(i < 0)) {
					try {
						db2owner = PropertyBroker.getProperty("DB2OWNER","dtppsyup");
						setSqlId = conn.prepareStatement("set current sqlid = ?");
						setSqlId.setString(1, db2owner);
						setSqlId.execute();
						commitSqlId = conn.createStatement();
						commitSqlId.execute("commit");
					}
					catch (SQLException se) {
						if(se.getSQLState().equals("S1010")) {
						}
						else {
							LogWriter.writeLog(se);
							LogWriter.writeLog("Error: Set Current SqlId failed.");
							if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
								LogWriter.writeLog("Process terminating due to database/sql exception");
								System.exit(1);
							}
						}
					}
					catch (Exception e) {
						LogWriter.writeLog(e);
						LogWriter.writeLog("Error: Set Current SqlId failed.");
						if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
							LogWriter.writeLog("Process terminating due to database/sql exception");
							System.exit(1);
						}
					}
				}
			
			} 
			catch (Exception e) {
				sybil.common.util.LogWriter.writeLog(e);
				LogWriter.writeLog("Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
		
	return;
	}
	

	private static String getIssueDate(){
		
		String issueDate = null;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT COVER_DATE FROM " + magazineInf + " WHERE PLANT = ? and MAG = ? and ISSUE = ? ";
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, plantId.toUpperCase());
		selectMag.setString(2, magCode.toLowerCase());
		selectMag.setString(3, issueNum);
		
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			issueDate  = rs.getString("COVER_DATE");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Issue Date error " + magCode);
		} finally {
		    if (rs != null) {
		        try {
		        	rs.close();
		        } catch (SQLException e) { /* ignored */}
		    }
		    if (selectMag != null) {
		        try {
		        	selectMag.close();
		        } catch (SQLException e) { /* ignored */}
		    }
		}
		return issueDate;
	}

	private static int magazineKey(String magazineCode){
		
		int magKey = 0;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT MAG_KEY, NAME  FROM " + sybMag + " WHERE MAG_CD = ? ";
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, magazineCode);
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			magKey  = (int)rs.getInt("MAG_KEY");
			magName = rs.getString("NAME");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Code Select error " + magazineCode);
		} finally {
		    if (rs != null) {
		        try {
		        	rs.close();
		        } catch (SQLException e) { /* ignored */}
		    }
		    if (selectMag != null) {
		        try {
		        	selectMag.close();
		        } catch (SQLException e) { /* ignored */}
		    }
		}
		return magKey;
	}

	
	private static String getPlantName(String plantId) {

		String plantName = null;
		PreparedStatement selectPlant = null;
		ResultSet rs = null;

		String SQL = "SELECT NAME FROM " + sybplant + " WHERE PLANT_ID = ? ";

		try {
			selectPlant = conn.prepareStatement(SQL);
			selectPlant.setString(1, plantId);

			rs = selectPlant.executeQuery();

			while (rs.next()) {
				plantName = rs.getString("NAME");
			}
		} catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Plant name error " + plantId);
		} finally {
		    if (rs != null) {
		        try {
		        	rs.close();
		        } catch (SQLException e) { /* ignored */}
		    }
		    if (selectPlant != null) {
		        try {
		        	selectPlant.close();
		        } catch (SQLException e) { /* ignored */}
		    }
		}
		return plantName;
	}

	private static void initializePos(){
		for (int i = 0; i<pos.length; i++){
			pos [i] = 0;
		}		
	}
	
	private static void getRollPos(int rollNum, String braceId){
		
		for (int a = 0; a < rollVec.size(); a++) {
			RollPosition rollPos = (RollPosition) rollVec.get(a);
			
			if (rollPos.getRollNum() == rollNum	&& (rollPos.getBraceId().compareTo(braceId) == 0)) {
				pos[rollPos.getRollPos()-1] = 1;
			}
		}
	}
	
	private static void loadRollNumVec(String jobId,String bId){
		
		PreparedStatement selectcopyCnt = null;
		ResultSet rsSet = null;
		int asignPos = 0;
		String saveBrId = "";

		String SQL = "Select distinct A.MAG_KY, A.PLANT_ID, A.MAG_CD, A.ISS_NUM, A.ISS_WK_NUM, B.BRACE_ID, A.ROLL_NUM from  "
					+ pkgsum  + " A,  " + rollsumTableName + "  B " 
					+ " WHERE A.MAG_KY = ? and A.INSTNC_CD = ? AND A.PLANT_ID = ? and A.MAG_CD = ? and A.ISS_NUM = ? and A.ISS_WK_NUM = ?  and A.JOB_ID = ? and B.BRACE_ID = ?"
					+ " AND A.MAG_KY = B.MAG_KY AND A.INSTNC_CD = B.INSTNC_CD AND A.PLANT_ID = B.PLANT_ID  AND A.MAG_CD = B.MAG_CD AND A.ISS_NUM  = B.ISS_NUM "
					+ " AND A.ISS_WK_NUM  = B.ISS_WK_NUM AND A.JOB_ID  = B.JOB_ID AND A.ROLL_NUM = B.ROLL_NUM  AND A.PAL_SACK_IND = 'P' AND A.PAL_SACK_IND = B.PAL_SACK_IND "
					+ " ORDER BY A.MAG_KY, A.PLANT_ID, A.MAG_CD, A.ISS_NUM, A.ISS_WK_NUM, B.BRACE_ID, A.ROLL_NUM ";
		
		
		try {
			
			selectcopyCnt = conn.prepareStatement(SQL);
			selectcopyCnt.setInt(1, magKey);
			selectcopyCnt.setString(2, instCd);
			selectcopyCnt.setString(3, plantId);
			selectcopyCnt.setString(4, magCode);
			selectcopyCnt.setInt(5, toNum.toNumber(issueNum));
			selectcopyCnt.setInt(6, toNum.toNumber(issueWeek));
			selectcopyCnt.setString(7, jobId);
			selectcopyCnt.setString(8, bId);
			rsSet = selectcopyCnt.executeQuery();
			
			while (rsSet.next()){
			
			String braceId  = rsSet.getString("BRACE_ID");
			String rollNum  = rsSet.getString("ROLL_NUM");
			
			if (braceId.compareTo(saveBrId)== 0)
				asignPos ++;
			else{
				saveBrId = braceId;
				asignPos = 1;
			}
			RollPosition rollPos = new RollPosition(braceId,Integer.valueOf(rollNum).intValue(),asignPos);
			rollVec.add(rollPos);
			
			}
		} 
		catch (SQLException se) {
			LogWriter.writeLog(se);
		}finally {
		    if (rsSet != null) {
		        try {
		        	rsSet.close();
		        } catch (SQLException e) { /* ignored */}
		    }
		    if (selectcopyCnt != null) {
		        try {
		        	selectcopyCnt.close();
		        } catch (SQLException e) { /* ignored */}
		    }
		}    
		return;
	}
	
	private static void createPDF(String jobId, String rptType){
		
		boolean firstPass = true;
		PdfPTable outertable = null;
		Document rollMatDoc = new Document(PageSize.LETTER.rotate(), -80, -80, 0, 0);
		
		PallRoll = new Vector();
		rollVec = new Vector();
		rollsPerBrace = new Vector();
		
		String RptPath = sybil.common.util.PropertyBroker.getProperty("NewPDFReportsPath","Not found");
		String fileName = magCode.toLowerCase() + ".i" + issueNum + "." + plantId + ".OMS_Pallet_Roll_Matrix." + issueWeek + "." + rptType ;
		
		rollByBrace(jobId);
		
		try {
			
			if (rollsPerBrace.size() > 0){ 
			PdfWriter writer = PdfWriter.getInstance(rollMatDoc,new FileOutputStream(RptPath + fileName + ".pdf"));
			
			writer.setViewerPreferences(PdfWriter.PageModeFullScreen);
			writer.setPageEvent(new RollMatrix());
			
			Date toDay = new Date(); 
			SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, MMM d, yyyy, HH:mm a ");
		
			PdfPCell dummyCell = new PdfPCell(new Phrase("",TIMESBOLD_12));
			dummyCell.setBorderWidth(0);
			
			rollMatDoc.open();
			
			for( int x=0;x<rollsPerBrace.size();x++){
				String savePalletNum = " ";
				NumofRolls numRoll = (NumofRolls) rollsPerBrace.get(x);
				
				if (numRoll.getNumOfRolls() > 19){
					//  More Rolls start here 
					PreparedStatement selectcopyCnt = null;
					ResultSet rsSet = null;
					boolean gotRoll = false;
					String SavePalletNum = " ";
					int asignPos = 1;
					
					String SQL = "Select A.MAG_KY, A.PLANT_ID, A.MAG_CD, A.ISS_NUM, A.ISS_WK_NUM, B.BRACE_ID, A.PAL_SACK_NUM, A.ROLL_NUM from  "
						+ pkgsum  + " A,  " + rollsumTableName + "  B " 
						+ " WHERE A.MAG_KY = ? and A.INSTNC_CD = ? and A.PLANT_ID = ? and A.MAG_CD = ? and A.ISS_NUM = ? and A.ISS_WK_NUM = ? and A.JOB_ID = ? and B.BRACE_ID = ?"
						+ " AND A.MAG_KY = B.MAG_KY and A.INSTNC_CD = B.INSTNC_CD AND A.PLANT_ID = B.PLANT_ID  AND A.MAG_CD = B.MAG_CD AND A.ISS_NUM  = B.ISS_NUM "
						+ " AND A.ISS_WK_NUM  = B.ISS_WK_NUM AND A.JOB_ID  = B.JOB_ID AND A.ROLL_NUM = B.ROLL_NUM  AND A.PAL_SACK_IND = 'P' AND A.PAL_SACK_IND = B.PAL_SACK_IND "
						+ " ORDER BY A.MAG_KY, A.PLANT_ID, A.MAG_CD, A.ISS_NUM, A.ISS_WK_NUM, B.BRACE_ID, A.PAL_SACK_NUM, A.ROLL_NUM ";

					try {
						
						selectcopyCnt = conn.prepareStatement(SQL);
						selectcopyCnt.setInt(1, magKey);
						selectcopyCnt.setString(2, instCd);
						selectcopyCnt.setString(3, plantId);
						selectcopyCnt.setString(4, magCode);
						selectcopyCnt.setInt(5, toNum.toNumber(issueNum));
						selectcopyCnt.setInt(6, toNum.toNumber(issueWeek));
						selectcopyCnt.setString(7, jobId);
						selectcopyCnt.setString(8, numRoll.getBraceId());
						rsSet = selectcopyCnt.executeQuery();
						
						while (rsSet.next()) {

							String braceId = rsSet.getString("BRACE_ID");
							int rollNum = Integer.valueOf(rsSet.getString("ROLL_NUM")).intValue();
							String palletNum = rsSet.getString("PAL_SACK_NUM");

							PalletRoll palletRoll = new PalletRoll(braceId, rollNum,palletNum);
							PallRoll.add(palletRoll);
							
							gotRoll = false;
							for (int a = 0; a < rollVec.size(); a++) {
								RollPosition rollPos = (RollPosition) rollVec.get(a);
								if (rollNum == rollPos.getRollNum())
									gotRoll = true;
							}

							
							if (gotRoll)
								continue;
							else {
								RollPosition rollPos = new RollPosition(braceId, rollNum, asignPos++);
								rollVec.add(rollPos);
								
				//				LogWriter.writeLog("Brace Id    : "   + braceId + " Roll Num : " + rollNum);
							}
							
							if (rollVec.size() >= 19) {
				//				Morethan 20 rolls report section Starts here 
								int pageLine = 0;
								initializePos();
								
				//				LogWriter.writeLog("rollVec.size()   : "   + rollVec.size());
								
								outertable = new PdfPTable(1);
								outertable.setHeaderRows(9);
							
								String dateHdr = String.valueOf(dateFormat.format(toDay)) + " Issue :" + issueNum + " Cover :" + issueDate ; 
								PdfPCell header0 = new PdfPCell(new Phrase(dateHdr,COURIER_NORMAL_NINE));
								header0.setBorderWidth(0);
								outertable.addCell(header0);
							
								PdfPCell titleheader = new PdfPCell(new Phrase("Plant Pallet / Roll Matrix", 
									FontFactory.getFont(FontFactory.TIMES_ROMAN, 24, Font.BOLD, Color.BLACK)));
								titleheader.setHorizontalAlignment(Element.ALIGN_CENTER);
								titleheader.setBorderWidth(0);
								outertable.addCell(titleheader);
							
								int [] table9 = {4,9,9,4,5,5,5,5,5};
								PdfPTable issueHdrTable = new PdfPTable(9);
								issueHdrTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
								issueHdrTable.setWidths(table9);
								issueHdrTable.addCell(new Phrase("Plant :",TIMESBOLD_12));
								issueHdrTable.addCell(new Phrase(plantName.trim(),TIMESNORAML_12));
								issueHdrTable.addCell(new Phrase(magName.trim(),TIMESNORAML_12));
								issueHdrTable.addCell(new Phrase("Issue :",TIMESBOLD_12));
								String issueDateCell = issueDate + "    (" + issueNum + "-" + issueWeek + ")"; 
								issueHdrTable.addCell(new Phrase(issueDateCell,TIMESNORAML_12));
								issueHdrTable.addCell(new Phrase("",TIMESBOLD_12));
								issueHdrTable.addCell(new Phrase("",TIMESBOLD_12));
								issueHdrTable.addCell(new Phrase("",TIMESBOLD_12));
								issueHdrTable.addCell(new Phrase("",TIMESBOLD_12));
							
								PdfPCell issueHdrcell = new PdfPCell(issueHdrTable);
								issueHdrcell.setBorderWidth(0);
								outertable.addCell(issueHdrcell);
							
								for(int i=0;i<2;i++)outertable.addCell(dummyCell);

								int [] tablew = {2,9,9,2,5};
								PdfPTable braceHdrTable = new PdfPTable(5);
								braceHdrTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
								braceHdrTable.setWidths(tablew);
								braceHdrTable.addCell(new Phrase("Brace :",TIMESBOLD_12));
								String braceCell = AddSpace.addSpace(numRoll.getBraceId(), 3, ' ') + " ";
								braceHdrTable.addCell(new Phrase(braceCell,TIMESNORAML_12));
								braceHdrTable.addCell(new Phrase("",TIMESNORAML_12));
								braceHdrTable.addCell(new Phrase("",TIMESNORAML_12)); 
								braceHdrTable.addCell(new Phrase("",TIMESNORAML_12));
							
								PdfPCell braceHdrcell = new PdfPCell(braceHdrTable);
								braceHdrcell.setBorderWidth(0);
								outertable.addCell(braceHdrcell);
							
								int [] tableh1w = {3,5,4,5,4,5,3,3,3,3,3};
								PdfPTable xyTable = new PdfPTable(11);
								xyTable.setWidths(tableh1w);
								xyTable.getDefaultCell().setBorder(Rectangle.NO_BORDER | Rectangle.BOTTOM);
								xyTable.getDefaultCell().setBorderWidthBottom(1);
								xyTable.getDefaultCell().setPaddingBottom(5);
								xyTable.addCell(new Phrase("Pallet ",TIMESBOLD_12));
								xyTable.addCell(new Phrase("Roll Numbers",TIMESBOLD_12));
								for(int z= 0; z<9;z++){
									xyTable.addCell(new Phrase("",TIMESBOLD_12));
								}
							
								PdfPCell xyCell = new PdfPCell(xyTable);
								xyCell.setBorderWidth(0);
								outertable.addCell(xyCell);
								
								PdfPTable rollNumTable = new PdfPTable(20);
								rollNumTable.setWidths(tableh3w);
								rollNumTable.getDefaultCell().setBorder(Rectangle.NO_BORDER );
								rollNumTable.getDefaultCell().setBorderWidthBottom(0);
								rollNumTable.addCell(new Phrase(" ",TIMESBOLD_12));
								int numRollCount = 0;
								
								for (int a = 0; a<rollVec.size(); a++){
									RollPosition bracePerRoll = (RollPosition)rollVec.get(a);
									if (bracePerRoll.getBraceId().compareTo(numRoll.getBraceId()) == 0 ){
										String rollHdr = AddSpace.addSpace(String.valueOf(bracePerRoll.getRollNum()),3,'0') + " ";
										rollNumTable.addCell(new Phrase(rollHdr,TIMESBOLD_12));
										numRollCount++;
									}
								}
								for (int a=0;a<20-numRollCount;a++){
									rollNumTable.addCell(new Phrase(" ",TIMESBOLD_12));
								}
							
								PdfPCell rollNumCell = new PdfPCell(rollNumTable);
								rollNumCell.setBorderWidth(0);
								outertable.addCell(rollNumCell);
							
								outertable.addCell(dummyCell);
								
								for (int oneSet = 0; oneSet < PallRoll.size(); oneSet++) {
									PalletRoll PalletRoll = (PalletRoll) PallRoll.get(oneSet);
									String BraceId = PalletRoll.getBraceId();
									int RollNum  = PalletRoll.getRollNum();
									String PalletNum = PalletRoll.getPalletNum();
									
									//LogWriter.writeLog("PallRoll.size()  :  "  + PallRoll.size() + " Brace Id :" + braceId);
									
									if (PalletNum.compareTo(SavePalletNum) == 0) {
										getRollPos(RollNum, BraceId);
									}
									else{
										if (firstPass){
											firstPass = false;
										} 
										else {
											PdfPTable matrixTable = new PdfPTable(20);
											matrixTable.setWidths(tableh3w);
											matrixTable.getDefaultCell().setBorder(Rectangle.NO_BORDER );
											matrixTable.getDefaultCell().setBorderWidthBottom(0);
										
											String palletNumCell = AddSpace.addSpace(SavePalletNum, 4, '0') + " ";
											matrixTable.addCell(new Phrase(palletNumCell,TIMESBOLD_12));
											
											for (int G=0;G<pos.length;G++){
												
												if (pos[G] == 1){
													matrixTable.getDefaultCell().setBorder(DRAWLRT);
													matrixTable.getDefaultCell().setBorderWidthBottom(1);
													matrixTable.addCell(new Phrase(palletNumCell,TIMESNORAML_12));
												}
												else{
													matrixTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
													matrixTable.getDefaultCell().setBorderWidthBottom(0);
													matrixTable.addCell(new Phrase("",TIMESBOLD_12));   
												}
											}
											PdfPCell matrixCell = new PdfPCell(matrixTable);
											matrixCell.setBorderWidth(0);
											matrixCell.setHorizontalAlignment(Element.ALIGN_CENTER);
											outertable.addCell(matrixCell);pageLine++;
											
											if (pageLine == 30){
												LogWriter.writeLog("FM Roll Matrix - pageLine 0  :  " + pageLine);
												pageLine = 0;
											}
											initializePos();
										}
										SavePalletNum = PalletNum;
										getRollPos(RollNum, BraceId);
									}	
								}
								PdfPTable matrixTable = new PdfPTable(20);
								matrixTable.setWidths(tableh3w);
								matrixTable.getDefaultCell().setBorder(Rectangle.NO_BORDER );
								matrixTable.getDefaultCell().setBorderWidthBottom(0);
							
								String palletNumCell = AddSpace.addSpace(SavePalletNum, 4, '0') + " ";
								matrixTable.addCell(new Phrase(palletNumCell,TIMESBOLD_12));
								
								for (int G=0;G<pos.length;G++){
									
									if (pos[G] == 1){
										matrixTable.getDefaultCell().setBorder(DRAWLRT);
										matrixTable.getDefaultCell().setBorderWidthBottom(1);
										matrixTable.addCell(new Phrase(palletNumCell,TIMESNORAML_12));
									}
									else{
										matrixTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
										matrixTable.getDefaultCell().setBorderWidthBottom(0);
										matrixTable.addCell(new Phrase("",TIMESBOLD_12));   
									}
								}
								PdfPCell matrixCell = new PdfPCell(matrixTable);
								matrixCell.setBorderWidth(0);
								matrixCell.setHorizontalAlignment(Element.ALIGN_CENTER);
								outertable.addCell(matrixCell);pageLine++;
								
								initializePos();
								
								LogWriter.writeLog("M Roll Matrix - pageLine 1  :  " + pageLine);
								if (pageLine < 30) {
									int totLine = 0;
									
									if (pageLine < 30)totLine = 10;
									if (pageLine < 25)totLine = 20 + 26;
									if (pageLine < 20)totLine = 20 + 36;
									if (pageLine < 15)totLine = 45 + 36;
									if (pageLine < 10)totLine = 50 + 36;
									for (; pageLine < totLine; pageLine++) {
									outertable.addCell(dummyCell);
									}
									LogWriter.writeLog("M Roll Matrix - pageLine 2  :  " + pageLine);
								}
								pageLine = 0;
								
								rollMatDoc.add(outertable);
								firstPass = true;
								PallRoll.clear();
								rollVec.clear();
								asignPos = 1;
							}// report if								

						}// While End
						if (rollVec.size() > 0){   // Remaining rolls report if
							int pageLine = 0;
							initializePos();
							
			//				LogWriter.writeLog("rollVec.size()   : "   + rollVec.size());
							
							outertable = new PdfPTable(1);
							outertable.setHeaderRows(9);
						
							String dateHdr = String.valueOf(dateFormat.format(toDay)) + " Issue :" + issueNum + " Cover :" + issueDate ; 
							PdfPCell header0 = new PdfPCell(new Phrase(dateHdr,COURIER_NORMAL_NINE));
							header0.setBorderWidth(0);
							outertable.addCell(header0);
						
							PdfPCell titleheader = new PdfPCell(new Phrase("Plant Pallet / Roll Matrix", 
								FontFactory.getFont(FontFactory.TIMES_ROMAN, 24, Font.BOLD, Color.BLACK)));
							titleheader.setHorizontalAlignment(Element.ALIGN_CENTER);
							titleheader.setBorderWidth(0);
							outertable.addCell(titleheader);
						
							int [] table9 = {4,9,9,4,5,5,5,5,5};
							PdfPTable issueHdrTable = new PdfPTable(9);
							issueHdrTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
							issueHdrTable.setWidths(table9);
							issueHdrTable.addCell(new Phrase("Plant :",TIMESBOLD_12));
							issueHdrTable.addCell(new Phrase(plantName.trim(),TIMESNORAML_12));
							issueHdrTable.addCell(new Phrase(magName.trim(),TIMESNORAML_12));
							issueHdrTable.addCell(new Phrase("Issue :",TIMESBOLD_12));
							String issueDateCell = issueDate + "    (" + issueNum + "-" + issueWeek + ")"; 
							issueHdrTable.addCell(new Phrase(issueDateCell,TIMESNORAML_12));
							issueHdrTable.addCell(new Phrase("",TIMESBOLD_12));
							issueHdrTable.addCell(new Phrase("",TIMESBOLD_12));
							issueHdrTable.addCell(new Phrase("",TIMESBOLD_12));
							issueHdrTable.addCell(new Phrase("",TIMESBOLD_12));
						
							PdfPCell issueHdrcell = new PdfPCell(issueHdrTable);
							issueHdrcell.setBorderWidth(0);
							outertable.addCell(issueHdrcell);
						
							for(int i=0;i<2;i++)outertable.addCell(dummyCell);

							int [] tablew = {2,9,9,2,5};
							PdfPTable braceHdrTable = new PdfPTable(5);
							braceHdrTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
							braceHdrTable.setWidths(tablew);
							braceHdrTable.addCell(new Phrase("Brace :",TIMESBOLD_12));
							String braceCell = AddSpace.addSpace(numRoll.getBraceId(), 3, ' ') + " ";
							braceHdrTable.addCell(new Phrase(braceCell,TIMESNORAML_12));
							braceHdrTable.addCell(new Phrase("",TIMESNORAML_12));
							braceHdrTable.addCell(new Phrase("",TIMESNORAML_12)); 
							braceHdrTable.addCell(new Phrase("",TIMESNORAML_12));
						
							PdfPCell braceHdrcell = new PdfPCell(braceHdrTable);
							braceHdrcell.setBorderWidth(0);
							outertable.addCell(braceHdrcell);
						
							int [] tableh1w = {3,5,4,5,4,5,3,3,3,3,3};
							PdfPTable xyTable = new PdfPTable(11);
							xyTable.setWidths(tableh1w);
							xyTable.getDefaultCell().setBorder(Rectangle.NO_BORDER | Rectangle.BOTTOM);
							xyTable.getDefaultCell().setBorderWidthBottom(1);
							xyTable.getDefaultCell().setPaddingBottom(5);
							xyTable.addCell(new Phrase("Pallet ",TIMESBOLD_12));
							xyTable.addCell(new Phrase("Roll Numbers",TIMESBOLD_12));
							for(int z= 0; z<9;z++){
								xyTable.addCell(new Phrase("",TIMESBOLD_12));
							}
						
							PdfPCell xyCell = new PdfPCell(xyTable);
							xyCell.setBorderWidth(0);
							outertable.addCell(xyCell);
							
							PdfPTable rollNumTable = new PdfPTable(20);
							rollNumTable.setWidths(tableh3w);
							rollNumTable.getDefaultCell().setBorder(Rectangle.NO_BORDER );
							rollNumTable.getDefaultCell().setBorderWidthBottom(0);
							rollNumTable.addCell(new Phrase(" ",TIMESBOLD_12));
							int numRollCount = 0;
							
							for (int a = 0; a<rollVec.size(); a++){
								RollPosition bracePerRoll = (RollPosition)rollVec.get(a);
								if (bracePerRoll.getBraceId().compareTo(numRoll.getBraceId()) == 0 ){
									String rollHdr = AddSpace.addSpace(String.valueOf(bracePerRoll.getRollNum()),3,'0') + " ";
									rollNumTable.addCell(new Phrase(rollHdr,TIMESBOLD_12));
									numRollCount++;
								}
							}
							for (int a=0;a<20-numRollCount;a++){
								rollNumTable.addCell(new Phrase(" ",TIMESBOLD_12));
							}
						
							PdfPCell rollNumCell = new PdfPCell(rollNumTable);
							rollNumCell.setBorderWidth(0);
							outertable.addCell(rollNumCell);
						
							outertable.addCell(dummyCell);
							
							for (int oneSet = 0; oneSet < PallRoll.size(); oneSet++) {
								PalletRoll PalletRoll = (PalletRoll) PallRoll.get(oneSet);
								String BraceId = PalletRoll.getBraceId();
								int RollNum  = PalletRoll.getRollNum();
								String PalletNum = PalletRoll.getPalletNum();
								
								//LogWriter.writeLog("PallRoll.size()  :  "  + PallRoll.size() + " Brace Id :" + braceId);
								
								if (PalletNum.compareTo(SavePalletNum) == 0) {
									getRollPos(RollNum, BraceId);
								}
								else{
									if (firstPass){
										firstPass = false;
									} 
									else {
										PdfPTable matrixTable = new PdfPTable(20);
										matrixTable.setWidths(tableh3w);
										matrixTable.getDefaultCell().setBorder(Rectangle.NO_BORDER );
										matrixTable.getDefaultCell().setBorderWidthBottom(0);
									
										String palletNumCell = AddSpace.addSpace(SavePalletNum, 4, '0') + " ";
										matrixTable.addCell(new Phrase(palletNumCell,TIMESBOLD_12));
										
										for (int G=0;G<pos.length;G++){
											
											if (pos[G] == 1){
												matrixTable.getDefaultCell().setBorder(DRAWLRT);
												matrixTable.getDefaultCell().setBorderWidthBottom(1);
												matrixTable.addCell(new Phrase(palletNumCell,TIMESNORAML_12));
											}
											else{
												matrixTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
												matrixTable.getDefaultCell().setBorderWidthBottom(0);
												matrixTable.addCell(new Phrase("",TIMESBOLD_12));   
											}
										}
										PdfPCell matrixCell = new PdfPCell(matrixTable);
										matrixCell.setBorderWidth(0);
										matrixCell.setHorizontalAlignment(Element.ALIGN_CENTER);
										outertable.addCell(matrixCell);pageLine++;
										
										if (pageLine == 30){
											LogWriter.writeLog("FM Roll Matrix - pageLine 0  :  " + pageLine);
											pageLine = 0;
										}
										initializePos();
									}
									SavePalletNum = PalletNum;
									getRollPos(RollNum, BraceId);
								}	
							}
							PdfPTable matrixTable = new PdfPTable(20);
							matrixTable.setWidths(tableh3w);
							matrixTable.getDefaultCell().setBorder(Rectangle.NO_BORDER );
							matrixTable.getDefaultCell().setBorderWidthBottom(0);
						
							String palletNumCell = AddSpace.addSpace(SavePalletNum, 4, '0') + " ";
							matrixTable.addCell(new Phrase(palletNumCell,TIMESBOLD_12));
							
							for (int G=0;G<pos.length;G++){
								
								if (pos[G] == 1){
									matrixTable.getDefaultCell().setBorder(DRAWLRT);
									matrixTable.getDefaultCell().setBorderWidthBottom(1);
									matrixTable.addCell(new Phrase(palletNumCell,TIMESNORAML_12));
								}
								else{
									matrixTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
									matrixTable.getDefaultCell().setBorderWidthBottom(0);
									matrixTable.addCell(new Phrase("",TIMESBOLD_12));   
								}
							}
							PdfPCell matrixCell = new PdfPCell(matrixTable);
							matrixCell.setBorderWidth(0);
							matrixCell.setHorizontalAlignment(Element.ALIGN_CENTER);
							outertable.addCell(matrixCell);pageLine++;
							
							initializePos();
							
							LogWriter.writeLog("M Roll Matrix - pageLine 1  :  " + pageLine);
							if (pageLine < 30) {
								int totLine = 0;
								
								if (pageLine < 30)totLine = 10;
								if (pageLine < 25)totLine = 20 + 26;
								if (pageLine < 20)totLine = 20 + 36;
								if (pageLine < 15)totLine = 45 + 36;
								if (pageLine < 10)totLine = 50 + 36;
								for (; pageLine < totLine; pageLine++) {
								outertable.addCell(dummyCell);
								}
								LogWriter.writeLog("M Roll Matrix - pageLine 2  :  " + pageLine);
							}
							pageLine = 0;
							
							rollMatDoc.add(outertable);
							firstPass = true;
							PallRoll.clear();
							rollVec.clear();
							asignPos = 1;							
						}  // Remaining rolls report if
					} 
					catch (SQLException se) {
						LogWriter.writeLog(se);
					}

					
				}	//  End More Rolls process.
				else
				{ 
					int pageLine = 0;
					loadOneRollBrace(jobId,numRoll.getBraceId());
					initializePos();
					
					outertable = new PdfPTable(1);
					outertable.setHeaderRows(9);
				
					String dateHdr = String.valueOf(dateFormat.format(toDay)) + " Issue :" + issueNum + " Cover :" + issueDate ; 
					PdfPCell header0 = new PdfPCell(new Phrase(dateHdr,COURIER_NORMAL_NINE));
					header0.setBorderWidth(0);
					outertable.addCell(header0);
				
					PdfPCell titleheader = new PdfPCell(new Phrase("Plant Pallet / Roll Matrix", 
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 24, Font.BOLD, Color.BLACK)));
					titleheader.setHorizontalAlignment(Element.ALIGN_CENTER);
					titleheader.setBorderWidth(0);
					outertable.addCell(titleheader);
				
					int [] table9 = {4,9,9,2,2,5,7,2,2};
					PdfPTable issueHdrTable = new PdfPTable(9);
					issueHdrTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
					issueHdrTable.setWidths(table9);
					issueHdrTable.addCell(new Phrase("Plant :",TIMESBOLD_12));
					issueHdrTable.addCell(new Phrase(plantName.trim(),TIMESNORAML_12));
					issueHdrTable.addCell(new Phrase(magName.trim(),TIMESNORAML_12));
					issueHdrTable.addCell(new Phrase("",TIMESBOLD_12)); 
					issueHdrTable.addCell(new Phrase("",TIMESNORAML_12));
					issueHdrTable.addCell(new Phrase("Issue : ",TIMESBOLD_12));
					String issueDateCell = issueDate + "    (" + issueNum + "-" + issueWeek + ")";
					issueHdrTable.addCell(new Phrase(issueDateCell,TIMESBOLD_12));
					issueHdrTable.addCell(new Phrase("",TIMESBOLD_12));
					issueHdrTable.addCell(new Phrase("",TIMESBOLD_12));
				
					PdfPCell issueHdrcell = new PdfPCell(issueHdrTable);
					issueHdrcell.setBorderWidth(0);
					outertable.addCell(issueHdrcell);
				
					for(int i=0;i<2;i++)outertable.addCell(dummyCell);
				
					int [] tablew = {2,9,9,2,5};
					PdfPTable braceHdrTable = new PdfPTable(5);
					braceHdrTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
					braceHdrTable.setWidths(tablew);
					braceHdrTable.addCell(new Phrase("Brace :",TIMESBOLD_12));
					String braceCell = AddSpace.addSpace(numRoll.getBraceId(), 3, ' ') + " ";
					braceHdrTable.addCell(new Phrase(braceCell,TIMESNORAML_12));
					braceHdrTable.addCell(new Phrase("",TIMESNORAML_12));
					braceHdrTable.addCell(new Phrase("",TIMESNORAML_12)); 
					braceHdrTable.addCell(new Phrase("",TIMESNORAML_12));
				
					PdfPCell braceHdrcell = new PdfPCell(braceHdrTable);
					braceHdrcell.setBorderWidth(0);
					outertable.addCell(braceHdrcell);
				
					int [] tableh1w = {3,5,4,5,4,5,3,3,3,3,3};
					PdfPTable xyTable = new PdfPTable(11);
					xyTable.setWidths(tableh1w);
					xyTable.getDefaultCell().setBorder(Rectangle.NO_BORDER | Rectangle.BOTTOM);
					xyTable.getDefaultCell().setBorderWidthBottom(1);
					xyTable.getDefaultCell().setPaddingBottom(5);
					xyTable.addCell(new Phrase("Pallet ",TIMESBOLD_12));
					xyTable.addCell(new Phrase("Roll Numbers",TIMESBOLD_12));
					for(int z= 0; z<9;z++){
						xyTable.addCell(new Phrase("",TIMESBOLD_12));
					}
				
					PdfPCell xyCell = new PdfPCell(xyTable);
					xyCell.setBorderWidth(0);
					outertable.addCell(xyCell);
					
					PdfPTable rollNumTable = new PdfPTable(20);
					rollNumTable.setWidths(tableh3w);
					rollNumTable.getDefaultCell().setBorder(Rectangle.NO_BORDER );
					rollNumTable.getDefaultCell().setBorderWidthBottom(0);
					rollNumTable.addCell(new Phrase(" ",TIMESBOLD_12));
					int numRollCount = 0;
					
					for (int a = 0; a<rollVec.size(); a++){
						RollPosition bracePerRoll = (RollPosition)rollVec.get(a);
						if (bracePerRoll.getBraceId().compareTo(numRoll.getBraceId()) == 0 ){
							String rollHdr = AddSpace.addSpace(String.valueOf(bracePerRoll.getRollNum()),3,'0') + " ";
							rollNumTable.addCell(new Phrase(rollHdr,TIMESBOLD_12));
							numRollCount++;
						}
					}
					for (int a=0;a<20-numRollCount;a++){
						rollNumTable.addCell(new Phrase(" ",TIMESBOLD_12));
					}
				
					PdfPCell rollNumCell = new PdfPCell(rollNumTable);
					rollNumCell.setBorderWidth(0);
					outertable.addCell(rollNumCell);
				
					outertable.addCell(dummyCell);
					
					for (int oneSet = 0; oneSet < PallRoll.size(); oneSet++) {
						PalletRoll palletRoll = (PalletRoll) PallRoll.get(oneSet);
						String braceId = palletRoll.getBraceId();
						int rollNum  = palletRoll.getRollNum();
						String palletNum = palletRoll.getPalletNum();
						
						if (palletNum.compareTo(savePalletNum) == 0) {
							getRollPos(rollNum, braceId);
						}
						else{
							if (firstPass){
								firstPass = false;
							} 
							else {
								PdfPTable matrixTable = new PdfPTable(20);
								matrixTable.setWidths(tableh3w);
								matrixTable.getDefaultCell().setBorder(Rectangle.NO_BORDER );
								matrixTable.getDefaultCell().setBorderWidthBottom(0);
							
								String palletNumCell = AddSpace.addSpace(savePalletNum, 4, '0') + " ";
								matrixTable.addCell(new Phrase(palletNumCell,TIMESBOLD_12));
								
								for (int G=0;G<pos.length;G++){
									
									if (pos[G] == 1){
										matrixTable.getDefaultCell().setBorder(DRAWLRT);
										matrixTable.getDefaultCell().setBorderWidthBottom(1);
										matrixTable.addCell(new Phrase(palletNumCell,TIMESNORAML_12));
									}
									else{
										matrixTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
										matrixTable.getDefaultCell().setBorderWidthBottom(0);
										matrixTable.addCell(new Phrase("",TIMESBOLD_12));   
									}
								}
								PdfPCell matrixCell = new PdfPCell(matrixTable);
								matrixCell.setBorderWidth(0);
								matrixCell.setHorizontalAlignment(Element.ALIGN_CENTER);
								outertable.addCell(matrixCell);pageLine++;
								
								if (pageLine >= 30) {
									LogWriter.writeLog("Roll Matrix - pageLine 0  :  " + pageLine);
									pageLine = 0;
								}
								initializePos();
							}
							savePalletNum = palletNum;
							getRollPos(rollNum, braceId);
						}	
					}
					PdfPTable matrixTable = new PdfPTable(20);
					matrixTable.setWidths(tableh3w);
					matrixTable.getDefaultCell().setBorder(Rectangle.NO_BORDER );
					matrixTable.getDefaultCell().setBorderWidthBottom(0);
				
					String palletNumCell = AddSpace.addSpace(savePalletNum, 4, '0') + " ";
					matrixTable.addCell(new Phrase(palletNumCell,TIMESBOLD_12));
					
					for (int G=0;G<pos.length;G++){
						
						if (pos[G] == 1){
							matrixTable.getDefaultCell().setBorder(DRAWLRT);
							matrixTable.getDefaultCell().setBorderWidthBottom(1);
							matrixTable.addCell(new Phrase(palletNumCell,TIMESNORAML_12));
						}
						else{
							matrixTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
							matrixTable.getDefaultCell().setBorderWidthBottom(0);
							matrixTable.addCell(new Phrase("",TIMESBOLD_12));   
						}
					}
					PdfPCell matrixCell = new PdfPCell(matrixTable);
					matrixCell.setBorderWidth(0);
					matrixCell.setHorizontalAlignment(Element.ALIGN_CENTER);
					outertable.addCell(matrixCell);pageLine++;
					
					LogWriter.writeLog("Roll Matrix - pageLine 1  :  " + pageLine);
					 
					if (pageLine < 30) {
						int totLine = 0;
						if (pageLine < 20)totLine = 20;
						if (pageLine < 15)totLine = 45;
						if (pageLine < 10)totLine = 50;
						if (pageLine < 2)totLine = 51;
						for (; pageLine < totLine + 36; pageLine++) {
						outertable.addCell(dummyCell);
						}
					}
					LogWriter.writeLog(" Roll Matrix - pageLine 2  :  " + pageLine);
					pageLine = 0;
					
					initializePos();
					
					firstPass = true;
					PallRoll.clear();
					rollMatDoc.add(outertable);
				}
			}
		}	
			
		}catch (DocumentException de) {
			System.err.println(de.getMessage());
		} catch (IOException ioe) {
			System.err.println(ioe.getMessage());
		}
		rollMatDoc.close();
	}
	

	private static void loadOneRollBrace(String jobId,String braceId){
		
		PreparedStatement selectcopyCnt = null;
		ResultSet rs = null;
		
		String SQL = "Select A.MAG_KY, A.PLANT_ID, A.MAG_CD, A.ISS_NUM, A.ISS_WK_NUM, B.BRACE_ID, A.PAL_SACK_NUM, A.ROLL_NUM from  "
			+ pkgsum  + " A,  " + rollsumTableName + "  B " 
			+ " WHERE A.MAG_KY = ? and A.INSTNC_CD = ? and A.PLANT_ID = ? and A.MAG_CD = ? and A.ISS_NUM = ? and A.ISS_WK_NUM = ? and A.JOB_ID = ? and B.BRACE_ID = ?"
			+ " AND A.MAG_KY = B.MAG_KY AND A.INSTNC_CD = B.INSTNC_CD AND A.PLANT_ID = B.PLANT_ID  AND A.MAG_CD = B.MAG_CD AND A.ISS_NUM  = B.ISS_NUM "
			+ " AND A.ISS_WK_NUM  = B.ISS_WK_NUM AND A.JOB_ID  = B.JOB_ID AND A.ROLL_NUM = B.ROLL_NUM  AND A.PAL_SACK_IND = 'P' AND A.PAL_SACK_IND = B.PAL_SACK_IND "
			+ " ORDER BY A.MAG_KY, A.PLANT_ID, A.MAG_CD, A.ISS_NUM, A.ISS_WK_NUM, B.BRACE_ID, A.PAL_SACK_NUM, A.ROLL_NUM ";

		
		loadRollNumVec(jobId,braceId);
		
		try {
				
			selectcopyCnt = conn.prepareStatement(SQL);
			selectcopyCnt.setInt(1, magKey);
			selectcopyCnt.setString(2, instCd);
			selectcopyCnt.setString(3, plantId);
			selectcopyCnt.setString(4, magCode);
			selectcopyCnt.setInt(5, toNum.toNumber(issueNum));
			selectcopyCnt.setInt(6, toNum.toNumber(issueWeek));
			selectcopyCnt.setString(7, jobId);
			selectcopyCnt.setString(8, braceId);
			rs = selectcopyCnt.executeQuery();
			
			while (rs.next()) {
				
				String rollNum = rs.getString("ROLL_NUM");
				String palletNum = rs.getString("PAL_SACK_NUM");
				
				PalletRoll palletRoll = new PalletRoll(braceId, Integer.valueOf(rollNum).intValue(),palletNum);
				PallRoll.add(palletRoll);
		
			}			
		} 
		catch (SQLException se) {
			LogWriter.writeLog(se);
		} finally {
		    if (rs != null) {
		        try {
		        	rs.close();
		        } catch (SQLException e) { /* ignored */}
		    }
		    if (selectcopyCnt != null) {
		        try {
		        	selectcopyCnt.close();
		        } catch (SQLException e) { /* ignored */}
		    }
		}
		
		return;
	}

	private static void rollByBrace(String jobId){
		
		PreparedStatement selectcopyCnt = null;
		ResultSet rsSet = null;		


		String SQL = "Select A.MAG_KY, A.PLANT_ID, A.MAG_CD, A.ISS_NUM, A.ISS_WK_NUM, B.BRACE_ID, COUNT(DISTINCT A.ROLL_NUM) AS NUM_OF_ROLLS  from  "
					+ pkgsum  + " A,  " + rollsumTableName + "  B " 
					+ " WHERE A.MAG_KY = ? AND A.INSTNC_CD = ? and A.PLANT_ID = ? and A.MAG_CD = ? and A.ISS_NUM = ? and A.ISS_WK_NUM = ? and A.JOB_ID = ? "
					+ " AND A.MAG_KY = B.MAG_KY AND A.INSTNC_CD = B.INSTNC_CD AND A.PLANT_ID = B.PLANT_ID  AND A.MAG_CD = B.MAG_CD AND A.ISS_NUM  = B.ISS_NUM "
					+ " AND A.ISS_WK_NUM  = B.ISS_WK_NUM AND A.JOB_ID  = B.JOB_ID AND A.ROLL_NUM = B.ROLL_NUM  AND A.PAL_SACK_IND = 'P' AND A.PAL_SACK_IND = B.PAL_SACK_IND "
					+ " GROUP BY A.MAG_KY, A.PLANT_ID, A.MAG_CD, A.ISS_NUM, A.ISS_WK_NUM, B.BRACE_ID ";
		
		try {	
			selectcopyCnt = conn.prepareStatement(SQL);
			selectcopyCnt.setInt(1, magKey);
			selectcopyCnt.setString(2, instCd);
			selectcopyCnt.setString(3, plantId);
			selectcopyCnt.setString(4, magCode);
			selectcopyCnt.setInt(5, toNum.toNumber(issueNum));
			selectcopyCnt.setInt(6, toNum.toNumber(issueWeek));
			selectcopyCnt.setString(7, jobId);
			rsSet = selectcopyCnt.executeQuery();
			
			while (rsSet.next()){
			
				String braceId  = rsSet.getString("BRACE_ID");
				int numOfRoll  = Integer.valueOf(rsSet.getString("NUM_OF_ROLLS")).intValue();
			
				NumofRolls numRoll = new NumofRolls(braceId,numOfRoll);
				rollsPerBrace.add(numRoll);
				
			}
		} 
		catch (SQLException se) {
			LogWriter.writeLog(se);
		}
		finally {
		    if (rsSet != null) {
		        try {
		        	rsSet.close();
		        } catch (SQLException e) { /* ignored */}
		    }
		    if (selectcopyCnt != null) {
		        try {
		        	selectcopyCnt.close();
		        } catch (SQLException e) { /* ignored */}
		    }
		}
		return ;
	}
	
	public synchronized static void createPlantPalletRollMatrixReport(Magazine mag){
		
		
		try{
			Thread.sleep(3000);
		} catch( InterruptedException ie) {}
		
		PreparedStatement selectJobID = null;
		ResultSet rsJobId = null;
		
		initialize(mag);
		 
		open();
		
		String SQL = "Select distinct JOB_ID from  " + pkgsum
					+ " WHERE MAG_KY = ? and INSTNC_CD = ? and PLANT_ID = ? and MAG_CD = ? and ISS_NUM = ? and ISS_WK_NUM = ? ";
	
		magKey = magazineKey(magCode);
		
		issueDate = getIssueDate();
		
		plantName = getPlantName(plantId);
		
		instCd = InstanceCd.getInstCd(magKey, issueDate);
		
		try {
			
			selectJobID = conn.prepareStatement(SQL);
			selectJobID.setInt(1, magKey);
			selectJobID.setString(2, instCd);
			selectJobID.setString(3, plantId);
			selectJobID.setString(4, magCode);
			selectJobID.setInt(5, toNum.toNumber(issueNum));
			selectJobID.setInt(6, toNum.toNumber(issueWeek));
			rsJobId = selectJobID.executeQuery();
			
			while (rsJobId.next()){
			
			String jobId  = rsJobId.getString("JOB_ID");
				
			if (jobId.endsWith("U")){
				createPDF(jobId,"USPS");
				LogWriter.writeLog(" USPS Roll Matrix Report Generated   ");
			} else if (jobId.endsWith("F")){
				createPDF(jobId,"FOREIGN");
				LogWriter.writeLog(" Foreign USPS Roll Matrix Report Generated   ");
			}
			}
		} 
		catch (SQLException se) {
			LogWriter.writeLog(se);
		} finally {
		    if (rsJobId != null) {
		        try {
		        	rsJobId.close();
		        } catch (SQLException e) { /* ignored */}
		    }
		    if (selectJobID != null) {
		        try {
		        	selectJobID.close();
		        } catch (SQLException e) { /* ignored */}
		    }
		}
		
		return;
	}		
}