package com.pdf.report;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import sybil.common.model.Magazine;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;

import com.report.text.Document;
import com.report.text.DocumentException;
import com.report.text.Element;
import com.report.text.ExceptionConverter;
import com.report.text.Font;
import com.report.text.FontFactory;
import com.report.text.PageSize;
import com.report.text.Phrase;
import com.report.text.Rectangle;
import com.report.text.pdf.BaseFont;
import com.report.text.pdf.PdfContentByte;
import com.report.text.pdf.PdfPCell;
import com.report.text.pdf.PdfPTable;
import com.report.text.pdf.PdfPageEventHelper;
import com.report.text.pdf.PdfTemplate;
import com.report.text.pdf.PdfWriter;

public class BreakOut extends PdfPageEventHelper {
	
	
	public static String magInfo = "TBA_MAG_INFO";
	public static String magazineSyb = "TBA_SYB_MAGAZINE";
	public static String rollsumTableName = "TBA_ROLL_SUM";
	public static String sybMag = "TBA_SYB_MAGAZINE";
	public static String canadianBagSum = "TBA_CNDN_BAG_SUM";
	public static String magazineInf = "TBA_MAGAZINEINF";
	public static String postalbookTableName = "TBA_POST_BOOK";
	public static String custBvTableName = "TBA_CUST_BV";
	public static String rllmpu = "TBA_RLL_MPU";
	
	private static ResultSet resultset = null;
	private static String magName = null;
		
	
	private static Connection conn = null;
	
	protected PdfTemplate total;
 	protected BaseFont helv;
 
 	public void onOpenDocument(PdfWriter writer, Document document) {
		total = writer.getDirectContent().createTemplate(100, 100);
		total.setBoundingBox(new Rectangle(-20, -20, 100, 100));
		try {
			helv = BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI,BaseFont.NOT_EMBEDDED);
		} catch (Exception e) {
			throw new ExceptionConverter(e);
		}
	}
 
	public void onEndPage(PdfWriter writer, Document document) {
		PdfContentByte cb = writer.getDirectContent();
		cb.saveState();
		String text = "Page " + writer.getPageNumber() + " of  ";
		float textBase = document.bottom() - 15;
		float textSize = helv.getWidthPoint(text, 9);
		float textCenter = document.right()/2;
		cb.beginText();
		cb.setFontAndSize(helv, 10);

		cb.setTextMatrix(textCenter, textBase);
		cb.showText(text);
		cb.endText();
		cb.addTemplate(total, textCenter + textSize, textBase);
		cb.restoreState();
	}
 
	
	public void onCloseDocument(PdfWriter writer, Document document) {
		total.beginText();
		total.setFontAndSize(helv, 10);
		total.setTextMatrix(0, 0);
		total.showText(String.valueOf(writer.getPageNumber() - 1));
		total.endText();
	}
	
	private static void open() {

		PreparedStatement setSqlId = null;
		Statement commitSqlId = null;
		String x = null;
		String db2owner = null;
		int i = 0;
		
		String userDb = sybil.common.util.PropertyBroker.getProperty("database.login","sybil");
		String pswdDb = sybil.common.util.PropertyBroker.getProperty("database.password","sybil");
		
		
		if( conn == null) {
			try {
				Class.forName(sybil.common.util.PropertyBroker.getProperty("database.driver", "Not Found"));
				conn = DriverManager.getConnection(sybil.common.util.PropertyBroker.getProperty("database.server", "Not Found"), userDb, pswdDb);

				//
				x = PropertyBroker.getProperty("database.driver", "Not Found").toLowerCase();
				i = x.indexOf("db2");
				if (!(i < 0)) {
					try {
						db2owner = PropertyBroker.getProperty("DB2OWNER","dtppsyup");
						setSqlId = conn.prepareStatement("set current sqlid = ?");
						setSqlId.setString(1, db2owner);
						setSqlId.execute();
						commitSqlId = conn.createStatement();
						commitSqlId.execute("commit");
					}
					catch (SQLException se) {
						if(se.getSQLState().equals("S1010")) {
						}
						else {
							LogWriter.writeLog(se);
							LogWriter.writeLog("Error: Set Current SqlId failed.");
							if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
								LogWriter.writeLog("Process terminating due to database/sql exception");
								System.exit(1);
							}
						}
					}
					catch (Exception e) {
						LogWriter.writeLog(e);
						LogWriter.writeLog("Error: Set Current SqlId failed.");
						if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
							LogWriter.writeLog("Process terminating due to database/sql exception");
							System.exit(1);
						}
					}
				}
			
			} 
			catch (Exception e) {
				sybil.common.util.LogWriter.writeLog(e);
				LogWriter.writeLog("Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
		
	return;
	}
	
	public static void close() {
		
		if( conn != null) {		
			try { conn.close(); }catch(Exception sql ){};
			conn = null;
		}
		return;
	}
	
	private static int magazineKey(String magazineCode){
		
		int magKey = 0;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT MAG_KEY, NAME  FROM " + sybMag + " WHERE MAG_CD = ? ";
		LogWriter.writeLog("select from " + sybMag + "   "  + SQL);
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, magazineCode);
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			magKey  = (int)rs.getInt("MAG_KEY");
			magName = rs.getString("NAME");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Code Select error " + magazineCode);
		}
		return magKey;
	}

	private static String getIssueDate(Magazine mag){
		
		String issueDate = null;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT COVER_DATE FROM " + magazineInf + " WHERE PLANT = ? and MAG = ? and ISSUE = ? ";
		LogWriter.writeLog("select from " + magazineInf + "   "  + SQL);
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, mag.getPlant().toUpperCase());
		selectMag.setString(2, mag.getMagCode().toLowerCase());
		selectMag.setString(3, mag.getIssue());
		
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			issueDate  = rs.getString("COVER_DATE");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Issue Date error " + mag.getMagCode());
		}
		return issueDate;
	}

	
	public static synchronized void CreateBreakOutPDF(Magazine mag){
		
		String magCode = mag.getMagCode().trim();
		
		if (magCode.compareTo("SU") == 0 ){
			CreateBreakOutSU(mag);
			LogWriter.writeLog(" Sunset BreakOut Report Generated " );
		}
		else if (magCode.compareTo("LV") == 0 ){
			CreateBreakOutLV(mag);
			LogWriter.writeLog(" Martha Living BreakOut Report Generated " );
		}
		else {  
			CreateBreakOut(mag);
			LogWriter.writeLog(" BreakOut Report Generated " );
		}
		return;
	}
	
	/*
	 * 
	 * 
	 * 
	 */
	public static synchronized void CreateBreakOutSU(Magazine mag){
		
		PreparedStatement selectcopyCnt = null;
		Document brakOutSUDoc = new Document(PageSize.LETTER,-50,-50,36,36);
		
		boolean firstRow = true;
		boolean firstFileType = true;
		boolean firstRollEntry = true;
		
		String saveFiletype = "  ";
		String savebraceId = " ";
		String saveDopId = " ";
		String SaveRollId = " ";
		
		int ctr = 1;
		int rollIdCount = 0;
		int rollCountperDop = 0;
		int rollCountFT = 0;
		int totRollCount = 0; 
		int totFileTypeCount = 0;
		int dopCountperBrace = 0;
		int dopTotCount = 0;
		int dopCountFT = 0;
		int rptdopCount = 0;
		int braceCountFT = 0;
		int rptrollCount = 0;
		int rptTotBraceCount = 0;
		int rpttotFileTypeCount = 0;
		

		String magCode = mag.getMagCode().trim();
		String issueNum = mag.getIssue().trim();
		String issueWeek = mag.getWeek().trim();
		String plantId = mag.getPlant().toUpperCase().trim();
		
		String RptPath = sybil.common.util.PropertyBroker.getProperty("NewPDFReportsPath","Not found");
		String fileName = magCode.toLowerCase() + ".i" + issueNum + "." + plantId + ".Break_Out." + issueWeek;
		
		open();
		            
		String SQL  = "SELECT " +
				"  DELIVERY_TYPE, PROCESS_TYPE, DATA_TYPE, WEEK_NUM, BRACEID " +
				" ,DOP_ID, ROLLID, COPY_CNT  FROM  " +  magInfo +  
		        "  where MAG  = ? and PLANT = ? and ISSUE = ? AND WEEK_NUM = ? " +               
		        "  ORDER BY  DELIVERY_TYPE, PROCESS_TYPE, DATA_TYPE, BRACEID, DOP_ID, ROLLID  " ;
		        
		String issueDate = getIssueDate(mag);
		
		int magKey = magazineKey(magCode);
		
		LogWriter.writeLog("Sunset Magakine Key : " + magKey );
		try {
			
			PdfWriter writer = PdfWriter.getInstance(brakOutSUDoc,				
					new FileOutputStream(RptPath + fileName + ".pdf"));
			

			writer.setViewerPreferences(PdfWriter.PageModeFullScreen);
			writer.setPageEvent(new BreakOut());
			
			brakOutSUDoc.open();
			
			Date toDay = new Date(); 
			SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, MMM d, yyyy, HH:mm a "); 

      		PdfPTable outertable = new PdfPTable(1);
			outertable.setHeaderRows(9);
			
			PdfPCell header0 = new PdfPCell(new Phrase(String.valueOf(dateFormat.format(toDay)),
					FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,Color.black)));
			header0.setBorderWidth(0);
			outertable.addCell(header0);
			
			String issueHdr = "Issue :" + issueDate + "(" + issueNum + " - " + issueWeek +")";
			PdfPCell issueCell = new PdfPCell(new Phrase(issueHdr,
					FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,Color.black)));
			issueCell.setBorderWidth(0);
			outertable.addCell(issueCell);
			
			PdfPCell cell1 = new PdfPCell(new Phrase(
					"Sybil Break out Report by Roll", FontFactory.getFont(FontFactory.COURIER, 15, Font.BOLD, Color.BLACK)));
			cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell1.setBorderWidth(0);
			outertable.addCell(cell1);
									
			PdfPCell dummyCell = new PdfPCell(new Phrase("", FontFactory.getFont(
								FontFactory.COURIER, 10, Font.BOLD, Color.black)));
			dummyCell.setBorderWidth(0);
			outertable.addCell(dummyCell);

			selectcopyCnt = conn.prepareStatement(SQL);
			
			selectcopyCnt.setString(1, magCode);
			selectcopyCnt.setString(2, plantId);
			selectcopyCnt.setString(3, issueNum);
			selectcopyCnt.setString(4, issueWeek);
					
			resultset = selectcopyCnt.executeQuery();
			
			while (resultset.next()){
			
				String deliveryType = resultset.getString("DELIVERY_TYPE").trim();
 				String processType  = resultset.getString("PROCESS_TYPE").trim();
				String dataType = resultset.getString("DATA_TYPE").trim();
				String weekNum = resultset.getString("WEEK_NUM");
				String braceId = resultset.getString("BRACEID");
				String dopId = resultset.getString("DOP_ID");
				String rollId = resultset.getString("ROLLID");
				String copyCnt = resultset.getString("COPY_CNT");
				
				String Filetype = deliveryType.concat(processType).concat(dataType).concat(weekNum);
				
			if (firstRow) {
				
				String header1 = "Magazine : " + magName.trim() + "                 Plant : " + plantId + "                 Issue :" + issueNum + " - " + issueWeek  ;
				PdfPCell magCell = new PdfPCell(new Phrase(header1,
						FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD,Color.black)));
				magCell.setBorderWidth(0);
				outertable.addCell(magCell);
									
				for ( int G = 0; G <2; G++){
					PdfPCell dummyCell1 = new PdfPCell(new Phrase("", FontFactory.getFont(
									FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					dummyCell1.setBorderWidth(0);
					outertable.addCell(dummyCell1);}	
				
				String header2 = "   Sybil File Name          Brace       DOP          Roll                      Count " ;
				PdfPCell Cell2 = new PdfPCell(new Phrase(header2,
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,Color.black)));
				Cell2.setBorderWidth(0);
				outertable.addCell(Cell2);
				
				
				PdfPCell hLine = new PdfPCell(new Phrase(" ",
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,Color.black)));
				hLine.setBorderWidth(0);
				outertable.addCell(hLine);
				firstRow = false;
			}				
			
			if (Filetype.compareTo(saveFiletype) == 0){
				Filetype = " ";
				if (braceId.compareTo(savebraceId) == 0) {
					braceId = " ";
					if (dopId.compareTo(saveDopId) == 0) {
						dopId = " ";
						if (rollId.compareTo(SaveRollId) == 0){
							
						String detailInfo = AddSpace.addSpace(Filetype,16,' ')  + "  " + AddSpace.addSpace(braceId,4,' ') + "      " + AddSpace.addSpace(dopId,3,' ') + "  " + AddSpace.addSpace(rollId,3,'0') + "         " +  AddSpace.addSpace(PlaceComma.placeComma((Integer.valueOf(copyCnt)).intValue()),9)  ;
						PdfPCell detailType = new PdfPCell(
								new Phrase(detailInfo, FontFactory.getFont(FontFactory.COURIER, 10, Font.NORMAL, Color.black)));
						detailType.setBorderWidth(0);
						outertable.addCell(detailType);ctr++;
						rollIdCount += Integer.valueOf(copyCnt).intValue(); 
						}
						else{
							if (firstRollEntry){
							     firstRollEntry = false;	
									
									totRollCount += rollIdCount;
									dopTotCount +=rollIdCount;
									rollIdCount = 0;
				      		 }
							else{
								
								totRollCount += rollIdCount;
								dopTotCount += rollIdCount;
								rollIdCount = 0;
							}
							SaveRollId = rollId;
							rollCountperDop += 1;
							
							String detailInfo = AddSpace.addSpace(Filetype,16,' ')  + "  " + AddSpace.addSpace(braceId,4,' ') + "      " + AddSpace.addSpace(dopId,3,' ') + "  " + AddSpace.addSpace(rollId,3,'0') + "         " +  AddSpace.addSpace(PlaceComma.placeComma((Integer.valueOf(copyCnt)).intValue()),9)  ;
							
							PdfPCell detailType = new PdfPCell(
									new Phrase(detailInfo, FontFactory.getFont(FontFactory.COURIER, 10, Font.NORMAL, Color.black)));
							detailType.setBorderWidth(0);
							outertable.addCell(detailType);ctr++;
							rollIdCount += Integer.valueOf(copyCnt).intValue();
						}
					}	
					else {
							
							String rollForDop = AddSpace.addSpace(" ",46,' ') + "  " + AddSpace.addSpace(PlaceComma.placeComma(rollCountperDop),9) + AddSpace.addSpace("Rolls for DOP  ",17,' ')+ "  " + AddSpace.addSpace(saveDopId,4,' ')  ;
							PdfPCell rollForDopCell = new PdfPCell(
									new Phrase(rollForDop, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
							rollForDopCell.setBorderWidth(0);
							outertable.addCell(rollForDopCell);ctr++;
							
							totRollCount += rollIdCount;
							dopTotCount += rollIdCount;
							rollCountFT += rollCountperDop;
							
							String TotDopCount = AddSpace.addSpace("DOP's ",31,' ')  + "   " + AddSpace.addSpace(saveDopId,4,' ') + "  " + AddSpace.addSpace("Total ",5,' ') +  AddSpace.addSpace(PlaceComma.placeComma(dopTotCount),9)  ;
							PdfPCell totDopCountCell = new PdfPCell(
									new Phrase(TotDopCount, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
							totDopCountCell.setBorderWidth(0);
							outertable.addCell(totDopCountCell);ctr++;
															
							rollIdCount = 0;firstRollEntry = true; rollCountperDop = 0;dopTotCount=0;
						
						saveDopId = dopId;
						SaveRollId = rollId;
						dopCountperBrace +=1;rollCountperDop += 1;
						
						rollIdCount += Integer.valueOf(copyCnt).intValue();
						
						String detailInfo = AddSpace.addSpace(Filetype,16,' ')  + "  " + AddSpace.addSpace(braceId,4,' ') + "    " + AddSpace.addSpace(dopId,3,' ') + "  " + AddSpace.addSpace(rollId,3,'0') + "         " +  AddSpace.addSpace(PlaceComma.placeComma((Integer.valueOf(copyCnt)).intValue()),9)  ;
						
						PdfPCell detailType = new PdfPCell(
								new Phrase(detailInfo, FontFactory.getFont(FontFactory.COURIER, 10, Font.NORMAL, Color.black)));
						detailType.setBorderWidth(0);
						outertable.addCell(detailType);ctr++;
					}
				}
				else {
					
					
					String rollForDop = AddSpace.addSpace(" ",46,' ') + "  " + AddSpace.addSpace(PlaceComma.placeComma(rollCountperDop),9) + AddSpace.addSpace("Rolls for DOP  ",17,' ')+ "  " + AddSpace.addSpace(saveDopId,4,' ')  ;
					PdfPCell rollForDopCell = new PdfPCell(
							new Phrase(rollForDop, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					rollForDopCell.setBorderWidth(0);
					outertable.addCell(rollForDopCell);ctr++;
					
					String rollForBrace = AddSpace.addSpace(" ",46,' ') + "  " + AddSpace.addSpace(PlaceComma.placeComma(rollCountperDop),9) + AddSpace.addSpace("Rolls for Brace",17,' ') + AddSpace.addSpace(savebraceId,4,' ')  ;
					PdfPCell rollForBraceCell = new PdfPCell(
							new Phrase(rollForBrace, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					rollForBraceCell.setBorderWidth(0);
					outertable.addCell(rollForBraceCell);ctr++;
					
					String dopForBrace = AddSpace.addSpace(" ",46,' ') + "  " + AddSpace.addSpace(PlaceComma.placeComma(dopCountperBrace),9) + AddSpace.addSpace("DOPs for Brace ",17,' ') + AddSpace.addSpace(savebraceId,4,' ')  ;
					PdfPCell dopForBraceCell = new PdfPCell(
							new Phrase(dopForBrace, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					dopForBraceCell.setBorderWidth(0);
					outertable.addCell(dopForBraceCell);ctr++;
					
					dopTotCount += rollIdCount;
					totRollCount += rollIdCount;
					
					String TotDopCount = AddSpace.addSpace("DOP's ",31,' ')  + "   " + AddSpace.addSpace(saveDopId,4,' ') + "  " + AddSpace.addSpace("Total ",5,' ') +  AddSpace.addSpace(PlaceComma.placeComma(dopTotCount),9)  ;
					PdfPCell totDopCountCell = new PdfPCell(
							new Phrase(TotDopCount, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					totDopCountCell.setBorderWidth(0);
					outertable.addCell(totDopCountCell);ctr++;
					
					String TotRollCount = AddSpace.addSpace("Brace ",31,' ')  + "  " + AddSpace.addSpace(savebraceId,4,' ') + "    " + AddSpace.addSpace("Total ",5,' ') +  AddSpace.addSpace(PlaceComma.placeComma(totRollCount),9)  ;
					PdfPCell totRollCountCell = new PdfPCell(
							new Phrase(TotRollCount, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					totRollCountCell.setBorderWidth(0);
					outertable.addCell(totRollCountCell);ctr++;
					
					totFileTypeCount += totRollCount;rollCountFT += rollCountperDop;dopCountFT += dopCountperBrace;
					
					for ( int G = 0; G <2; G++) outertable.addCell(dummyCell);
					
					rollIdCount = 0;firstRollEntry = true;rollCountperDop=0;totRollCount= 0;dopCountperBrace=0;dopTotCount=0;
					
					savebraceId = braceId;
					saveDopId = dopId;
					SaveRollId = rollId;rollCountperDop += 1;dopCountperBrace +=1;braceCountFT +=1;
					
					rollIdCount += Integer.valueOf(copyCnt).intValue();
					
					String detailInfo = AddSpace.addSpace(Filetype,16,' ')  + "  " + AddSpace.addSpace(braceId,4,' ') + "    " + AddSpace.addSpace(dopId,3,' ') + "  " + AddSpace.addSpace(rollId,3,'0') + "         " +  AddSpace.addSpace(PlaceComma.placeComma((Integer.valueOf(copyCnt)).intValue()),9)  ;
					PdfPCell detailType = new PdfPCell(
							new Phrase(detailInfo, FontFactory.getFont(FontFactory.COURIER, 10, Font.NORMAL, Color.black)));
					detailType.setBorderWidth(0);
					outertable.addCell(detailType);ctr++;									
				}	
			} 
			else {	
				if (firstFileType){
					firstFileType = false;
				}
				else{
					
					totRollCount += rollIdCount;rollCountFT += rollCountperDop;dopCountFT += dopCountperBrace;
					braceCountFT +=1;
					
					
					String TotRollCount = AddSpace.addSpace("Brace ",31,' ')  + "  " + AddSpace.addSpace(savebraceId,4,' ') + "    " + AddSpace.addSpace("Total ",5,' ') +  AddSpace.addSpace(PlaceComma.placeComma(totRollCount),9)  ;
					PdfPCell totRollCountCell = new PdfPCell(
							new Phrase(TotRollCount, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					totRollCountCell.setBorderWidth(0);
					outertable.addCell(totRollCountCell);ctr++;
					for ( int G = 0; G <2; G++) outertable.addCell(dummyCell);
					
					totFileTypeCount += totRollCount;
					
					String TotBraceCount = AddSpace.addSpace("Total Copies, ",14,' ')  + "   " + AddSpace.addSpace(saveFiletype,16,' ') + "    " +  AddSpace.addSpace(PlaceComma.placeComma(totFileTypeCount),9)  ;
					PdfPCell totBraceCountCell = new PdfPCell(
							new Phrase(TotBraceCount, FontFactory.getFont(FontFactory.COURIER, 12, Font.BOLD, Color.black)));
					totBraceCountCell.setBorderWidth(0);
					outertable.addCell(totBraceCountCell);ctr++;
					
					String rollForFT = AddSpace.addSpace(" ",46,' ') + "  " + AddSpace.addSpace(PlaceComma.placeComma(rollCountFT),9) + AddSpace.addSpace("Rolls for ",12,' ')+ AddSpace.addSpace(saveFiletype,4,' ')  ;
					PdfPCell rollForftCell = new PdfPCell(
							new Phrase(rollForFT, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					rollForftCell.setBorderWidth(0);
					outertable.addCell(rollForftCell);ctr++;
					
					String dopForFT = AddSpace.addSpace(" ",46,' ') + "  " + AddSpace.addSpace(PlaceComma.placeComma(dopCountFT),9) + AddSpace.addSpace("DOPs for  ",12,' ') + AddSpace.addSpace(saveFiletype,4,' ')  ;
					PdfPCell dopForftCell = new PdfPCell(
							new Phrase(dopForFT, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					dopForftCell.setBorderWidth(0);
					outertable.addCell(dopForftCell);ctr++;
					
					String braceForFT = AddSpace.addSpace(" ",46,' ') + "  " + AddSpace.addSpace(PlaceComma.placeComma(braceCountFT),9) + AddSpace.addSpace("Braces for ",12,' ') + AddSpace.addSpace(saveFiletype,4,' ')  ;
					PdfPCell braceForftCell = new PdfPCell(
							new Phrase(braceForFT, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					braceForftCell.setBorderWidth(0);
					outertable.addCell(braceForftCell);ctr++;
					
					
					rpttotFileTypeCount += totFileTypeCount;
					rptTotBraceCount +=braceCountFT;
					rptdopCount += dopCountFT;
					rptrollCount += rollCountFT;
					
					
					for ( int G = 0; G <2; G++) outertable.addCell(dummyCell);
					
					rollIdCount = 0;firstRollEntry = true;rollCountperDop=0;totRollCount= 0;totFileTypeCount=0;
					rollCountFT =0;dopCountFT=0;dopCountperBrace=0;braceCountFT=0;

				}
				
				saveFiletype = Filetype;
				savebraceId = braceId;
				saveDopId = dopId;
				SaveRollId = rollId;rollCountperDop += 1;
				
				dopCountperBrace +=1;

				rollIdCount += Integer.valueOf(copyCnt).intValue();
				
				String detailInfo = AddSpace.addSpace(Filetype,16,' ')  + "  " + AddSpace.addSpace(braceId,4,' ') + "    " + AddSpace.addSpace(dopId,3,' ') + "  " + AddSpace.addSpace(rollId,3,'0') + "         " +  AddSpace.addSpace(PlaceComma.placeComma((Integer.valueOf(copyCnt)).intValue()),9)  ;
				PdfPCell detailType = new PdfPCell(
						new Phrase(detailInfo, FontFactory.getFont(FontFactory.COURIER, 10, Font.NORMAL, Color.black)));
				detailType.setBorderWidth(0);
				outertable.addCell(detailType);ctr++;
												     
			}
			if (ctr > 45) ctr = 1;
		}  
			
			totRollCount += rollIdCount;rollCountFT += rollCountperDop;
			dopCountFT += dopCountperBrace;
			
							
			String TotRollCount = AddSpace.addSpace("Brace ",31,' ')  + "  " + AddSpace.addSpace(savebraceId,4,' ') + "    " + AddSpace.addSpace("Total ",5,' ') +  AddSpace.addSpace(PlaceComma.placeComma(totRollCount),9)  ;
			PdfPCell totRollCountCell = new PdfPCell(
					new Phrase(TotRollCount, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
			totRollCountCell.setBorderWidth(0);
			outertable.addCell(totRollCountCell);
			for ( int G = 0; G <2; G++) outertable.addCell(dummyCell);
			
			totFileTypeCount += totRollCount;
			
			String TotBraceCount = AddSpace.addSpace("Total Copies, ",14,' ')  + "   " + AddSpace.addSpace(saveFiletype,16,' ') + "    " +  AddSpace.addSpace(PlaceComma.placeComma(totFileTypeCount),9)  ;
			PdfPCell totBraceCountCell = new PdfPCell(
					new Phrase(TotBraceCount, FontFactory.getFont(FontFactory.COURIER, 12, Font.BOLD, Color.black)));
			totBraceCountCell.setBorderWidth(0);
			outertable.addCell(totBraceCountCell);
			
			String rollForFT = AddSpace.addSpace(" ",46,' ') + "  " + AddSpace.addSpace(PlaceComma.placeComma(rollCountFT),9) + AddSpace.addSpace("Rolls for ",12,' ')+ AddSpace.addSpace(saveFiletype,4,' ')  ;
			PdfPCell rollForftCell = new PdfPCell(
					new Phrase(rollForFT, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
			rollForftCell.setBorderWidth(0);
			outertable.addCell(rollForftCell);
			
			String dopForFT = AddSpace.addSpace(" ",46,' ') + "  " + AddSpace.addSpace(PlaceComma.placeComma(dopCountFT),9) + AddSpace.addSpace("DOPs for  ",12,' ') + AddSpace.addSpace(saveFiletype,4,' ')  ;
			PdfPCell dopForftCell = new PdfPCell(
					new Phrase(dopForFT, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
			dopForftCell.setBorderWidth(0);
			outertable.addCell(dopForftCell);
			
			String braceForFT = AddSpace.addSpace(" ",46,' ') + "  " + AddSpace.addSpace(PlaceComma.placeComma(braceCountFT),9) + AddSpace.addSpace("Braces for ",12,' ') + AddSpace.addSpace(saveFiletype,4,' ')  ;
			PdfPCell braceForftCell = new PdfPCell(
					new Phrase(braceForFT, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
			braceForftCell.setBorderWidth(0);
			outertable.addCell(braceForftCell);
			
			rpttotFileTypeCount += totFileTypeCount;rptrollCount+=rollCountFT;rptdopCount+=dopCountFT;
			
			for ( int G = 0; G <2; G++) outertable.addCell(dummyCell);
			
			String rptTotCount = AddSpace.addSpace(" ",24,' ') + "  " + AddSpace.addSpace("Grand Total Copies: ",22,' ')  + "  " + AddSpace.addSpace(PlaceComma.placeComma(rpttotFileTypeCount),9)   ;
			PdfPCell rpttotCountCell = new PdfPCell(
					new Phrase(rptTotCount, FontFactory.getFont(FontFactory.COURIER, 12, Font.BOLD, Color.black)));
			rpttotCountCell.setBorderWidth(0);
			outertable.addCell(rpttotCountCell);
			
			String rptrollCountF = AddSpace.addSpace(" ",24,' ') + "  " + AddSpace.addSpace("Total Rolls ",22,' ') + AddSpace.addSpace(PlaceComma.placeComma(rptrollCount),9) ;
			PdfPCell rptrollCountCell = new PdfPCell(
					new Phrase(rptrollCountF, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
			rptrollCountCell.setBorderWidth(0);
			outertable.addCell(rptrollCountCell);
			
			String rptdopCountF = AddSpace.addSpace(" ",24,' ') + "  " + AddSpace.addSpace("Total DOPs ",22,' ') + AddSpace.addSpace(PlaceComma.placeComma(rptdopCount),9) ;
			PdfPCell rptdopCountCell = new PdfPCell(
					new Phrase(rptdopCountF, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
			rptdopCountCell.setBorderWidth(0);
			outertable.addCell(rptdopCountCell);
			
			String rptbraceCountF = AddSpace.addSpace(" ",24,' ') + "  " + AddSpace.addSpace("Total Braces  ",22,' ') + AddSpace.addSpace(PlaceComma.placeComma(rptTotBraceCount),9)  ;
			PdfPCell rptbracecountCell = new PdfPCell(
					new Phrase(rptbraceCountF, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
			rptbracecountCell.setBorderWidth(0);
			outertable.addCell(rptbracecountCell);

			
			brakOutSUDoc.add(outertable);

		} 
		catch (SQLException se) {
			System.err.println(se.getMessage());
		}
	
		catch (DocumentException de) {
			System.err.println(de.getMessage());
		} catch (IOException ioe) {
			System.err.println(ioe.getMessage());
		}			
		brakOutSUDoc.close();
		close();
		
		return;

		
		
	}
	
	/*
	 * 
	 * 
	 * 
	 */
	
	public static synchronized void CreateBreakOutLV(Magazine mag){
		
		boolean firstRow = true;
		boolean firstFileType = true;
		
		int ctr = 1;
		int pageLine = 45;
		int mpuTotCount = 0;
		int rptTotCount = 0;
		
		String saveFiletype = "  ";
		String saveMpuId = " ";
					
		PreparedStatement selectcopyCnt = null;
		Document brakOutLV = new Document(PageSize.LETTER,-50,-50,36,36);
	
		
		String magCode = mag.getMagCode().trim();
		String issueNum = mag.getIssue().trim();
		String issueWeek = mag.getWeek().trim();
		String plantId = mag.getPlant().toUpperCase().trim();
		
		String RptPath = sybil.common.util.PropertyBroker.getProperty("NewPDFReportsPath","Not found");
		String fileName = magCode.toLowerCase() + ".i" + issueNum + "." + plantId + ".Break_Out." + issueWeek;
		
		open();
		            
		String SQL  = "SELECT MIO.DELIVERY_TYPE, MIO.PROCESS_TYPE, MIO.DATA_TYPE, MIO.WEEK_NUM,  " +
		 			" MIO.BRACEID, MIO.DOP_ID, MIO.ROLLID, RLM.CNTNR_TYP, RLM.MPU_ID, RLM.COPY_CNT " +             
				    " FROM  " +  magInfo + " MIO ," + rllmpu + " RLM " +
		            " WHERE  MIO.MAG = ? AND MIO.PLANT = ? AND MIO.ISSUE = ? AND MIO.WEEK_NUM  = ? " +               
		            " AND RLM.MAG_KY = ? AND RLM.INSTNC_CD = ? AND RLM.ISS_NUM = ? AND RLM.ISS_WK_NUM = ?" +           
		            " AND RLM.PLANT_ID = MIO.PLANT AND RLM.MAG_CD = MIO.MAG AND RLM.ROLL_ID = MIO.ROLLID  " +
		            " ORDER BY  RLM.MPU_ID";
//		            " ORDER BY  MIO.DELIVERY_TYPE, MIO.PROCESS_TYPE, MIO.DATA_TYPE, MIO.WEEK_NUM, " +
//		            " RLM.MPU_ID, MIO.DOP_ID, MIO.BRACEID, MIO.ROLLID, RLM.CNTNR_TYP " ;   
		
		LogWriter.writeLog("LV Break out SQL  : " + SQL);
		
		int magKey = magazineKey(magCode);
		
		String issueDate = getIssueDate(mag);
		
		String instCd = InstanceCd.getInstCd(magKey, issueDate);
		
		try {
			
			PdfWriter writer = PdfWriter.getInstance(brakOutLV,				
					new FileOutputStream(RptPath + fileName + ".pdf"));
			

			writer.setViewerPreferences(PdfWriter.PageModeFullScreen);
			writer.setPageEvent(new BreakOut());
			
			brakOutLV.open();
			
			Date toDay = new Date(); 
			SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, MMM d, yyyy, HH:mm a "); 

      		PdfPTable outertable = new PdfPTable(1);
			outertable.setHeaderRows(9);
			
			PdfPCell header0 = new PdfPCell(new Phrase(String.valueOf(dateFormat.format(toDay)),
					FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,Color.black)));
			header0.setBorderWidth(0);
			outertable.addCell(header0);
			
			String issueHdr = "Issue :" + issueDate + "(" + issueNum + " - " + issueWeek +")";
			PdfPCell issueCell = new PdfPCell(new Phrase(issueHdr,
					FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,Color.black)));
			issueCell.setBorderWidth(0);
			outertable.addCell(issueCell);
			
			PdfPCell cell1 = new PdfPCell(new Phrase(
					"Sybil Break out Report by Mail Piece Unit", FontFactory.getFont(FontFactory.COURIER, 15, Font.BOLD, Color.BLACK)));
			cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell1.setBorderWidth(0);
			outertable.addCell(cell1);
									
			PdfPCell dummyCell = new PdfPCell(new Phrase("", FontFactory.getFont(
								FontFactory.COURIER, 10, Font.BOLD, Color.black)));
			dummyCell.setBorderWidth(0);
			outertable.addCell(dummyCell);

			selectcopyCnt = conn.prepareStatement(SQL);
			selectcopyCnt.setString(1, magCode);
			selectcopyCnt.setString(2, plantId);
			selectcopyCnt.setString(3, issueNum);
			selectcopyCnt.setString(4, issueWeek);
			selectcopyCnt.setInt(5, magKey);
			selectcopyCnt.setString(6, instCd);
			selectcopyCnt.setInt(7, toNum.toNumber(issueNum));
			selectcopyCnt.setInt(8, toNum.toNumber(issueWeek));
									
			resultset = selectcopyCnt.executeQuery();
			
			while (resultset.next()){
				
				String deliveryType = resultset.getString("DELIVERY_TYPE").trim();
 				String processType  = resultset.getString("PROCESS_TYPE").trim();
				String dataType = resultset.getString("DATA_TYPE").trim();
				String weekNum = resultset.getString("WEEK_NUM");
				String braceId = resultset.getString("BRACEID");
				String dopId = resultset.getString("DOP_ID");
				String rollId = resultset.getString("ROLLID");
				String cntnrTyp = resultset.getString("CNTNR_TYP");
				String mpuId = resultset.getString("MPU_ID");
				String copyCnt = resultset.getString("COPY_CNT");
				
				String Filetype = deliveryType.concat(processType).concat(dataType).concat(weekNum);
				
			if (firstRow) {
				
				String header1 = "Magazine : " + magName.trim() + "                 Plant : " + plantId + "                 Issue :" + issueNum + " - " + issueWeek  ;
				PdfPCell magCell = new PdfPCell(new Phrase(header1,
						FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD,Color.black)));
				magCell.setBorderWidth(0);
				outertable.addCell(magCell);
									
				for ( int G = 0; G <2; G++){
					PdfPCell dummyCell1 = new PdfPCell(new Phrase("", FontFactory.getFont(
									FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					dummyCell1.setBorderWidth(0);
					outertable.addCell(dummyCell1);}	
				
				String header2 = "   Striptype                      DOP        BraceId      Roll        Type          Mpuid         CopyCount " ;
				PdfPCell Cell2 = new PdfPCell(new Phrase(header2,
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,Color.black)));
				Cell2.setBorderWidth(0);
				outertable.addCell(Cell2);
				
				
				PdfPCell hLine = new PdfPCell(new Phrase(" ",
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,Color.black)));
				hLine.setBorderWidth(0);
				outertable.addCell(hLine);
				firstRow = false;
			}				
			
			if (Filetype.compareTo(saveFiletype) == 0){
				if (mpuId.compareTo(saveMpuId) == 0){
					if (ctr == pageLine){
						ctr=1;
						pageLine = 45;
					}else{
						Filetype = " ";
					}
					String detailInfo = AddSpace.addSpace(Filetype,18,' ')  + "  " + AddSpace.addSpace(dopId,3,' ') + "   " + AddSpace.addSpace(braceId,4,' ') + "   " + AddSpace.addSpace(rollId,3,'0') + "     " + AddSpace.addSpace(cntnrTyp,1,' ')+ "       " + AddSpace.addSpace(mpuId,4,'0') + "    "+  AddSpace.addSpace(PlaceComma.placeComma((Integer.valueOf(copyCnt)).intValue()),9)  ;
					PdfPCell detailType = new PdfPCell(
								new Phrase(detailInfo, FontFactory.getFont(FontFactory.COURIER, 10, Font.NORMAL, Color.black)));
					detailType.setBorderWidth(0);
					outertable.addCell(detailType);ctr++;
					mpuTotCount += Integer.valueOf(copyCnt).intValue();
						}
				else{
					for ( int G = 0; G <2; G++) {outertable.addCell(dummyCell);ctr++;pageLine++;}
					
					String mputotInfo = AddSpace.addSpace(" ",5,' ') + "  " +AddSpace.addSpace("Totals Per MPUID:",17,' ')+ " " + AddSpace.addSpace(saveMpuId,4,'0') + "  " + AddSpace.addSpace("For Type: ",10,' ')+ " " + AddSpace.addSpace(saveFiletype,18,' ') + AddSpace.addSpace(PlaceComma.placeComma(mpuTotCount),9) ;
					PdfPCell mputotCell = new PdfPCell(
							new Phrase(mputotInfo, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					mputotCell.setBorderWidth(0);
					outertable.addCell(mputotCell);ctr++;
					rptTotCount += mpuTotCount;
					mpuTotCount=0;
					
					for ( int G = 0; G <2; G++) {outertable.addCell(dummyCell);ctr++;}pageLine++;
					
					String detailInfo = AddSpace.addSpace(Filetype,18,' ')  + "  " + AddSpace.addSpace(dopId,3,' ') + "   " + AddSpace.addSpace(braceId,4,' ') + "   " + AddSpace.addSpace(rollId,3,'0') + "     " + AddSpace.addSpace(cntnrTyp,1,' ')+ "       " + AddSpace.addSpace(mpuId,4,'0') + "    "+  AddSpace.addSpace(PlaceComma.placeComma((Integer.valueOf(copyCnt)).intValue()),9)  ;
					PdfPCell detailType = new PdfPCell(
								new Phrase(detailInfo, FontFactory.getFont(FontFactory.COURIER, 10, Font.NORMAL, Color.black)));
					detailType.setBorderWidth(0);
					outertable.addCell(detailType);ctr++;
					mpuTotCount += Integer.valueOf(copyCnt).intValue();
					saveMpuId = mpuId;
				}	
			}else {	
				if (firstFileType){
					firstFileType = false;
				}
				else{
					for ( int G = 0; G <2; G++) {outertable.addCell(dummyCell);ctr++;pageLine++;}
					String mputotInfo = AddSpace.addSpace(" ",5,' ') + "  " +AddSpace.addSpace("Totals Per MPUID:",17,' ')+ " " + AddSpace.addSpace(saveMpuId,4,'0') + "  " + AddSpace.addSpace("For Type: ",10,' ')+ " " + AddSpace.addSpace(saveFiletype,18,' ') + AddSpace.addSpace(PlaceComma.placeComma(mpuTotCount),9) ;
					PdfPCell mputotCell = new PdfPCell(
							new Phrase(mputotInfo, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					mputotCell.setBorderWidth(0);
					outertable.addCell(mputotCell);ctr++;
					rptTotCount += mpuTotCount;
					mpuTotCount=0;
					for ( int G = 0; G <2; G++) {outertable.addCell(dummyCell);ctr++;}pageLine++;
					
				}
				saveMpuId = mpuId;
				saveFiletype = Filetype;
				mpuTotCount += Integer.valueOf(copyCnt).intValue();
				String detailInfo = AddSpace.addSpace(Filetype,18,' ')  + "  " + AddSpace.addSpace(dopId,3,' ') + "   " + AddSpace.addSpace(braceId,4,' ') + "   " + AddSpace.addSpace(rollId,3,'0') + "     " + AddSpace.addSpace(cntnrTyp,1,' ')+ "       " + AddSpace.addSpace(mpuId,4,'0') + "    "+  AddSpace.addSpace(PlaceComma.placeComma((Integer.valueOf(copyCnt)).intValue()),9)  ;
				PdfPCell detailType = new PdfPCell(
								new Phrase(detailInfo, FontFactory.getFont(FontFactory.COURIER, 10, Font.NORMAL, Color.black)));
				detailType.setBorderWidth(0);
				outertable.addCell(detailType);ctr++;
												     
			}
		}
			for ( int G = 0; G <=2; G++) outertable.addCell(dummyCell);
			String mputotInfo = AddSpace.addSpace(" ",5,' ') + "  " +AddSpace.addSpace("Totals Per MPUID:",17,' ')+ " " + AddSpace.addSpace(saveMpuId,4,'0') + "  " + AddSpace.addSpace("For Type: ",10,' ')+ " " + AddSpace.addSpace(saveFiletype,18,' ') + AddSpace.addSpace(PlaceComma.placeComma(mpuTotCount),9) ;
			PdfPCell mputotCell = new PdfPCell(
					new Phrase(mputotInfo, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
			mputotCell.setBorderWidth(0);
			outertable.addCell(mputotCell);
			rptTotCount += mpuTotCount;
			for ( int G = 0; G <=2; G++) outertable.addCell(dummyCell);
			String rpttotInfo = AddSpace.addSpace(" ",50,' ') + "  " +  AddSpace.addSpace("Total : ",10,' ')+ " "  + AddSpace.addSpace(PlaceComma.placeComma(rptTotCount),9) ;
			PdfPCell rpttotCell = new PdfPCell(
					new Phrase(rpttotInfo, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
			rpttotCell.setBorderWidth(0);
			outertable.addCell(rpttotCell);
		
			brakOutLV.add(outertable);

		} 
		catch (SQLException se) {
			System.err.println(se.getMessage());
		}
	
		catch (DocumentException de) {
			System.err.println(de.getMessage());
		} catch (IOException ioe) {
			System.err.println(ioe.getMessage());
		}			
		brakOutLV.close();
		close();
		
	return;	
	}
	
	/*
	 * 
	 * 
	 * 
	 */
	
	public static synchronized void CreateBreakOut(Magazine mag){
		
		PreparedStatement selectcopyCnt = null;
		Document brakOutDoc = new Document(PageSize.LETTER,-50,-50,36,36);
		
		boolean firstRow = true;
		boolean firstFileType = true;
		boolean firstRollEntry = true;
		
		String saveFiletype = "  ";
		String savebraceId = " ";
		String saveDopId = " ";
		String SaveRollId = " ";
		
		int ctr = 1;
		int rollIdCount = 0;
		int rollCountperDop = 0;
		int rollCountperBrace = 0;
		int rollCountFT = 0;
		int totRollCount = 0; 
		int totFileTypeCount = 0;
		int dopCountperBrace = 0;
		int dopTotCount = 0;
		int dopCountFT = 0;
		int rptdopCount = 0;
		int braceCountFT = 0;
		int rptrollCount = 0;
		int rptTotBraceCount = 0;
		int rpttotFileTypeCount = 0;
		

		String magCode = mag.getMagCode().trim();
		String issueNum = mag.getIssue().trim();
		String issueWeek = mag.getWeek().trim();
		String plantId = mag.getPlant().toUpperCase().trim();
		
		String RptPath = sybil.common.util.PropertyBroker.getProperty("NewPDFReportsPath","Not found");
		String fileName = magCode.toLowerCase() + ".i" + issueNum + "." + plantId + ".Break_Out." + issueWeek;
		
		open();
		            
		String SQL  = "SELECT " +
				"  A.MAG_CD, A.PLANT_ID, A.DELIVERY_TYPE, A.PROCESS_TYPE, A.DATA_TYPE, B.WEEK_NUM, B.BRACEID " +
				" ,B.DOP_ID, A.roll_id, A.XSHEET_BV_NME, SUM((A.COPY_CNT) * A.NEST_COPY_CNT) AS NEST_TOT_COPY_CNT " +
		        " FROM  " + custBvTableName   + "   A, " + magInfo + " B " + 
		        "  where A.mag_ky  = ? and A.INSTNC_CD = ? and A.mag_cd = ? and A.plant_id = ? and A.iss_num  = ? AND A.ISS_WK_NUM  = ? " +               
		        "  AND B.ISSUE  = ? AND B.WEEK_NUM = ? and A.plant_ID  = B.PLANT  and A.mag_CD = B.MAG " +           
		        "  and A.DELIVERY_TYPE = B.DELIVERY_TYPE and A.PROCESS_TYPE = B.PROCESS_TYPE " +
		        "  and A.DATA_TYPE = B.DATA_TYPE and A.roll_id = B.rollid " +
		        "  Group by  A.MAG_CD, A.PLANT_ID, A.DELIVERY_TYPE, A.PROCESS_TYPE, A.DATA_TYPE , B.WEEK_NUM, " +
		        "  B.BRACEID, B.DOP_ID, A.roll_id, A.XSHEET_BV_NME " +
		        "  ORDER BY  A.MAG_CD, A.PLANT_ID, A.DELIVERY_TYPE, A.PROCESS_TYPE, A.DATA_TYPE, B.WEEK_NUM, " +
		        "  B.BRACEID, B.DOP_ID, A.roll_id, A.XSHEET_BV_NME " ;   
		
		int magKey = magazineKey(magCode);
		
		String issueDate = getIssueDate(mag);
		
		String instCd = InstanceCd.getInstCd(magKey, issueDate);
		
		try {
			
			PdfWriter writer = PdfWriter.getInstance(brakOutDoc,				
					new FileOutputStream(RptPath + fileName + ".pdf"));
			

			writer.setViewerPreferences(PdfWriter.PageModeFullScreen);
			writer.setPageEvent(new BreakOut());
			
			brakOutDoc.open();
			
			Date toDay = new Date(); 
			SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, MMM d, yyyy, HH:mm a "); 

      		PdfPTable outertable = new PdfPTable(1);
			outertable.setHeaderRows(9);
			
			PdfPCell header0 = new PdfPCell(new Phrase(String.valueOf(dateFormat.format(toDay)),
					FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,Color.black)));
			header0.setBorderWidth(0);
			outertable.addCell(header0);
			
			String issueHdr = "Issue :" + issueDate + "(" + issueNum + " - " + issueWeek +")";
			PdfPCell issueCell = new PdfPCell(new Phrase(issueHdr,
					FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,Color.black)));
			issueCell.setBorderWidth(0);
			outertable.addCell(issueCell);
			
			PdfPCell cell1 = new PdfPCell(new Phrase(
					"Sybil Break out Report by Book Version", FontFactory.getFont(FontFactory.COURIER, 15, Font.BOLD, Color.BLACK)));
			cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell1.setBorderWidth(0);
			outertable.addCell(cell1);
									
			PdfPCell dummyCell = new PdfPCell(new Phrase("", FontFactory.getFont(
								FontFactory.COURIER, 10, Font.BOLD, Color.black)));
			dummyCell.setBorderWidth(0);
			outertable.addCell(dummyCell);

			selectcopyCnt = conn.prepareStatement(SQL);
			selectcopyCnt.setInt(1, magKey);
			selectcopyCnt.setString(2, instCd);
			selectcopyCnt.setString(3, magCode);
			selectcopyCnt.setString(4, plantId);
			selectcopyCnt.setInt(5, toNum.toNumber(issueNum));
			selectcopyCnt.setInt(6, toNum.toNumber(issueWeek));
			selectcopyCnt.setString(7, issueNum);
			selectcopyCnt.setString(8, issueWeek);
					
			resultset = selectcopyCnt.executeQuery();
			
			while (resultset.next()){
			
				String deliveryType = resultset.getString("DELIVERY_TYPE").trim();
 				String processType  = resultset.getString("PROCESS_TYPE").trim();
				String dataType = resultset.getString("DATA_TYPE").trim();
				String weekNum = resultset.getString("WEEK_NUM");
				String braceId = resultset.getString("BRACEID");
				String dopId = resultset.getString("DOP_ID");
				String rollId = resultset.getString("roll_id");
				String xsheetBvName = resultset.getString("XSHEET_BV_NME");
				String copyCnt = resultset.getString("NEST_TOT_COPY_CNT");
				
				String Filetype = deliveryType.concat(processType).concat(dataType).concat(weekNum);
				
			if (firstRow) {
				
				String header1 = "Magazine : " + magName.trim() + "                 Plant : " + plantId + "                 Issue :" + issueNum + " - " + issueWeek  ;
				PdfPCell magCell = new PdfPCell(new Phrase(header1,
						FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD,Color.black)));
				magCell.setBorderWidth(0);
				outertable.addCell(magCell);
									
				for ( int G = 0; G <2; G++){
					PdfPCell dummyCell1 = new PdfPCell(new Phrase("", FontFactory.getFont(
									FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					dummyCell1.setBorderWidth(0);
					outertable.addCell(dummyCell1);}	
				
				String header2 = "   Sybil File Name          Brace       DOP          Roll         BookVersion          Count " ;
				PdfPCell Cell2 = new PdfPCell(new Phrase(header2,
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,Color.black)));
				Cell2.setBorderWidth(0);
				outertable.addCell(Cell2);
				
				
				PdfPCell hLine = new PdfPCell(new Phrase(" ",
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,Color.black)));
				hLine.setBorderWidth(0);
				outertable.addCell(hLine);
				firstRow = false;
			}				
			
			if (Filetype.compareTo(saveFiletype) == 0){
				Filetype = " ";
				if (braceId.compareTo(savebraceId) == 0) {
					braceId = " ";
					if (dopId.compareTo(saveDopId) == 0) {
						dopId = " ";
						if (rollId.compareTo(SaveRollId) == 0){
							
						String detailInfo = AddSpace.addSpace(Filetype,16,' ')  + "  " + AddSpace.addSpace(braceId,4,' ') + "      " + AddSpace.addSpace(dopId,3,' ') + "  " + AddSpace.addSpace(rollId,3,'0') + "     " + AddSpace.addSpace(xsheetBvName,5,' ') + "    "+  AddSpace.addSpace(PlaceComma.placeComma((Integer.valueOf(copyCnt)).intValue()),9)  ;
						PdfPCell detailType = new PdfPCell(
								new Phrase(detailInfo, FontFactory.getFont(FontFactory.COURIER, 10, Font.NORMAL, Color.black)));
						detailType.setBorderWidth(0);
						outertable.addCell(detailType);ctr++;
						rollIdCount += Integer.valueOf(copyCnt).intValue(); 
						}
						else{
							if (firstRollEntry){
							     firstRollEntry = false;	
							     String rolltotInfo = AddSpace.addSpace(" ",52,' ') + "  " + AddSpace.addSpace(PlaceComma.placeComma(rollIdCount),9) + AddSpace.addSpace("Copies For Roll",17,' ')+ " " + AddSpace.addSpace(SaveRollId,3,'0')  ;
									PdfPCell rolltotCell = new PdfPCell(
											new Phrase(rolltotInfo, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
									rolltotCell.setBorderWidth(0);
									outertable.addCell(rolltotCell);ctr++;
									
									totRollCount += rollIdCount;
									dopTotCount +=rollIdCount;
									//LogWriter.writeLog("rollIDCount 1  : " + rollIdCount + " " + totRollCount);
									rollIdCount = 0;
				      		 }
							else{
								String rolltotInfo = AddSpace.addSpace(" ",52,' ') + "  " + AddSpace.addSpace(PlaceComma.placeComma(rollIdCount),9) + AddSpace.addSpace("Copies For Roll",17,' ')+ " " + AddSpace.addSpace(SaveRollId,3,'0')  ;
								PdfPCell rolltotCell = new PdfPCell(
										new Phrase(rolltotInfo, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
								rolltotCell.setBorderWidth(0);
								outertable.addCell(rolltotCell);ctr++;
								
								totRollCount += rollIdCount;
								dopTotCount += rollIdCount;
								//LogWriter.writeLog("rollIDCount 1  : " + rollIdCount + " " + totRollCount);
								rollIdCount = 0;
							}
							SaveRollId = rollId;
							rollCountperDop += 1;
							
							String detailInfo = AddSpace.addSpace(Filetype,16,' ')  + "  " + AddSpace.addSpace(braceId,4,' ') + "      " + AddSpace.addSpace(dopId,3,' ') + "  " + AddSpace.addSpace(rollId,3,'0') + "     " + AddSpace.addSpace(xsheetBvName,5,' ') + "    "+  AddSpace.addSpace(PlaceComma.placeComma((Integer.valueOf(copyCnt)).intValue()),9)  ;
							
							PdfPCell detailType = new PdfPCell(
									new Phrase(detailInfo, FontFactory.getFont(FontFactory.COURIER, 10, Font.NORMAL, Color.black)));
							detailType.setBorderWidth(0);
							outertable.addCell(detailType);ctr++;
							rollIdCount += Integer.valueOf(copyCnt).intValue();
						}
					}	
					else {
						
							String rolltotInfo = AddSpace.addSpace(" ",52,' ') + "  " + AddSpace.addSpace(PlaceComma.placeComma(rollIdCount),9) + AddSpace.addSpace("Copies For Roll",17,' ')+ " " + AddSpace.addSpace(SaveRollId,3,'0')  ;
							PdfPCell rolltotCell = new PdfPCell(
								new Phrase(rolltotInfo, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
							rolltotCell.setBorderWidth(0);
							outertable.addCell(rolltotCell);ctr++;
							
							String rollForDop = AddSpace.addSpace(" ",52,' ') + "  " + AddSpace.addSpace(PlaceComma.placeComma(rollCountperDop),9) + AddSpace.addSpace("Rolls for DOP  ",17,' ')+ "  " + AddSpace.addSpace(saveDopId,4,' ')  ;
							PdfPCell rollForDopCell = new PdfPCell(
									new Phrase(rollForDop, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
							rollForDopCell.setBorderWidth(0);
							outertable.addCell(rollForDopCell);ctr++;
							
							totRollCount += rollIdCount;
							dopTotCount += rollIdCount;
							rollCountperBrace += rollCountperDop;
							
							String TotDopCount = AddSpace.addSpace("DOP's ",37,' ')  + "   " + AddSpace.addSpace(saveDopId,4,' ') + "  " + AddSpace.addSpace("Total ",5,' ') +  AddSpace.addSpace(PlaceComma.placeComma(dopTotCount),9)  ;
							PdfPCell totDopCountCell = new PdfPCell(
									new Phrase(TotDopCount, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
							totDopCountCell.setBorderWidth(0);
							outertable.addCell(totDopCountCell);ctr++;
							
							rollIdCount = 0;firstRollEntry = true; rollCountperDop = 0;dopTotCount=0;
						
						saveDopId = dopId;
						SaveRollId = rollId;
						dopCountperBrace +=1;rollCountperDop += 1;
						
						rollIdCount += Integer.valueOf(copyCnt).intValue();
						
						String detailInfo = AddSpace.addSpace(Filetype,16,' ')  + "  " + AddSpace.addSpace(braceId,4,' ') + "    " + AddSpace.addSpace(dopId,3,' ') + "  " + AddSpace.addSpace(rollId,3,'0') + "     " + AddSpace.addSpace(xsheetBvName,5,' ') + "    "+  AddSpace.addSpace(PlaceComma.placeComma((Integer.valueOf(copyCnt)).intValue()),9)  ;
						
						PdfPCell detailType = new PdfPCell(
								new Phrase(detailInfo, FontFactory.getFont(FontFactory.COURIER, 10, Font.NORMAL, Color.black)));
						detailType.setBorderWidth(0);
						outertable.addCell(detailType);ctr++;
					}
				}
				else {
					
					
					rollCountperBrace +=rollCountperDop;
					//LogWriter.writeLog("rollIDCount 2  : " + rollIdCount + " " + totRollCount);
					String rolltotInfo = AddSpace.addSpace(" ",52,' ') + "  " + AddSpace.addSpace(PlaceComma.placeComma(rollIdCount),9) + AddSpace.addSpace("Copies For Roll",17,' ')+ " " + AddSpace.addSpace(SaveRollId,3,'0')  ;
					PdfPCell rolltotCell = new PdfPCell(
							new Phrase(rolltotInfo, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					rolltotCell.setBorderWidth(0);
					outertable.addCell(rolltotCell);ctr++;
					
					String rollForDop = AddSpace.addSpace(" ",52,' ') + "  " + AddSpace.addSpace(PlaceComma.placeComma(rollCountperDop),9) + AddSpace.addSpace("Rolls for DOP  ",17,' ')+ "  " + AddSpace.addSpace(saveDopId,4,' ')  ;
					PdfPCell rollForDopCell = new PdfPCell(
							new Phrase(rollForDop, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					rollForDopCell.setBorderWidth(0);
					outertable.addCell(rollForDopCell);ctr++;
					
					String rollForBrace = AddSpace.addSpace(" ",52,' ') + "  " + AddSpace.addSpace(PlaceComma.placeComma(rollCountperBrace),9) + AddSpace.addSpace("Rolls for Brace",17,' ') + AddSpace.addSpace(savebraceId,4,' ')  ;
					PdfPCell rollForBraceCell = new PdfPCell(
							new Phrase(rollForBrace, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					rollForBraceCell.setBorderWidth(0);
					outertable.addCell(rollForBraceCell);ctr++;
					
					String dopForBrace = AddSpace.addSpace(" ",52,' ') + "  " + AddSpace.addSpace(PlaceComma.placeComma(dopCountperBrace),9) + AddSpace.addSpace("DOPs for Brace ",17,' ') + AddSpace.addSpace(savebraceId,4,' ')  ;
					PdfPCell dopForBraceCell = new PdfPCell(
							new Phrase(dopForBrace, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					dopForBraceCell.setBorderWidth(0);
					outertable.addCell(dopForBraceCell);ctr++;
					
					dopTotCount += rollIdCount;
					totRollCount += rollIdCount;
					
					String TotDopCount = AddSpace.addSpace("DOP's ",37,' ')  + "   " + AddSpace.addSpace(saveDopId,4,' ') + "  " + AddSpace.addSpace("Total ",5,' ') +  AddSpace.addSpace(PlaceComma.placeComma(dopTotCount),9)  ;
					PdfPCell totDopCountCell = new PdfPCell(
							new Phrase(TotDopCount, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					totDopCountCell.setBorderWidth(0);
					outertable.addCell(totDopCountCell);ctr++;
					
					String TotRollCount = AddSpace.addSpace("Brace ",37,' ')  + "  " + AddSpace.addSpace(savebraceId,4,' ') + "    " + AddSpace.addSpace("Total ",5,' ') +  AddSpace.addSpace(PlaceComma.placeComma(totRollCount),9)  ;
					PdfPCell totRollCountCell = new PdfPCell(
							new Phrase(TotRollCount, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					totRollCountCell.setBorderWidth(0);
					outertable.addCell(totRollCountCell);ctr++;
					
					totFileTypeCount += totRollCount;rollCountFT += rollCountperBrace;dopCountFT += dopCountperBrace;
					rollCountperBrace = 0;
					
					for ( int G = 0; G <2; G++) outertable.addCell(dummyCell);
					
					rollIdCount = 0;firstRollEntry = true;rollCountperDop=0;totRollCount= 0;dopCountperBrace=0;dopTotCount=0;
					
					savebraceId = braceId;
					saveDopId = dopId;
					SaveRollId = rollId;rollCountperDop += 1;dopCountperBrace +=1;braceCountFT +=1;
					
					rollIdCount += Integer.valueOf(copyCnt).intValue();
					
					String detailInfo = AddSpace.addSpace(Filetype,16,' ')  + "  " + AddSpace.addSpace(braceId,4,' ') + "    " + AddSpace.addSpace(dopId,3,' ') + "  " + AddSpace.addSpace(rollId,3,'0') + "     " + AddSpace.addSpace(xsheetBvName,5,' ') + "    "+  AddSpace.addSpace(PlaceComma.placeComma((Integer.valueOf(copyCnt)).intValue()),9)  ;
					PdfPCell detailType = new PdfPCell(
							new Phrase(detailInfo, FontFactory.getFont(FontFactory.COURIER, 10, Font.NORMAL, Color.black)));
					detailType.setBorderWidth(0);
					outertable.addCell(detailType);ctr++;									
				}	
			} 
			else {	
				if (firstFileType){
					firstFileType = false;
				}
				else{
					
					totRollCount += rollIdCount;rollCountFT += rollCountperBrace + rollCountperDop;dopCountFT += dopCountperBrace;
					braceCountFT +=1;
					
					//LogWriter.writeLog("rollIDCount 3  : " + rollIdCount + " " + totRollCount);
					
					//LogWriter.writeLog("dopCountFT 4G  : " + dopCountFT + " " );
					
					String TotRollCount = AddSpace.addSpace("Brace ",37,' ')  + "  " + AddSpace.addSpace(savebraceId,4,' ') + "    " + AddSpace.addSpace("Total ",5,' ') +  AddSpace.addSpace(PlaceComma.placeComma(totRollCount),9)  ;
					PdfPCell totRollCountCell = new PdfPCell(
							new Phrase(TotRollCount, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					totRollCountCell.setBorderWidth(0);
					outertable.addCell(totRollCountCell);ctr++;
					for ( int G = 0; G <2; G++) outertable.addCell(dummyCell);
					
					totFileTypeCount += totRollCount;
					
					String TotBraceCount = AddSpace.addSpace("Total Copies, ",20,' ')  + "  " + AddSpace.addSpace(saveFiletype,16,' ') + "    " +  AddSpace.addSpace(PlaceComma.placeComma(totFileTypeCount),9)  ;
					PdfPCell totBraceCountCell = new PdfPCell(
							new Phrase(TotBraceCount, FontFactory.getFont(FontFactory.COURIER, 12, Font.BOLD, Color.black)));
					totBraceCountCell.setBorderWidth(0);
					outertable.addCell(totBraceCountCell);ctr++;
					
					String rollForFT = AddSpace.addSpace(" ",52,' ') + "  " + AddSpace.addSpace(PlaceComma.placeComma(rollCountFT),9) + AddSpace.addSpace("Rolls for ",12,' ')+ AddSpace.addSpace(saveFiletype,4,' ')  ;
					PdfPCell rollForftCell = new PdfPCell(
							new Phrase(rollForFT, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					rollForftCell.setBorderWidth(0);
					outertable.addCell(rollForftCell);ctr++;
					
					String dopForFT = AddSpace.addSpace(" ",52,' ') + "  " + AddSpace.addSpace(PlaceComma.placeComma(dopCountFT),9) + AddSpace.addSpace("DOPs for  ",12,' ') + AddSpace.addSpace(saveFiletype,4,' ')  ;
					PdfPCell dopForftCell = new PdfPCell(
							new Phrase(dopForFT, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					dopForftCell.setBorderWidth(0);
					outertable.addCell(dopForftCell);ctr++;
					
					String braceForFT = AddSpace.addSpace(" ",52,' ') + "  " + AddSpace.addSpace(PlaceComma.placeComma(braceCountFT),9) + AddSpace.addSpace("Braces for ",12,' ') + AddSpace.addSpace(saveFiletype,4,' ')  ;
					PdfPCell braceForftCell = new PdfPCell(
							new Phrase(braceForFT, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					braceForftCell.setBorderWidth(0);
					outertable.addCell(braceForftCell);ctr++;
					
					
					rpttotFileTypeCount += totFileTypeCount;
					rptTotBraceCount +=braceCountFT;
					rptdopCount += dopCountFT;
					rptrollCount += rollCountFT;
					
					
					for ( int G = 0; G <2; G++) outertable.addCell(dummyCell);
					
					rollIdCount = 0;firstRollEntry = true;rollCountperDop=0;totRollCount= 0;totFileTypeCount=0;
					rollCountFT =0;dopCountFT=0;dopCountperBrace=0;braceCountFT=0;rollCountperBrace=0;

				}
				
				saveFiletype = Filetype;
				savebraceId = braceId;
				saveDopId = dopId;
				SaveRollId = rollId;rollCountperDop += 1;
				
				dopCountperBrace +=1;

				rollIdCount += Integer.valueOf(copyCnt).intValue();
				
				String detailInfo = AddSpace.addSpace(Filetype,16,' ')  + "  " + AddSpace.addSpace(braceId,4,' ') + "    " + AddSpace.addSpace(dopId,3,' ') + "  " + AddSpace.addSpace(rollId,3,'0') + "     " + AddSpace.addSpace(xsheetBvName,5,' ') + "    "+  AddSpace.addSpace(PlaceComma.placeComma((Integer.valueOf(copyCnt)).intValue()),9)  ;
				PdfPCell detailType = new PdfPCell(
						new Phrase(detailInfo, FontFactory.getFont(FontFactory.COURIER, 10, Font.NORMAL, Color.black)));
				detailType.setBorderWidth(0);
				outertable.addCell(detailType);ctr++;
												     
			}
			if (ctr > 45) ctr = 1;
		}  
			
			totRollCount += rollIdCount;rollCountFT += rollCountperDop;
			dopCountFT += dopCountperBrace;
			
			//LogWriter.writeLog("dopCountFT 4  : " + dopCountFT + " " );
			
			String TotRollCount = AddSpace.addSpace("Brace ",37,' ')  + "  " + AddSpace.addSpace(savebraceId,4,' ') + "    " + AddSpace.addSpace("Total ",5,' ') +  AddSpace.addSpace(PlaceComma.placeComma(totRollCount),9)  ;
			PdfPCell totRollCountCell = new PdfPCell(
					new Phrase(TotRollCount, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
			totRollCountCell.setBorderWidth(0);
			outertable.addCell(totRollCountCell);
			for ( int G = 0; G <2; G++) outertable.addCell(dummyCell);
			
			totFileTypeCount += totRollCount;
			
			String TotBraceCount = AddSpace.addSpace("Total Copies, ",20,' ')  + "  " + AddSpace.addSpace(saveFiletype,16,' ') + "    " +  AddSpace.addSpace(PlaceComma.placeComma(totFileTypeCount),9)  ;
			PdfPCell totBraceCountCell = new PdfPCell(
					new Phrase(TotBraceCount, FontFactory.getFont(FontFactory.COURIER, 12, Font.BOLD, Color.black)));
			totBraceCountCell.setBorderWidth(0);
			outertable.addCell(totBraceCountCell);
			
			String rollForFT = AddSpace.addSpace(" ",52,' ') + "  " + AddSpace.addSpace(PlaceComma.placeComma(rollCountFT),9) + AddSpace.addSpace("Rolls for ",12,' ')+ AddSpace.addSpace(saveFiletype,4,' ')  ;
			PdfPCell rollForftCell = new PdfPCell(
					new Phrase(rollForFT, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
			rollForftCell.setBorderWidth(0);
			outertable.addCell(rollForftCell);
			
			String dopForFT = AddSpace.addSpace(" ",52,' ') + "  " + AddSpace.addSpace(PlaceComma.placeComma(dopCountFT),9) + AddSpace.addSpace("DOPs for  ",12,' ') + AddSpace.addSpace(saveFiletype,4,' ')  ;
			PdfPCell dopForftCell = new PdfPCell(
					new Phrase(dopForFT, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
			dopForftCell.setBorderWidth(0);
			outertable.addCell(dopForftCell);
			
			String braceForFT = AddSpace.addSpace(" ",52,' ') + "  " + AddSpace.addSpace(PlaceComma.placeComma(braceCountFT),9) + AddSpace.addSpace("Braces for ",12,' ') + AddSpace.addSpace(saveFiletype,4,' ')  ;
			PdfPCell braceForftCell = new PdfPCell(
					new Phrase(braceForFT, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
			braceForftCell.setBorderWidth(0);
			outertable.addCell(braceForftCell);
			
			rpttotFileTypeCount += totFileTypeCount;rptrollCount+=rollCountFT;rptdopCount+=dopCountFT;
			rptTotBraceCount +=braceCountFT;
			
			for ( int G = 0; G <2; G++) outertable.addCell(dummyCell);
			
			String rptTotCount = AddSpace.addSpace(" ",30,' ') + "  " + AddSpace.addSpace("Grand Total Copies: ",22,' ')  + "  " + AddSpace.addSpace(PlaceComma.placeComma(rpttotFileTypeCount),9)   ;
			PdfPCell rpttotCountCell = new PdfPCell(
					new Phrase(rptTotCount, FontFactory.getFont(FontFactory.COURIER, 12, Font.BOLD, Color.black)));
			rpttotCountCell.setBorderWidth(0);
			outertable.addCell(rpttotCountCell);
			
			String rptrollCountF = AddSpace.addSpace(" ",30,' ') + "  " + AddSpace.addSpace("Total Rolls ",22,' ') + AddSpace.addSpace(PlaceComma.placeComma(rptrollCount),9) ;
			PdfPCell rptrollCountCell = new PdfPCell(
					new Phrase(rptrollCountF, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
			rptrollCountCell.setBorderWidth(0);
			outertable.addCell(rptrollCountCell);
			
			String rptdopCountF = AddSpace.addSpace(" ",30,' ') + "  " + AddSpace.addSpace("Total DOPs ",22,' ') + AddSpace.addSpace(PlaceComma.placeComma(rptdopCount),9) ;
			PdfPCell rptdopCountCell = new PdfPCell(
					new Phrase(rptdopCountF, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
			rptdopCountCell.setBorderWidth(0);
			outertable.addCell(rptdopCountCell);
			
			String rptbraceCountF = AddSpace.addSpace(" ",30,' ') + "  " + AddSpace.addSpace("Total Braces  ",22,' ') + AddSpace.addSpace(PlaceComma.placeComma(rptTotBraceCount),9)  ;
			PdfPCell rptbracecountCell = new PdfPCell(
					new Phrase(rptbraceCountF, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
			rptbracecountCell.setBorderWidth(0);
			outertable.addCell(rptbracecountCell);

			
			brakOutDoc.add(outertable);

		} 
		catch (SQLException se) {
			System.err.println(se.getMessage());
		}
	
		catch (DocumentException de) {
			System.err.println(de.getMessage());
		} catch (IOException ioe) {
			System.err.println(ioe.getMessage());
		}			
		brakOutDoc.close();
		close();
		
		return;

		
		
	}

}
