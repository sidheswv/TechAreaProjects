package com.pdf.report;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.text.DecimalFormat;
import java.util.Date;

import sybil.common.model.Magazine;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;

import com.report.text.Document;
import com.report.text.DocumentException;
import com.report.text.Element;
import com.report.text.ExceptionConverter;
import com.report.text.Font;
import com.report.text.FontFactory;
import com.report.text.PageSize;
import com.report.text.Phrase;
import com.report.text.Rectangle;
import com.report.text.pdf.BaseFont;
import com.report.text.pdf.PdfContentByte;
import com.report.text.pdf.PdfPCell;
import com.report.text.pdf.PdfPTable;
import com.report.text.pdf.PdfPageEventHelper;
import com.report.text.pdf.PdfTemplate;
import com.report.text.pdf.PdfWriter;

public class CarrierRoutePercentage extends PdfPageEventHelper {
	
	public static String geocarriercntTable = "TBA_GEO_CR_CNT";

	public static String magazineInf = "TBA_MAGAZINEINF";

	public static String sybMag = "TBA_SYB_MAGAZINE";

	private static Connection conn = null;

	private static ResultSet resultset = null;
	
	private static Font COURIER_BOLD = FontFactory.getFont(
			FontFactory.COURIER, 12, Font.BOLD, Color.black);

	private static Font COURIER_NORMAL = FontFactory.getFont(
			FontFactory.COURIER, 12, Font.NORMAL, Color.black);

	private static String magName = null;

	protected PdfTemplate total;

	protected BaseFont helv;
 
 	public void onOpenDocument(PdfWriter writer, Document document) {
		total = writer.getDirectContent().createTemplate(100, 100);
		total.setBoundingBox(new Rectangle(-20, -20, 100, 100));
		try {
			helv = BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI,BaseFont.NOT_EMBEDDED);
		} catch (Exception e) {
			throw new ExceptionConverter(e);
		}
	}
 
	public void onEndPage(PdfWriter writer, Document document) {
		PdfContentByte cb = writer.getDirectContent();
		cb.saveState();
		String text = "Page " + writer.getPageNumber() + " of  ";
		float textBase = document.bottom() - 15;
		float textSize = helv.getWidthPoint(text, 9);
		float textCenter = document.right()/2;
		cb.beginText();
		cb.setFontAndSize(helv, 10);

		cb.setTextMatrix(textCenter, textBase);
		cb.showText(text);
		cb.endText();
		cb.addTemplate(total, textCenter + textSize, textBase);
		cb.restoreState();
	}
 	
	public void onCloseDocument(PdfWriter writer, Document document) {
		total.beginText();
		total.setFontAndSize(helv, 10);
		total.setTextMatrix(0, 0);
		total.showText(String.valueOf(writer.getPageNumber() - 1));
		total.endText();
	}
	
	private static void open() {

		PreparedStatement setSqlId = null;
		Statement commitSqlId = null;
		String x = null;
		String db2owner = null;
		int i = 0;
		
		String userDb = sybil.common.util.PropertyBroker.getProperty("database.login","sybil");
		String pswdDb = sybil.common.util.PropertyBroker.getProperty("database.password","sybil");
		
		
		if( conn == null) {
			try {
				Class.forName(sybil.common.util.PropertyBroker.getProperty("database.driver", "Not Found"));
				conn = DriverManager.getConnection(sybil.common.util.PropertyBroker.getProperty("database.server", "Not Found"), userDb, pswdDb);

				//
				x = PropertyBroker.getProperty("database.driver", "Not Found").toLowerCase();
				i = x.indexOf("db2");
				if (!(i < 0)) {
					try {
						db2owner = PropertyBroker.getProperty("DB2OWNER","dtppsyup");
						setSqlId = conn.prepareStatement("set current sqlid = ?");
						setSqlId.setString(1, db2owner);
						setSqlId.execute();
						commitSqlId = conn.createStatement();
						commitSqlId.execute("commit");
					}
					catch (SQLException se) {
						if(se.getSQLState().equals("S1010")) {
						}
						else {
							LogWriter.writeLog(se);
							LogWriter.writeLog("Error: Set Current SqlId failed.");
							if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
								LogWriter.writeLog("Process terminating due to database/sql exception");
								System.exit(1);
							}
						}
					}
					catch (Exception e) {
						LogWriter.writeLog(e);
						LogWriter.writeLog("Error: Set Current SqlId failed.");
						if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
							LogWriter.writeLog("Process terminating due to database/sql exception");
							System.exit(1);
						}
					}
				}
			
			} 
			catch (Exception e) {
				sybil.common.util.LogWriter.writeLog(e);
				LogWriter.writeLog("Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
		
	return;
	}

	public static void close() {
		
		if( conn != null) {		
			try { conn.close(); }catch(Exception sql ){};
			conn = null;
		}
		return;
	}

	private static String getIssueDate(Magazine mag){
		
		String issueDate = null;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT COVER_DATE FROM " + magazineInf + " WHERE PLANT = ? and MAG = ? and ISSUE = ? ";
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, mag.getPlant().toUpperCase());
		selectMag.setString(2, mag.getMagCode().toLowerCase());
		selectMag.setString(3, mag.getIssue());
		
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			issueDate  = rs.getString("COVER_DATE");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Issue Date error " + mag.getMagCode());
		}
		return issueDate;
	}

	private static int magazineKey(String magazineCode){
		
		int magKey = 0;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT MAG_KEY, NAME  FROM " + sybMag + " WHERE MAG_CD = ? ";
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, magazineCode);
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			magKey  = (int)rs.getInt("MAG_KEY");
			magName = rs.getString("NAME");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Code Select error " + magazineCode);
		}
		return magKey;
	}
	
	public synchronized static void CreatePDF(Magazine mag){
		
		PreparedStatement selectcopyCnt = null;
		Document crpercentDoc = new Document(PageSize.LETTER,0,0,36,36);
		String savebindgrpname = "  ";
		String saveBraceId = " ";
		String percent = "%";
		
		int Copies = 0;
		int CRCopies = 0;
		int TotalCopies = 0;
		int TotalCRCopies = 0;
		int linectr = 1;
		
		boolean firstRow = true;	
		boolean firstTime = true;
		boolean noCRpercent = true;
		
		int [] tablew = {26,5,8,8,6};

		String magCode = mag.getMagCode().trim();
		String issueNum = mag.getIssue().trim();
		String issueWeek = mag.getWeek().trim();
		String plantId = mag.getPlant().toUpperCase().trim();
		
		String RptPath = sybil.common.util.PropertyBroker.getProperty("NewPDFReportsPath","Not found");
		String fileName = magCode.toLowerCase() + ".i" + issueNum + "." + plantId + ".OMS_CarrierRoute_Percentage." + issueWeek;
		
		open();
		            
		String SQL  = "SELECT BIND_GRP_NME, GEO_COMBO_NME, " +
				" SUM(PD_COPY_CNT) AS PAIDCPY, SUM(FREE_COPY_CNT) AS FREECPY, SUM(CR_PD_COPY_CNT) AS CRPAIDCPY, SUM(CR_FREE_COPY_CNT) AS CRFREECPY"
		    + " FROM  " + geocarriercntTable                  
	        + " WHERE  MAG_KY = ? and INSTNC_CD = ? AND MAG_CD = ? AND PLANT_ID = ? AND ISS_NUM = ? AND ISS_WK_NUM = ? "
	        + "GROUP BY BIND_GRP_NME, GEO_COMBO_NME "
	        + " ORDER BY BIND_GRP_NME, GEO_COMBO_NME ";
		
		int magKey = magazineKey(magCode);
		
		String issueDate = getIssueDate(mag);
		
		String instCd = InstanceCd.getInstCd(magKey, issueDate);
		
		try {
			
			PdfWriter writer = PdfWriter.getInstance(crpercentDoc,				
					new FileOutputStream(RptPath + fileName + ".pdf"));
			

			writer.setViewerPreferences(PdfWriter.PageModeFullScreen);
			writer.setPageEvent(new CarrierRoutePercentage());
			
			crpercentDoc.open();
			
			PdfPCell dummyCell = new PdfPCell(new Phrase("", FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
			dummyCell.setBorderWidth(0);
			
			Date toDay = new Date(); 
			SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, MMM d, yyyy, HH:mm a "); 

      		PdfPTable outertable = new PdfPTable(1);
			outertable.setHeaderRows(10);
			
			PdfPCell header0 = new PdfPCell(new Phrase(String.valueOf(dateFormat.format(toDay)),
					FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,Color.black)));
			header0.setBorderWidth(0);
			outertable.addCell(header0);
			
			PdfPCell cell1 = new PdfPCell(new Phrase(
					"Carrier Route Percentage Report", FontFactory.getFont(
							FontFactory.TIMES_ROMAN, 18, Font.BOLD |Font.UNDERLINE, Color.BLACK)));
			cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell1.setBorderWidth(0);
			outertable.addCell(cell1);
					
			for ( int s = 0; s <=2; s++)outertable.addCell(dummyCell);

			selectcopyCnt = conn.prepareStatement(SQL);
		
			selectcopyCnt.setInt(1, magKey);
			selectcopyCnt.setString(2, instCd);
			selectcopyCnt.setString(3, magCode);
			selectcopyCnt.setString(4, plantId);
			selectcopyCnt.setInt(5, toNum.toNumber(issueNum));
			selectcopyCnt.setInt(6, toNum.toNumber(issueWeek));
					
			resultset = selectcopyCnt.executeQuery();
			
			while (resultset.next()){
				
				noCRpercent = false;
				 
				String bindingGroupName = resultset.getString("BIND_GRP_NME");
				String geoComboName = resultset.getString("GEO_COMBO_NME");
				String pdcopyCount = resultset.getString("PAIDCPY");
				String freecopyCount = resultset.getString("FREECPY");
				String pdCRcopyCount = resultset.getString("CRPAIDCPY");
				String freeCRcopyCount = resultset.getString("CRFREECPY");
								
				CRCopies = (Integer.valueOf(pdCRcopyCount).intValue() + Integer.valueOf(freeCRcopyCount).intValue());
				Copies = ((Integer.valueOf(pdcopyCount).intValue() + Integer.valueOf(freecopyCount).intValue()) + CRCopies);
				float crpercent = ((float) CRCopies / (float) Copies) * (float) 100;
				String CRPercent = Math.round(crpercent) + percent;	
						
			if (firstRow) {
				
				String header1 = "Magazine : " + magName.trim() + "        Plant : " + plantId + "         Issue Date : " + issueDate + "      Issue :" + issueNum + " - " + issueWeek  ;
				PdfPCell magCell = new PdfPCell(new Phrase(header1,
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,Color.black)));
				magCell.setBorderWidth(0);
				outertable.addCell(magCell);
				
				for ( int G = 0; G <=2; G++)outertable.addCell(dummyCell);		
				
				PdfPTable headertable1 = new PdfPTable(5);
				headertable1.getDefaultCell().setBorder(Rectangle.NO_BORDER | Rectangle.BOTTOM);
				headertable1.setWidths(tablew);
				headertable1.addCell(new Phrase("Binding Group ",COURIER_BOLD));
				headertable1.addCell(new Phrase("GEO Combo Name",COURIER_BOLD));
				headertable1.addCell(new Phrase("Copies",COURIER_BOLD));
				headertable1.addCell(new Phrase("CR Copies",COURIER_BOLD));
				headertable1.addCell(new Phrase("CR Percent",COURIER_BOLD));
				
				PdfPCell headercell1 = new PdfPCell(headertable1);
				headercell1.setBorderWidth(0);
				headercell1.setBackgroundColor(new Color(108, 253, 206));
				outertable.addCell(headercell1);
				
				firstRow = false;
			}				
			
			if (bindingGroupName.compareTo(savebindgrpname) == 0){
				
				bindingGroupName = " ";
				PdfPTable detailTable = new PdfPTable(5);
			    detailTable.getDefaultCell().setBorder(Rectangle.NO_BORDER );
			    detailTable.setWidths(tablew);
			    detailTable.addCell(new Phrase(bindingGroupName,COURIER_NORMAL));
			    detailTable.addCell(new Phrase(geoComboName,COURIER_NORMAL));
			    detailTable.addCell(new Phrase(Integer.toString(Copies),COURIER_NORMAL));
			    detailTable.addCell(new Phrase(Integer.toString(CRCopies),COURIER_NORMAL));
			    detailTable.addCell(new Phrase(CRPercent,COURIER_NORMAL));
					
			    PdfPCell detailCell = new PdfPCell(detailTable);
			    detailCell.setBorderWidth(0);
			    outertable.addCell(detailCell);
			    TotalCopies += Copies;
			    TotalCRCopies += CRCopies;
			    
			} 
			else {	
				 if (firstTime){
				     firstTime = false;	
	      		 }
			     else{
			    	 for ( int G = 0; G <2; G++) outertable.addCell(dummyCell);
			    	 float totalcrpercent = ((float) TotalCRCopies / (float) TotalCopies) * (float) 100;
					 String TotalCRPercent = Math.round(totalcrpercent) + percent;	
					 
					 PdfPTable totalTable = new PdfPTable(5);
				     totalTable.getDefaultCell().setBorder(Rectangle.NO_BORDER | Rectangle.TOP);
				     totalTable.setWidths(tablew);
				     totalTable.addCell(new Phrase("                         Total",COURIER_BOLD));
				     totalTable.addCell(new Phrase(" ",COURIER_BOLD));
				     totalTable.addCell(new Phrase(Integer.toString(TotalCopies),COURIER_BOLD));
					 totalTable.addCell(new Phrase(Integer.toString(TotalCRCopies),COURIER_BOLD));
					 totalTable.addCell(new Phrase(TotalCRPercent,COURIER_BOLD));		
					 	
					 PdfPCell totalCell = new PdfPCell(totalTable); 
					 totalCell.setBorderWidth(0);
					 outertable.addCell(totalCell);
					   
					 TotalCopies = 0;
				     TotalCRCopies = 0;
				     
			    	 for ( int G = 0; G <2; G++)outertable.addCell(dummyCell);
			     }			
			     savebindgrpname = bindingGroupName;
			     saveBraceId = geoComboName;
			     
			     PdfPTable detailTable = new PdfPTable(5);
			     detailTable.getDefaultCell().setBorder(Rectangle.NO_BORDER | Rectangle.TOP);
			     detailTable.setWidths(tablew);
			     detailTable.addCell(new Phrase(bindingGroupName,COURIER_NORMAL));
			     detailTable.addCell(new Phrase(geoComboName,COURIER_NORMAL));
			     detailTable.addCell(new Phrase(Integer.toString(Copies),COURIER_NORMAL));
				 detailTable.addCell(new Phrase(Integer.toString(CRCopies),COURIER_NORMAL));
				 detailTable.addCell(new Phrase(CRPercent,COURIER_NORMAL));
					
			     PdfPCell detailCell = new PdfPCell(detailTable);
			     detailCell.setBorderWidth(0);
			     outertable.addCell(detailCell);
			     TotalCopies += Copies;
				 TotalCRCopies += CRCopies;
				 			     
			    }
		}   				
	    	 if (noCRpercent){
				String header1 = "Magazine : " + magName.trim() + "        Plant : " + plantId + "     Issue Date : " + issueDate + "Issue :" + issueNum + " - " + issueWeek  ;
				PdfPCell magCell = new PdfPCell(new Phrase(header1,
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,Color.black)));
				magCell.setBorderWidth(0);
				outertable.addCell(magCell);
				
				for ( int G = 0; G <5; G++)outertable.addCell(dummyCell);		
				
				PdfPTable headertable1 = new PdfPTable(5);
				headertable1.getDefaultCell().setBorder(Rectangle.NO_BORDER | Rectangle.BOTTOM);
				headertable1.setWidths(tablew);
				headertable1.addCell(new Phrase("Binding Group ",COURIER_BOLD));
				headertable1.addCell(new Phrase("GEO Combo Name",COURIER_BOLD));
				headertable1.addCell(new Phrase("Copies",COURIER_BOLD));
				headertable1.addCell(new Phrase("CR Copies",COURIER_BOLD));
				headertable1.addCell(new Phrase("CR Percent",COURIER_BOLD));
												
				PdfPCell headercell1 = new PdfPCell(headertable1);
				headercell1.setBorderWidth(0);
				headercell1.setBackgroundColor(new Color(108, 253, 206));
				outertable.addCell(headercell1);
			} else {
				for ( int G = 0; G <2; G++) outertable.addCell(dummyCell);
		    	 float totalcrpercent = ((float) TotalCRCopies / (float) TotalCopies) * (float) 100;
				 String TotalCRPercent = Math.round(totalcrpercent) + percent;	

				 PdfPTable totalTable = new PdfPTable(5);
			     totalTable.getDefaultCell().setBorder(Rectangle.NO_BORDER | Rectangle.TOP);
			     totalTable.setWidths(tablew);
			     totalTable.addCell(new Phrase("                         Total",COURIER_BOLD));
			     totalTable.addCell(new Phrase(" ",COURIER_BOLD));
			     totalTable.addCell(new Phrase(Integer.toString(TotalCopies),COURIER_BOLD));
				 totalTable.addCell(new Phrase(Integer.toString(TotalCRCopies),COURIER_BOLD));
				 totalTable.addCell(new Phrase(TotalCRPercent,COURIER_BOLD));		
				 	
				 PdfPCell totalCell = new PdfPCell(totalTable); 
				 totalCell.setBorderWidth(0);
				 outertable.addCell(totalCell);
				     
				 TotalCopies = 0;
			     TotalCRCopies = 0;
			}
			crpercentDoc.add(outertable);

		} 
		catch (SQLException se) {
			System.err.println(se.getMessage());
		}
	
		catch (DocumentException de) {
			System.err.println(de.getMessage());
		} catch (IOException ioe) {
			System.err.println(ioe.getMessage());
		}			
		crpercentDoc.close();
		close();
		LogWriter.writeLog(" Carrier Route Percentage Report Generated " );
		return;
	}


}
