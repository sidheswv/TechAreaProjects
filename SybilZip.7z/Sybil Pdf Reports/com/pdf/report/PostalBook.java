package com.pdf.report;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import sybil.common.model.Magazine;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;

import com.report.text.Document;
import com.report.text.DocumentException;
import com.report.text.Element;
import com.report.text.ExceptionConverter;
import com.report.text.Font;
import com.report.text.FontFactory;
import com.report.text.PageSize;
import com.report.text.Phrase;
import com.report.text.Rectangle;
import com.report.text.pdf.BaseFont;
import com.report.text.pdf.PdfContentByte;
import com.report.text.pdf.PdfPCell;
import com.report.text.pdf.PdfPTable;
import com.report.text.pdf.PdfPageEventHelper;
import com.report.text.pdf.PdfTemplate;
import com.report.text.pdf.PdfWriter;

public class PostalBook extends PdfPageEventHelper {

	public static String magInfo = "TBA_MAG_INFO";

	public static String postalbookTableName = "TBA_POST_BOOK";

	public static String magazineInf = "TBA_MAGAZINEINF";

	public static String sybMag = "TBA_SYB_MAGAZINE";

	private static final Font TIMESNORAML_12 = FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.NORMAL, Color.black);

	private static final Font TIMESBOLD_12 = FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD, Color.black);

	private static Connection conn = null;

	private static ResultSet resultset = null;

	private static String magName = null;

	protected PdfTemplate total;

	protected BaseFont helv;
 
 	public void onOpenDocument(PdfWriter writer, Document document) {
		total = writer.getDirectContent().createTemplate(100, 100);
		total.setBoundingBox(new Rectangle(-20, -20, 100, 100));
		try {
			helv = BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI,BaseFont.NOT_EMBEDDED);
		} catch (Exception e) {
			throw new ExceptionConverter(e);
		}
	}
 
	public void onEndPage(PdfWriter writer, Document document) {
		PdfContentByte cb = writer.getDirectContent();
		cb.saveState();
		String text = "Page " + writer.getPageNumber() + " of  ";
		float textBase = document.bottom() - 15;
		float textSize = helv.getWidthPoint(text, 9);
		float textCenter = document.right()/2;
		cb.beginText();
		cb.setFontAndSize(helv, 10);

		cb.setTextMatrix(textCenter, textBase);
		cb.showText(text);
		cb.endText();
		cb.addTemplate(total, textCenter + textSize, textBase);
		cb.restoreState();
	}
 	
	public void onCloseDocument(PdfWriter writer, Document document) {
		total.beginText();
		total.setFontAndSize(helv, 10);
		total.setTextMatrix(0, 0);
		total.showText(String.valueOf(writer.getPageNumber() - 1));
		total.endText();
	}
	

	private static void open() {

		PreparedStatement setSqlId = null;
		Statement commitSqlId = null;
		String x = null;
		String db2owner = null;
		int i = 0;
		
		String userDb = sybil.common.util.PropertyBroker.getProperty("database.login","sybil");
		String pswdDb = sybil.common.util.PropertyBroker.getProperty("database.password","sybil");
		
		
		if( conn == null) {
			try {
				Class.forName(sybil.common.util.PropertyBroker.getProperty("database.driver", "Not Found"));
				conn = DriverManager.getConnection(sybil.common.util.PropertyBroker.getProperty("database.server", "Not Found"), userDb, pswdDb);

				//
				x = PropertyBroker.getProperty("database.driver", "Not Found").toLowerCase();
				i = x.indexOf("db2");
				if (!(i < 0)) {
					try {
						db2owner = PropertyBroker.getProperty("DB2OWNER","dtppsyup");
						setSqlId = conn.prepareStatement("set current sqlid = ?");
						setSqlId.setString(1, db2owner);
						setSqlId.execute();
						commitSqlId = conn.createStatement();
						commitSqlId.execute("commit");
					}
					catch (SQLException se) {
						if(se.getSQLState().equals("S1010")) {
						}
						else {
							LogWriter.writeLog(se);
							LogWriter.writeLog("Error: Set Current SqlId failed.");
							if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
								LogWriter.writeLog("Process terminating due to database/sql exception");
								System.exit(1);
							}
						}
					}
					catch (Exception e) {
						LogWriter.writeLog(e);
						LogWriter.writeLog("Error: Set Current SqlId failed.");
						if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
							LogWriter.writeLog("Process terminating due to database/sql exception");
							System.exit(1);
						}
					}
				}
			
			} 
			catch (Exception e) {
				sybil.common.util.LogWriter.writeLog(e);
				LogWriter.writeLog("Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
		
	return;
	}
		
	private static int magazineKey(String magazineCode){
		
		int magKey = 0;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT MAG_KEY, NAME  FROM " + sybMag + " WHERE MAG_CD = ? ";
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, magazineCode);
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			magKey  = (int)rs.getInt("MAG_KEY");
			magName = rs.getString("NAME");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Code Select error " + magazineCode);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectMag != null) {
				try {
					selectMag.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		return magKey;
	}


	
	public static synchronized void CreatePDF(Magazine mag){
		
		PreparedStatement selectcopyCnt = null;
		Document pobDoc = new Document(PageSize.LETTER,20,20,20,20);
		String saverollNum = "  ";
		boolean firstRow = true;	
		boolean firstTime = true;
		int [] tablehw = {9,2,9,2,9,2,9};
		
		String magCode = mag.getMagCode().trim();
		String issueNum = mag.getIssue().trim();
		String issueWeek = mag.getWeek().trim();
		String plantId = mag.getPlant().toUpperCase().trim();
		
		String RptPath = sybil.common.util.PropertyBroker.getProperty("NewPDFReportsPath","Not found");
		String fileName = magCode.toLowerCase() + ".i" + issueNum + "." + plantId + ".OMS_Postal_Book." + issueWeek;
		
		open();
		                     
		String SQL  = "SELECT ROLL_NUM, XSHT_BV_NME, BOOK_NUM, DRVR_CD"
		    + " FROM  " + postalbookTableName                  
	        + " WHERE  MAG_KY = ? AND INSTNC_CD = ? AND MAG_CD = ? AND PLANT_ID = ? AND ISS_NUM = ? and ISS_WK_NUM = ? "
	        + "ORDER BY ROLL_NUM, XSHT_BV_NME";
		
		
		int magKey = magazineKey(magCode);
		
		String instCd = InstanceCd.getInstCd(magKey, toNum.toNumber(issueNum), toNum.toNumber(issueWeek));
		
		try {
			
			PdfWriter writer = PdfWriter.getInstance(pobDoc,				
					new FileOutputStream(RptPath + fileName + ".pdf"));
			

			writer.setViewerPreferences(PdfWriter.PageModeFullScreen);
			writer.setPageEvent(new PostalBook());
			
			pobDoc.open();
			
			Date toDay = new Date(); 
			SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, MMM d, yyyy, HH:mm a "); 
			
			PdfPCell dummyCell = new PdfPCell(new Phrase("", FontFactory.getFont(
					FontFactory.COURIER, 10, Font.NORMAL, Color.black)));
			dummyCell.setBorderWidth(0);
			
			
			PdfPTable outertable = new PdfPTable(1);
			outertable.setHeaderRows(9);
			
			PdfPCell header0 = new PdfPCell(new Phrase(String.valueOf(dateFormat.format(toDay)),
					FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,
							Color.black)));
			header0.setBorderWidth(0);
			outertable.addCell(header0);
			
			PdfPCell cell1 = new PdfPCell(new Phrase("Postal Book Report", FontFactory.getFont(
							FontFactory.TIMES_ROMAN, 24, Font.NORMAL, Color.BLACK)));
			cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell1.setBorderWidth(0);
			outertable.addCell(cell1);
	
			outertable.addCell(dummyCell);
			
			selectcopyCnt = conn.prepareStatement(SQL);
			selectcopyCnt.setInt(1, magKey);
			selectcopyCnt.setString(2, instCd);
			selectcopyCnt.setString(3, magCode);
			selectcopyCnt.setString(4, plantId);
			selectcopyCnt.setInt(5, toNum.toNumber(issueNum));
			selectcopyCnt.setInt(6, toNum.toNumber(issueWeek));

			resultset = selectcopyCnt.executeQuery();
			
			while (resultset.next()){
				
			if (firstRow) {
							
				String header1 = "       " + magName.trim()  + "           " + issueNum + " - " + issueWeek  + "     USPS" ;
				PdfPCell magCell = new PdfPCell(new Phrase(header1,
						FontFactory.getFont(FontFactory.TIMES_ROMAN, 16, Font.NORMAL,Color.black)));
				magCell.setHorizontalAlignment(Element.ALIGN_CENTER);
				magCell.setBorderWidth(0);
				outertable.addCell(magCell);
				
				for ( int G = 0; G <2; G++)outertable.addCell(dummyCell);
				
				
				PdfPTable headerTable = new PdfPTable(7);
				headerTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				headerTable.setWidths(tablehw);
				headerTable.addCell(new Phrase("Roll",TIMESBOLD_12));
				headerTable.addCell(new Phrase("",TIMESNORAML_12));
				headerTable.addCell(new Phrase("Edition",TIMESBOLD_12));
				headerTable.addCell(new Phrase("",TIMESNORAML_12));
				headerTable.addCell(new Phrase("Driver Code",TIMESBOLD_12));
				headerTable.addCell(new Phrase("",TIMESNORAML_12));
				headerTable.addCell(new Phrase("Postal Book#",TIMESBOLD_12));
				
				PdfPCell headerCell = new PdfPCell(headerTable);
				headerCell.setBorderWidth(0);
				outertable.addCell(headerCell);
							
				for ( int G = 0; G <=2; G++)outertable.addCell(dummyCell);
									
				firstRow = false;
				}				
			
			String rollNum = resultset.getString("ROLL_NUM");
			String edition = resultset.getString("XSHT_BV_NME");
			String driverCode = resultset.getString("DRVR_CD");
			String postalBk = resultset.getString("BOOK_NUM"); 
			 	
			if (rollNum.compareTo(saverollNum) == 0){
				
				rollNum = "";
				
				PdfPTable detailTable = new PdfPTable(7);
				detailTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				detailTable.setWidths(tablehw);
				detailTable.addCell(new Phrase(rollNum,TIMESNORAML_12));
				detailTable.addCell(new Phrase("",TIMESNORAML_12));
				String editionDisp = AddSpace.addSpace(edition,4,'0') +"";				
				detailTable.addCell(new Phrase(editionDisp,TIMESNORAML_12));
				detailTable.addCell(new Phrase("",TIMESNORAML_12));
				String dCodeDisp = AddSpace.addSpace(driverCode,3,' ')  + "";
				detailTable.addCell(new Phrase(dCodeDisp,TIMESNORAML_12));
				detailTable.addCell(new Phrase("",TIMESNORAML_12));
				String pBookeDisp = AddSpace.addSpace(postalBk,4,' ')  + "";
				detailTable.addCell(new Phrase(pBookeDisp,TIMESNORAML_12));
				
				PdfPCell headerCell = new PdfPCell(detailTable);
				headerCell.setBorderWidth(0);
				outertable.addCell(headerCell);
				
			} else {
			     saverollNum = rollNum;	
			     if (firstTime){
				     firstTime = false;	
	      		 }
			     else{
			    	 for ( int G = 0; G <=2; G++){
							outertable.addCell(dummyCell);}
			     }	 
			    	 PdfPTable detailTable = new PdfPTable(7);
					 detailTable.getDefaultCell().setBorder(Rectangle.NO_BORDER | Rectangle.TOP);
					 detailTable.setWidths(tablehw);
					 String rollNumDisp = AddSpace.addSpace(rollNum,3,'0')  + "";
					 detailTable.addCell(new Phrase(rollNumDisp,TIMESNORAML_12));
					 detailTable.addCell(new Phrase("",TIMESNORAML_12));
					 String editionDisp = AddSpace.addSpace(edition,4,'0') +"";
					 detailTable.addCell(new Phrase(editionDisp,TIMESNORAML_12));
					 detailTable.addCell(new Phrase("",TIMESNORAML_12));
					 String dCodeDisp = AddSpace.addSpace(driverCode,3,' ')  + "";
					 detailTable.addCell(new Phrase(dCodeDisp,TIMESNORAML_12));
					 detailTable.addCell(new Phrase("",TIMESNORAML_12));
					 String pBookeDisp = AddSpace.addSpace(postalBk,4,' ')  + "";
					 detailTable.addCell(new Phrase(pBookeDisp,TIMESNORAML_12));
					 	
					 PdfPCell headerCell = new PdfPCell(detailTable);
					 headerCell.setBorderWidth(0);
					 outertable.addCell(headerCell);
			}
		}
			pobDoc.add(outertable);
		}	
		catch (SQLException se) {
			System.err.println(se.getMessage());
		}
	
		catch (DocumentException de) {
			System.err.println(de.getMessage());
		} catch (IOException ioe) {
			System.err.println(ioe.getMessage());
		} finally {
			if (resultset != null) {
				try {
					resultset.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectcopyCnt != null) {
				try {
					selectcopyCnt.close();
				} catch (SQLException e) { /* ignored */}
			}
		}	
		pobDoc.close();
	}	

}
