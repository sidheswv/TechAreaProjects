package com.pdf.report;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import sybil.common.model.Magazine;
import sybil.common.persistence.ZipFilePersistent;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;

public class RollInfoInterface {

	public static String sybMag = "TBA_SYB_MAGAZINE";

	public static String magazineInf = "TBA_MAGAZINEINF";

	public static String magInfo = "TBA_MAG_INFO";
	
	public static String intefaceCntl = "TBA_INTER_FILE_CNTL";

	private static Connection conn = null;
	
	private static void open() {

		PreparedStatement setSqlId = null;
		Statement commitSqlId = null;
		String x = null;
		String db2owner = null;
		int i = 0;
		
		String userDb = sybil.common.util.PropertyBroker.getProperty("database.login","sybil");
		String pswdDb = sybil.common.util.PropertyBroker.getProperty("database.password","sybil");
		
		
		if( conn == null) {
			try {
				Class.forName(sybil.common.util.PropertyBroker.getProperty("database.driver", "Not Found"));
				conn = DriverManager.getConnection(sybil.common.util.PropertyBroker.getProperty("database.server", "Not Found"), userDb, pswdDb);

				//
				x = PropertyBroker.getProperty("database.driver", "Not Found").toLowerCase();
				i = x.indexOf("db2");
				if (!(i < 0)) {
					try {
						db2owner = PropertyBroker.getProperty("DB2OWNER","dtppsyup");
						setSqlId = conn.prepareStatement("set current sqlid = ?");
						setSqlId.setString(1, db2owner);
						setSqlId.execute();
						commitSqlId = conn.createStatement();
						commitSqlId.execute("commit");
					}
					catch (SQLException se) {
						if(se.getSQLState().equals("S1010")) {
						}
						else {
							LogWriter.writeLog(se);
							LogWriter.writeLog("Error: Set Current SqlId failed.");
							if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
								LogWriter.writeLog("Process terminating due to database/sql exception");
								System.exit(1);
							}
						}
					}
					catch (Exception e) {
						LogWriter.writeLog(e);
						LogWriter.writeLog("Error: Set Current SqlId failed.");
						if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
							LogWriter.writeLog("Process terminating due to database/sql exception");
							System.exit(1);
						}
					}
				}
			
			} 
			catch (Exception e) {
				sybil.common.util.LogWriter.writeLog(e);
				LogWriter.writeLog("Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
		
	return;
	}
	
	
	public static void close() {
		
		if( conn != null) {		
			try { conn.close(); }catch(Exception sql ){};
			conn = null;
		}
		return;
	}
	
	public static synchronized void generateInterfaceFile(Magazine mag) {
		
		boolean interFaceFile = false;
		
		String plantCode = mag.getPlant().toUpperCase();
		String magCode = mag.getMagCode().toUpperCase();
		
		interFaceFile = getInterfaceFileStatus(plantCode,magCode);
		if (interFaceFile){
			generateInterfaceFilezip(mag);
			LogWriter.writeLog(" Roll Info InterFace file Generated   ");
		}
		else{
			interFaceFile = getInterfaceFileStatus(plantCode,"XX");
			if (interFaceFile){
				generateInterfaceFilezip(mag);
				LogWriter.writeLog(" Roll Info InterFace file Generated   ");
			}
		}
		return;
	}
	
	private synchronized static boolean getInterfaceFileStatus(String plantCode, String magCode) {
		
		PreparedStatement selectIFC = null;
		ResultSet rsRioIfc = null;
		boolean generateInterfaceFile = false;
		
		open();
		
		String SQL = "Select INTER_FILE_IND, INTER_FILE_DESC FROM  " + intefaceCntl
				+ " WHERE PLANT_ID = ? AND MAG_CD = ? AND INTER_FILE_CD = 'RIO' ";
		
		try {
			
			String ifcInd = null;
			selectIFC = conn.prepareStatement(SQL);
			selectIFC.setString(1, plantCode);
			selectIFC.setString(2, magCode);
			
			rsRioIfc = selectIFC.executeQuery();
			
			while (rsRioIfc.next()){
				ifcInd = rsRioIfc.getString("INTER_FILE_IND");
				if (ifcInd.equals("Y"))
					generateInterfaceFile = true;
				else
					generateInterfaceFile = false;
			}
			rsRioIfc.close();
		} 
		catch (SQLException se) {
			LogWriter.writeLog(se);
		}
		return generateInterfaceFile;
	}

	

	private synchronized static void generateInterfaceFilezip(Magazine mag) {
		
		
		PreparedStatement rollInfoPS = null;
		ResultSet resultset = null;
				
		String magCode = mag.getMagCode().trim();
		String issueNum = mag.getIssue().trim();
		String issueWeek = mag.getWeek().trim();
		String plantId = mag.getPlant().toUpperCase().trim();
		
		String interFaceFilePath = sybil.common.util.PropertyBroker.getProperty("NEW_IFF_PATH","Not found");
		String fileName = interFaceFilePath.concat(magCode.toUpperCase() + "." + issueNum + "." + plantId + ".RollInfo." + issueWeek + ".txt");
		
		LogWriter.writeLog("File Name is --- " + fileName);
		
		open();
		
		String rollInfoInterfaceSql = " SELECT PLANT as PLANT_ID, MAG as MAG_CD, ISSUE as ISSUE_NUM, WEEK_NUM as WEEK, UPPER(DELIVERY_TYPE) AS DELIVERY_TYPE, UPPER(PROCESS_TYPE) AS PROCESS_TYPE, UPPER(DATA_TYPE) AS DATA_TYPE, "
								  + "  BRACEID as BRACE_ID, DOP_ID, ROLLID as ROLL_ID, COPY_CNT " 
								  + " FROM " + magInfo
								  + " WHERE  PLANT = ? AND MAG = ? AND ISSUE = ? AND WEEK_NUM = ? AND DATA_TYPE = 'cust'   "
								  + " ORDER BY BRACEID, DELIVERY_TYPE, PROCESS_TYPE, DATA_TYPE, ROLLID  ";
		            
			
		String s = null;
		PrintWriter outputFile = null;
		File f = null;
		
		try {

			rollInfoPS = conn.prepareStatement(rollInfoInterfaceSql);
			rollInfoPS.setString(1, plantId);
			rollInfoPS.setString(2, magCode);
			rollInfoPS.setString(3, issueNum);
			rollInfoPS.setString(4, issueWeek);
						
			resultset = rollInfoPS.executeQuery();
				
			ResultSetMetaData rsmd = resultset.getMetaData();
			int colcount = rsmd.getColumnCount();

			String outputFileName = fileName.trim();
			
			f = new File(outputFileName);

			outputFile = new PrintWriter(new OutputStreamWriter(new FileOutputStream(f),"ASCII"));				

			String s1 = rsmd.getColumnName(1) + '\u0009';

			for(int colnames=2; colnames<=colcount; colnames++){
				s1 = s1 + rsmd.getColumnName(colnames) + '\u0009';
			}

			s1 = s1 + "\n";

			outputFile.print(s1);
				
			while (resultset.next()) {
				
				s = resultset.getString(1) + '\u0009';
					int i=2;
					for(; i<colcount; i++){
						s = s + resultset.getObject(i) + '\u0009';
					}
				s = s + resultset.getObject(i) ;
				s = s +"\n";
				outputFile.print(s);
			}
			resultset.close();
			rollInfoPS.close();
			outputFile.close();

		ZipFilePersistent zp = new ZipFilePersistent(outputFileName.substring(0,outputFileName.length()-3).concat("zip"));
		zp.addFile(f);
		zp.closeZipfile();
		close();
			
		}
		catch (SQLException se) {
			se.printStackTrace();
			LogWriter.writeLog(se);
		}
		catch (Exception e) {
			e.printStackTrace();		
			LogWriter.writeLog(e);
		}finally{
			if(f.exists())
			f.delete();
		}
	}
}
