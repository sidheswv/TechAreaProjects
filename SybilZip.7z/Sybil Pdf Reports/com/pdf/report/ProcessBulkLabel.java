package com.pdf.report;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream; 

import sybil.common.model.IssueCustomer;
import sybil.common.model.Magazine;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;
import sybil.common.util.StringFunctions;
import sybil.common.util.SybilIssueCustomerFileParser;
import sybil.common.util.SybilWarningException;

import com.report.text.Chunk;
import com.report.text.Document;
import com.report.text.DocumentException;
import com.report.text.Element;
import com.report.text.Font;
import com.report.text.FontFactory;
import com.report.text.HeaderFooter;
import com.report.text.Image;
import com.report.text.PageSize;
import com.report.text.Phrase;
import com.report.text.Rectangle;
import com.report.text.pdf.ColumnText;
import com.report.text.pdf.PdfContentByte;
import com.report.text.pdf.PdfPCell;
import com.report.text.pdf.PdfPTable;
import com.report.text.pdf.PdfWriter;

public class ProcessBulkLabel {
	
	
	private Magazine magazine = null;
	
	private static final float H = 3.54f * 72;
	private static final float W = 3.6f * 72;
	private static final float LRM = .005f * 72; 
	private static final float TBM = .0002f * 72;
	private static final float GAP = .56f * 72;
	
	private Document bulkLabelDoc = null;
	
	private ColumnText ct = null;
	private PdfContentByte cb = null;
	private PdfWriter writer = null;
	private PdfPTable table = null;
	

	
	private float ACROSS = 0;
	private float DOWN = 0;
	
	public static String nl = System.getProperty("line.separator");
    
	private int counter = 0;
	private float [] COLS ;
  
	private String magCode = null;
	private String plantId = null;
	private String issueNum = null;
	private String issueWeek = null;
	private String deliveryType = null;
	private String processType = null;
	private String theDeliveryType = null;
	private String dataType = null;

	private int errorCtr = 0;
	private int ctr = 0;
	
	private static StringBuffer addSpace(String strValue,int numLen,char padValue){
		StringBuffer str = new StringBuffer(strValue);
		
		int num = numLen - str.length();
	
		for (int j=0;j<=num;j++){	
			str = str.insert(j, padValue);
		}
		return str;
	}
	
	private void reportHeader(){
		
		Date toDay = new Date(); 
		SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, MMM d, yyyy, HH:mm a ");

		String titleMag = "   " + String.valueOf(dateFormat.format(toDay)) + "  Magazine : " + magCode + " Issue : " + issueNum + " - " + issueWeek + "   Plant Id : " + plantId ;
		HeaderFooter header = new HeaderFooter(new Phrase(titleMag,FontFactory.getFont(FontFactory.COURIER, 12, Font.BOLD, new Color(255, 0, 0))), false);
        header.setBorderWidth(0);
       	bulkLabelDoc.setHeader(header);
	}
	
	private void init (){
		
		cb = writer.getDirectContent();  

        ct = new ColumnText(cb); 
        ct.setSimpleColumn(50, PageSize.LETTER.getHeight()-20, 50, PageSize.LETTER.getWidth(), 0, Element.ALIGN_LEFT);

        ACROSS = ( PageSize.LETTER.getWidth() - (LRM * 2) ) / W;  
        ACROSS -= ACROSS % 1; 

        DOWN = ( PageSize.LETTER.getHeight() - (TBM * 2) ) / H; 
        DOWN -= DOWN % 1;  

        COLS = new float [(int)ACROSS + 1 + ((int)ACROSS)];

        float cols = 0;  

        table = new PdfPTable ( COLS.length );
        table.getDefaultCell().setBorder(Rectangle.NO_BORDER);

        for (int i = 0; i < COLS.length; i++){
            if (i == 0 || i == COLS.length-1) {
                COLS[i] = LRM;
                cols += LRM;
                continue;
            }       
            if ((i+1) % 2 != 0 && i != COLS.length-1){  //if odd its a gap

                COLS[i] = GAP;
                cols += GAP;
                continue;
            }else {
                COLS[i] = W;
                cols += W;
                continue;
            }
        }
        try {
        	
            table.setTotalWidth(cols);  //tried removing this, not good
            table.setWidths(COLS);
            table.setLockedWidth(true);

            table.getDefaultCell().setPaddingBottom(0.0f);
            table.getDefaultCell().setPaddingTop(0.0f);

        } catch (DocumentException ex) {
        	LogWriter.writeLog(ex);
        }

		
	}
	
	private void finish(){
		if (counter < ACROSS){

	        for (int i = counter; i < ACROSS ; i++){

	            table.addCell("");
	            table.addCell("");
	            counter++;

	        }

	            table.addCell("");  //last cell

	        }
        try {  //this could actually be put in finnish()

        		bulkLabelDoc.add(table);
             } catch (DocumentException ex) {
            	 LogWriter.writeLog(ex);			
		}
        
	}
	

	public static synchronized void ProcessBulkLabelReport(Magazine mag){

		ProcessBulkLabel p1= new ProcessBulkLabel();
		ZipFile zf = null;
		ZipInputStream zis = null;
		ZipInputStream zisf = null;
		BufferedReader bfr = null;
		InputStreamReader isr = null;
		p1.errorCtr = 0;
		p1.ctr = 0;
		p1.magazine = mag;
		p1.ACROSS = 0;p1.DOWN = 0;p1.counter = 0;
		
		p1.bulkLabelDoc = new Document(PageSize.LETTER,0,0,9,0);
		
		p1.magCode = mag.getMagCode().trim();
		p1.issueNum = mag.getIssue().trim();
		p1.plantId = mag.getPlant().toUpperCase().trim();
		p1.issueWeek = mag.getWeek().trim();
		p1.processType = mag.getProcessType().toUpperCase().trim();
		p1.deliveryType = mag.getDeliveryType().toUpperCase().trim();
		
		String RptPath = sybil.common.util.PropertyBroker.getProperty("NewPDFReportsPath","Not found");
		String fileName = p1.magCode.toLowerCase() + ".i" + p1.issueNum + "." + p1.plantId + ".OMS_PSBulk_Label." + p1.issueWeek + "." + p1.deliveryType + "." + p1.processType;
		
		String destDir = (PropertyBroker.getProperty("ProcessInputFileDirPSB"));

		File newFile = new File((destDir) + p1.magazine.getFileName());
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(newFile);
		} catch (FileNotFoundException e) {
			LogWriter.writeLog("Error in FileInputStream zip file <" + newFile + "> in directory <" + destDir + ">");
			e.printStackTrace();
		}

		LogWriter.writeLog("Started processing zip file <" + newFile + "> in directory <" + destDir + ">");
		
		try {
			p1.writer = PdfWriter.getInstance(p1.bulkLabelDoc, new FileOutputStream(RptPath + fileName + ".pdf"));
			if(p1.writer==null){
       			LogWriter.writeLog("Writer not open in ProcesBulkLabel");
     			LogWriter.writeLog("Process terminating due to PdfWriter error");
       			System.exit(1);					
			}
			else {
				p1.writer.open();
			}
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        
        p1.reportHeader();
       	p1.bulkLabelDoc.open();
       	if (p1.bulkLabelDoc.isOpen())
            p1.init();
       	else
       	{
       		LogWriter.writeLog("Document not open in ProcesBulkLabel");
     		LogWriter.writeLog("Process terminating due to document exception");
       		System.exit(1);
        }
       	LogWriter.writeLog("newFile="+newFile);
 //  new start     **************************
    	// This delay is introduced to avoid zip file read issues
       	int waitInterval = 0;
    	String sleepVal = PropertyBroker.getProperty("BulkLabelZipFileSleepValue");
    	if (sleepVal == null) 
    	{
    		waitInterval = 60000;
    	} 
    	else 
    	{
    		try 
    		{
    			waitInterval = Integer.parseInt(sleepVal);
    		} 
    		catch (NumberFormatException ex) 
    		{
    			LogWriter.writeLog(ex);
    			waitInterval = 60000;
    		}
    	}

        try {
			zis = new ZipInputStream(new BufferedInputStream(fis));
			if (PropertyBroker.getProperty("MVS", "true").equals("true")) {
				LogWriter.writeLog("Creating InputStreamReader using ASCII mode of zipfile: " + newFile );
				isr = new InputStreamReader(zis, "ASCII");
			}
			else {
				LogWriter.writeLog("Creating InputStreamReader using default mode of zipfile: " + newFile );
				isr = new InputStreamReader(zis);
			}
				
			bfr = new java.io.BufferedReader(isr);

			ZipEntry entry;
			while (((entry = zis.getNextEntry()) != null)) {
				LogWriter.writeLog("Starting processing InputStreamReader of zipfile: " + newFile + isr +" for member " + entry.getName());

				String data = entry.getName().toLowerCase().trim();

				boolean test =true ;
				
				try {
					 test = Float.valueOf(data).isNaN();
				    }
				catch(Exception ex) {
					continue;		  
		  		}
				
				LogWriter.writeLog("Processing InputStreamReader of zipfile: " + newFile + isr +" for member " + data);
				if((!data.equals("9999") && (!test) ) ) { // if loop to fix the issue - start
						if( p1.magazine.isBulkLabels() && (!data.equals("9999") && (!test) ) ) {
							LogWriter.writeLog("processing " + data +" member of zipFile: " + newFile + " : member = "+ data);
							p1.ctr += p1.createBulkLabel(bfr);
							LogWriter.writeLog("After calling p1 create Bulklables of zipfile: " + newFile + " : member = "+ data);
					 }
	
				} // if loop to fix the issue - end
			} // while
			// Close the current entry of the zip file.
			try {
				if(isr != null) {
					LogWriter.writeLog("Closing InputStreamReader of zipfile: " + newFile +":"+ isr );
					isr.close();
				}					
				if(bfr != null) {
					LogWriter.writeLog("Closing BufferedReader of zipfile: " + newFile +":"+  bfr );
					bfr.close();
				}
				if(zis != null) {
					LogWriter.writeLog("Closing InputStream using of zipfile: " + newFile +":"+  zis );
					zis.close();
				}					
			}
			catch (Exception ex) {
				LogWriter.writeLog(ex);
			}	

			p1.finish();
		} // try
        
        

	catch (Exception ex) {
			LogWriter.writeLog(new Exception ("Error on zip file <" + newFile + ">"));
			if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
				LogWriter.writeLog(ex);
				LogWriter.writeLog("Process terminating due error");
				ex.printStackTrace();
				System.exit(1);
			}
		}
	
	LogWriter.writeLog(p1.magazine.getPrefix() + ": Bulk Labels Porcessed :  <" + (p1.ctr) + "> records.. Errors " + p1.errorCtr);

	if (p1.errorCtr > 0) {
		if (PropertyBroker.getProperty("TblLoadTrk", "false").equals("true")) {
			
		}
		if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
			LogWriter.writeLog("Process terminating due to database/sql exception");
			System.exit(1);
		}
	}
	p1.bulkLabelDoc.close();
	try {
	zf.close();
	
	}catch(Exception ioe){};

	if (p1.ctr == 0) {
		File createFile = new File(RptPath, fileName + ".pdf");
		LogWriter.writeLog(" No Bulk label for : " + createFile);
		if (createFile.exists()){
			LogWriter.writeLog(" The file is : " + createFile + "exists");
			createFile.delete();
		}
	}
        
	}
        
	
	private synchronized int createBulkLabel(BufferedReader rdr){
		
		
		String aRec = null;
		IssueCustomer rec = new IssueCustomer();	
		
		String line1 = null;
		String line2 = null;
		String line3 = null;
		String line4 = null;
		String line5 = null;
		String line6 = null;

		String newCity = null;
	    
		

	
	/******************************************************************************
	******* START OF THE PROCESSING FOR FOREIGN USPS AND CAN LABELS ***************
	******************************************************************************/

			
			
			try {
									
			while (!((aRec = rdr.readLine()) == null)) {

				ctr++;
				String newCtr = null;
				int labelCount = ctr;
				Integer labelCountobj = new Integer(labelCount);
				newCtr = labelCountobj.toString();
				
				String labelCounter = new String(StringFunctions.fixSize(newCtr,5,'0',StringFunctions.RIGHT));
				
				
				if( aRec.trim().length() == 0)
					continue;
					
				if (aRec.length() < 9) continue;
				SybilIssueCustomerFileParser syb = new SybilIssueCustomerFileParser();
				syb.parseString(aRec, rec);
			
		/* Retrieve all the data for the table through Issue Customer Via the abstract 
			  Class MagazineLabel.	

		*/
				// Foreign
				String pubCode = rec.getMagazineLabel().publicationCode.toUpperCase();					
				String theKeyLine = rec.getMagazineLabel().acsKeyline.toUpperCase();
				String theLabelMagID = rec.getMagazineLabel().magCode.toUpperCase();
				String theContCode = rec.getMagazineLabel().continentID.toUpperCase();
				String theEditionCode = rec.getMagazineLabel().editionCode.toUpperCase();
				String theExpDate = rec.getMagazineLabel().alphaExpireDate.toUpperCase();
				String theCustName = rec.getMagazineLabel().customerName.toUpperCase();
				String theMakeupCode = rec.getMagazineLabel().makeupCode.toUpperCase();
				boolean theEndPackageIndicator = rec.getMagazineLabel().endOfPackageIndicator;
				String theAddLine2 = rec.getMagazineLabel().addressLine2.toUpperCase();			    
				boolean theEndPalletSackIndicator = rec.getMagazineLabel().endofPalletSackIndicator;
				String theAddLine1 = rec.getMagazineLabel().addressLine1.toUpperCase();
				String thePalletSackIndicator = rec.getMagazineLabel().palletSackIndicator.toUpperCase();
				String thePalletSackNumber = rec.getMagazineLabel().palletSackNumber;
				String theCity = rec.getMagazineLabel().city.toUpperCase();
				String numOfCopies = rec.getMagazineLabel().numberOfCopies;
				String bookVersion = rec.getMagazineLabel().bookVersion;
				String geoComboNme = rec.getMagazineLabel().GeoComboName;
				
				
				String theState = rec.getMagazineLabel().state.toUpperCase();	
				String theUSZip = rec.getMagazineLabel().USzipCode.toUpperCase();
				String zipPlus4 = rec.getMagazineLabel().zipPlus4.toUpperCase();
				String theBarCode = rec.getMagazineLabel().barcode.toUpperCase();
				String theEndLine = rec.getMagazineLabel().endorsementLine.toUpperCase();
				String ImbBarcodeData = rec.getMagazineLabel().imbBarcodeData;
		
//	******** Redefine the fields to fill with spaces or zeros ************//

				String thePSNumber = new String(StringFunctions.fixSize(thePalletSackNumber,5,'0',StringFunctions.RIGHT));
				String keyLine = new String(StringFunctions.fixSize(theKeyLine,19,' ',StringFunctions.LEFT));
				String CustName = new String(StringFunctions.fixSize(theCustName,30,' ',StringFunctions.LEFT));
				String addLine2 = new String(StringFunctions.fixSize(theAddLine2,30,' ',StringFunctions.LEFT));
				String addLine1 = new String(StringFunctions.fixSize(theAddLine1,30,' ',StringFunctions.LEFT));	
				
				
				
//				********* Fields used in the Magazine Label for CAN ONLY**********************//

				String theCanCarrierLiteral = rec.getMagazineLabel().canadianCarrierLiteral.toUpperCase();
				String theCanNonDirect = rec.getMagazineLabel().canadianNonDirect.toUpperCase();
				String theCarrierRtNum = rec.getMagazineLabel().carrierRouteNumber.toUpperCase();
				String theCanMonthCode = rec.getMagazineLabel().canadianMonthCode.toUpperCase();
				String theCanZip = rec.getMagazineLabel().canadianZipCode.toUpperCase();
				String thePkgNum = rec.getMagazineLabel().packageNumber.toUpperCase();
				String OEL = rec.getMagazineLabel().canadianOEL.toUpperCase();
				String CanadaOEL = new String(StringFunctions.fixSize(OEL,38,' ',StringFunctions.LEFT));
	
//********* Special breakdown of Fields for CAN label Use **********************//
	
				String buf = new String(StringFunctions.fixSize(thePkgNum,6,'0',StringFunctions.RIGHT));
				String canCarLiteral = new String(StringFunctions.fixSize(theCanCarrierLiteral,2,' ',StringFunctions.RIGHT));
				String canNonDir = new String(StringFunctions.fixSize(theCanNonDirect,2,' ',StringFunctions.RIGHT));
				String rtNum = new String(StringFunctions.fixSize(theCarrierRtNum,4,' ',StringFunctions.RIGHT));
				String canZip = new String(StringFunctions.fixSize(theCanZip,6,' ',StringFunctions.LEFT));
				String theNewCity = new String(StringFunctions.fixSize(theCity,20,' ',StringFunctions.LEFT));
				
				
		

//	******************  Start of Label lines  ***************************//
				
				
				String endPackInd = " ";
				if 	(theEndPackageIndicator)
					endPackInd = "#";
				else
					endPackInd = " ";
				

				if (deliveryType.equals("BLKFORGN")){
					newCity = new String(StringFunctions.fixSize(theCity,35,' ',StringFunctions.LEFT));
				
				    line1 = addSpace(pubCode,5,' ') + " " + addSpace(" ",50,' ');
				    
				    line4 = addLine2 + "  " +  "#" + addSpace(labelCounter,4,'0') + endPackInd;
				    
				    line6 = addSpace(newCity,30, ' ') + " ";
				}
				
				
				if (deliveryType.equals("BLKUSPS")){
					newCity = new String(StringFunctions.fixSize(theCity,20,' ',StringFunctions.LEFT));
					
					line1 = addSpace(pubCode,5,' ') + "  " + "*********" + theEndLine;
					
					line4 = addLine2 + "  "  + "#" + addSpace(labelCounter,4,'0') + endPackInd;
					
					if (theBarCode != null && theBarCode.length() >0) 
						line6 =  newCity.trim() + " " + theState + " " + theUSZip + "-" + zipPlus4;
					else 
						line6 = newCity.trim() + ". " + theState + " " + theUSZip + "-" + zipPlus4;
					
				}	
				
				if (deliveryType.equals("BLKCAN") ){
					String newEndline = new String(StringFunctions.fixSize(theEndLine,10,' ',StringFunctions.LEFT));
				    line1 = buf.substring(0,2) + "/" + buf.substring(2,6) + " " + newEndline + " " + canCarLiteral + " " + canNonDir + " " + rtNum + "      " + "(" + theCanMonthCode + ")" + " ";
				    
				    line4 = addLine2 + "  " + addSpace(labelCounter,5,'0') + endPackInd;
				    
				    line6 = theNewCity.trim() + " " + theState + "  " +(canZip.substring(0,3)) + " " + (canZip.substring(3,6));
				}
				
				
				
				
				if (theLabelMagID.length() > 1) {
					line2 = addSpace(keyLine,15,' ') + "" + addSpace(theLabelMagID,1,' ') + addSpace(geoComboNme,2,' ') + addSpace(theEditionCode,8,' ') + addSpace(theExpDate,5,' ');	
				}
				else {
					line2 = addSpace(keyLine,16,' ') + "  " +  addSpace(theLabelMagID,2,' ') + addSpace(theContCode,2,' ') + addSpace(theEditionCode,7,' ') + addSpace(theExpDate,5,' ');
				}

				line3 = CustName + "   " + addSpace(theMakeupCode,4,' ');
				
				
				
				
				String psInd = " ";
				if (theEndPalletSackIndicator)
					psInd = "#";
				else
					psInd = " ";
				
				
				line5 = addLine1 + " "  + addSpace(thePalletSackIndicator,1,' ') + addSpace(thePSNumber,1,' ') + psInd;
				
				String temptext = null;
				if (deliveryType.equals("BLKCAN")){
					temptext = CanadaOEL + nl + line1 + nl + line2 + nl + line3 + nl + line4 + nl
					+ line5 + nl + line6;
				}
				else{
					temptext = nl + line1 + nl + line2 + nl + line3 + nl + line4 + nl
					+ line5 + nl + line6;
				}

				
				String text = nl+ "TCS                            " + nl+ "PO BOX 62270               PERIODICALS"+ nl 
		         + "TAMPA,FL  33662-2701                  "+ nl + nl + nl + nl + nl +nl
		         + addSpace(" ",10,' ') + addSpace(numOfCopies,3,' ') + addSpace("COPIES",6,' ')
		         + nl 
		         + addSpace(" ",13,' ')+ addSpace(bookVersion,3,'0')
		         + nl
		         + nl+nl
		         + nl
		         + temptext; 
		          
	                 
				if (deliveryType.equals("BLKUSPS")){
					String textUSPS1 = nl+ "TCS                            " + nl+ "PO BOX 62270               PERIODICALS"+ nl 
			         + "TAMPA,FL  33662-2701                  "+ nl + nl + nl
			         + addSpace(" ",10,' ') + addSpace(numOfCopies,3,' ') + addSpace("COPIES",6,' ')
			         + nl 
			         + addSpace(" ",13,' ')+ addSpace(bookVersion,3,'0') + nl + nl + nl +nl;
					
					String textUSPS2 = nl + line1  + nl + line2 + nl + line3 + nl + line4 + nl +  line5 + nl + line6; 
					
					Image mg = Image.getInstance(IntelligentBarcode.createUspsIntelligentBarcode(ImbBarcodeData,cb));
					Phrase ph = null;
		            try {
		            	ph = new Phrase(textUSPS1, new Font (Font.COURIER, 10, Font.NORMAL));
		                ph.add(new Phrase(new Chunk(mg, 0, 0)));
		                ph.add(new Chunk(textUSPS2, new Font (Font.COURIER, 10, Font.NORMAL)));
		            } catch (Exception e) {
		            	LogWriter.writeLog(e);
		            	LogWriter.writeLog("ProcessBulkLabel -- Error in Phrase : " + text);
		            }
					
					PdfPCell cell = new PdfPCell(ph);
					cell.setFixedHeight(H);

			        cell.setNoWrap(true);

			        cell.setVerticalAlignment(Element.ALIGN_LEFT);
			        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			        cell.setBorder(Rectangle.NO_BORDER);  

			        counter++;  

			        table.addCell("");
			        table.addCell(cell);
				} else {
					PdfPCell cell = new PdfPCell();

			        cell = new PdfPCell (new Phrase(text, new Font (Font.COURIER, 10, Font.NORMAL)));
			        cell.setFixedHeight(H);

			        cell.setNoWrap(true);

			        cell.setVerticalAlignment(Element.ALIGN_LEFT);
			        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			        cell.setBorder(Rectangle.NO_BORDER);  

			        counter++;

			        table.addCell("");
			        table.addCell(cell);
				}
				
				if (counter == ACROSS) table.addCell("");  //at the end
				
				if (counter == ACROSS) counter = 0;  //if at the end reset the counter
				        
				
			}  // End of Read ....
			
			}	
			catch(Exception e){
				SybilWarningException warning = new SybilWarningException(magazine.getPrefix() + ": Error processing CAN Backdate Labels.");
				LogWriter.writeLog(warning);
				LogWriter.writeLog(e);
				
			}
			return ctr;
	}

}
