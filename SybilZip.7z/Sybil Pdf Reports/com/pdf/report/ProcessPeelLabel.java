package com.pdf.report;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import sybil.common.model.IssueCustomer;
import sybil.common.model.Magazine;
import sybil.common.util.LogWriter;

import sybil.common.util.PropertyBroker;
import sybil.common.util.StringFunctions;
import sybil.common.util.SybilIssueCustomerFileParser;
import sybil.common.util.SybilWarningException;

import com.report.text.Chunk;
import com.report.text.Document;
import com.report.text.DocumentException;
import com.report.text.Element;
import com.report.text.Font;
import com.report.text.FontFactory;
import com.report.text.ExceptionConverter;
import com.report.text.Image;
import com.report.text.PageSize;
import com.report.text.Phrase;
import com.report.text.Rectangle;
import com.report.text.pdf.ColumnText;
import com.report.text.pdf.PdfContentByte;
import com.report.text.pdf.PdfPCell;
import com.report.text.pdf.PdfPTable;
import com.report.text.pdf.PdfWriter;
import com.report.text.pdf.PdfPageEventHelper;

public class ProcessPeelLabel {
	
	
	private static Magazine magazine = null;
	
	
	//private static final float H = 1.058f * 72;
	private static final float H = 1.05f * 72;
	private static final float W = 3.65f * 72;
	private static final float LRM = .004f * 72;  
	private static final float TBM = .00350f * 72;
	private static final float GAP = .86f * 72;
	
	private static Document peelLabelDoc = null;
	
	private static ColumnText ct = null;
	private static PdfContentByte cb = null;
	private static PdfWriter writer = null;
	private static PdfPTable table = null;
	private static PdfPTable imageTable = null;
	
	private static ZipFile zf = null;
	private static InputStream zis = null;
	private static BufferedReader bfr = null;
	private static InputStreamReader isr = null;
	private static InputStreamReader zipisr = null;
	
	private static float ACROSS = 0;
	private static float DOWN = 0;
	
	public static String nl = System.getProperty("line.separator");
    
	private static int counter = 0;
	private static int brkCount = 0;
	private static float [] COLS ;
  
	private static String magCode = null;
	private static String plantId = null;
	private static String issueNum = null;
	private static String issueWeek = null;
	private static String deliveryType = null;
	private static String processType = null;
	private static String theDeliveryType = null;
	private static String dataType = null;
	private static String theBindingGroupName = null;
	private static TableHeader event = null;
	
	private static int errorCtr = 0;
	private static int ctr = 0;
    
    static class TableHeader extends PdfPageEventHelper {
        /** The header text. */
        String myheader;
        /**
         * Allows us to change the content of the header.
         * @param header The new header String
         */
        public void setHeader(String myheader) {
            this.myheader = myheader;
        }
       
        /**
         * Adds a header to every page
         * @see com.itextpdf.text.pdf.PdfPageEventHelper#onEndPage(
         *      com.itextpdf.text.pdf.PdfWriter, com.itextpdf.text.Document)
         */
        public void onEndPage(PdfWriter writer, Document document) {
            PdfPTable table = new PdfPTable(1);
            try {
        		Date toDay = new Date(); 
        		SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yy HH:mm");
            	table.setWidths(new int[]{18});
                table.setTotalWidth(600);
                table.setLockedWidth(true);
                table.getDefaultCell().setFixedHeight(60);
                table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
                table.getDefaultCell().setVerticalAlignment(Element.ALIGN_TOP);
                String titleMag = ""+ String.valueOf(dateFormat.format(toDay)) + "    Mag:" + magCode + " Iss:" + issueNum + "-" + issueWeek + " Plant:" + plantId + "   " + myheader;
                table.addCell(new Phrase(titleMag,FontFactory.getFont(FontFactory.COURIER, 11.0f, Font.BOLD, new Color(255, 0, 0))));
                table.writeSelectedRows(0, -1, 22, 799, writer.getDirectContent());
            }
            catch(DocumentException de) {
                throw new ExceptionConverter(de);
            }
        }
        
    }
	private static synchronized StringBuffer addSpace(String strValue,int numLen,char padValue){
		StringBuffer str = new StringBuffer(strValue);
		
		int num = numLen - str.length();
	
		for (int j=0;j<=num;j++){	
			str = str.insert(j, padValue);
		}
		return str;
	}
	
	private static synchronized void init (){
		
		cb = writer.getDirectContent();  

        ct = new ColumnText(cb); 
        ct.setSimpleColumn(50, PageSize.LETTER.getHeight()-20, 50, PageSize.LETTER.getWidth(), 0, Element.ALIGN_LEFT);

        ACROSS = ( PageSize.LETTER.getWidth() - (LRM * 2) ) / W;  
        ACROSS -= ACROSS % 1; 

        DOWN = ( PageSize.LETTER.getHeight() - (TBM * 2) ) / H; 
        DOWN -= DOWN % 1;  

        COLS = new float [(int)ACROSS + 1 + ((int)ACROSS)];

        float cols = 0;  
       
        table = new PdfPTable ( COLS.length );
        table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        
        for (int i = 0; i < COLS.length; i++){
            if (i == 0 || i == COLS.length-1) {
                COLS[i] = LRM;
                cols += LRM;
                continue;
            }       
            if ((i+1) % 2 != 0 && i != COLS.length-1){  //if odd its a gap

                COLS[i] = GAP;
                cols += GAP;
                continue;
            }else {
                COLS[i] = W;
                cols += W;
                continue;
            }
        }
        try {
        	
        	table.setTotalWidth(cols);  //tried removing this, not good
            table.setWidths(COLS);
            table.setLockedWidth(true);

            table.getDefaultCell().setPaddingBottom(0.0f);
            table.getDefaultCell().setPaddingTop(0.0f);

        } catch (DocumentException ex) {
        	LogWriter.writeLog(ex);
        }

		
	}
	
	private static synchronized void finish(){
		if (counter < ACROSS){

	        for (int i = counter; i < ACROSS ; i++){

	            table.addCell("");
	            table.addCell("");
	            counter++;
	        }
	            table.addCell("");  
	        }
        try {  

        	peelLabelDoc.add(table);
        	theBindingGroupName = null;
        	
             } catch (DocumentException ex) {
            	 LogWriter.writeLog(ex);
             					
		}
	}
	private void bindingInit (){
		
        float cols = 0;  
       
        table = new PdfPTable ( COLS.length );
        table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        
        for (int i = 0; i < COLS.length; i++){
            if (i == 0 || i == COLS.length-1) {
                COLS[i] = LRM;
                cols += LRM;
                continue;
            }       
            if ((i+1) % 2 != 0 && i != COLS.length-1){  //if odd its a gap

                COLS[i] = GAP;
                cols += GAP;
                continue;
            }else {
                COLS[i] = W;
                cols += W;
                continue;
            }
        }
        try {
            table.setTotalWidth(cols);  //tried removing this, not good
            table.setWidths(COLS);
            table.setLockedWidth(true);

            table.getDefaultCell().setPaddingBottom(0.0f);
            table.getDefaultCell().setPaddingTop(0.0f);
        } catch (DocumentException ex) {
        	LogWriter.writeLog(ex);
        }

		
	}

	private void bindingFinish(){
		if (counter < ACROSS){

	        for (int i = counter; i < ACROSS ; i++){

	            table.addCell("");
	            table.addCell("");
	            counter++;
	        }
	            table.addCell("");  
	        }
        try {  

        	peelLabelDoc.add(table);

             } catch (DocumentException ex) {
            	 LogWriter.writeLog(ex);
             					
		}
	}
	
	public static synchronized void ProcessPeelLabelReport(Magazine mag){
		

		zf = null;
		zis = null;
		bfr = null;
		isr = null;
		zipisr = null;
		
		magazine = mag;
		
		magCode = mag.getMagCode().toUpperCase();
		plantId = mag.getPlant().toUpperCase();
		issueNum = mag.getIssue().toUpperCase();
		issueWeek = mag.getWeek().trim();
		deliveryType = mag.getDeliveryType().toUpperCase();
		processType = mag.getProcessType().toUpperCase();
		theDeliveryType = mag.getDeliveryType().toUpperCase();
		dataType = mag.getDataType().toUpperCase();
		
		ACROSS = 0;DOWN = 0;counter = 0;ctr=0;
		peelLabelDoc = new Document(PageSize.LETTER,0,0,22,0);
		
		String psThreshHold = (String)PropertyBroker.getProperty("psThreshHold");
		String RptPath = sybil.common.util.PropertyBroker.getProperty("NewPDFReportsPath","Not found");
		String fileName = magCode.toLowerCase() + ".i" + issueNum + "." + plantId + ".OMS_Peel_Labels." + issueWeek + "." + processType + "." + deliveryType;
		String destDir = null;

		if( magazine.isPeelLabels() || magazine.isBackDateLabel()){
			destDir = PropertyBroker.getProperty("PeelLabels","c:\\s\\sp\\data\\sybil\\planthome\\inputdata\\");
		}

		File newFile = new File((destDir) + magazine.getFileName());
		try {
            writer = PdfWriter.getInstance(peelLabelDoc, new FileOutputStream(RptPath + fileName + ".pdf"));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        
        event = new TableHeader();
        writer.setPageEvent(event);
                
        peelLabelDoc.open();
   
        init();
                
        int c = 0;
        try {
			zf = new ZipFile(newFile);
			java.util.Enumeration e = zf.entries();
		
			while (e.hasMoreElements()) {

				int customercount = 0;
				ZipEntry currZE = (ZipEntry) e.nextElement();
				String data = currZE.getName().toLowerCase().trim();
				zis = zf.getInputStream(currZE);
			 		
				if (PropertyBroker.getProperty("MVS", "false").equals("true")) {
					isr = new InputStreamReader(zis, "ASCII");
				}
				else {
					isr = new InputStreamReader(zis);
				}
				
				bfr = new java.io.BufferedReader(isr);
				
				boolean test =true ;
		
				try {
					 test = Float.valueOf(data).isNaN();
				    }
				catch(Exception ex) {
					continue;		  
		  		}
				if ( magazine.isBackDateLabel() && (!data.equals("9999"))) {
					if (!test) {
						while((c = bfr.read()) != -1) {
							if( c == '\n')
							customercount++;
						}
					}
					InputStream zipin = zf.getInputStream(currZE);
					if (PropertyBroker.getProperty("MVS", "false").equals("true")) {
						zipisr = new InputStreamReader(zipin, "ASCII");
					}
					else {
						zipisr = new InputStreamReader(zipin);
					}
					
					java.io.BufferedReader buf = new java.io.BufferedReader(zipisr);
					
					if( magazine.isBackDateLabel() && (customercount < Integer.valueOf(psThreshHold).intValue())  && (!data.equals("9999") && (!test) ) ) {
						new ProcessPeelLabel().createPeelLabel(buf);
					}
				}
				if (magazine.isPeelLabels() && (!data.equals("9999"))) {
					new ProcessPeelLabel().createPeelLabel(bfr);
				 }

				// Close the current entry of the zip file.
				try {
					bfr.close();
					zis.close();
					
				}
				catch (Exception ex) {
					LogWriter.writeLog(ex);
				}	
			} // while
			finish();
		} // try
		catch (Exception ex) {
			LogWriter.writeLog(new Exception ("Error on zip file <" + newFile + ">"));
			if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
				LogWriter.writeLog("Process terminating due error");
				System.exit(1);
			}
		}
		
    
	LogWriter.writeLog(magazine.getPrefix() + ": Peel Labels Processed  <" + (ctr - 1) + "> records.. Errors " + errorCtr);

	if (errorCtr > 0) {
		if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
			LogWriter.writeLog("Process terminating due to database/sql exception");
			System.exit(1);
		}
	}
	
	peelLabelDoc.close();

	try {
	zf.close();
	
	}catch(Exception ioe){};
	
	if (ctr == 0) {
		File createFile = new File(RptPath, fileName + ".pdf");
		LogWriter.writeLog(" No Peel label for : " + createFile);
		if (createFile.exists()){
			LogWriter.writeLog(" The file is : " + createFile + "exists");
			createFile.delete();
		}
	}
}
        
	
	private synchronized void createPeelLabel(BufferedReader rdr){
		
		
		String aRec = null;
		IssueCustomer rec = new IssueCustomer();	
		
		String line1 = null;
		String line2 = null;
		String line3 = null;
		String line4 = null;
		String line5 = null;
		String line6 = null;
		
		String newCity = null;
		
		String text = null;
	    

	/******************************************************************************
	******* START OF THE PROCESSING FOR FOREIGN USPS AND CAN LABELS ***************
	******************************************************************************/

			
			
			try {
				while (!((aRec = rdr.readLine()) == null)) {

					ctr++;
					String newCtr = null;
					int labelCount = ctr;
					Integer labelCountobj = new Integer(labelCount);
					newCtr = labelCountobj.toString();
					LogWriter.writeLog("ctr value in ProcessPeelLabel before " + ctr);
					if(ctr==1){
						brkCount = 0;
						theBindingGroupName = null;
					}
					String labelCounter = new String(StringFunctions.fixSize(newCtr,5,'0',StringFunctions.RIGHT));
					LogWriter.writeLog("ctr value in ProcessPeelLabel after: " + labelCounter);
					
					if( aRec.trim().length() == 0)
						continue;
						
					if (aRec.length() < 9) continue;
					SybilIssueCustomerFileParser syb = new SybilIssueCustomerFileParser();
					syb.parseString(aRec, rec);
					//new page title when binding group changes
					LogWriter.writeLog("Before theBindingGroupName Count=" + brkCount + " value=" + theBindingGroupName);
					if((theBindingGroupName != null) && !(theBindingGroupName.equals(rec.getBindingGroupName()))){
			        	brkCount++;
			        	bindingFinish();
						LogWriter.writeLog("Inside theBindingGroupName Count=" + brkCount + " value=" + theBindingGroupName);
						peelLabelDoc.newPage();
						bindingInit();
						counter = 0;
					}
			/* Retrieve all the data for the table through Issue Customer Via the abstract 
				  Class MagazineLabel.	

			*/
					// Foreign
					String pubCode = rec.getMagazineLabel().publicationCode.toUpperCase();					
					String theKeyLine = rec.getMagazineLabel().acsKeyline.toUpperCase();
					String theLabelMagID = rec.getMagazineLabel().magCode.toUpperCase();
					String theContCode = rec.getMagazineLabel().continentID.toUpperCase();
					String theEditionCode = rec.getMagazineLabel().editionCode.toUpperCase();
					String theExpDate = rec.getMagazineLabel().alphaExpireDate.toUpperCase();
					String theCustName = rec.getMagazineLabel().customerName.toUpperCase();
					String theMakeupCode = rec.getMagazineLabel().makeupCode.toUpperCase();
					boolean theEndPackageIndicator = rec.getMagazineLabel().endOfPackageIndicator;
					String theAddLine2 = rec.getMagazineLabel().addressLine2.toUpperCase();			    
					boolean theEndPalletSackIndicator = rec.getMagazineLabel().endofPalletSackIndicator;
					String theAddLine1 = rec.getMagazineLabel().addressLine1.toUpperCase();
					String thePalletSackIndicator = rec.getMagazineLabel().palletSackIndicator.toUpperCase();
					String thePalletSackNumber = rec.getMagazineLabel().palletSackNumber;
					String theCity = rec.getMagazineLabel().city.toUpperCase();
					
					
					String theState = rec.getMagazineLabel().state.toUpperCase();	
					String theUSZip = rec.getMagazineLabel().USzipCode.toUpperCase();
					String zipPlus4 = rec.getMagazineLabel().zipPlus4.toUpperCase();
					String theBarCode = rec.getMagazineLabel().barcode.toUpperCase();
					String theEndLine = rec.getMagazineLabel().endorsementLine.toUpperCase();
			
//		******** Redefine the fields to fill with spaces or zeros ************//

					String thePSNumber = new String(StringFunctions.fixSize(thePalletSackNumber,5,'0',StringFunctions.RIGHT));
					String keyLine = new String(StringFunctions.fixSize(theKeyLine,19,' ',StringFunctions.LEFT));
					String CustName = new String(StringFunctions.fixSize(theCustName,30,' ',StringFunctions.LEFT));
					String addLine2 = new String(StringFunctions.fixSize(theAddLine2,30,' ',StringFunctions.LEFT));
					String addLine1 = new String(StringFunctions.fixSize(theAddLine1,30,' ',StringFunctions.LEFT));	
					
					
					
//					********* Fields used in the Magazine Label for CAN ONLY**********************//

					String theCanCarrierLiteral = rec.getMagazineLabel().canadianCarrierLiteral.toUpperCase();
					String theCanNonDirect = rec.getMagazineLabel().canadianNonDirect.toUpperCase();
					String theCarrierRtNum = rec.getMagazineLabel().carrierRouteNumber.toUpperCase();
					String theCanMonthCode = rec.getMagazineLabel().canadianMonthCode.toUpperCase();
					String theCanZip = rec.getMagazineLabel().canadianZipCode.toUpperCase();
					String thePkgNum = rec.getMagazineLabel().packageNumber.toUpperCase();
					String OEL = rec.getMagazineLabel().canadianOEL.toUpperCase();
					String CanadaOEL = new String(StringFunctions.fixSize(OEL,38,' ',StringFunctions.LEFT));
					
					String ImbBarcodeData = rec.getMagazineLabel().imbBarcodeData;

						
//	********* Special breakdown of Fields for CAN label Use **********************//
		
					String buf = new String(StringFunctions.fixSize(thePkgNum,6,'0',StringFunctions.RIGHT));
					String canCarLiteral = new String(StringFunctions.fixSize(theCanCarrierLiteral,2,' ',StringFunctions.RIGHT));
					String canNonDir = new String(StringFunctions.fixSize(theCanNonDirect,2,' ',StringFunctions.RIGHT));
					String rtNum = new String(StringFunctions.fixSize(theCarrierRtNum,4,' ',StringFunctions.RIGHT));
					String canZip = new String(StringFunctions.fixSize(theCanZip,6,' ',StringFunctions.LEFT));
					String theNewCity = new String(StringFunctions.fixSize(theCity,20,' ',StringFunctions.LEFT));
					
					
			

//		******************  Start of Label lines  ***************************//
					
					
					String endPackInd = " ";
					if 	(theEndPackageIndicator)
						endPackInd = "#";
					else
						endPackInd = " ";
					

					if (deliveryType.equals("FOREIGN") || deliveryType.equals("PSFORGN")){
						newCity = new String(StringFunctions.fixSize(theCity,35,' ',StringFunctions.LEFT));
					
					    line1 = addSpace(pubCode,5,' ') + " " + addSpace(" ",50,' ');
					    
					    line4 = addLine2 + " " +  addSpace(" ",12,' ') + "#" + addSpace(labelCounter,4,'0') + endPackInd;
					    
					    line6 = addSpace(newCity,30, ' ') + " ";
					}
					
					
					if (deliveryType.equals("USPS") || deliveryType.equals("PSUSPS") || deliveryType.equals("SUUSSCPS")){
						newCity = new String(StringFunctions.fixSize(theCity,20,' ',StringFunctions.LEFT));
						
						line1 = addSpace(pubCode,5,' ') + " " + addSpace(" ",12,' ') + "*********" + theEndLine;
						
						line4 = addLine2 + " " +  addSpace(" ",12,' ') + "#" + addSpace(labelCounter,4,'0') + endPackInd;
						
						if (theBarCode != null && theBarCode.length() >0) 
							line6 =  newCity.trim() + " " + theState + " " + theUSZip + "-" + zipPlus4;
						else 
							line6 = newCity.trim() + ". " + theState + " " + theUSZip + "-" + zipPlus4;
						
					}	
					
					if (deliveryType.equals("CAN") || deliveryType.equals("PSCAN")|| deliveryType.equals("SUCASCPS")){
					    line1 = buf.substring(0,2) + "/" + buf.substring(2,6) + addSpace(" ",16,' ') + theEndLine + " " + canCarLiteral + " " + canNonDir + " " + rtNum + " " + "(" + theCanMonthCode + ")" + " ";
					    
					    line4 = addLine2 + " " + addSpace(" ",12,' ') + addSpace(labelCounter,5,'0') + endPackInd;
					    
					    line6 = theNewCity.trim() + " " + theState + "  " +(canZip.substring(0,3)) + " " + (canZip.substring(3,6));
					}
					
					
					
					
					if (theLabelMagID.length() > 1) {
						line2 = addSpace(keyLine,16,' ') + " " + addSpace(" ",8,' ') + addSpace(theLabelMagID,2,' ') + addSpace(theEditionCode,10,' ') + addSpace(theExpDate,6,' ');	
					}
					else {
						line2 = addSpace(keyLine,16,' ') + " " + addSpace(" ",8,' ') + addSpace(theLabelMagID,2,' ') + addSpace(theContCode,2,' ') + addSpace(theEditionCode,10,' ') + addSpace(theExpDate,6,' ');
					}

					line3 = CustName + " " + addSpace(" ",13,' ') + addSpace(theMakeupCode,4,' ');
					
					
					
					
					String psInd = " ";
					if (theEndPalletSackIndicator)
						psInd = "#";
					else
						psInd = " ";
						
					line5 = addLine1 + " " + addSpace(" ",11,' ') + addSpace(thePalletSackIndicator,1,' ') + addSpace(thePSNumber,1,' ') + psInd;
		       
				if (deliveryType.equals("CAN") || deliveryType.equals("PSCAN")|| deliveryType.equals("SUCASCPS")){
					text = CanadaOEL + nl + line1 + nl + line2 + nl + line3 + nl + line4 + nl
					+ line5 + nl + line6;
				}
				else{
					text = nl + line1 + nl + line2 + nl + line3 + nl + line4 + nl
					+ line5 + nl + line6;
				}
			    
				if (deliveryType.equals("USPS") || deliveryType.equals("PSUSPS") || deliveryType.equals("SUUSSCPS")){
					
					Image mg = Image.getInstance(IntelligentBarcode.createUspsIntelligentBarcode(ImbBarcodeData,cb));
					
					Phrase ph = null;
		            try {
		                ph = new Phrase(new Chunk(mg, 0, 0));
		                ph.add(new Chunk(text, new Font (Font.COURIER, 8, Font.NORMAL)));
		            } catch (Exception e) {
		            	LogWriter.writeLog(e);
		            	LogWriter.writeLog("ProcessPeelLabel -- Error in Phrase : " + text);
		            }
					
					PdfPCell cell = new PdfPCell(ph);
					cell.setFixedHeight(H);

					cell.setNoWrap(true);
					
					cell.setVerticalAlignment(Element.ALIGN_LEFT);
					cell.setHorizontalAlignment(Element.ALIGN_LEFT);
					cell.setBorder(Rectangle.NO_BORDER);
					
					counter++; 
					
					table.addCell("");
					table.addCell(cell);
				} else {
					PdfPCell cell = new PdfPCell();
					cell = new PdfPCell(new Phrase(text, new Font (Font.COURIER, 8, Font.NORMAL)));
					
					cell.setFixedHeight(H);

					cell.setNoWrap(true);
					
					cell.setVerticalAlignment(Element.ALIGN_LEFT);
					cell.setHorizontalAlignment(Element.ALIGN_LEFT);
					cell.setBorder(Rectangle.NO_BORDER);
					
					counter++; 
					
					table.addCell("");
					table.addCell(cell);
				}
				
				if (counter == ACROSS)
					table.addCell(""); // at the end

				if (counter == ACROSS)
					counter = 0; // if at the end reset the counter
					        
				theBindingGroupName = rec.getBindingGroupName();
				event.setHeader(theBindingGroupName);
				}  // End of Read ....
			}	
			catch(Exception e){
				SybilWarningException warning = new SybilWarningException(magazine.getPrefix() + ": Error processing CAN Backdate Labels.");
				LogWriter.writeLog(warning);
				LogWriter.writeLog(e);
				
			}

	}

}

