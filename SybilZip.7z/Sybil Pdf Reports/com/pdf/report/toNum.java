package com.pdf.report;

public class toNum {
	protected static int toNumber(String s) {

		int i = 0;
		
		try {
			i = Integer.parseInt(s);
		} catch (Exception e) {
			return 0;
		}
		
		return i;
	}
}
