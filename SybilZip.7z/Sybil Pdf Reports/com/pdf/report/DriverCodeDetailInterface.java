package com.pdf.report;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import sybil.common.model.Magazine;
import sybil.common.persistence.ZipFilePersistent;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;

public class DriverCodeDetailInterface {
	public static String sybMag = "TBA_SYB_MAGAZINE";

	public static String magazineInf = "TBA_MAGAZINEINF";

	public static String custBvTableName = "TBA_CUST_BV";
	
	public static String intefaceCntl = "TBA_INTER_FILE_CNTL";

	private static Connection dCdConn = null;
	
	private static void open() {

		PreparedStatement setSqlId = null;
		Statement commitSqlId = null;
		String x = null;
		String db2owner = null;
		int i = 0;
		
		String userDb = sybil.common.util.PropertyBroker.getProperty("database.login","sybil");
		String pswdDb = sybil.common.util.PropertyBroker.getProperty("database.password","sybil");
		
		
		if( dCdConn == null) {
			try {
				Class.forName(sybil.common.util.PropertyBroker.getProperty("database.driver", "Not Found"));
				dCdConn = DriverManager.getConnection(sybil.common.util.PropertyBroker.getProperty("database.server", "Not Found"), userDb, pswdDb);

				//
				x = PropertyBroker.getProperty("database.driver", "Not Found").toLowerCase();
				i = x.indexOf("db2");
				if (!(i < 0)) {
					try {
						db2owner = PropertyBroker.getProperty("DB2OWNER","dtppsyup");
						setSqlId = dCdConn.prepareStatement("set current sqlid = ?");
						setSqlId.setString(1, db2owner);
						setSqlId.execute();
						commitSqlId = dCdConn.createStatement();
						commitSqlId.execute("commit");
					}
					catch (SQLException se) {
						if(se.getSQLState().equals("S1010")) {
						}
						else {
							LogWriter.writeLog(se);
							LogWriter.writeLog("Error: Set Current SqlId failed.");
							if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
								LogWriter.writeLog("Process terminating due to database/sql exception");
								System.exit(1);
							}
						}
					}
					catch (Exception e) {
						LogWriter.writeLog(e);
						LogWriter.writeLog("Error: Set Current SqlId failed.");
						if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
							LogWriter.writeLog("Process terminating due to database/sql exception");
							System.exit(1);
						}
					}
				}
			
			} 
			catch (Exception e) {
				sybil.common.util.LogWriter.writeLog(e);
				LogWriter.writeLog("Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
		
	return;
	}
	
	
	public static void close() {
		
		if( dCdConn != null) {		
			try { dCdConn.close(); }catch(Exception sql ){};
			dCdConn = null;
		}
		return;
	}
	
	private static int magazineKey(String magazineCode){
		
		int magKey = 0;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT MAG_KEY, NAME  FROM " + sybMag + " WHERE MAG_CD = ? ";
		LogWriter.writeLog("select from " + sybMag + "   "  + SQL);
		
		try {
		selectMag = dCdConn.prepareStatement(SQL);
		selectMag.setString(1, magazineCode);
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			magKey  = (int)rs.getInt("MAG_KEY");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Code Select error " + magazineCode);
		}
		return magKey;
	}
	
	private static String getIssueDate(Magazine mag){
		
		String issueDate = null;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT COVER_DATE FROM " + magazineInf + " WHERE PLANT = ? and MAG = ? and ISSUE = ? ";
		
		try {
		selectMag = dCdConn.prepareStatement(SQL);
		selectMag.setString(1, mag.getPlant().toUpperCase());
		selectMag.setString(2, mag.getMagCode().toLowerCase());
		selectMag.setString(3, mag.getIssue());
		
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			issueDate  = rs.getString("COVER_DATE");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Issue Date error " + mag.getMagCode());
		}
		return issueDate;
	}

	
	public static synchronized void generateInterfaceFile(Magazine mag) {
			
		open();
		
		boolean interFaceFile = false;
		
		String driverCodeNewInterfaceSql =  " SELECT DISTINCT PLANT_ID, MAG_CD, ISS_NUM as ISSUE_NUM, ISS_WK_NUM as WEEK, ROLL_NUM as ROLLID, GEO_CAT_ID as MARKET_ID, XSHEET_BV_NME, PREM_DRIVER_CD as PRELIM_DRIVERCODE, FNL_DRIVER_CD as FINAL_DRIVERCODE, COPY_CNT as TOTAL_COPIES " 
			  + " FROM " + custBvTableName
			  + " WHERE  MAG_KY = ? AND INSTNC_CD = ? AND MAG_CD = ? AND PLANT_ID = ? AND ISS_NUM = ? AND ISS_WK_NUM = ?  "
			  + " ORDER BY ROLL_NUM ";
		
		String driverCodeOldInterfaceSql = " SELECT DISTINCT PLANT_ID, MAG_CD, ISS_NUM as ISSUE_NUM, ISS_WK_NUM as WEEK, XSHEET_BV_NME as BOOKVERSION, FNL_DRIVER_CD as FINAL_DRIVERCODE " 
			  + " FROM " + custBvTableName
			  + " WHERE  MAG_KY = ? AND INSTNC_CD = ? AND MAG_CD = ? AND PLANT_ID = ? AND ISS_NUM = ? AND ISS_WK_NUM = ?  "
			  + " ORDER BY BOOKVERSION ";
		
		String plantCode = mag.getPlant().toUpperCase();
		String magCode = mag.getMagCode().toUpperCase();
		
		interFaceFile = getInterfaceFileStatus("DCN",plantCode, magCode);
				
		if (interFaceFile) {
			generateInterfaceFilezip(mag, driverCodeNewInterfaceSql,"new");
			LogWriter.writeLog(" Driver Code new InterFace file Generated   ");
		}
		else{
			interFaceFile = getInterfaceFileStatus("DCN",plantCode, "XX");
			if (interFaceFile) {
				generateInterfaceFilezip(mag, driverCodeNewInterfaceSql,"new");
				LogWriter.writeLog(" Driver Code new InterFace file Generated   ");
			}
		}
		
		interFaceFile = false;
		interFaceFile = getInterfaceFileStatus("DCO",plantCode, magCode);
		if (interFaceFile) {
			generateInterfaceFilezip(mag, driverCodeOldInterfaceSql,"old");
			LogWriter.writeLog(" Driver Code new InterFace file Generated   ");
		}
		else{
			interFaceFile = getInterfaceFileStatus("DCO",plantCode, "XX");
			if (interFaceFile) {
				generateInterfaceFilezip(mag, driverCodeOldInterfaceSql,"old");
				LogWriter.writeLog(" Driver Code new InterFace file Generated   ");
			}
		}
		return;
	}
	
	
	private synchronized static boolean getInterfaceFileStatus(String ifCd, String plantCode, String magCode) {
		
		PreparedStatement selectIFC = null;
		ResultSet rsRioIfc = null;
		boolean generateInterfaceFile = false;
		
		open();
		
		String SQL = "Select INTER_FILE_IND, INTER_FILE_DESC FROM  " + intefaceCntl
				+ " WHERE PLANT_ID = ? AND MAG_CD = ? AND INTER_FILE_CD = ? ";
		
		try {
			
			String ifcInd = null;
			selectIFC = dCdConn.prepareStatement(SQL);
			selectIFC.setString(1, plantCode);
			selectIFC.setString(2, magCode);
			selectIFC.setString(3, ifCd);
			
			rsRioIfc = selectIFC.executeQuery();
			
			while (rsRioIfc.next()){
				ifcInd = rsRioIfc.getString("INTER_FILE_IND");
				if (ifcInd.equals("Y"))
					generateInterfaceFile = true;
				else
					generateInterfaceFile = false;
			}
			rsRioIfc.close();
		} 
		catch (SQLException se) {
			LogWriter.writeLog(se);
		}
		return generateInterfaceFile;
	}


	private synchronized static void generateInterfaceFilezip(Magazine mag, String driverCodeInterfaceSql,String dcdInd) {
		
		
		PreparedStatement driverCodePS = null;
		ResultSet resultset = null;
				
		String magCode = mag.getMagCode().trim();
		String issueNum = mag.getIssue().trim();
		String issueWeek = mag.getWeek().trim();
		String plantId = mag.getPlant().toUpperCase().trim();
		
		String interFaceFilePath = sybil.common.util.PropertyBroker.getProperty("NEW_IFF_PATH","Not found");
		String fileName = interFaceFilePath.concat(magCode.toUpperCase() + "." + issueNum + "." + plantId + ".DriverCodeDetail_" + dcdInd + "." + issueWeek + ".txt");
		
		LogWriter.writeLog("File Name is --- " + fileName);
		
		open();
		
		            
		int magKey = magazineKey(magCode);
		
		String issueDate = getIssueDate(mag);
		
		String instCd = InstanceCd.getInstCd(magKey, issueDate);
			
		String s = null;
		PrintWriter outputFile = null;
		File f = null;
		
		try {

			driverCodePS = dCdConn.prepareStatement(driverCodeInterfaceSql);
			driverCodePS.setInt(1, magKey);
			driverCodePS.setString(2, instCd);
			driverCodePS.setString(3, magCode);
			driverCodePS.setString(4, plantId);
			driverCodePS.setInt(5, toNum.toNumber(issueNum));
			driverCodePS.setInt(6, toNum.toNumber(issueWeek));
						
			resultset = driverCodePS.executeQuery();
				
			ResultSetMetaData rsmd = resultset.getMetaData();
			int colcount = rsmd.getColumnCount();

			String outputFileName = fileName.trim();
			
			f = new File(outputFileName);

			outputFile = new PrintWriter(new OutputStreamWriter(new FileOutputStream(f),"ASCII"));				

			String s1 = rsmd.getColumnName(1) + '\u0009';

			for(int colnames=2; colnames<=colcount; colnames++){
				s1 = s1 + rsmd.getColumnName(colnames) + '\u0009';
			}

			s1 = s1 + "\n";

			outputFile.print(s1);
				
			while (resultset.next()) {
				
				s = resultset.getString(1) + '\u0009';
					int i=2;
					for(; i<colcount; i++){
						s = s + resultset.getObject(i) + '\u0009';
					}
				s = s + resultset.getObject(i) ;
				s = s +"\n";
				outputFile.print(s);
			}
			resultset.close();
			driverCodePS.close();
			outputFile.close();

		ZipFilePersistent zp = new ZipFilePersistent(outputFileName.substring(0,outputFileName.length()-3).concat("zip"));
		zp.addFile(f);
		zp.closeZipfile();
		close();
			
		}
		catch (SQLException se) {
			se.printStackTrace();
			LogWriter.writeLog(se);
		}
		catch (Exception e) {
			e.printStackTrace();		
			LogWriter.writeLog(e);
		}finally{
			if(f.exists())
			f.delete();
		}
	}
}
