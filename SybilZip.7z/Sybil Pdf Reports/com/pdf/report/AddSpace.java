package com.pdf.report;

public class AddSpace {

	
	public static final int LEFT = -1;

	public static final int RIGHT = -2;

	
	protected static StringBuffer addSpace(StringBuffer str, int size){

		int num = size - str.length();
	
		for (int j=0;j<=num;j++){	
			str = str.insert(j, ' ');
		}
		return str;
	}

	
	protected static StringBuffer addSpace(int arg_num){
		StringBuffer str = new StringBuffer(String.valueOf(arg_num));
		
		int num = 3 - str.length();
	
		for (int j=0;j<=num;j++){	
			str = str.insert(j, ' ');
		}
		return str;
	}
	
	protected static StringBuffer addSpace(int arg_num,int numLen){
		StringBuffer str = new StringBuffer(String.valueOf(arg_num));
		
		int num = numLen - str.length();
	
		for (int j=0;j<=num;j++){	
			str = str.insert(j, ' ');
		}
		return str;
	}
	
	protected static StringBuffer addSpaceB(StringBuffer str, int size){
		
		int num = size - str.length();
			if (str.length() == 3)
				num +=1;
			if (str.length() == 2)
				num +=2;
			if (str.length() == 1)
				num +=3;
			for (int j=0;j<=num;j++){	
				str = str.insert(j, ' ');
			}
			return str;
	}
	
	
	protected static StringBuffer addSpace(String strValue,int numLen,char padValue){
		StringBuffer str = new StringBuffer(strValue);
		
		int num = numLen - str.length();
	
		for (int j=0;j<=num;j++){	
			str = str.insert(j, padValue);
		}
		return str;
	}
	
	public static String fixSize(String buffer, int size, char fillChar,
			int justification) {

		char[] buf = new char[size];
		int length = buffer.length();
		int num_fill_chars = size - length;
		int pos = 0;

		for (int i = 0; i < size; i++) {

			if (justification == RIGHT) {
				if (i < num_fill_chars)
					buf[i] = fillChar;
				else
					buf[i] = buffer.charAt(pos++);
			} else {
				if (i < length)
					buf[i] = buffer.charAt(pos++);
				else
					buf[i] = fillChar;
			}

		}

		return String.valueOf(buf);
	}

}
