package com.pdf.report;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import sybil.common.model.Magazine;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;

import com.report.text.Document;
import com.report.text.DocumentException;
import com.report.text.Element;
import com.report.text.ExceptionConverter;
import com.report.text.Font;
import com.report.text.FontFactory;
import com.report.text.Phrase;
import com.report.text.Rectangle;
import com.report.text.pdf.BaseFont;
import com.report.text.pdf.PdfContentByte;
import com.report.text.pdf.PdfPCell;
import com.report.text.pdf.PdfPTable;
import com.report.text.pdf.PdfPageEventHelper;
import com.report.text.pdf.PdfTemplate;
import com.report.text.pdf.PdfWriter;

public class CanadianBagSummary extends PdfPageEventHelper {
	
	public static String canadianBagSum = "TBA_CNDN_BAG_SUM";
	public static String magazineInf = "TBA_MAGAZINEINF";
	public static String sybMag = "TBA_SYB_MAGAZINE";
	
	private static Connection conn = null;
	private static ResultSet resultset = null;
	private static String magName = null;
	
	protected PdfTemplate total;
 	protected BaseFont helv;
 
 	public void onOpenDocument(PdfWriter writer, Document document) {
		total = writer.getDirectContent().createTemplate(100, 100);
		total.setBoundingBox(new Rectangle(-20, -20, 100, 100));
		try {
			helv = BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI,BaseFont.NOT_EMBEDDED);
		} catch (Exception e) {
			throw new ExceptionConverter(e);
		}
	}
 
	public void onEndPage(PdfWriter writer, Document document) {
		PdfContentByte cb = writer.getDirectContent();
		cb.saveState();
		String text = "Page " + writer.getPageNumber() + " of  ";
		float textBase = document.bottom() - 15;
		float textSize = helv.getWidthPoint(text, 9);
		float textCenter = document.right()/2;
		cb.beginText();
		cb.setFontAndSize(helv, 10);

		cb.setTextMatrix(textCenter, textBase);
		cb.showText(text);
		cb.endText();
		cb.addTemplate(total, textCenter + textSize, textBase);
		cb.restoreState();
	}
 	
	public void onCloseDocument(PdfWriter writer, Document document) {
		total.beginText();
		total.setFontAndSize(helv, 10);
		total.setTextMatrix(0, 0);
		total.showText(String.valueOf(writer.getPageNumber() - 1));
		total.endText();
	}
	
	private static void open() {

		PreparedStatement setSqlId = null;
		Statement commitSqlId = null;
		String x = null;
		String db2owner = null;
		int i = 0;
		
		String userDb = sybil.common.util.PropertyBroker.getProperty("database.login","sybil");
		String pswdDb = sybil.common.util.PropertyBroker.getProperty("database.password","sybil");
		
		
		if( conn == null) {
			try {
				Class.forName(sybil.common.util.PropertyBroker.getProperty("database.driver", "Not Found"));
				conn = DriverManager.getConnection(sybil.common.util.PropertyBroker.getProperty("database.server", "Not Found"), userDb, pswdDb);

				//
				x = PropertyBroker.getProperty("database.driver", "Not Found").toLowerCase();
				i = x.indexOf("db2");
				if (!(i < 0)) {
					try {
						db2owner = PropertyBroker.getProperty("DB2OWNER","dtppsyup");
						setSqlId = conn.prepareStatement("set current sqlid = ?");
						setSqlId.setString(1, db2owner);
						setSqlId.execute();
						commitSqlId = conn.createStatement();
						commitSqlId.execute("commit");
					}
					catch (SQLException se) {
						if(se.getSQLState().equals("S1010")) {
						}
						else {
							LogWriter.writeLog(se);
							LogWriter.writeLog("Error: Set Current SqlId failed.");
							if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
								LogWriter.writeLog("Process terminating due to database/sql exception");
								System.exit(1);
							}
						}
					}
					catch (Exception e) {
						LogWriter.writeLog(e);
						LogWriter.writeLog("Error: Set Current SqlId failed.");
						if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
							LogWriter.writeLog("Process terminating due to database/sql exception");
							System.exit(1);
						}
					}
				}
			
			} 
			catch (Exception e) {
				sybil.common.util.LogWriter.writeLog(e);
				LogWriter.writeLog("Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
		
	return;
	}
	

	private static String getIssueDate(Magazine mag){
		
		String issueDate = null;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT COVER_DATE FROM " + magazineInf + " WHERE PLANT = ? and MAG = ? and ISSUE = ? ";
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, mag.getPlant().toUpperCase());
		selectMag.setString(2, mag.getMagCode().toLowerCase());
		selectMag.setString(3, mag.getIssue());
		
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			issueDate  = rs.getString("COVER_DATE");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Issue Date error " + mag.getMagCode());
		}finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectMag != null) {
				try {
					selectMag.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		return issueDate;
	}

	private static int magazineKey(String magazineCode){
		
		int magKey = 0;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT MAG_KEY, NAME  FROM " + sybMag + " WHERE MAG_CD = ? ";
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, magazineCode);
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			magKey  = (int)rs.getInt("MAG_KEY");
			magName = rs.getString("NAME");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Code Select error " + magazineCode);
		}finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectMag != null) {
				try {
					selectMag.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		return magKey;
	}


	public static synchronized void CreatePDF(Magazine mag) {
		
		PreparedStatement selectBsr = null;
		Document cbsrDoc = new Document();
		boolean firstTime = true;
		int braceTotalCopy = 0;
		int braceRptTotalCopy = 0;
		String savebraceId = " ";
		String magCode = mag.getMagCode().trim();
		String issueNum = mag.getIssue().trim();
		String plantId = mag.getPlant().toUpperCase().trim();
		String issueWeek = mag.getWeek().trim();
		String processType = mag.getProcessType().trim();
		
		
		String RptPath = sybil.common.util.PropertyBroker.getProperty("NewPDFReportsPath","Not found");
		String fileName = magCode.toLowerCase() + ".i" + issueNum + "." + plantId + ".Canadian_Bag_Summary." + issueWeek + "." + processType;
		
		String SQL = " SELECT PLANT_ID , MAG_CD, ISS_NUM, ISS_WK_NUM, PROCESS_TYPE, BRACE_ID,  " +
		            "DROP_OFF_PT , PT_ENTRY, ROLL_NUM,  GEO_CAT_ID,  XSHEET_BV_NME, " +
		            "MIN_BAG_NUM, MAX_BAG_NUM, NUM_PKG,  COPY_CNT, BRACE_NME, " +
		            "DEPART_TIME FROM  " + canadianBagSum +
		            " WHERE MAG_KY = ? AND INSTNC_CD = ? AND PLANT_ID = ? AND MAG_CD = ? AND ISS_NUM = ? AND ISS_WK_NUM = ?  " +
		            " ORDER BY BRACE_ID, DROP_OFF_PT, PT_ENTRY, ROLL_NUM, GEO_CAT_ID, XSHEET_BV_NME ";
			
		open();
		
		int magKey = magazineKey(magCode);
		String issueDate = getIssueDate(mag);
		String instCd = InstanceCd.getInstCd(magKey, issueDate);
		
		try {
		
			PdfWriter writer = PdfWriter.getInstance(cbsrDoc,				
					new FileOutputStream(RptPath + fileName + ".pdf"));
			
			writer.setViewerPreferences(PdfWriter.PageModeFullScreen);
			writer.setPageEvent(new CanadianBagSummary());
			
			cbsrDoc.setMargins(0, 0, 3, 20);
			
			cbsrDoc.open();
			
			Date toDay = new Date(); 
			SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, MMM d, yyyy, HH:mm a "); 
			
			
			PdfPTable outertable = new PdfPTable(1);
			outertable.setHeaderRows(6);
			
			PdfPCell header0 = new PdfPCell(new Phrase(String.valueOf(dateFormat.format(toDay)),
					FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,Color.black)));
			header0.setBorderWidth(0);
			outertable.addCell(header0);
				
			outertable.setSplitLate(false);
			
			String issueHdr = "Issue :" + issueDate + "(" + issueNum + " - " + issueWeek +")";
			PdfPCell issueCell = new PdfPCell(new Phrase(issueHdr,
					FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,Color.black)));
			issueCell.setBorderWidth(0);
			outertable.addCell(issueCell);
			
			PdfPCell cell1 = new PdfPCell(new Phrase(
					"Canadian Bag Summary Report", FontFactory.getFont(FontFactory.COURIER, 18, Font.BOLD, Color.BLACK)));
			cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell1.setBorderWidth(0);
			outertable.addCell(cell1);
			
			String header1 = "Magazine : " + magName.trim() + " " + "Plant : " + plantId + "   " + "Issue :" + issueNum + " - " + issueWeek ;
			PdfPCell magCell = new PdfPCell(new Phrase(header1,
					FontFactory.getFont(FontFactory.COURIER, 12, Font.BOLD,
							Color.black)));
			magCell.setBorderWidth(0);
			outertable.addCell(magCell);
			
			for ( int s = 0; s <=2; s++){
				PdfPCell dummyCell = new PdfPCell(new Phrase("", FontFactory.getFont(
								FontFactory.COURIER, 10, Font.BOLD, Color.black)));
				dummyCell.setBorderWidth(0);
				outertable.addCell(dummyCell);}
			
	
			selectBsr = conn.prepareStatement(SQL);
			selectBsr.setInt(1, magKey);
			selectBsr.setString(2, instCd);
			selectBsr.setString(3, plantId);
			selectBsr.setString(4, magCode);
			selectBsr.setInt(5, toNum.toNumber(issueNum));
			selectBsr.setString(6, issueWeek);
			resultset = selectBsr.executeQuery();
			
			while (resultset.next()){
				
				String braceId = resultset.getString("BRACE_ID");
 				String dropOffPt  = resultset.getString("DROP_OFF_PT");
				String ptEntry = resultset.getString("PT_ENTRY");
				String rollNum = resultset.getString("ROLL_NUM");
 				String geoCatId  = resultset.getString("GEO_CAT_ID").trim(); 
 				String xsheetBV =  resultset.getString("XSHEET_BV_NME");
				String minBagNum = resultset.getString("MIN_BAG_NUM");
				String maxBagNum = resultset.getString("MAX_BAG_NUM");
				String numPkg = resultset.getString("NUM_PKG");
				String copyCnt = resultset.getString("COPY_CNT");
				String braceNme = resultset.getString("BRACE_NME");
				String departTime = resultset.getString("DEPART_TIME");
				
				String bookVersion = geoCatId.concat(" - ").concat(xsheetBV);
				
				
				if (braceId.compareTo(savebraceId)== 0){
					
					String detailInfo = rollNum  + "       " + bookVersion + "        "  + minBagNum + "           " +   maxBagNum + "             " +  AddSpace.addSpace(Integer.valueOf(numPkg).intValue()) + "       " +  AddSpace.addSpace(PlaceComma.placeComma(Integer.valueOf(copyCnt).intValue()),9);
					PdfPCell detailType = new PdfPCell(
							new Phrase(detailInfo, FontFactory.getFont(
									FontFactory.COURIER, 10, Font.NORMAL, Color.black)));
					
					detailType.setBorderWidth(0);
					outertable.addCell(detailType);
					braceTotalCopy += (Integer.valueOf(copyCnt)).intValue();
					
				}
				else{
					savebraceId = braceId;
					if (firstTime){
						String header2 = "Brace : " +  braceId + " " + braceNme.trim()  + "  Depart Time: " +  departTime.trim() + "    DOP: " + dropOffPt.trim() + "    POE: " + ptEntry.trim();
						PdfPCell fileType = new PdfPCell(
								new Phrase(header2, FontFactory.getFont(
										FontFactory.COURIER, 10, Font.BOLD, Color.black)));
						
						fileType.setBorderWidth(0);
						outertable.addCell(fileType);						
						
						for ( int s = 0; s <=2; s++){
						PdfPCell dummyCell = new PdfPCell(new Phrase("", FontFactory.getFont(
										FontFactory.COURIER, 10, Font.BOLD, Color.black)));
						dummyCell.setBorderWidth(0);
						outertable.addCell(dummyCell);}
						
						
						String header3 = "Roll " + "     "+  " Bookversion " + "   " + " Min BAG # " + "   " + " Max BAG # " + "   Pkg Count " + "   Copy Count ";
						PdfPCell fileType1 = new PdfPCell(
								new Phrase(header3, FontFactory.getFont(
										FontFactory.COURIER, 10, Font.BOLD, Color.black)));
						
						fileType1.setBorderWidth(0);
						outertable.addCell(fileType1);
						firstTime = false;
					}
					else{
						String totalInfo = "                                               " +  "Brace Total: " + "      " +  AddSpace.addSpace(PlaceComma.placeComma((braceTotalCopy)),9);
						PdfPCell detailType = new PdfPCell(
								new Phrase(totalInfo, FontFactory.getFont(
										FontFactory.COURIER, 10, Font.BOLD, Color.black)));
						
						detailType.setBorderWidth(0);
						outertable.addCell(detailType);
						braceRptTotalCopy +=braceTotalCopy;
						braceTotalCopy = 0;
						
						for ( int s = 0; s <=2; s++){
							PdfPCell dummyCell = new PdfPCell(new Phrase("", FontFactory.getFont(
											FontFactory.COURIER, 10, Font.BOLD, Color.black)));
							dummyCell.setBorderWidth(0);
							outertable.addCell(dummyCell);}
						
						String header2 = "Brace : " +  braceId + " " + braceNme.trim()  + "  Depart Time: " +  departTime.trim() + "    DOP: " + dropOffPt.trim() + "    POE: " + ptEntry.trim();
						PdfPCell fileType = new PdfPCell(
								new Phrase(header2, FontFactory.getFont(
										FontFactory.COURIER, 10, Font.BOLD, Color.black)));
						
						fileType.setBorderWidth(0);
						outertable.addCell(fileType);						
						
						for ( int s = 0; s <=2; s++){
						PdfPCell dummyCell = new PdfPCell(new Phrase("", FontFactory.getFont(
										FontFactory.COURIER, 10, Font.BOLD, Color.black)));
						dummyCell.setBorderWidth(0);
						outertable.addCell(dummyCell);}
						
						
						String header3 = "Roll " + "     "+  " Bookversion " + "   " + " Min BAG # " + "   " + " Max BAG # " + "   Pkg Count " + "   Copy Count ";
						PdfPCell fileType1 = new PdfPCell(
								new Phrase(header3, FontFactory.getFont(
										FontFactory.COURIER, 10, Font.BOLD, Color.black)));
						
						fileType1.setBorderWidth(0);
						outertable.addCell(fileType1);
					}
						
				braceTotalCopy += (Integer.valueOf(copyCnt)).intValue();	
				String detailInfo = rollNum  + "       " + bookVersion + "        "  + minBagNum + "           " +   maxBagNum + "             " +  AddSpace.addSpace(Integer.valueOf(numPkg).intValue()) + "       " +  AddSpace.addSpace(PlaceComma.placeComma(Integer.valueOf(copyCnt).intValue()),9);
				PdfPCell detailType = new PdfPCell(
						new Phrase(detailInfo, FontFactory.getFont(
								FontFactory.COURIER, 10, Font.NORMAL, Color.black)));
				
				detailType.setBorderWidth(0);
				
				outertable.addCell(detailType);
			}
			
		}
			braceRptTotalCopy += braceTotalCopy;
				String totalInfo = "                                               " +  "Brace Total: " + "      " +  AddSpace.addSpace(PlaceComma.placeComma((braceTotalCopy)),9);
				PdfPCell detailType = new PdfPCell(
						new Phrase(totalInfo, FontFactory.getFont(
								FontFactory.COURIER, 10, Font.BOLD, Color.black)));
				
				detailType.setBorderWidth(0);		
				outertable.addCell(detailType);
			
				String rptTotal = "                                               " +  "Report Total: " + "      " +  AddSpace.addSpace(PlaceComma.placeComma(braceRptTotalCopy),9);
				PdfPCell rptType = new PdfPCell(
						new Phrase(rptTotal, FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
				rptType.setBorderWidth(0);		
				outertable.addCell(rptType);
		
			cbsrDoc.add(outertable);
		}	catch (SQLException se) {
				LogWriter.writeLog(se);
			}catch (DocumentException de) {
				System.err.println(de.getMessage());
			}catch (IOException ioe) {
				System.err.println(ioe.getMessage());
		} finally {
			if (resultset != null) {
				try {
					resultset.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectBsr != null) {
				try {
					selectBsr.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		cbsrDoc.close();
		LogWriter.writeLog(" Canadian Bag Summary Report Generated " );
		return;
		
	}

}
