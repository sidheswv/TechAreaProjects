package com.pdf.report;

public class PalletRoll {
	String braceId ;
	int rollNum ;
	String palletNum;
	public PalletRoll(String braceId, int rollNum, String palletNum) {
		super();
		this.braceId = braceId;
		this.rollNum = rollNum;
		this.palletNum = palletNum;
	}
	public String getBraceId() {
		return braceId;
	}
	public void setBraceId(String braceId) {
		this.braceId = braceId;
	}
	public String getPalletNum() {
		return palletNum;
	}
	public void setPalletNum(String palletNum) {
		this.palletNum = palletNum;
	}
	public int getRollNum() {
		return rollNum;
	}
	public void setRollNum(int rollNum) {
		this.rollNum = rollNum;
	}

}
