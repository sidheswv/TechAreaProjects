package com.pdf.report;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import sybil.common.model.Magazine;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;

import com.report.text.Document;
import com.report.text.DocumentException;
import com.report.text.Element;
import com.report.text.ExceptionConverter;
import com.report.text.Font;
import com.report.text.FontFactory;
import com.report.text.PageSize;
import com.report.text.Phrase;
import com.report.text.Rectangle;
import com.report.text.pdf.BaseFont;
import com.report.text.pdf.PdfContentByte;
import com.report.text.pdf.PdfPCell;
import com.report.text.pdf.PdfPTable;
import com.report.text.pdf.PdfPageEventHelper;
import com.report.text.pdf.PdfTemplate;
import com.report.text.pdf.PdfWriter;



public class BulkCountSummary extends PdfPageEventHelper {

	public static String bulkCount = "TBA_PS_BULK_CNT";
	public static String magazineInf = "TBA_MAGAZINEINF";
	public static String sybMag = "TBA_SYB_MAGAZINE";
	
	private static Connection conn = null;
	private static ResultSet resultset = null;
	private static String magName = null;
	
	protected PdfTemplate total;
 	protected BaseFont helv;
 
 	public void onOpenDocument(PdfWriter writer, Document document) {
		total = writer.getDirectContent().createTemplate(100, 100);
		total.setBoundingBox(new Rectangle(-20, -20, 100, 100));
		try {
			helv = BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI,BaseFont.NOT_EMBEDDED);
		} catch (Exception e) {
			throw new ExceptionConverter(e);
		}
	}
 
	public void onEndPage(PdfWriter writer, Document document) {
		PdfContentByte cb = writer.getDirectContent();
		cb.saveState();
		String text = "Page " + writer.getPageNumber() + " of  ";
		float textBase = document.bottom() - 15;
		float textSize = helv.getWidthPoint(text, 9);
		float textCenter = document.right()/2;
		cb.beginText();
		cb.setFontAndSize(helv, 10);

		cb.setTextMatrix(textCenter, textBase);
		cb.showText(text);
		cb.endText();
		cb.addTemplate(total, textCenter + textSize, textBase);
		cb.restoreState();
	}
 	
	public void onCloseDocument(PdfWriter writer, Document document) {
		total.beginText();
		total.setFontAndSize(helv, 10);
		total.setTextMatrix(0, 0);
		total.showText(String.valueOf(writer.getPageNumber() - 1));
		total.endText();
	}
	
	private static void open() {

		PreparedStatement setSqlId = null;
		Statement commitSqlId = null;
		String x = null;
		String db2owner = null;
		int i = 0;
		
		String userDb = sybil.common.util.PropertyBroker.getProperty("database.login","sybil");
		String pswdDb = sybil.common.util.PropertyBroker.getProperty("database.password","sybil");
		
		
		if( conn == null) {
			try {
				Class.forName(sybil.common.util.PropertyBroker.getProperty("database.driver", "Not Found"));
				conn = DriverManager.getConnection(sybil.common.util.PropertyBroker.getProperty("database.server", "Not Found"), userDb, pswdDb);

				//
				x = PropertyBroker.getProperty("database.driver", "Not Found").toLowerCase();
				i = x.indexOf("db2");
				if (!(i < 0)) {
					try {
						db2owner = PropertyBroker.getProperty("DB2OWNER","dtppsyup");
						setSqlId = conn.prepareStatement("set current sqlid = ?");
						setSqlId.setString(1, db2owner);
						setSqlId.execute();
						commitSqlId = conn.createStatement();
						commitSqlId.execute("commit");
					}
					catch (SQLException se) {
						if(se.getSQLState().equals("S1010")) {
						}
						else {
							LogWriter.writeLog(se);
							LogWriter.writeLog("Error: Set Current SqlId failed.");
							if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
								LogWriter.writeLog("Process terminating due to database/sql exception");
								System.exit(1);
							}
						}
					}
					catch (Exception e) {
						LogWriter.writeLog(e);
						LogWriter.writeLog("Error: Set Current SqlId failed.");
						if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
							LogWriter.writeLog("Process terminating due to database/sql exception");
							System.exit(1);
						}
					}
				}
			
			} 
			catch (Exception e) {
				sybil.common.util.LogWriter.writeLog(e);
				LogWriter.writeLog("Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
		
	return;
	}
	

	private static String getIssueDate(Magazine mag){
		
		String issueDate = null;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT COVER_DATE FROM " + magazineInf + " WHERE PLANT = ? and MAG = ? and ISSUE = ? ";
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, mag.getPlant().toUpperCase());
		selectMag.setString(2, mag.getMagCode().toLowerCase());
		selectMag.setString(3, mag.getIssue());
		
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			issueDate  = rs.getString("COVER_DATE");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Issue Date error " + mag.getMagCode());
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) { /* ignored */}
			}
			if (selectMag != null) {
				try {
					selectMag.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		return issueDate;
	}

	private static int magazineKey(String magazineCode){
		
		int magKey = 0;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT MAG_KEY, NAME  FROM " + sybMag + " WHERE MAG_CD = ? ";
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, magazineCode);
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			magKey  = (int)rs.getInt("MAG_KEY");
			magName = rs.getString("NAME");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Code Select error " + magazineCode);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) { /* ignored */}
			}
			if (selectMag != null) {
				try {
					selectMag.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		return magKey;
	}

	
	public synchronized static void createBulkCountReport(Magazine mag){
		
		PreparedStatement selectcopyCnt = null;
		Document bulkDoc = new Document(PageSize.LETTER,-50,-50,30,30);
		
		boolean firstRow = true;
		boolean noBulkCount = true;
		int totalCopy = 0;
		int rptTotal = 0;
		int ctr = 1;
		
		String magCode = mag.getMagCode().trim();
		String issueNum = mag.getIssue().trim();
		String plantId = mag.getPlant().toUpperCase().trim();
		String issueWeek = mag.getWeek().trim();
		String processType = mag.getProcessType().toUpperCase().trim();
		String deliveryType = mag.getDeliveryType().toUpperCase().trim();
		
		String RptPath = sybil.common.util.PropertyBroker.getProperty("NewPDFReportsPath","Not found");
		String fileName = magCode.toLowerCase() + ".i" + issueNum + "." + plantId + ".OMS_PS_Bulk_Label_Count." + issueWeek  + "." + deliveryType + "." + processType; 
			
		open();
		
		String SQL = "Select XSHEET_BV_NME, COPY_CNT from "
					+ bulkCount
					+ " WHERE MAG_KY = ? and INSTNC_CD = ? and PLANT_ID = ? and  MAG_CD = ? and ISS_NUM = ? and ISS_WK_NUM = ? and PROCESS_TYPE = ? and DELIVERY_TYPE  = ? "
					+ " order by XSHEET_BV_NME " ;
		
		String issueDate = getIssueDate(mag);
		int magKey = magazineKey(magCode);
		String instCd = InstanceCd.getInstCd(magKey, issueDate);

		
		try {
				
			PdfWriter writer = PdfWriter.getInstance(bulkDoc,				
					new FileOutputStream(RptPath + fileName + ".pdf"));
			
			writer.setViewerPreferences(PdfWriter.PageModeFullScreen);
			writer.setPageEvent(new BulkCountSummary());
			
			bulkDoc.open();
			
			Date toDay = new Date(); 
			SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, MMM d, yyyy, HH:mm a "); 
			
			PdfPTable outertable = new PdfPTable(1);
			outertable.setHeaderRows(9);
			
			PdfPCell header0 = new PdfPCell(new Phrase(String.valueOf(dateFormat.format(toDay)),
					FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,
							Color.black)));
			header0.setBorderWidth(0);
			outertable.addCell(header0);
			
			PdfPCell cell0 = new PdfPCell(new Phrase("PSBulk Counts Report", FontFactory.getFont(
							FontFactory.COURIER, 17, Font.BOLD, Color.BLACK)));
			cell0.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell0.setBorderWidth(0);
			outertable.addCell(cell0);
			
			for ( int G = 0; G <2; G++){
				PdfPCell dummyCell1 = new PdfPCell(new Phrase("", FontFactory.getFont(
								FontFactory.COURIER, 10, Font.BOLD, Color.black)));
				dummyCell1.setBorderWidth(0);
				outertable.addCell(dummyCell1);}
			
			String header1 = "Plant : " + plantId + "  Issue : " +  issueDate.trim() + " (" + issueNum + " - " + issueWeek + ")" +  "  Magazine : " + magName.trim() ;
			  
			String header2 = AddSpace.addSpace(" ", 15, ' ' ) + " " + AddSpace.addSpace("BookVersion", 12, ' ' ) +  "  " + AddSpace.addSpace(" ", 20, ' ' ) + "Copy count " ;
			
			selectcopyCnt = conn.prepareStatement(SQL);
			selectcopyCnt.setInt(1, magKey);
			selectcopyCnt.setString(2, instCd);
			selectcopyCnt.setString(3, plantId);
			selectcopyCnt.setString(4, magCode);
			selectcopyCnt.setInt(5, toNum.toNumber(issueNum));
			selectcopyCnt.setInt(6, toNum.toNumber(issueWeek));
			selectcopyCnt.setString(7, processType);
			selectcopyCnt.setString(8, deliveryType);
			resultset = selectcopyCnt.executeQuery();
			
			
			while (resultset.next()){
				noBulkCount = false;	
			if (firstRow) {
				
				PdfPCell magCell = new PdfPCell(new Phrase(header1,
						FontFactory.getFont(FontFactory.COURIER, 12, Font.NORMAL,Color.black)));
				magCell.setBorderWidth(0);
				outertable.addCell(magCell);
				
				
				for ( int G = 0; G <=2; G++){
					PdfPCell dummyCell1 = new PdfPCell(new Phrase("", FontFactory.getFont(
									FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					dummyCell1.setBorderWidth(0);
					outertable.addCell(dummyCell1);}
				
				PdfPCell cellThree = new PdfPCell(new Phrase(header2, FontFactory.getFont(
						FontFactory.COURIER, 12, Font.BOLD, Color.black)));
				cellThree.setBorderWidth(0);
				outertable.addCell(cellThree);
				firstRow = false;
			}
		
			String bvNum = resultset.getString("XSHEET_BV_NME").trim();
			String copyCount = resultset.getString("COPY_CNT");
			
			
			String detailInfo = AddSpace.addSpace(" ", 18, ' ')  +  "  " + AddSpace.addSpace(bvNum, 3, '0') + AddSpace.addSpace(" ", 25, ' ' ) + AddSpace.addSpace((PlaceComma.placeComma((Integer.valueOf(copyCount)).intValue())),9);
				PdfPCell detailCell = new PdfPCell(new Phrase(detailInfo, FontFactory.getFont(
								FontFactory.COURIER, 12, Font.NORMAL, Color.black)));				
			detailCell.setBorderWidth(0);
			outertable.addCell(detailCell);ctr++;
			totalCopy += (Integer.valueOf(copyCount)).intValue();

			}	
			if (noBulkCount) {		
				
				PdfPCell cellTwo = new PdfPCell(new Phrase(header1,	FontFactory.getFont(
					FontFactory.COURIER, 12, Font.BOLD,Color.black)));
				cellTwo.setBorderWidth(0);
				outertable.addCell(cellTwo);

				PdfPCell cellThree = new PdfPCell(new Phrase(header2, FontFactory.getFont(
					FontFactory.COURIER, 12, Font.BOLD, Color.black)));
				cellThree.setBackgroundColor(new Color(192, 253, 171));
				cellThree.setBorderWidth(0);
				outertable.addCell(cellThree);
				for ( int G = 0; G <=2; G++){
					PdfPCell dummyCell = new PdfPCell(new Phrase("", FontFactory.getFont(
									FontFactory.COURIER, 10, Font.BOLD, Color.black)));
					dummyCell.setBorderWidth(0);
					outertable.addCell(dummyCell);}
			}
			else {
				rptTotal += totalCopy;
				String totalInfo = AddSpace.addSpace("TOTAL",30,' ')+ " " + AddSpace.addSpace(" ",19,' ') + AddSpace.addSpace(PlaceComma.placeComma(totalCopy),9);
				PdfPCell TotalCell = new PdfPCell(	new Phrase(totalInfo, FontFactory.getFont(FontFactory.COURIER, 12, Font.NORMAL, Color.black)));
				TotalCell.setBorderWidth(0);
				outertable.addCell(TotalCell);ctr++;
				
			}
			bulkDoc.add(outertable);
			
		} 
		catch (SQLException se) {
			LogWriter.writeLog(se);
		}
		
		catch (DocumentException de) {
			System.err.println(de.getMessage());
		} catch (IOException ioe) {
			System.err.println(ioe.getMessage());
		} finally {
			if (resultset != null) {
				try {
					resultset.close();
				} catch (SQLException e) { /* ignored */}
			}
			if (selectcopyCnt != null) {
				try {
					selectcopyCnt.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		bulkDoc.close();
		LogWriter.writeLog("PS Bulk Count Report Generated " );
		return;
	}
}

