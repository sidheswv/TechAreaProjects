package com.pdf.report;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import sybil.common.model.Magazine;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;
import sybil.common.util.SybilWarningException;

import com.report.text.Document;
import com.report.text.DocumentException;
import com.report.text.Element;
import com.report.text.Font;
import com.report.text.FontFactory;
import com.report.text.HeaderFooter;
import com.report.text.PageSize;
import com.report.text.Phrase;
import com.report.text.Rectangle;
import com.report.text.pdf.ColumnText;
import com.report.text.pdf.PdfContentByte;
import com.report.text.pdf.PdfPCell;
import com.report.text.pdf.PdfPTable;
import com.report.text.pdf.PdfWriter;

public class FirstClassLabel {
	
	
	private static Magazine magazine = null;
	
	public static final float H = 1.058f * 72;
    public static final float W = 2.5f * 72;
    public static final float LRM = .004f * 72;
    public static final float TBM = .00350f * 72;
    public static final float GAP = .3f * 72;
	
	protected static Document fcLabelDoc = new Document(PageSize.LETTER,0,0,9,0);
	
	protected static ColumnText ct = null;
	protected static PdfContentByte cb = null;
	protected static PdfWriter writer = null;
	protected static PdfPTable table = null;
	
	public static float ACROSS = 0;
	public static float DOWN = 0;
	
	public static String nl = System.getProperty("line.separator");
    
	public static int counter = 0;
	public static float [] COLS ;
  
	public static Font DOC_FONT = new Font (Font.COURIER, 8, Font.NORMAL);
	
	public static String magCode = null;
	public static String plantId = null;
	public static String issueNum = null;
	public static String issueWeek = null;
	public static String deliveryType = null;
	public static String processType = null;
	public static String theDeliveryType = null;
	public static String dataType = null;
	
	public static int errorCtr = 0;
	public static int ctr = 0;

	public FirstClassLabel(Magazine mag){

		super();
		magazine = mag;
		
		magCode = mag.getMagCode().toUpperCase();
		plantId = mag.getPlant().toUpperCase();
		issueNum = mag.getIssue().toUpperCase();
		issueWeek = mag.getWeek().trim();
		deliveryType = mag.getDeliveryType().toUpperCase();
		processType = mag.getProcessType().toUpperCase();
		theDeliveryType = mag.getDeliveryType().toUpperCase();
		dataType = mag.getDataType().toUpperCase();
	}
	
	private static StringBuffer addSpace(String strValue,int numLen,char padValue){
		StringBuffer str = new StringBuffer(strValue);
		
		int num = numLen - str.length();
	
		for (int j=0;j<=num;j++){	
			str = str.insert(j, padValue);
		}
		return str;
	}
	
	private static void reportHeader(){
		
		Date toDay = new Date(); 
		SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, MMM d, yyyy, HH:mm a ");

		String titleMag = "   " + String.valueOf(dateFormat.format(toDay)) + "  Magazine : " + magCode + " Issue : " + issueNum + " - " + issueWeek + "   Plant Id : " + plantId ;
		HeaderFooter header = new HeaderFooter(new Phrase(titleMag,FontFactory.getFont(FontFactory.COURIER, 12, Font.BOLD, new Color(255, 0, 0))), false);
        header.setBorderWidth(0);
        fcLabelDoc.setHeader(header);

	}
	
	protected static void init (){
		
		cb = writer.getDirectContent();  

        ct = new ColumnText(cb); 
        ct.setSimpleColumn(50, PageSize.LETTER.getHeight()-20, 50, PageSize.LETTER.getWidth(), 0, Element.ALIGN_LEFT);

        ACROSS = ( PageSize.LETTER.getWidth() - (LRM * 2) ) / W;  
        ACROSS -= ACROSS % 1; 

        DOWN = ( PageSize.LETTER.getHeight() - (TBM * 2) ) / H; 
        DOWN -= DOWN % 1;  

        COLS = new float [(int)ACROSS + 1 + ((int)ACROSS)];

        float cols = 0;  

        table = new PdfPTable ( COLS.length );
        table.getDefaultCell().setBorder(Rectangle.NO_BORDER);

        for (int i = 0; i < COLS.length; i++){
            if (i == 0 || i == COLS.length-1) {
                COLS[i] = LRM;
                cols += LRM;
                continue;
            }       
            if ((i+1) % 2 != 0 && i != COLS.length-1){  //if odd its a gap

                COLS[i] = GAP;
                cols += GAP;
                continue;
            }else {
                COLS[i] = W;
                cols += W;
                continue;
            }
        }
        try {
        	
            table.setTotalWidth(cols);  //tried removing this, not good
            table.setWidths(COLS);
            table.setLockedWidth(true);

            table.getDefaultCell().setPaddingBottom(0.0f);
            table.getDefaultCell().setPaddingTop(0.0f);

        } catch (DocumentException ex) {
        	LogWriter.writeLog(ex);
        }

		
	}
	
	public static void finish(){
		if (counter < ACROSS){

	        for (int i = counter; i < ACROSS ; i++){

	            table.addCell("");
	            table.addCell("");
	            counter++;

	        }

	            table.addCell("");  //last cell

	        }
        try {  //this could actually be put in finnish()


        	fcLabelDoc.add(table);


             } catch (DocumentException ex) {
            	 LogWriter.writeLog(ex);
             					
		}
	}
	public synchronized void ProcessFirstClassLabelReport(BufferedReader rdr){
		
		int errorCtr = 0;
		int ctr = 0;
		
		ACROSS = 0;DOWN = 0;counter = 0;
		
		fcLabelDoc = new Document(PageSize.LETTER,0,0,9,0);
			
		
		String RptPath = sybil.common.util.PropertyBroker.getProperty("NewPDFReportsPath","Not found");
		String fileName = magCode.toLowerCase() + ".i" + issueNum + "." + plantId + ".OMS_First_Class_Label." + issueWeek;
		
		try {
            writer = PdfWriter.getInstance(fcLabelDoc, new FileOutputStream(RptPath + fileName + ".pdf"));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        
        reportHeader();
                
        fcLabelDoc.open();
   
        init();
        
        createFirstClassLabel(rdr);
       
		finish();
    
	LogWriter.writeLog(magazine.getPrefix() + ": First Class Labels: Loaded <" + (ctr - 1) + "> records.. Errors " + errorCtr);

	if (errorCtr > 0) {
		if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
			LogWriter.writeLog("Process terminating due to database/sql exception");
			System.exit(1);
		}
	}
	
	fcLabelDoc.close();

	}
        
	
	public synchronized void createFirstClassLabel(BufferedReader rdr){
		
		
		String aRec = null;
			
		
		String line1 = null;
		String line2 = null;
		String line3 = null;
		String line4 = null;
		String line5 = null;

		String zipCode = null;
		

	    

	/******************************************************************************
	******* START OF THE PROCESSING FOR FOREIGN USPS AND CAN LABELS ***************
	******************************************************************************/

			
			
			try {
				
				while (!((aRec = rdr.readLine()) == null)) {

					if( aRec.trim().length() == 0)
						continue;
					
					
					String State =  (aRec.substring(5,7)).trim();
					String City =  (aRec.substring(7,27)).trim();
					String Name =  (aRec.substring(27,57)).trim();
					
					String addrLine1 =  (aRec.substring(87,117)).trim();
					String addrLine2 =  (aRec.substring(117,147)).trim();
					String Zip4 =  (aRec.substring(147,151)).trim();
//					String Country = (aRec.substring(173,203)).trim();
					
					String Asc_Account =  (aRec.substring(215,234)).trim();
/*					String KeyLine =  (aRec.substring(320,336)).trim();
					String XSheet_BV =  (aRec.substring(336,341)).trim();
					String Acs_Code =  (aRec.substring(350,358)).trim();
*/					String expissue = (aRec.substring(210,215)).trim();
					
					if (deliveryType.equalsIgnoreCase("FCCAN")){
						zipCode =  (aRec.substring(167,173)).trim();
						line5 = City + " " + State + " " + zipCode;
					}else {
						zipCode =  (aRec.substring(0,5)).trim();
						line5 = City + " " + State + " " + zipCode + " - " + Zip4;
					}

					line1 = Asc_Account + " " + addSpace(magCode,2,' ') + " " + addSpace(expissue,5,' ');
					line2 = Name;
					line3 = addrLine2;
					line4 = addrLine1;
					
					
			    String text = line1 + nl + line2 + nl + line3 + nl + line4 + nl
						+ line5 ;

				PdfPCell cell = new PdfPCell();

				cell = new PdfPCell(new Phrase(text, DOC_FONT));

				cell.setFixedHeight(H);

				cell.setNoWrap(true);

				cell.setVerticalAlignment(Element.ALIGN_LEFT);
				cell.setHorizontalAlignment(Element.ALIGN_LEFT);
				cell.setBorder(Rectangle.NO_BORDER);

				counter++; // 'int counter' keeps track of how many times
				// this method is called within a range of X (X = ACROSS)

				table.addCell("");
				table.addCell(cell);
				if (counter == ACROSS)
					table.addCell(""); // at the end

				if (counter == ACROSS)
					counter = 0; // if at the end reset the counter
					        
					
				}  // End of Read ....
		
			}	
			catch(Exception e){
				SybilWarningException warning = new SybilWarningException(magazine.getPrefix() + ": Error processing CAN Backdate Labels.");
				LogWriter.writeLog(warning);
				LogWriter.writeLog(e);
				
			}

	}

}