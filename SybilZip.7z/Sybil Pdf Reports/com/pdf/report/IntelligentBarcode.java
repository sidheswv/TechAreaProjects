package com.pdf.report;

import java.awt.Graphics2D;
import java.awt.RenderingHints;

import com.report.text.pdf.PdfContentByte;
import com.report.text.pdf.PdfTemplate;

import com.sybil.barcode4j.impl.fourstate.USPSIntelligentMailBean;
import com.sybil.barcode4j.output.java2d.Java2DCanvasProvider;
import com.sybil.barcode4j.tools.UnitConv;

public class IntelligentBarcode {
	
	private static final float height = 15.0f;
	private static final float width =  600.0f;

	public static PdfTemplate createUspsIntelligentBarcode(String code, PdfContentByte cb) { 
		
        if ((code.length() != 20) && (code.length() != 25) && (code.length() != 29) && (code.length() != 31)) { 
                throw new RuntimeException("UspsIntelligentBarcode: code length of " + code.length() + " is invalid."); 
        } 
         
        PdfTemplate tp = cb.createTemplate(width, height); 
         
        Graphics2D g2 = tp.createGraphics(width, height); 
        g2.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON); 
        g2.scale(2.5, 2.835);  
        Java2DCanvasProvider provider = new Java2DCanvasProvider(g2, 0); 
                 
        USPSIntelligentMailBean barcode = new USPSIntelligentMailBean(); 
         
        barcode.setAscenderHeight(UnitConv.in2mm(0.1f) * 0.7f);   
        barcode.setTrackHeight(UnitConv.in2mm(0.05f)* 0.7f);       
        barcode.setBarHeight(UnitConv.in2mm(0.145f)* 0.7f); 
        barcode.setIntercharGapWidth(UnitConv.in2mm(0.04f)* 0.7f * 1.13f);  
        barcode.generateBarcode(provider, code); 
        
        g2.dispose(); 
        
        return tp;
         
	} 
	
}
