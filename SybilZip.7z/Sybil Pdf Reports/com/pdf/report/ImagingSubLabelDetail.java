package com.pdf.report;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import sybil.common.model.Magazine;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;

import com.report.text.Document;
import com.report.text.DocumentException;
import com.report.text.Element;
import com.report.text.ExceptionConverter;
import com.report.text.Font;
import com.report.text.FontFactory;
import com.report.text.PageSize;
import com.report.text.Phrase;
import com.report.text.Rectangle;
import com.report.text.pdf.BaseFont;
import com.report.text.pdf.PdfContentByte;
import com.report.text.pdf.PdfPCell;
import com.report.text.pdf.PdfPTable;
import com.report.text.pdf.PdfPageEventHelper;
import com.report.text.pdf.PdfTemplate;
import com.report.text.pdf.PdfWriter;

public class ImagingSubLabelDetail extends PdfPageEventHelper {
	
	public static String rollsumTableName = "TBA_ROLL_SUM";
	public static String magazineInf = "TBA_MAGAZINEINF";
	public static String sybMag = "TBA_SYB_MAGAZINE";
	
	private static Connection conn = null;
	private static ResultSet resultset = null;
	private static String magName = null;
	
	private static Font TIMESROMAN_BOLD8  = FontFactory.getFont(FontFactory.TIMES_ROMAN, 8, Font.BOLD,Color.black);
	
	private static Font TIMESROMAN_BOLD  = FontFactory.getFont(FontFactory.TIMES_ROMAN, 10, Font.BOLD,Color.black);
	
	private static Font COURIER_NORMAL  = FontFactory.getFont(FontFactory.COURIER, 10, Font.NORMAL,Color.black);
	
	protected PdfTemplate total;
 	protected BaseFont helv;
 
 	public void onOpenDocument(PdfWriter writer, Document document) {
		total = writer.getDirectContent().createTemplate(100, 100);
		total.setBoundingBox(new Rectangle(-20, -20, 100, 100));
		try {
			helv = BaseFont.createFont(BaseFont.HELVETICA, BaseFont.WINANSI,BaseFont.NOT_EMBEDDED);
		} catch (Exception e) {
			throw new ExceptionConverter(e);
		}
	}
 
	public void onEndPage(PdfWriter writer, Document document) {
		PdfContentByte cb = writer.getDirectContent();
		cb.saveState();
		String text = "Page " + writer.getPageNumber() + " of  ";
		float textBase = document.bottom() - 15;
		float textSize = helv.getWidthPoint(text, 9);
		float textCenter = document.right()/2;
		cb.beginText();
		cb.setFontAndSize(helv, 10);

		cb.setTextMatrix(textCenter, textBase);
		cb.showText(text);
		cb.endText();
		cb.addTemplate(total, textCenter + textSize, textBase);
		cb.restoreState();
	}
 	
	public void onCloseDocument(PdfWriter writer, Document document) {
		total.beginText();
		total.setFontAndSize(helv, 10);
		total.setTextMatrix(0, 0);
		total.showText(String.valueOf(writer.getPageNumber() - 1));
		total.endText();
	}
	
	private static void open() {

		PreparedStatement setSqlId = null;
		Statement commitSqlId = null;
		String x = null;
		String db2owner = null;
		int i = 0;
		
		String userDb = sybil.common.util.PropertyBroker.getProperty("database.login","sybil");
		String pswdDb = sybil.common.util.PropertyBroker.getProperty("database.password","sybil");
		
		
		if( conn == null) {
			try {
				Class.forName(sybil.common.util.PropertyBroker.getProperty("database.driver", "Not Found"));
				conn = DriverManager.getConnection(sybil.common.util.PropertyBroker.getProperty("database.server", "Not Found"), userDb, pswdDb);

				//
				x = PropertyBroker.getProperty("database.driver", "Not Found").toLowerCase();
				i = x.indexOf("db2");
				if (!(i < 0)) {
					try {
						db2owner = PropertyBroker.getProperty("DB2OWNER","dtppsyup");
						setSqlId = conn.prepareStatement("set current sqlid = ?");
						setSqlId.setString(1, db2owner);
						setSqlId.execute();
						commitSqlId = conn.createStatement();
						commitSqlId.execute("commit");
					}
					catch (SQLException se) {
						if(se.getSQLState().equals("S1010")) {
						}
						else {
							LogWriter.writeLog(se);
							LogWriter.writeLog("Error: Set Current SqlId failed.");
							if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
								LogWriter.writeLog("Process terminating due to database/sql exception");
								System.exit(1);
							}
						}
					}
					catch (Exception e) {
						LogWriter.writeLog(e);
						LogWriter.writeLog("Error: Set Current SqlId failed.");
						if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
							LogWriter.writeLog("Process terminating due to database/sql exception");
							System.exit(1);
						}
					}
				}
			
			} 
			catch (Exception e) {
				sybil.common.util.LogWriter.writeLog(e);
				LogWriter.writeLog("Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
		
	return;
	}
	

	private static String getIssueDate(Magazine mag){
		
		String issueDate = null;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT COVER_DATE FROM " + magazineInf + " WHERE PLANT = ? and MAG = ? and ISSUE = ? ";
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, mag.getPlant().toUpperCase());
		selectMag.setString(2, mag.getMagCode().toLowerCase());
		selectMag.setString(3, mag.getIssue());
		
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			issueDate  = rs.getString("COVER_DATE");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Issue Date error " + mag.getMagCode());
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectMag != null) {
				try {
					selectMag.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		return issueDate;
	}

	private static int magazineKey(String magazineCode){
		
		int magKey = 0;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT MAG_KEY, NAME  FROM " + sybMag + " WHERE MAG_CD = ? ";
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, magazineCode);
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			magKey  = (int)rs.getInt("MAG_KEY");
			magName = rs.getString("NAME");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Code Select error " + magazineCode);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectMag != null) {
				try {
					selectMag.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		return magKey;
	}

	
	public synchronized static void CreatePDF(Magazine mag){
		
		PreparedStatement selectcopyCnt = null;
		Document idDoc = new Document(PageSize.LETTER,0,0,25,25);
		String savebraceId = "  ";
		boolean firstRow = true;	
		boolean firstTime = true;
		boolean noImageDetailRpt = true;
		int totalCopy = 0;
		int braceCopy = 0;
		
		int [] tablew = {4,4,6,4,9,6,12};
		
		String magCode = mag.getMagCode().trim();
		String issueNum = mag.getIssue().trim();
		String issueWeek = mag.getWeek().trim();
		String plantId = mag.getPlant().toUpperCase().trim();
		String processType = mag.getProcessType().toUpperCase().trim();
		
		String RptPath = sybil.common.util.PropertyBroker.getProperty("NewPDFReportsPath","Not found");
		String fileName = magCode.toLowerCase() + ".i" + issueNum + "." + plantId + ".OMS_Imaging_Sub_Label_Detail." + issueWeek + "." + processType;
		
		open();
		            
		String SQL  = "SELECT BRACE_ID, BIND_GRP_NME, JOB_ID, ROLL_NUM, GEO_CAT_ID, GEO_CAT_NME, "
		    + "DEPART_DT, DEPART_TIME, LABEL_MTH, PAL_SACK_IND, XSHEET_BV_NME, COPY_CNT"
		    + " FROM  " + rollsumTableName                  
	        + " WHERE  MAG_KY = ? AND INSTNC_CD = ? AND MAG_CD = ? AND PLANT_ID = ? AND ISS_NUM = ? AND ISS_WK_NUM = ? AND LABEL_MTH IN ('AM','PL') "
	        + "ORDER BY BRACE_ID , ROLL_NUM ";
		
		//LogWriter.writeLog("select from TBA_ROLL_NUM query " + SQL);
		
		int magKey = magazineKey(magCode);
		
		String issueDate = getIssueDate(mag);
		
		String instCd = InstanceCd.getInstCd(magKey, issueDate);
		
		try {
			
			PdfWriter writer = PdfWriter.getInstance(idDoc,				
					new FileOutputStream(RptPath + fileName + ".pdf"));
			

			writer.setViewerPreferences(PdfWriter.PageModeFullScreen);
			writer.setPageEvent(new ImagingSubLabelDetail());
			
			idDoc.open();
			
			PdfPCell dummyCell = new PdfPCell(new Phrase("", FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD, Color.black)));
			dummyCell.setBorderWidth(0);
			
			Date toDay = new Date(); 
			SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, MMM d, yyyy, HH:mm a "); 

      		PdfPTable outertable = new PdfPTable(1);
			outertable.setHeaderRows(11);
			
			PdfPCell header0 = new PdfPCell(new Phrase(String.valueOf(dateFormat.format(toDay)),
					FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,Color.black)));
			header0.setBorderWidth(0);
			outertable.addCell(header0);
			
			String issueHdr = "Issue :" + issueDate + "(" + issueNum + " - " + issueWeek +")";
			PdfPCell issueCell = new PdfPCell(new Phrase(issueHdr,
					FontFactory.getFont(FontFactory.COURIER, 9, Font.NORMAL,Color.black)));
			issueCell.setBorderWidth(0);
			outertable.addCell(issueCell);
			
			PdfPCell cell1 = new PdfPCell(new Phrase(
					"Imaging Subscriber Label Report", FontFactory.getFont(
							FontFactory.TIMES_ROMAN, 14, Font.NORMAL, Color.BLACK)));
			cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell1.setBorderWidth(0);
			outertable.addCell(cell1);
					
			PdfPCell cell2 = new PdfPCell(new Phrase(
					"Detail List of Attached Mail and Paper Label Rolls", FontFactory.getFont(
							FontFactory.TIMES_ROMAN, 14, Font.NORMAL, Color.BLACK)));
			cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell2.setBorderWidth(0);
			outertable.addCell(cell2);
			
		
			for ( int s = 0; s <=2; s++)outertable.addCell(dummyCell);

			selectcopyCnt = conn.prepareStatement(SQL);
			selectcopyCnt.setInt(1, magKey);
			selectcopyCnt.setString(2, instCd);
			selectcopyCnt.setString(3, magCode);
			selectcopyCnt.setString(4, plantId);
			selectcopyCnt.setInt(5, toNum.toNumber(issueNum));
			selectcopyCnt.setInt(6, toNum.toNumber(issueWeek));

			resultset = selectcopyCnt.executeQuery();
			
			while (resultset.next()){
				noImageDetailRpt = false;
				String braceId = resultset.getString("BRACE_ID");
 				String bindGrp  = resultset.getString("BIND_GRP_NME");
				String rollNum = resultset.getString("ROLL_NUM");
				String marketId = resultset.getString("GEO_CAT_ID");
				String desc = resultset.getString("GEO_CAT_NME");
				String departDt = resultset.getString("DEPART_DT");
				String departTime = resultset.getString("DEPART_TIME");
				String labelMth = resultset.getString("LABEL_MTH");
				String palsackInd = resultset.getString("PAL_SACK_IND");
				String Xsheet = resultset.getString("XSHEET_BV_NME");
				String copyCnt = resultset.getString("COPY_CNT");
				String jobId = resultset.getString("JOB_ID");
				
				totalCopy += Integer.valueOf(copyCnt).intValue();
				
			if (firstRow) {
				
				String header1 = "Magazine : " + magName.trim() + "  Plant : " + plantId + "  Issue :" + issueNum + " - " + issueWeek +  "  JobId : " + jobId;
				PdfPCell magCell = new PdfPCell(new Phrase(header1,
						FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD,
								Color.black)));
				magCell.setBorderWidth(0);
				outertable.addCell(magCell);
				
				for ( int G = 0; G <=2; G++)outertable.addCell(dummyCell);			
				firstRow = false;
			}				
			
			if (braceId.compareTo(savebraceId) == 0){
				
				PdfPTable detailTable = new PdfPTable(7);
				detailTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				detailTable.setWidths(tablew);
				detailTable.addCell(new Phrase(labelMth,COURIER_NORMAL));
				String rollNumDisp = AddSpace.addSpace(rollNum,3,'0') + "";
				detailTable.addCell(new Phrase(rollNumDisp,COURIER_NORMAL));
				String copyCountDisp  = AddSpace.addSpace(PlaceComma.placeComma(Integer.valueOf(copyCnt).intValue()),5) +"";
				detailTable.addCell(new Phrase(copyCountDisp,COURIER_NORMAL));
				detailTable.addCell(new Phrase(palsackInd,COURIER_NORMAL));
				detailTable.addCell(new Phrase(Xsheet,COURIER_NORMAL));
				detailTable.addCell(new Phrase(marketId,COURIER_NORMAL));
				detailTable.addCell(new Phrase(desc,COURIER_NORMAL));
					
				PdfPCell detailCell = new PdfPCell(detailTable);
				detailCell.setBorderWidth(0);
				outertable.addCell(detailCell);
				
				braceCopy += Integer.valueOf(copyCnt).intValue();
				
			} 
			else {	
			     if (firstTime){
				     firstTime = false;	
	      		 }
			     else{   	 
			    	 for ( int G = 0; G <2; G++)outertable.addCell(dummyCell);
			    	 
			    	 int [] braceTotw = {3,5,7,3,9,6,12}; 
			    	 PdfPTable braceTotalTable = new PdfPTable(7);
					 braceTotalTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
					 braceTotalTable.setWidths(braceTotw);
					 braceTotalTable.addCell(new Phrase(savebraceId,TIMESROMAN_BOLD8));
					 braceTotalTable.addCell(new Phrase(" Brace Total :",TIMESROMAN_BOLD8));
					 String totCopyCountDisp  = AddSpace.addSpace(PlaceComma.placeComma(braceCopy),6) +"";
					 braceTotalTable.addCell(new Phrase(totCopyCountDisp,COURIER_NORMAL));
					 braceTotalTable.addCell(new Phrase("",COURIER_NORMAL));
					 braceTotalTable.addCell(new Phrase("",COURIER_NORMAL));
					 braceTotalTable.addCell(new Phrase("",COURIER_NORMAL));
					 braceTotalTable.addCell(new Phrase("",COURIER_NORMAL));
						
					 PdfPCell braceTotalCell = new PdfPCell(braceTotalTable);
					 braceTotalCell.setBorderWidth(0);
					 outertable.addCell(braceTotalCell);
			    	 
					 braceCopy = 0;	
					 
					 for (int G = 0; G <2; G++)outertable.addCell(dummyCell);
			     }			
			     savebraceId = braceId;
			     
			     int [] braceTablew = {6,6,9};
			     PdfPTable braceHeader = new PdfPTable(3);
				 braceHeader.getDefaultCell().setBorder(Rectangle.NO_BORDER | Rectangle.BOTTOM);
				 braceHeader.setWidths(braceTablew);
				 String braceDisp = " Brace " +  braceId;
				 braceHeader.addCell(new Phrase(braceDisp,TIMESROMAN_BOLD));
				 braceHeader.addCell(new Phrase(bindGrp.trim(),TIMESROMAN_BOLD));
				 String dateTime = "( " +  departDt + "       " + departTime + "  )";
				 braceHeader.addCell(new Phrase(dateTime,TIMESROMAN_BOLD));
				 	
				 PdfPCell braceHeaderCell = new PdfPCell(braceHeader);
				 braceHeaderCell.setBorderWidth(0);
				 outertable.addCell(braceHeaderCell);
				 
				 for ( int G = 0; G <2; G++)
					outertable.addCell(dummyCell);
				 
				 PdfPTable headertable1 = new PdfPTable(7);
				 headertable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				 headertable1.setWidths(tablew);
				 headertable1.addCell(new Phrase("Attached/Paper ",TIMESROMAN_BOLD));
				 headertable1.addCell(new Phrase("Roll Num",TIMESROMAN_BOLD));
				 headertable1.addCell(new Phrase("Copy Count",TIMESROMAN_BOLD));
				 headertable1.addCell(new Phrase("Sack or Pallet",TIMESROMAN_BOLD));
				 headertable1.addCell(new Phrase("X-Sheet Book Version Name",TIMESROMAN_BOLD));
				 headertable1.addCell(new Phrase("Market Id",TIMESROMAN_BOLD));
				 headertable1.addCell(new Phrase("Description",TIMESROMAN_BOLD));
					
				 PdfPCell headercell1 = new PdfPCell(headertable1);
				 headercell1.setBorderWidth(0);
				 outertable.addCell(headercell1);
					
				 braceCopy += Integer.valueOf(copyCnt).intValue();
				 
				 PdfPTable detailTable = new PdfPTable(7);
				 detailTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				 detailTable.setWidths(tablew);
				 detailTable.addCell(new Phrase(labelMth,COURIER_NORMAL));
				 String rollNumDisp = AddSpace.addSpace(rollNum,3,'0') + "";
				 detailTable.addCell(new Phrase(rollNumDisp,COURIER_NORMAL));
				 String copyCountDisp  = AddSpace.addSpace(PlaceComma.placeComma(Integer.valueOf(copyCnt).intValue()),5) +"";
				 detailTable.addCell(new Phrase(copyCountDisp,COURIER_NORMAL));
				 detailTable.addCell(new Phrase(palsackInd,COURIER_NORMAL));
				 detailTable.addCell(new Phrase(Xsheet,COURIER_NORMAL));
				 detailTable.addCell(new Phrase(marketId,COURIER_NORMAL));
				 detailTable.addCell(new Phrase(desc,COURIER_NORMAL));
					
				 PdfPCell detailCell = new PdfPCell(detailTable);
				 detailCell.setBorderWidth(0);
				 outertable.addCell(detailCell);
			    }
		}
			
			if (noImageDetailRpt){
				String header1 = "Magazine : " + magName.trim() + "  Plant : " + plantId + "  Issue :" + issueNum + " - " + issueWeek  ;
				PdfPCell magCell = new PdfPCell(new Phrase(header1,
						FontFactory.getFont(FontFactory.COURIER, 10, Font.BOLD,
								Color.black)));
				magCell.setBorderWidth(0);
				outertable.addCell(magCell);
				
				for ( int G = 0; G <=2; G++)
					outertable.addCell(dummyCell);
				
			}
			else{
				int [] braceTotw = {3,5,7,3,9,6,12};
		    	PdfPTable braceTotalTable = new PdfPTable(7);
				braceTotalTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				braceTotalTable.setWidths(braceTotw);
				braceTotalTable.addCell(new Phrase(savebraceId,TIMESROMAN_BOLD8));
				braceTotalTable.addCell(new Phrase(" Brace Total :",TIMESROMAN_BOLD8));
				String totCopyCountDisp  = AddSpace.addSpace(PlaceComma.placeComma(braceCopy),6) +"";
				braceTotalTable.addCell(new Phrase(totCopyCountDisp,COURIER_NORMAL));
				braceTotalTable.addCell(new Phrase("",COURIER_NORMAL));
				braceTotalTable.addCell(new Phrase("",COURIER_NORMAL));
				braceTotalTable.addCell(new Phrase("",COURIER_NORMAL));
				braceTotalTable.addCell(new Phrase("",COURIER_NORMAL));
					
				PdfPCell braceTotalCell = new PdfPCell(braceTotalTable);
				braceTotalCell.setBorderWidth(0);
				outertable.addCell(braceTotalCell);
			}
			for ( int G = 0; G <=2; G++)outertable.addCell(dummyCell);
			
			int [] braceTablew = {6,6,9};
		    PdfPTable rptTotalHeader = new PdfPTable(3);
			rptTotalHeader.getDefaultCell().setBorder(Rectangle.NO_BORDER | Rectangle.BOTTOM | Rectangle.TOP );
			rptTotalHeader.setWidths(braceTablew);
			rptTotalHeader.addCell(new Phrase("REPORT TOTAL :",TIMESROMAN_BOLD));
			String rptTotal = PlaceComma.placeComma(totalCopy) +"";
			rptTotalHeader.addCell(new Phrase(rptTotal,TIMESROMAN_BOLD));
			rptTotalHeader.addCell(new Phrase("Attached Mail and Paper Labels",TIMESROMAN_BOLD));
			 	
			PdfPCell rptTotalHeaderCell = new PdfPCell(rptTotalHeader);
			rptTotalHeaderCell.setBorderWidth(0);
			outertable.addCell(rptTotalHeaderCell);
			
			idDoc.add(outertable);

		} 
		catch (SQLException se) {
			System.err.println(se.getMessage());
		}
	
		catch (DocumentException de) {
			System.err.println(de.getMessage());
		} catch (IOException ioe) {
			System.err.println(ioe.getMessage());
		} finally {
			if (resultset != null) {
				try {
					resultset.close();
				} catch (SQLException e) { /* ignored */}
			}
			if (selectcopyCnt != null) {
				try {
					selectcopyCnt.close();
				} catch (SQLException e) { /* ignored */}
			}
		}			
		idDoc.close();
		LogWriter.writeLog(" Imaging Sub Label Detail Report Generated " );
		return;
	}


}
