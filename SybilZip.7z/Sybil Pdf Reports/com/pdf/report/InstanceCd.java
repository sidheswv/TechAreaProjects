package com.pdf.report;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;

public class InstanceCd {
	
	private static String instCd = null;
	
	private static Connection conn = null;
	
	public static String magInstnc = "TBA_MAG_INSTNC";
	
	private static void open() {

		PreparedStatement setSqlId = null;
		Statement commitSqlId = null;
		String x = null;
		String db2owner = null;
		int i = 0;
		
		String userDb = sybil.common.util.PropertyBroker.getProperty("database.login","sybil");
		String pswdDb = sybil.common.util.PropertyBroker.getProperty("database.password","sybil");
		
		
		if( conn == null) {
			try {
				Class.forName(sybil.common.util.PropertyBroker.getProperty("database.driver", "Not Found"));
				conn = DriverManager.getConnection(sybil.common.util.PropertyBroker.getProperty("database.server", "Not Found"), userDb, pswdDb);

				//
				x = PropertyBroker.getProperty("database.driver", "Not Found").toLowerCase();
				i = x.indexOf("db2");
				if (!(i < 0)) {
					try {
						db2owner = PropertyBroker.getProperty("DB2OWNER","dtppsyup");
						setSqlId = conn.prepareStatement("set current sqlid = ?");
						setSqlId.setString(1, db2owner);
						setSqlId.execute();
						commitSqlId = conn.createStatement();
						commitSqlId.execute("commit");
					}
					catch (SQLException se) {
						if(se.getSQLState().equals("S1010")) {
						}
						else {
							LogWriter.writeLog(se);
							LogWriter.writeLog("Error: Set Current SqlId failed.");
							if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
								LogWriter.writeLog("Process terminating due to database/sql exception");
								System.exit(1);
							}
						}
					}
					catch (Exception e) {
						LogWriter.writeLog(e);
						LogWriter.writeLog("Error: Set Current SqlId failed.");
						if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
							LogWriter.writeLog("Process terminating due to database/sql exception");
							System.exit(1);
						}
					}
				}
			
			} 
			catch (Exception e) {
				sybil.common.util.LogWriter.writeLog(e);
				LogWriter.writeLog("Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
		
	return;
	}


	public static String getInstCd(int magKey,String issueDate){
		 
		PreparedStatement selectMagInst = null;
		ResultSet rs = null;
		
		open();
		
		LogWriter.writeLog(" Issue Date : " + issueDate);
		String db2Date = "20".concat(issueDate.substring(6, 8)).concat("-").concat(issueDate.substring(0, 2)).concat("-").concat(issueDate.substring(3, 5));
		LogWriter.writeLog(" DB2 Date : " + db2Date);
				
		String SQL = "SELECT INSTNC_CD FROM " + magInstnc + " WHERE MAG_KY = ? AND ISS_DT = ?  ";
		
		try {
		selectMagInst = conn.prepareStatement(SQL);
		selectMagInst.setInt(1, magKey);
		selectMagInst.setString(2, db2Date);
		
		rs = selectMagInst.executeQuery();
		
		while (rs.next()){
			instCd  = rs.getString("INSTNC_CD");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Code Select error " + magKey + " Issue Date : " + issueDate + " DB2Date : " + db2Date);
			LogWriter.writeLog("Process terminating due to database/sql exception");
			System.exit(1);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectMagInst != null) {
				try {
					selectMagInst.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		return instCd;
	}
	
	public static String getInstCd(int magKey,int issueNum, int issueWeek){
		 
		PreparedStatement selectMagInst = null;
		ResultSet rs = null;
		
		open();
				
		String SQL = "SELECT INSTNC_CD FROM " + magInstnc + " WHERE MAG_KY = ? AND ISS_NUM = ? and ISS_WK_NUM = ? ";
		
		try {
		selectMagInst = conn.prepareStatement(SQL);
		selectMagInst.setInt(1, magKey);
		selectMagInst.setInt(2, issueNum);
		selectMagInst.setInt(3, issueWeek);
		
		rs = selectMagInst.executeQuery();
		
		while (rs.next()){
			instCd  = rs.getString("INSTNC_CD");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Code Select error " + magKey + " Issue Num : " + issueNum + "Issue Week : " + issueWeek);
			LogWriter.writeLog("Process terminating due to database/sql exception");
			System.exit(1);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) { /* ignored */}
				}
			if (selectMagInst != null) {
				try {
					selectMagInst.close();
				} catch (SQLException e) { /* ignored */}
			}
		}
		return instCd;
	}
}
