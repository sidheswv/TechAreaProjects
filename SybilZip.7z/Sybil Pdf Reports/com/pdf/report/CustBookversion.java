package com.pdf.report;

import java.io.BufferedReader;
import java.io.EOFException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.StringTokenizer;

import sybil.common.model.Magazine;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;
import sybil.common.util.SybilWarningException;

public class CustBookversion {
	
	public static String sybMag = "TBA_SYB_MAGAZINE";

	public static String magazineInf = "TBA_MAGAZINEINF";

	public static String custBvTableName = "TBA_CUST_BV";

	private static Connection conn = null;
	
	private static void open() {

		PreparedStatement setSqlId = null;
		Statement commitSqlId = null;
		String x = null;
		String db2owner = null;
		int i = 0;
		
		String userDb = sybil.common.util.PropertyBroker.getProperty("database.login","sybil");
		String pswdDb = sybil.common.util.PropertyBroker.getProperty("database.password","sybil");
		
		
		if( conn == null) {
			try {
				Class.forName(sybil.common.util.PropertyBroker.getProperty("database.driver", "Not Found"));
				conn = DriverManager.getConnection(sybil.common.util.PropertyBroker.getProperty("database.server", "Not Found"), userDb, pswdDb);

				//
				x = PropertyBroker.getProperty("database.driver", "Not Found").toLowerCase();
				i = x.indexOf("db2");
				if (!(i < 0)) {
					try {
						db2owner = PropertyBroker.getProperty("DB2OWNER","dtppsyup");
						setSqlId = conn.prepareStatement("set current sqlid = ?");
						setSqlId.setString(1, db2owner);
						setSqlId.execute();
						commitSqlId = conn.createStatement();
						commitSqlId.execute("commit");
					}
					catch (SQLException se) {
						if(se.getSQLState().equals("S1010")) {
						}
						else {
							LogWriter.writeLog(se);
							LogWriter.writeLog("Error: Set Current SqlId failed.");
							if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
								LogWriter.writeLog("Process terminating due to database/sql exception");
								System.exit(1);
							}
						}
					}
					catch (Exception e) {
						LogWriter.writeLog(e);
						LogWriter.writeLog("Error: Set Current SqlId failed.");
						if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
							LogWriter.writeLog("Process terminating due to database/sql exception");
							System.exit(1);
						}
					}
				}
			
			} 
			catch (Exception e) {
				sybil.common.util.LogWriter.writeLog(e);
				LogWriter.writeLog("Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
		
	return;
	}
	
	
	public static void close() {
		
		if( conn != null) {		
			try { conn.close(); }catch(Exception sql ){};
			conn = null;
		}
		return;
	}
	
	private static int magazineKey(String magazineCode){
		
		int magKey = 0;
		PreparedStatement selectMag = null;
		ResultSet rs = null;
				
		String SQL = "SELECT MAG_KEY, NAME  FROM " + sybMag + " WHERE MAG_CD = ? ";
		LogWriter.writeLog("select from " + sybMag + "   "  + SQL);
		
		try {
		selectMag = conn.prepareStatement(SQL);
		selectMag.setString(1, magazineCode);
		rs = selectMag.executeQuery();
		
		while (rs.next()){
			magKey  = (int)rs.getInt("MAG_KEY");
		}
		}catch (SQLException se) {
			LogWriter.writeLog(se);
			LogWriter.writeLog("Magazine Code Select error " + magazineCode);
		}
		return magKey;
	}


	
	public static synchronized void ProcessCustBookversion(BufferedReader rdr, Magazine mag){	
		
		String rec = null;
		PreparedStatement insert;
		PreparedStatement delCBV;
		
		String magCode = mag.getMagCode().trim();
		String issueNum = mag.getIssue().trim();
		String plantId = mag.getPlant().toUpperCase().trim();
		String issueWeek = mag.getWeek().trim();
		
				
		String theDataType = mag.getDataType();
		String theProcType = mag.getProcessType();
		String theDelType = mag.getDeliveryType();
		
		Statement st;
		
		int errorCtr = 0;
		String RollId = null;
		String BookVersion = null;
		String geoCatId = null;
		int nestingFactor = 0;
		int CopyCount = 0;
		int PrelimDriverCode = 0;
		int finalDriverCode = 0;

		open();
			
		int magKey = magazineKey(magCode);
		
		String instCd = InstanceCd.getInstCd(magKey, toNum.toNumber(issueNum), toNum.toNumber(issueWeek));
		
		String delSQL = "DELETE FROM " + custBvTableName + 
		" WHERE  MAG_KY = ? AND INSTNC_CD = ? AND PLANT_ID = ? AND MAG_CD = ? AND  ISS_NUM = ? AND ISS_WK_NUM = ? " +
		" AND DATA_TYPE = ? AND PROCESS_TYPE = ? AND DELIVERY_TYPE = ? ";
		
		String commitSQL = "commit";
		
		try {

			delCBV = conn.prepareStatement(delSQL); 
				
			delCBV.setInt(1, magKey);
			delCBV.setString(2, instCd);
			delCBV.setString(3, plantId);
			delCBV.setString(4, magCode);
			delCBV.setInt(5, toNum.toNumber(issueNum));
			delCBV.setInt(6, toNum.toNumber(issueWeek));
			delCBV.setString(7, theDataType);
			delCBV.setString(8, theProcType);
			delCBV.setString(9, theDelType);
			delCBV.execute();
			st = conn.createStatement();
				//st.executeUpdate(delSQL);
			st.execute(commitSQL);
			
			delCBV.close();
			st.close();
		}

		catch (SQLException se) {
			if(se.getSQLState().equals("S1010")) {
			}
			else {
				LogWriter.writeLog(se);
				LogWriter.writeLog("MaildatLoader.processCustBookversion ... SQLException: error=" + 
					se.getErrorCode() + " state=" + se.getSQLState() + " msg=" + se.getMessage());
				if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
					LogWriter.writeLog("Process terminating due to database/sql exception");
					System.exit(1);
				}
			}
		}
	 
		catch (Exception e) {
			LogWriter.writeLog(e);
			if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
				LogWriter.writeLog("Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
		
		int ctr = 0;
		
		String insSQL = "insert into " + custBvTableName +  " (" +
				" MAG_KY, INSTNC_CD, PLANT_ID, MAG_CD, ISS_NUM, ISS_WK_NUM, DATA_TYPE, PROCESS_TYPE, " +
				" DELIVERY_TYPE, ROLL_NUM, XSHEET_BV_NME, GEO_CAT_ID, PREM_DRIVER_CD, " +
				" FNL_DRIVER_CD, COPY_CNT, NEST_COPY_CNT, ROLL_ID ) VALUES ( " +
				" ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) ";
		
		
		if (!theDataType.equalsIgnoreCase("oms2msg")){
			try {		
				
				insert = conn.prepareStatement(insSQL);
					
				while (!((rec = rdr.readLine()) == null)) {	

					if( rec.trim().length() == 0)
						continue;

		/// Parsing of the Customer Book Version file for loading into the table					
				String aString = null;
				StringTokenizer tokenizer = new StringTokenizer(rec, String.valueOf("\t"));
				
				if (tokenizer.countTokens() < 5) {
					LogWriter.writeLog("Error parsing CustBV record. Expected 5 fields, found " + tokenizer.countTokens() + ":" + rec);
					RollId = ("0000");
					BookVersion = ("000000");
					CopyCount = (new Integer(0)).intValue();
					PrelimDriverCode = (new Integer(0)).intValue();
					return;
				}

			// RollId	
				RollId = (tokenizer.nextToken().trim());

			// BookVersion	
				aString = tokenizer.nextToken().trim();
				try {
					BookVersion = (aString);
				} catch (NumberFormatException ex) {
					SybilWarningException e = new SybilWarningException
							("DatabaseFileLoader: Number conversion error caused by bookversion <" +
								aString + "> in CustBV record.");
					LogWriter.writeLog(e);
					BookVersion = ("000000");
				}

			// Copy Count	
				aString = tokenizer.nextToken().trim();
				try {
					CopyCount = (Integer.valueOf(aString)).intValue();
				} catch (NumberFormatException ex) {
					SybilWarningException e = new SybilWarningException
							("DatabaseFileLoader: Number conversion error caused by copy count <" +
								aString + "> in CustBV record.");
					LogWriter.writeLog(e);
					CopyCount = (new Integer(0)).intValue();
				}

			// Prelim Driver Code
				aString = tokenizer.nextToken().trim();
				try {
					PrelimDriverCode = (Integer.valueOf(aString)).intValue();
				} catch (NumberFormatException ex) {
					SybilWarningException e = new SybilWarningException
							("DatabaseFileLoader: Number conversion error caused by copy count <" +
								aString + "> in CustBV record.");
					LogWriter.writeLog(e);
					PrelimDriverCode = (new Integer(0)).intValue();
				}
				
			//	Geo Cat Id	
				aString = tokenizer.nextToken().trim();
				try {
					geoCatId = (aString);
				} catch (NumberFormatException ex) {
					SybilWarningException e = new SybilWarningException
							("DatabaseFileLoader: Number conversion error caused by bookversion <" +
								aString + "> in CustBV record.");
					LogWriter.writeLog(e);
					geoCatId = ("ZZZZ");
				}
				
			//	Nesting Factor
				aString = tokenizer.nextToken().trim();
				
				try {
					
					nestingFactor = (Integer.valueOf(aString)).intValue();
					if (nestingFactor == 0 ) nestingFactor = 01;
				} catch (NumberFormatException ex) {
					SybilWarningException e = new SybilWarningException
							("DatabaseFileLoader: Number conversion error caused by bookversion <" +
								aString + "> in CustBV record.");
					LogWriter.writeLog(e);
					nestingFactor = (new Integer(1)).intValue();
				}
				

					insert.setInt(1, magKey);
					insert.setString(2, instCd);
					insert.setString(3, plantId);
					insert.setString(4, magCode);
					insert.setInt(5, toNum.toNumber(issueNum));
					insert.setInt(6, toNum.toNumber(issueWeek));
					insert.setString(7, theDataType);
					insert.setString(8, theProcType);
					insert.setString(9, theDelType);
					insert.setInt(10, toNum.toNumber(RollId));
					insert.setString(11, BookVersion);
					insert.setString(12, geoCatId);
					insert.setInt(13, PrelimDriverCode);
					insert.setInt(14, finalDriverCode);
					insert.setInt(15, CopyCount);
					insert.setInt(16, nestingFactor);
					insert.setString(17, RollId);
					

					try{	
						insert.execute();
						ctr++;
					}catch(Exception e) {	
							LogWriter.writeLog(e);
							errorCtr++;
							LogWriter.writeLog("CustBookVersion: Error key ... " +  plantId.toUpperCase() + " " + 
									magKey + " " + instCd + " " + magCode + " " + toNum.toNumber(issueNum) + " " + issueWeek + " " + 
									theDataType + " " + theProcType + " " + theDelType + " " + RollId + " " + 
									BookVersion);
					}
				}
				st = conn.createStatement();
				st.execute(commitSQL);
				insert.close();
				st.close();
				LogWriter.writeLog(mag.getPrefix() + ": CustBookVersion: Loaded <" + ctr + "> records. Errors " + errorCtr);		
			}
		
			catch (EOFException ee){
				LogWriter.writeLog(mag.getPrefix() + ": CustBookVersion: Loaded <" + ctr + "> records. Errors " + errorCtr);
				
				if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
					LogWriter.writeLog("Process terminating due to database/sql exception");
					System.exit(1);
				}
			
			}
			catch (Exception e) {
					SybilWarningException warning = new SybilWarningException(mag.getPrefix() + ": Error processing CustBookVersion.");
					LogWriter.writeLog(warning);
					LogWriter.writeLog(e);
				
					if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
						LogWriter.writeLog("Process terminating due to database/sql exception");
						System.exit(1);
					}
			}
		}

		close();
		return;
	}
	


}
