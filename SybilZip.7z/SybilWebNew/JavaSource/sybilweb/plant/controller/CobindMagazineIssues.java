package sybilweb.plant.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class CobindMagazineIssues {

	private Map<String, String> cobindMagIssuesMap = new HashMap<String, String>();

	public CobindMagazineIssues() {
		String magkyCobind = null;
		int magkyCobindNumber = 0;
		String magissueCobind = null;
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			Hashtable parms = new Hashtable();
			parms.put(Context.INITIAL_CONTEXT_FACTORY,
					"com.ibm.ejs.ns.jndi.CNInitialContextFactory");
			Context ctx = new InitialContext(parms);
			DataSource ds = (DataSource) ctx.lookup("jdbc/sybil");
			conn = ds.getConnection();
			String db2owner = sybilweb.plant.controller.PropertyBroker.getProperty("DB2OWNER");
			LogWriter.writeLog("db2owner from property: "+db2owner);
			String queryCobind = "SELECT AA.COBIND_CYC_KY, AA.MAGCODEA FROM "
					+ "(SELECT A.COBIND_CYC_KY, CONCAT(CONCAT(B.MAG_CD, A.ISS_NUM), A.ISS_WK_NUM) AS MAGCODEA FROM "
					+ db2owner + ".TBA_COBIND_CYC_MAG A, " + db2owner
					+ ".TBA_SYB_MAGAZINE B "
					+ " WHERE A.MAG_KY = B.MAG_KEY) AA, "
					+ " (SELECT F.COBIND_CYC_KY, COUNT(*) FROM " + db2owner
					+ ".TBA_COBIND_CYC_MAG F "
					+ " GROUP BY F.COBIND_CYC_KY HAVING COUNT(*) = 2)BB "
					+ " WHERE AA.COBIND_CYC_KY = BB.COBIND_CYC_KY "
					+ " ORDER BY AA.COBIND_CYC_KY WITH UR";
			LogWriter.writeLog("Fetching Cobind issues: queryCobind "
					+ queryCobind);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(queryCobind);
			while (rs.next()) {
				magkyCobindNumber = rs.getInt(1);
				magkyCobind = String.format("%04d", magkyCobindNumber);
				magissueCobind = ((String) rs.getString(2)).trim();
				if (cobindMagIssuesMap.containsKey(magkyCobind)) {
					String oldVal = cobindMagIssuesMap.get(magkyCobind);
					oldVal = oldVal + "_" + magissueCobind;
					cobindMagIssuesMap.put(magkyCobind, oldVal);
					LogWriter.writeLog("Final time " + magkyCobind + ":"
							+ oldVal);
				} else {
					cobindMagIssuesMap.put(magkyCobind, magissueCobind);
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			LogWriter.writeLog("Error in fetching Cobind issues ");
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) { /* ignored */
				}
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) { /* ignored */
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) { /* ignored */
				}
			}
		}
	}

	public Map<String, String> getCobindMagIssuesMap() {
		return cobindMagIssuesMap;
	}
	
	public String getCobindMagIssues(String magkyCobind) {
		return cobindMagIssuesMap.get(magkyCobind);
	}
	public boolean containsCobindMagIssues(String magkyCobind) {
		return cobindMagIssuesMap.containsKey(magkyCobind);
	}
}