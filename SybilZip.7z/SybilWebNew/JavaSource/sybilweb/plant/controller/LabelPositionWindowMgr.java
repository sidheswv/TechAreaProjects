package sybilweb.plant.controller;

/**
 * Insert the type's description here.
 * Creation date: (8/9/01 3:12:10 PM)
 * @author: Srikanth Bapanapalli
 */

 import java.io.*;
 import java.util.*;
 
public class LabelPositionWindowMgr {
/**
 * LabelPositionWindowMgr constructor comment.
 */
public LabelPositionWindowMgr(String ctlfilename) {

	Magazine mag = new Magazine(ctlfilename);

	String plantid = mag.getPlant();
		try {
   sybilweb.plant.controller.PropertyBroker.load(sybilweb.plant.controller.PropertyBroker.inipath);
		} catch(Exception e){ e.printStackTrace(); }


	String path = sybilweb.plant.controller.PropertyBroker.getProperty("LogFileDirectory");
						
	path = path.concat(plantid.toUpperCase());
							
	path = path.concat("//InputData//");
	
	path = path + ctlfilename;

		try {

			File f = new File(path);
			if(!f.exists())
				System.out.println(path +"CTL file Not Found");
			}catch(Exception fne){ fne.printStackTrace();} 
	

		try {
			
				FileReader fr = new FileReader(path);

				

				
				
		} catch(Exception e){ e.printStackTrace(); }	

	
	
	
}
}
