package sybilweb.plant.controller;

import sybil.common.util.*;
/**
 * Insert the type's description here.
 * Creation date: (2/22/01 10:53:05 AM)
 * @author: Srikanth Bapanapalli
 */
public class Magazine implements java.io.Serializable{
	
	public final static String PaperLabel = "pl";
	public final static String STRIP = "strip";
	public final static String CUST = "cust";
	public final static String OFFICE = "office";

	public final static String REPORTS = "reports";
	
// moveable
	public final static String MERGE = "merge";
	public final static String POSTAL = "pobook";
	public final static String STORE = "storbook";
	public final static String REMOVE = "remove";
	public final static String OCCRPT = "occrpt";
	public final static String SYBILDAT = "sybildat";
	public final static String MAILDAT = "maildat";
	public final static String ROLLSUMMARY = "rollsum";
	public final static String POSTAL2 = "pobook2";
	public final static String STORE2 = "storbk2";
	public final static String LOR = "lorbook2";  // Length Of Run
	public final static String PACKAGE_SUMMARY = "pkgsum";
	public final static String PRESORT_PARAMETERS = "prsrt";
	public final static String DRIVER_CODE_BOOKVERSION = "bkversion";
	public final static String DRIVERCODE = "drivercd";
	public final static String BACKDATE = "bkdt";
	public final static String ISALRPT = "isalrpt";
	public final static String MLTIMAIL = "mltimail";
	public final static String MLTIMRGE = "mltimrge";

	private String magCode;
	private String magName;
	private String issue;
	private String plant;
	private String deliveryType;
	private String processType;
	private String dataType;
	private String week;
	private String recissdt;
	private String ext;

	private String inputFileName;
	private int weekNumber;
	private String singleMagCode;
	
	private int trimSize = 100;
	
	public static char fileSep = '.';
	public static char fileSepTwo = '_';
	public static int NOTSAMEMAGAZINE = -65000;
	private boolean invalidFileName = false;
	private String labelDestination = null;



public Magazine() {
//	codeNameXRef = new java.util.Properties();
}
/**
 * This method was created by a SmartGuide.
 * @param s java.lang.String
 */
public Magazine(java.io.File f) {
	this();
	inputFileName = f.getName();
	parse(inputFileName);
}
/**
 * This method was created by a SmartGuide.
 * @param s java.lang.String
 */
public Magazine(String s) {
	this();
	inputFileName = s;
	parse(inputFileName);
}
public Magazine(String m, String i) {
//	codeNameXRef = new java.util.Properties();
	
	// CHANGE: for testing JY
//	codeNameXRef.put("TD", "Time Domestic");
//	codeNameXRef.put("PE", "People");
//	codeNameXRef.put("MO", "Money Magazine");
	
	setMagCode(m);
	setIssue(i);

}
public Magazine(Magazine m) {
	this.magCode = m.getMagCode();
	this.magName = m.getMagName();
	this.issue = m.getIssue();
	this.plant = m.getPlant();
	this.deliveryType = m.getDeliveryType();
	this.processType = m.getProcessType();
	this.dataType = m.getDataType();
//	this.week;
//	this.ext;
}
public boolean equals(Object m) {
	if (!(m instanceof Magazine)) {
		return false;
	}
	else if (magCode.equals(((Magazine) m).getMagCode()) &&
			  magName.equals(((Magazine) m).getMagName()) &&
			  issue.equals(((Magazine) m).getIssue()) &&
			  deliveryType.equals(((Magazine) m).getDeliveryType()) &&
			  processType.equals(((Magazine) m).getProcessType()) &&
			  dataType.equals(((Magazine) m).getDataType()) &&
			  week.equals(((Magazine) m).getWeek())) {
		return true;
	}
	return false;
}
public boolean equals(Magazine m) {
	if (!(m instanceof Magazine)) {
		return false;
	}
	else if (magCode.equals(((Magazine) m).getMagCode()) &&
			  magName.equals(((Magazine) m).getMagName()) &&
			  issue.equals(((Magazine) m).getIssue()) &&
			  deliveryType.equals(((Magazine) m).getDeliveryType()) &&
			  processType.equals(((Magazine) m).getProcessType()) &&
			  dataType.equals(((Magazine) m).getDataType()) &&
			  week.equals(((Magazine) m).getWeek())) {
		return true;
	}
	return false;
}
public String getCommonPrefix() {
	StringBuffer sb = new StringBuffer(50);
	sb.append(magCode.toLowerCase());
	sb.append(fileSep);
	sb.append("i");
	sb.append(issue);
	sb.append(fileSep);
	sb.append(plant);
	sb.append(fileSep);
	sb.append(deliveryType);
	
	return sb.toString();
}
public String getCommonSuffix() {
	StringBuffer sb = new StringBuffer(50);
	sb.append(week);
	sb.append(fileSep);
	sb.append(ext);
	return sb.toString();
}
public String getDataType() {
	return dataType;
}
public String getDBTableName() {
	StringBuffer sb = new StringBuffer(20);
	sb.append(magCode);
	sb.append(issue);
	
	return sb.toString();
}
public String getDeliveryType() {
	return deliveryType;
}
public String getRecIssDt() {
	return recissdt;
}
public String getExt() {
	return ("." + ext);
}
/**
 * This method was created by a SmartGuide.
 * @return java.lang.String
 */
public String getFileName( ) {

	StringBuffer sb = new StringBuffer(50);
	sb.append(magCode.toLowerCase());
	sb.append(fileSep);
	sb.append("i");
	sb.append(issue);
	sb.append(fileSep);
	sb.append(plant);
	sb.append(fileSep);
	sb.append(deliveryType);
	sb.append(fileSep);
	sb.append(processType);
	sb.append(fileSep);
	sb.append(dataType);
	sb.append(fileSep);
	sb.append(week);
	sb.append(fileSep);
	sb.append(ext);

	return sb.toString();
	
}
public String getFileNameMdat1( ) {

	StringBuffer sb = new StringBuffer(50);
	sb.append(magCode.toLowerCase());
	sb.append(fileSep);
	sb.append("i");
	sb.append(issue);
	sb.append(fileSep);
	sb.append(plant);
	sb.append(fileSep);
	
	return sb.toString();
}
public String getFileNameMdat2( ) {	
	
	StringBuffer sb = new StringBuffer(50);
	sb.append(fileSep);
	sb.append(processType);
	sb.append(fileSep);
	sb.append(dataType);
	sb.append(fileSep);
	sb.append(week);
	sb.append(fileSep);
	sb.append(ext);

	return sb.toString();
	
}
public String getFileNameMMBD( ) {

	StringBuffer sb = new StringBuffer(50);
	sb.append(magCode.toLowerCase());
	sb.append(fileSep);
	sb.append("i");
	sb.append(issue);
	sb.append(fileSep);
	sb.append(plant);
	sb.append(fileSep);
	sb.append(deliveryType);
	sb.append(fileSep);
	sb.append(processType);
	sb.append(fileSep);
	sb.append(dataType);
	sb.append(fileSep);
	sb.append(week);
	sb.append(fileSep);
	sb.append(recissdt);
	sb.append(fileSep);
	sb.append(ext);

	return sb.toString();
	
}
public String getFullMagName() {
	
	StringBuffer buf = new StringBuffer();
	buf.append(magName);
	buf.append(" ");
	buf.append(issue);
	buf.append("-");
	buf.append(weekNumber);
	buf.append(" ");

	String s = deliveryType.substring(2).toUpperCase();

	if(deliveryType.toLowerCase().startsWith("pl")){
		if(s.equalsIgnoreCase("forgn"))
			buf.append("FOREIGN");
		else if(s.equalsIgnoreCase("usps"))
			buf.append("USPS");
		else if(s.equalsIgnoreCase("nolab"))
			buf.append("NOLABEL");
		else
			buf.append(s);
			
		buf.append( " Paper Label");
	}else if (deliveryType.toLowerCase().startsWith("nl")){
		if(s.equalsIgnoreCase("forgn"))
			buf.append("FOREIGN");
		else if(s.equalsIgnoreCase("usps"))
			buf.append("USPS");
		else if(s.equalsIgnoreCase("nolab"))
			buf.append("NOLABEL");
		else
			buf.append(s);
		
		buf.append(" No Label");	

	}else {
		buf.append(deliveryType.toUpperCase());
	}

	buf.append(" " );
		
	if (!processType.toUpperCase().equals("STRIP"))
		buf.append(processType.toUpperCase());
	
		
	return (buf.toString());
}
/**
 * This method was created by a SmartGuide.
 * @return java.lang.String
 */
public String getFullPrefix( ) {

	StringBuffer sb = new StringBuffer(50);
	sb.append(magCode.toLowerCase());
	sb.append(fileSep);
	sb.append("i");
	sb.append(issue);
	sb.append(fileSep);
	sb.append(plant);
	sb.append(fileSep);
	sb.append(deliveryType);
	sb.append(fileSep);
	sb.append(processType);
	sb.append(fileSep);
	sb.append(dataType);
	sb.append(fileSep);
	sb.append(week);

	return sb.toString();
	
}
public String getIssue() {
	return issue;
}
/**
 * This method was created by a SmartGuide.
 * @return java.lang.String
 */
public String getLongFileName( ) {

	StringBuffer sb = new StringBuffer(50);
	sb.append(magCode.toLowerCase());
	sb.append(fileSep);
	sb.append("i");
	sb.append(issue);
	sb.append(week);
	sb.append(fileSep);
	sb.append(plant);
	sb.append(fileSep);
	sb.append(deliveryType);
	sb.append(fileSep);
	sb.append(processType);

	return sb.toString();

}
/**
 * This method was created by a SmartGuide.
 * @return java.lang.String
 */
public String getLongFileNameDisplay( ) {

	StringBuffer sb = new StringBuffer(50);
	sb.append(magCode.toLowerCase());
	sb.append(fileSepTwo);
	sb.append("i");
	sb.append(issue);
	sb.append(week);
	sb.append(fileSepTwo);
	sb.append(plant);
	sb.append(fileSepTwo);
	sb.append(deliveryType);
	sb.append(fileSepTwo);
	sb.append(processType);

	
	return sb.toString();

}
public String getMagCode() {
	return magCode;
}
public String getMagCodeIssue() {
	return (magCode + issue);
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getMagIssuePlantPrefix() {
	return (magCode + 	fileSep + "i"+issue + fileSep + plant);
}
public String getMagName() {
	return magName;
}
public String getMagNameIssue() {
	StringBuffer buf = new StringBuffer();
	buf.append(magName);
	buf.append(" ");
	buf.append(issue);
	
	return buf.toString();
}
public String getPlant() {
	return plant;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getPlantMagIssue() {
	return (magCode + issue + plant);
}
/**
 * This method was created by a SmartGuide.
 * @return java.lang.String
 */
public String getPrefix( ) {

	StringBuffer sb = new StringBuffer(50);
	sb.append(magCode);
	sb.append(issue);
	sb.append(deliveryType);
	sb.append(processType);
	sb.append(dataType);
	sb.append(week);

	return sb.toString();
	
}
public String getProcessType() {
	return processType;
}
	public String getReportFilePrefix( ) {

	
	return "Hello";
	
}
public String getSingleMagCode() {
	return singleMagCode.trim();
}
/**
 * This method was created by a SmartGuide.
 * @param size int
 */
public int getTrimSize () {
	return trimSize;
}
public String getWeek() {
	return week;
}
public int getWeekNumber() {
	return weekNumber;
}
/**
 * This method was created in VisualAge.
 */
public boolean isBackDate() {

if ((processType.length() >= 4) && (processType.substring(0,4)).equalsIgnoreCase(BACKDATE) && dataType.equals(CUST)) {
		return true;
	}
	return false;
}
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean isBookVersionDriverCode() {
	if (dataType.equalsIgnoreCase(REPORTS) && 
		deliveryType.equalsIgnoreCase(DRIVER_CODE_BOOKVERSION)) {
		return true;
	}
	return false;
}
public boolean isCustData() {

	if (isMovableDataOnly() || isReportDataOnly() || isBookVersionDriverCode()){
		return false;
	}
	
	return true;	
}
public boolean isEarlyStart() {
	if (processType.equals(MERGE) && dataType.equals(CUST)) {
		return true;
	}
	return false;
}
/**
 * This method was created in VisualAge.
 */
public boolean isInvalidFileName() {
	return invalidFileName;	
}
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean isISALReport() {
	
		if (dataType.equalsIgnoreCase(REPORTS) &&
		deliveryType.equalsIgnoreCase(ISALRPT)) {
		return true;
	}
	return false;
}
public boolean isLengthOfRun() {
	if (processType.equals(STRIP) && dataType.equals(LOR)) {
		return true;
	}
	return false;
}
/**
 * This method was created by a SmartGuide.
 */
public boolean isMovableDataOnly ( ) {

	if (isEarlyStart() || isPostalBook() || isStorageBook() || isQuickKill() || isLengthOfRun() ||
		isPostalBook2() || isStorageBook2())
		return true;
	else
		return false;
		
}
/**
 * This method was created by a SmartGuide.
 * @return boolean
 */
public boolean isNYBranchOfficeMagazine ( ) {
	if (processType.equals(OFFICE) && dataType.equals(CUST)) 
		return true;

	return false;
}
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean isOCCReport() {
	if (dataType.equalsIgnoreCase(REPORTS) && 
		deliveryType.equalsIgnoreCase(OCCRPT)) {
		return true;
	}
	return false;
}
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean isPackageSummary() {
	if (dataType.equalsIgnoreCase(REPORTS) && 
		deliveryType.equalsIgnoreCase(PACKAGE_SUMMARY)) {
		return true;
	}
	return false;
}
public boolean isPostalBook() {
	if (processType.equals(STRIP) && dataType.equals(POSTAL)) {
		return true;
	}
	return false;
}
public boolean isPostalBook2() {
	if (processType.equals(STRIP) && dataType.equals(POSTAL2)) {
		return true;
	}
	return false;
}
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean isPresortParameters() {
	if (dataType.equalsIgnoreCase(REPORTS) && 
		deliveryType.equalsIgnoreCase(PRESORT_PARAMETERS)) {
		return true;
	}
	return false;
}
public boolean isQuickKill() {
	if (processType.equals(REMOVE) && dataType.equals(CUST)) {
		return true;
	}
	return false;
}
/**
 * This method was created by a SmartGuide.
 */
public boolean isReportDataOnly ( ) {


	if (dataType.equalsIgnoreCase(REPORTS) || dataType.equalsIgnoreCase(SYBILDAT))
		return true;
	else
		return false;
		
}
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean isRollSummary() {
	if (dataType.equalsIgnoreCase(REPORTS) && 
		deliveryType.equalsIgnoreCase(ROLLSUMMARY)) {
		return true;
	}
	return false;
}
public boolean isStorageBook() {
	if (processType.equals(STRIP) && dataType.equals(STORE)) {
		return true;
	}
	return false;
}
public boolean isStorageBook2() {
	if (processType.equals(STRIP) && dataType.equals(STORE2)) {
		return true;
	}
	return false;
}
public boolean isSybilDat() {
	if (dataType.equalsIgnoreCase(SYBILDAT)) {
		return true;
	}
	return false;
}
public int olderThan(Magazine m) {

	// Want to delete all data associated with the old magazine and issue
	// Delivery type does not matter.

	if (this.magCode.equals(m.magCode)) {
		return (Integer.parseInt(m.issue) - Integer.parseInt(this.issue));
	}
	else {
		return NOTSAMEMAGAZINE;
	}
}
/**
 * This method parses a file name for magazine information
 * @param s java.lang.String
 */
protected void parse(String s) {
	java.util.StringTokenizer st = new java.util.StringTokenizer(s, ".");
//	java.util.StringTokenizer stp = new java.util.StringTokenizer(s, " ");

	try{
		LogWriter.writeLog("s = "+s);
		if ((s.indexOf("Serp")>=0) || (s.indexOf("Cass")>=0)){
			setMagCode(st.nextToken().trim());

		}else{
			setMagCode(st.nextToken().trim());
			issue = st.nextToken().substring(1, 5);
			plant = st.nextToken().trim();
			deliveryType = st.nextToken().trim();
			processType = st.nextToken().trim();
			dataType = st.nextToken().trim();
			week = st.nextToken().trim();
			if ((dataType.equalsIgnoreCase(MLTIMAIL)) || (dataType.equalsIgnoreCase(MLTIMRGE))) {
				recissdt = st.nextToken().trim();
			}
			if( st.hasMoreTokens()){
				try{
					weekNumber = Integer.parseInt(week);
				}catch( Exception ex){
					LogWriter.writeLog(ex);
					LogWriter.writeLog("E", "", "", "Invalid file name format (week) <" + s + ">.");
					invalidFileName = true;
					return;
				}
				ext = st.nextToken().trim();
			} else {
				ext = week;
				week = "01";
			}
		}
			invalidFileName = false;      
	} catch( Exception e) {
		LogWriter.writeLog(e);
		LogWriter.writeLog("E", "", "","Invalid file name format <" + s + ">.");
		invalidFileName = true;
		return;  
	}
}
public void setDataType(String d) {
	dataType = d;
}
public void setDeliveryType(String d) {
	deliveryType = d;
}
public void setRecIssDt(String d) {
	recissdt = d;
}
public void setExtension(String e) {
	ext = e;
}
public void setIssue(String i) {
	issue = i;
}
public void setMagCode(String m) {
	magCode = m.toUpperCase();
	magName = (String) PropertyBroker.getProperty(magCode);
	if (magName == null) {
		magName = magCode;
	}
	if( (magName.indexOf(':')) != -1) {
		singleMagCode = magName.substring(0,1);
		magName = magName.substring(2);
	} else {
		singleMagCode = magCode.substring(0,1);
	}
		
}
public void setPlant(String p) {
	plant = p;
}
public void setProcessType(String p) {
	processType = p;
}
/**
 * This method was created by a SmartGuide.
 * @param size int
 */
public void setTrimSize (int size ) {
	trimSize = size;
	return;
}
public void setWeek(String w) {
	week = w;
	weekNumber = Integer.parseInt(week);
}
public String toString() {
	StringBuffer sb = new StringBuffer(50);
	sb.append(magName);
	sb.append(issue);
	sb.append(plant);
	sb.append(deliveryType);
	sb.append(processType);
	sb.append(dataType);
	return sb.toString();
}
}
