package sybilweb.plant.controller;

/**
 * This type was created in VisualAge.
 */
import java.util.*;
import java.io.*;
import sybil.common.util.*;
import sybil.common.model.*;

public class GTRFDriverCodeAssignmentMgr extends DriverCodeAssignmentMgr {

	private Hashtable GTRFDriverCodes = null;

/**
 * This method was created in VisualAge.
 * @param mag sybil.common.model.Magazine
 */
public GTRFDriverCodeAssignmentMgr(Magazine mag) {
	super(mag);
}
/**
 * This method was created in VisualAge.
 * @param customer IssueCustomer
 */
public void assignDriverCode(IssueCustomer customer){

	Integer driverCode = (Integer)GTRFDriverCodes.get(customer.getEditionCode());
	if (driverCode != null) {
		String code = StringFunctions.fixSize(String.valueOf(driverCode),4,'0',StringFunctions.RIGHT);
		customer.setMakeupCode(code);

//		LogWriter.writeLog(mag.getPrefix() + ": Assigned driver code " + code + " to edition " + customer.getEditionCode());
		if (!(customer.getMagazineLabel().makeupCode.equals("")))
			customer.getMagazineLabel().makeupCode = code;

	}else {
		if( invalidBV == null)
			invalidBV = new Vector();

		if( invalidBV.toString().indexOf(customer.getEditionCode().trim()) < 0){
			invalidBV.addElement(customer.getEditionCode().trim());
		}
	}

}
/**
 * This method was created in VisualAge.
 * @param fileName char
 */
public boolean loadDriverCodes() {

	BufferedReader fileReader = null;
	String line = null;

	String edition;
	Integer driverCode;


	try {
		fileReader = new BufferedReader(new FileReader(driverCodeFileName));
	} catch (java.io.FileNotFoundException fnfe) {
//		LogWriter.writeLog(new Exception(mag.getPrefix() + ": Error opening drivercode assignment file: File not found: " + driverCodeFileName));
		return false;
	}

	GTRFDriverCodes = new Hashtable();

	try {
/*		while (fileReader.ready()) {
			try {
				line = fileReader.readLine();
			}catch (java.io.IOException e) {
				LogWriter.writeLog("Can't read drivercode assignment file");
				return false;
			}
*/
		while ((line = fileReader.readLine()) != null) {

			if (line.trim().length() == 0) {
				continue;
			}

			StringTokenizer st = new StringTokenizer(line, String.valueOf(","));
			if (st.countTokens() != 2) {
//				LogWriter.writeLog(mag.getPrefix() + ": Driver code assignment file in wrong format");
				try{
					fileReader.close();
				} catch (IOException ioe){}
				return false;
			}

			try {
				edition = st.nextToken().trim();
				driverCode = new Integer(st.nextToken().trim());
			}catch (Exception nfe) {
//				LogWriter.writeLog(mag.getPrefix() + ": Number Format Exception: Driver code assignment file in wrong format");
				try{
					fileReader.close();
				} catch (IOException ioe){}
				return false;
			}

			GTRFDriverCodes.put(edition,driverCode);

		}


	}	catch(EOFException ee) {
	}	catch(Exception re) {
//		LogWriter.writeLog(re);
	}

	try{
		fileReader.close();
	} catch (IOException ioe){}


	return true;

}
}
