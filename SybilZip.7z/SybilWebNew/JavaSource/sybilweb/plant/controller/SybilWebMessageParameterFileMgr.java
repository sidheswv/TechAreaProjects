package sybilweb.plant.controller;

import sybil.common.util.*;
import sybil.common.model.*;
import java.util.*;
import java.io.*;

/**
 * Insert the type's description here.
 * Creation date: (3/13/01 11:09:04 AM)
 * @author: Srikanth Bapanapalli
 */
public class SybilWebMessageParameterFileMgr {
	MessageParameterParser messageParameterFileParser = new MessageParameterParser();
	MessageParameterWriter messageParameterFileWriter = new MessageParameterWriter();
	public Vector readMessageParameters (BufferedReader bfr ) {
	return messageParameterFileParser.readMessageParameters(bfr);
}
	public Vector readMessageParameters (Magazine mag ) {

	BufferedReader fileReader = null;
	FileReader fr = null;
	String filename = null;

	filename = PropertyBroker.getProperty("OLDFILEDIR") + mag.getFullPrefix() + ".CTL";
	
	try {
		fr = 	new FileReader(filename);
	} catch (java.io.FileNotFoundException fnfe) {
//		LogWriter.writeLog(new Exception(mag.getPrefix() + ": Error opening message parameter file"));
		return null;
	}
	
  	fileReader = new BufferedReader (fr);
  	
	
	return messageParameterFileParser.readMessageParameters(fileReader);
}
}
