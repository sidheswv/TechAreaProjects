package sybilweb.plant.controller;

import java.io.*;           
import java.sql.*;
import javax.sql.*;
import javax.servlet.*;     
import javax.servlet.http.*;
import java.util.*;         
import java.text.*;
import com.ibm.ejs.dbm.jdbcext.*;
import javax.naming.*;

/**
 * This type was created in VisualAge.
 */
public class MagListHash {
	java.util.Hashtable hashtable1 = new java.util.Hashtable();
	java.util.Hashtable hashtable2 = new java.util.Hashtable();
	String temp = null;

	
	DataSource ds =null;
	Connection conn = null;


/**
 * MagListHash constructor comment.
 */
public MagListHash() {
	super();
}
/**
 * This method was created in VisualAge.
 * @return java.util.Hashtable
 */
public Hashtable process(int mcode) {

try {
		Hashtable parms = new Hashtable();
		parms.put(Context.INITIAL_CONTEXT_FACTORY, "com.ibm.ejs.ns.jndi.CNInitialContextFactory");
		Context ctx = new InitialContext(parms);	
		ds = (DataSource)ctx.lookup("sybil");
		conn = ds.getConnection();
		String mvs = sybilweb.plant.controller.PropertyBroker.getProperty("MVS");
		if(mvs.equals("true"))
	 	{
			String db2owner = sybilweb.plant.controller.PropertyBroker.getProperty("DB2OWNER");
			Statement stmt = conn.createStatement();
			String query = "select * from " + db2owner + ".TBA_SYB_MAGAZINE";
			ResultSet rs = stmt.executeQuery(query);
			while(rs.next())
			{
				String code = rs.getString("MAG_CD");
				String magname = rs.getString("NAME");
				hashtable1.put(code,magname);
				hashtable2.put(magname,code);
			}
		stmt.close();		
		conn.close();
		 }
		} catch(Exception ex) { LogWriter.writeLog(ex); ex.printStackTrace(); }
	if(mcode==1)
	return hashtable1;
	else return hashtable2;
}
}
