package sybilweb.plant.controller;

import java.io.Serializable;

public class Address implements Serializable, Cloneable
{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int m_barCode;
    private String m_city;
    private String m_line1;
    private String m_line2;
    private String m_state;
    private String m_county;
    private String m_zipCode;
    private String m_country;
    private String m_zipPlus4;

    public Address()
    {
    }

    public void clear()
    {
    }

    public Object clone()
    {
        Address addr = null;
        try
        {
            addr = (Address)super.clone();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return addr;
    }

    public int getBarcode()
    {
        return m_barCode;
    }

    public String getCity()
    {
        return m_city;
    }

    public String getCountry()
    {
        return m_country;
    }

    public String getCounty()
    {
        return m_county;
    }

    public String getLine1()
    {
        return m_line1;
    }

    public String getLine2()
    {
        return m_line2;
    }

    public String getState()
    {
        return m_state;
    }

    public String getZipCode()
    {
        return m_zipCode;
    }

    public String getZipPlus4()
    {
        return m_zipPlus4;
    }

    public void setBarcode(int i)
    {
        m_barCode = i;
    }

    public void setCity(String s)
    {
        m_city = s.trim();
    }

    public void setCountry(String s)
    {
        m_country = s.trim();
    }

    public void setCounty(String s)
    {
        m_county = s.trim();
    }

    public void setLine1(String s)
    {
        m_line1 = s.trim();
    }

    public void setLine2(String s)
    {
        m_line2 = s.trim();
    }

    public void setState(String s)
    {
        m_state = s.trim();
    }

    public void setZipCode(String s)
    {
        if(s.trim().length() < 5)
        {
            m_zipCode = "";
            return;
        } else
        {
            m_zipCode = s.trim();
            return;
        }
    }

    public void setZipPlus4(String s)
    {
        m_zipPlus4 = s.trim();
    }

    public String toString()
    {
        StringBuffer buf = new StringBuffer();
        if(m_line1 != null && m_line1.length() > 0)
        {
            buf.append(m_line1);
        } else
        {
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        if(m_line2 != null && m_line2.length() > 0)
        {
            buf.append(m_line2);
        } else
        {
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        if(m_county != null && m_county.length() > 0)
        {
            buf.append(m_county);
        } else
        {
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        if(m_city != null && m_city.length() > 0)
        {
            buf.append(m_city);
        } else
        {
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        if(m_state != null && m_state.length() > 0)
        {
            buf.append(m_state);
        } else
        {
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        if(m_zipCode != null && m_zipCode.length() > 0)
        {
            buf.append(m_zipCode);
        } else
        {
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        if(m_country != null && m_country.length() > 0)
        {
            buf.append(m_country);
        } else
        {
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        buf.append(m_barCode);
        return buf.toString();
    }
}
