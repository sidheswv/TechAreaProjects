package sybilweb.plant.controller;

/**
 * LogWriter:
 *		This is the generic Log writer.
 *
 *		This static class must be initialized by calling the 'initialize' method with
 *		three parameters:
 *			boolean 	'true' to enable file logging.  Otherwise, all subsequent calls to
 *						writeLog will be sent to stdout (i.e. System.out.println).  If this
 *						is desired, it is not necessary to initialize LogWriter at all.
 *			long		Maximum size of log file before archiving the file and starting over.
 *						Archiving is done by renaming the current log file to the default name
 *						plus '.bak'.  Subsequent archives will overlay the previous archive.
 *			String		Fully qualified path for the log file.  If a partial path is passed,
 *						it will be created relative to the current system directory.  The specified
 *						path is appended with 'ERRORS.LOG' or 'MESSAGES.LOG' to create the actual
 *						log files.
 *
 *		The 'writeLog' method is overloaded, with three methods of invocation.
 *			1) writeLog (String) : Writes messages to the 'MESSAGES.LOG' file.
 *			2) writeLog (SybilWarningException) : Writes errors and warnings to
 *			   the 'MESSAGES.LOG' file.  The messages comes from e.getMessage().
 *			3)	writeLog (Exception) : Writes exceptions to the 'ERRORS.LOG' file.
 *
 * @author Steve Caum - Time Customer Service, Inc.
 */
import java.io.*;
import java.text.*;

public class LogWriter {

// File declarations for 'Errors' file.
	private static RandomAccessFile errorLogFile = null;
	private static FileDescriptor errorFD = null;
	private static FileOutputStream errorFOS = null;
	private static PrintWriter errorPW = null;
	private static File errorFile = null;

// File declarations for 'Messages' file.
	private static RandomAccessFile messageLogFile = null;
	private static FileDescriptor messageFD = null;
	private static FileOutputStream messageFOS = null;
	private static PrintWriter messagePW = null;
	private static File messageFile = null;

	private static String errorFileName = "NavigationLog";		// Name of logfile for ERRORS.
	private static String messageFileName = "NavigationLog";	// Name of logfile for MESSAGES.
	private static String fileExtension = ".log";			// Name of extension for log files.
	private static String backupFileExtension = ".bak";	// Name of extension for backup files.

	private static String fullErrorFileName = null;		// path and name concatenated.
	private static String fullMessageFileName = null;		// path and name concatenated.
	private static String fullBackupErrorFileName = null;	// path and name concatenated.
	private static String fullBackupMessageFileName = null;	// path and name concatenated.


// Variables that originate from the 'Property' file.
	private static String filePath = null;		// Directory path for output file
	private static String fileName = null;		// output file
	private static boolean writeLog = false;		// Switch to determine whether to log
	private static long maxFileSize = 2000000;	// Maximum size to let log grow to

// Miscellaneous internal variables
	private static boolean logWriterInitialized = false;	// 'First Call' indicator for initialization
	private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd kk:mm:ss");

/**
 * LogWriter constructor comment.
 */
public LogWriter() {
	super();
}
/**
 * This method was created by a SmartGuide.
 */
private static void closeErrorLog() {

	try {
		errorPW.close();
		errorFOS.close();
	} catch (Exception e) {
		System.out.println ("Error Closing Error Log File");
		e.printStackTrace();
	}

	errorPW = null;
	errorFOS = null;

	return;
}
/**
 * This method was created by a SmartGuide.
 */
private static void closeMessageLog() {

	try {
		messagePW.close();
		messageFOS.close();
	} catch (Exception e) {
		System.out.println ("message Closing Message Log File");
		e.printStackTrace();
	}

	messagePW = null;
	messageFOS = null;

	return;
}
/**
 * This method was created by a SmartGuide.
 */
protected void finalize( ) throws Throwable {

//	closeErrorLog();
	closeMessageLog();

	return;

}
/**
 * This method was created by a SmartGuide.
 * @return java.lang.String
 */
private static String getSystemDateTime() {

	java.util.Date now = new java.util.Date();

	return dateFormat.format (now);
}
/**
 * This method was created by a SmartGuide.
 */
private static void handleFileArchive() {

	if (!writeLog) return;

	java.text.SimpleDateFormat formatter = new SimpleDateFormat("yyyy_MM_dd_hh:mm:ss_aaa");
	java.util.Date today = new java.util.Date();
	String dateString = formatter.format(today);

	if (messageFile.length() > maxFileSize) {
		closeMessageLog();
		String archFileName2 = fullBackupMessageFileName + "." + dateString + ".log";
		File archFile = new File(archFileName2);
		if (archFile.exists())
			archFile.delete();
		messageFile.renameTo(archFile);
		messageFile.delete();
		messageFile = null;
		archFile = null;
		openMessageLog();
	}

	return;
}
/**
 * This method was created by a SmartGuide.
 * @param log boolean
 * @param max long
 * @param fpath String
 */

 public static synchronized void initialize(boolean log, long max, String fPath) {

	if (logWriterInitialized) return;

	logWriterInitialized = true;

	if (log) {
		writeLog = true;
	} else return;

	maxFileSize = max;

	filePath = fPath;

	fullErrorFileName = filePath + errorFileName + fileExtension;
	fullMessageFileName = filePath + messageFileName + fileExtension;

	fullBackupErrorFileName = filePath + errorFileName + backupFileExtension;
	fullBackupMessageFileName = filePath + messageFileName + backupFileExtension;

//	openErrorLog();
	openMessageLog();

	return;
}
/**
 * Insert the method's description here.
 * Creation date: (4/3/2002 12:01:41 PM)
 * @param log boolean
 * @param max long
 * @param fPath java.lang.String
 * @param fName java.lang.String
 */

public static synchronized void initialize(boolean log, long max, String fPath, String fName) {
	
	if (logWriterInitialized) return;
	logWriterInitialized = true;
	if (log) {
		writeLog = true;
	} else return;
	
	maxFileSize = max;
	filePath = fPath;
	fileName = fName;
	fullErrorFileName = filePath + fileName + "_err" + fileExtension;
	fullMessageFileName = filePath + fileName + "_msg" + fileExtension;
	fullBackupErrorFileName = filePath + fileName + "_err" + backupFileExtension;
	fullBackupMessageFileName = filePath + fileName + "_msg" + backupFileExtension;

	openErrorLog();
	openMessageLog();

	return;
}
/**
 * This method was created by a SmartGuide.
 */
private static void openErrorLog() {

	try {
		errorFile = new File (fullErrorFileName);
		errorFOS = new FileOutputStream (fullErrorFileName, true); // Open / append
		errorPW = new PrintWriter (errorFOS, true);		// Open with autoflush enabled
	} catch (Exception e) {
		System.out.println ("Error allocating / opening Error Log File");
		e.printStackTrace();
		System.exit(1);
	}

	return;
}
/**
 * This method was created by a SmartGuide.
 */
private static void openMessageLog() {

	try {
		System.out.println ("opening Message Log File "+fullMessageFileName);
		messageFile = new File (fullMessageFileName);
		messageFOS = new FileOutputStream (fullMessageFileName, true); // Open / append
		messagePW = new PrintWriter (messageFOS, true);	// Open with autoflush enabled
		messagePW.println(getSystemDateTime() + " =I=> Created Messages log  File");
		System.out.println (" created log file "+fullMessageFileName);
	} catch (Exception e) {
		System.out.println ("Error allocating / opening Message Log File");
		e.printStackTrace();
		System.exit(1);
	}

	return;

}
/**
 * This method was created by a SmartGuide.
 * @param e java.lang.Exception
 */
public static synchronized void writeLog(Exception e) {

	if (writeLog) {
		handleFileArchive();
		messagePW.println(getSystemDateTime() + " =E=> " + e.getMessage());
//		e.printStackTrace(errorPW);
		messagePW.flush();
	}
	else {
		System.err.println(getSystemDateTime() + " =E=> " + e.getMessage());
		e.printStackTrace();
	}

	return;
}
/**
 * This method was created by a SmartGuide.
 * @param msg java.lang.String
 */

public static synchronized void writeLog(String msg) {

	if (writeLog) {
		handleFileArchive();
		messagePW.println(getSystemDateTime() + " =I=> " + msg);
		messagePW.flush();
	}	
	else {
		System.out.println (getSystemDateTime() + " =I=> " + msg);
	}	
	
	return;
}
/**
 * This method was created by a SmartGuide.
 * @param msg java.lang.String
 */
public static synchronized void writeLog(String type, String plant, String magname, String msg) {

	if (writeLog) {
		handleFileArchive();
		messagePW.println(getSystemDateTime() + " ="+StringFunctions.fixSize(type.trim(),1,' ',StringFunctions.LEFT)+"=> "+StringFunctions.fixSize(plant.trim(),3,' ',StringFunctions.LEFT)+" "+StringFunctions.fixSize(magname,15,' ',StringFunctions.LEFT)+" "+msg);
		messagePW.flush();
	}
	else {
		System.out.println (getSystemDateTime() + " ="+type.trim()+"=> "+plant.trim()+" "+magname.trim()+" "+msg);
	}

	return;
}
/**
 * This method was created by a SmartGuide.
 * @param swe sybil.common.util.SybilWarningException
 */
public static synchronized void writeLog(SybilWarningException swe) {

	if (writeLog) {
		handleFileArchive();
		messagePW.println(getSystemDateTime() + " ===> " + swe.getMessage());
		messagePW.flush();
	}
	else {
		System.err.println(getSystemDateTime() + " ===> " + swe.getMessage());
	}

	return;
}
}
