package sybilweb.plant.controller;

import java.util.Vector;

public class Mag {

	private Long magKey;
	private String magNo;
	private String magCode;
	private String name;
	private String shortName;
	private String labelAbbrev;
	private String pubCode;
	private Vector magIssues;
	private Vector plantMags;
	public Mag() {
			super(); }
public String getLabelAbbrev()	{
	return labelAbbrev;
}
	public String getMagCode()
	{
		return magCode;
	}
	public Vector getMagIssues()
	{
		return magIssues;
	}
	public Long getMagKey()
	{
		return magKey;
	}
	public String getMagNo()
	{
		return magNo;
	}
	public String getName()
	{
		return name;
	}
	public Vector getPlantMags()
	{
		return plantMags;
	}
public String getPubCode()	{
	return pubCode;
}
public String getShortName()	{
	return shortName;
}
public void setLabelAbbrev(String s) {
	labelAbbrev = s;
	return;
}
	public void setMagCode(String magCodeValue)
	{
		magCode = magCodeValue;
	}
	public void setMagIssues(Vector magIssuesValue)
	{
		magIssues = magIssuesValue;
	}
	public void setMagKey(Long magKeyValue)
	{
		magKey = magKeyValue;
	}
	public void setMagNo(String magNoValue)
	{
		magNo = magNoValue;
	}
	public void setName(String nameValue)
	{
		name = nameValue;
	}
	public void setPlantMags(Vector plantMagsValue)
	{
		plantMags = plantMagsValue;
	}
public void setPubCode(String s) {
	pubCode = s;
	return;
}
public void setShortName(String s) {
	shortName = s;
	return;
}
/**
 * Print out data values
 */
public String toString() {
	StringBuffer buffer = new StringBuffer();
	buffer.append("MagKey=" + this.getMagKey() + "\r\n");
	buffer.append("MagNo=" + this.getMagNo() + "\r\n");
	buffer.append("MagCode=" + this.getMagCode() + "\r\n");
	buffer.append("Name=" + this.getName() + "\r\n");
	return buffer.toString();
}
}
