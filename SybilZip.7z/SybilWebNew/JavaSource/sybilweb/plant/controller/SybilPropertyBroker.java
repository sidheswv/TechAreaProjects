package sybilweb.plant.controller;

import java.io.*;           
import javax.servlet.*;     
import javax.servlet.http.*;
import java.util.*;         
import java.text.*;
import com.ibm.ejs.dbm.jdbcext.*;
import javax.naming.*;
import sybilweb.plant.controller.*;


/**
 * Insert the type's description here.
 * Creation date: (4/27/01 2:57:33 PM)
 * @author: Srikanth Bapanapalli
 */
public class SybilPropertyBroker extends javax.servlet.http.HttpServlet{
	public void destroy() 	{                                      

}
public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("This servlet does not service requests! ");
		out.println((String)PropertyBroker.getProperty("LogFileDirectory"));
		out.close();
	}
		public String getServletInfo() {
		return "SybilWeb PropertyBroker Servlet";
	}
	public void init(ServletConfig 	config) throws ServletException {

//	try {
//		System.out.println("Loading the Servlet SybilPropertyBroker");
//		String sybilwebinifile = config.getInitParameter("Sybilini");
//		System.out.println("The ini file set to  ==>"+ sybilwebinifile);
//		PropertyBroker.load(sybilwebinifile);
//		PropertyBroker.maininipath = sybilwebinifile;
//		} catch(Exception ex) {    ex.getMessage();     }

		String propertyFile = null;
		try {
			// Used the Admin console to bind the property to the server 
			// Environment name space binding.
			javax.naming.Context ctx=new javax.naming.InitialContext();
			propertyFile = (String)ctx.lookup("sybilini");
			System.out.println("SybilPropertyBroker.init: sybilini " + propertyFile);
			PropertyBroker.maininipath = propertyFile;
		} 
		catch (Exception e) {
			e.printStackTrace(System.out);	
		}

	}
}
