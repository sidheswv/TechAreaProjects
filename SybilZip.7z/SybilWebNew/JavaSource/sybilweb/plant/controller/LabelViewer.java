package sybilweb.plant.controller;

/**
 * Insert the type's description here.
 * Creation date: (10/8/01 1:25:09 PM)
 * @author: Srikanth Bapanapalli
 */


 import java.io.*;
 import java.util.*;
 import java.util.zip.*;
 import sybilweb.plant.persistence.*;

 
public class LabelViewer {
/**
 * Insert the method's description here.
 * Creation date: (10/8/01 1:45:49 PM)
 */
public LabelViewer() {}
/**
 * Insert the method's description here.
 * Creation date: (10/8/01 1:44:59 PM)
 * @param path java.lang.String
 * @param custFile java.lang.String
 * @param roll java.lang.String
 * @param plant java.lang.String
 */
public Vector createTempFile(String path, String custFile, String roll, String plant) {

	Vector customerData = new Vector();
	
	try {

	path = path.concat(plant.toUpperCase().trim());
	String custFilePath = path.concat("/InputData/");
	custFilePath = custFilePath.concat(custFile);
	String tempFilePath = path.concat("/");
	tempFilePath = tempFilePath.concat(plant.toUpperCase().trim());
	Magazine m = new Magazine(custFile);
	tempFilePath = tempFilePath.concat(m.getMagCode());
	tempFilePath = tempFilePath.concat("temproll.txt");
	System.out.println("custFilePath==>"+custFilePath);
	ZipFile zf = new ZipFile(custFilePath);
	FileOutputStream fos = new FileOutputStream(tempFilePath);
	OutputStreamWriter osw = new OutputStreamWriter(fos);
	BufferedWriter bw = new BufferedWriter(osw);
	InputStream zis = zf.getInputStream(zf.getEntry(roll));
	BufferedReader bfr = new BufferedReader(new InputStreamReader(zis, "ISO8859_1"));
	
	int count =0;
	String s = null;
	int counter =0;
	while((s = bfr.readLine()) != null) {
		counter=counter+1;
		customerData.addElement(s);
		bw.write(s, 0, s.length());
		bw.newLine();
	}
	
	
	bw.flush();
	bfr.close();
	zis.close();
	zf.close();
	fos.close();	
	
	} catch(Exception ex) { ex.printStackTrace(); return customerData;}	


	return customerData;
	
	}
/**
 * Insert the method's description here.
 * Creation date: (10/8/01 1:44:59 PM)
 * @param path java.lang.String
 * @param custFile java.lang.String
 * @param roll java.lang.String
 * @param plant java.lang.String
 */
public Vector createTempFile(String newFilePath, String path, String custFile, String roll, String plant) {

	Vector customerData = new Vector();
	
	try {

	path = path.concat(plant.toUpperCase().trim());
	String custFilePath = path.concat("/InputData/");
	custFilePath = custFilePath.concat(custFile);
	String tempFilePath = newFilePath.concat("/");
	tempFilePath = tempFilePath.concat(plant.toUpperCase().trim());
	Magazine m = new Magazine(custFile);
	tempFilePath = tempFilePath.concat(m.getMagCode());
	tempFilePath = tempFilePath.concat("temproll.txt");
	ZipFile zf = new ZipFile(custFilePath);
	FileOutputStream fos = new FileOutputStream(tempFilePath);
	OutputStreamWriter osw = new OutputStreamWriter(fos);
	BufferedWriter bw = new BufferedWriter(osw);
	InputStream zis = zf.getInputStream(zf.getEntry(roll));
	BufferedReader bfr = new BufferedReader(new InputStreamReader(zis, "ISO8859_1"));
	
	int count =0;
	String s = null;
	int counter =0;
	while((s = bfr.readLine()) != null) {
		counter=counter+1;
		customerData.addElement(s);
		bw.write(s, 0, s.length());
		bw.newLine();
	}
	
	
	bw.flush();
	bfr.close();
	zis.close();
	zf.close();
	fos.close();	
	
	} catch(Exception ex) { ex.printStackTrace(); return customerData;}	


	return customerData;
	
	}
/**
 * Insert the method's description here.
 * Creation date: (10/15/01 11:59:37 AM)
 * @return java.util.Vector
 * @param path java.lang.String
 * @param plant java.lang.String
 */
public Vector getCustomer(String path, String plant) {
	return null;
}
/**
 * Insert the method's description here.
 * Creation date: (10/19/01 10:49:08 AM)
 * @return java.util.Vector
 * @param path java.lang.String
 * @param custFile java.lang.String
 * @param roll java.lang.String
 * @param plant java.lang.String
 * @exception java.lang.Exception The exception description.
 */
public Vector getMagLabelMessage(String path, String custFile, int pos, String returnParam) throws java.lang.Exception {


	String tempFilePath = path.concat("/temproll.txt");

	Magazine mag = new Magazine(custFile);
	MessageParameterFileMgr mpfmgr = new MessageParameterFileMgr();
	Vector messageParameters = mpfmgr.readMessageParameters(mag);




	
	return null;
}
}
