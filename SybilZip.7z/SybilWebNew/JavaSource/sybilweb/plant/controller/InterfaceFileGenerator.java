package sybilweb.plant.controller;

/**
 * Insert the type's description here.
 * Creation date: (11/14/2002 10:25:40 AM)
 * @author: Srikanth Bapanapalli
 */
import java.sql.*;
import java.util.*;
import java.io.*;
import sybil.common.persistence.*;
//import lib.classes12.zip;


public class InterfaceFileGenerator {
	public String tableName = null;
	public Connection connTrk = null;
	public boolean fileComplete = false;
	public static String plantTableName = "TBA_SYB_PLANT";
	
/**
 * InterfaceFileGenerator constructor comment.
 */
public InterfaceFileGenerator() {
	super();
}
/**
 * Insert the method's description here.
 * Creation date: (11/14/2002 4:19:35 PM)
 * @param table java.lang.String
 */
public InterfaceFileGenerator(String tableName) {
	this.tableName = tableName;
	String driver = "";
	String database = "";
	String user = PropertyBroker.getProperty("SYBILTRACKINGDBLOGIN","sybil");
	String pswd = PropertyBroker.getProperty("SYBILTRACKINGDBPASSWORD","sybil");

	if( connTrk == null) {
		try {
			driver = PropertyBroker.getProperty("SYBILTRACKINGDBDRIVER", "SYBILTRACKINGDBDRIVER not defined");
			database = PropertyBroker.getProperty("SYBILTRACKINGDBCONNSTRING", "SYBILTRACKINGDBCONNSTRING not defined");
			Class.forName(driver);
			connTrk = DriverManager.getConnection(database, user, pswd);
		}
		catch (Exception e) {
			LogWriter.writeLog(e);
			LogWriter.writeLog(e.getMessage());
			LogWriter.writeLog("Error loading Oracle Drivers  ");
		}
	}
		
}
	public void generateInterfaceFile(String mag, String issue, String week, String plant,  String outputPath) {
	String s = null;
	PrintWriter outputFile = null;
	File f = null;
	
	try {
		String select = "SELECT *" +
			" FROM " + tableName +
			" WHERE mag_cd = ? AND issue_num = ? AND  week = ? AND plant_id = ?" + 
			" ORDER BY mag_cd, issue_num, plant_id, week";
		PreparedStatement psSelect = null;
		ResultSet result = null;
		psSelect = connTrk.prepareStatement(select);
		psSelect.setString(1, mag.trim().toUpperCase());
		psSelect.setString(2, issue.trim().toUpperCase());
		psSelect.setString(3, week.trim().toUpperCase());
		psSelect.setString(4, plant.trim().toUpperCase());
			
		result = psSelect.executeQuery();
		ResultSetMetaData rsmd = result.getMetaData();
		int colcount = rsmd.getColumnCount();

		String outputFileName = outputPath.trim();
		
		f = new File(outputFileName);
		FileOutputStream fos = new FileOutputStream(f);

		outputFile = new PrintWriter(new OutputStreamWriter(new FileOutputStream(f),"ASCII"));				

		String s1 = rsmd.getColumnName(1) + '\u0009';

		for(int colnames=2; colnames<=colcount; colnames++){
			s1 = s1 + rsmd.getColumnName(colnames) + '\u0009';
		}

		s1 = s1 + "\n";

		outputFile.print(s1);
			

		while (result.next()) {
			
			s = result.getString(1) + '\u0009';
				int i=2;
				for(; i<colcount; i++){
					s = s + result.getObject(i) + '\u0009';
				}
			s = s + result.getObject(i) ;
			s = s +"\n";
			outputFile.print(s);
		}
		result.close();
		psSelect.close();
		outputFile.close();
		connTrk.close();

	ZipFilePersistent zp = new ZipFilePersistent(outputFileName.substring(0,outputFileName.length()-3).concat("zip"));
	zp.addFile(f);
	zp.finish();
	
	fileComplete = true;

			
	}
	catch (SQLException se) {
		se.printStackTrace();
		LogWriter.writeLog(se);
	}
	catch (Exception e) {
		e.printStackTrace();		
		LogWriter.writeLog(e);
	}finally{
		if(f.exists())
		f.delete();
	}
}



	public void generateDRCDInterfaceFile(String mag, String issue, String week, String plant,  String outputPath) {
	String s = null;
	PrintWriter outputFile = null;
	File f = null;
	
	try {
		String select = "SELECT *" +
			" FROM " + tableName +
			" WHERE mag_cd = ? AND issue_num = ? AND  week = ? AND plant_id = ?" ;
		PreparedStatement psSelect = null;
		ResultSet result = null;
		psSelect = connTrk.prepareStatement(select);
		psSelect.setString(1, mag.trim().toUpperCase());
		psSelect.setString(2, issue.trim().toUpperCase());
		psSelect.setString(3, week.trim().toUpperCase());
		psSelect.setString(4, plant.trim().toUpperCase());
			
		result = psSelect.executeQuery();
		ResultSetMetaData rsmd = result.getMetaData();
		int colcount = rsmd.getColumnCount();

		String outputFileName = outputPath.trim();
		
		f = new File(outputFileName);
		FileOutputStream fos = new FileOutputStream(f);

		outputFile = new PrintWriter(new OutputStreamWriter(new FileOutputStream(f),"ASCII"));				

		String s1 = rsmd.getColumnName(1) + '\u0009';

		for(int colnames=2; colnames<=colcount; colnames++){
			s1 = s1 + rsmd.getColumnName(colnames) + '\u0009';
		}

		s1 = s1 + "\n";

		outputFile.print(s1);
			

		while (result.next()) {
			
			s = result.getString(1) + '\u0009';
				int i=2;
				for(; i<colcount; i++){
					s = s + result.getObject(i) + '\u0009';
				}
			s = s + result.getObject(i) ;
			s = s +"\n";
			outputFile.print(s);
		}
		result.close();
		psSelect.close();
		outputFile.close();
		connTrk.close();

	ZipFilePersistent zp = new ZipFilePersistent(outputFileName.substring(0,outputFileName.length()-3).concat("zip"));
	zp.addFile(f);
	zp.finish();
	
	fileComplete = true;

			
	}
	catch (SQLException se) {
		se.printStackTrace();
		LogWriter.writeLog(se);
	}
	catch (Exception e) {
		e.printStackTrace();		
		LogWriter.writeLog(e);
	}finally{
		if(f.exists())
		f.delete();
	}
}






	public void generateInterfaceFilebyJobID(String mag, String issue, String week, String plant,  String deliverytype, String outputPath) {
	String s = null;
	PrintWriter outputFile = null;
	File f = null;
	
	try {
		// first select to get plant number from table to be able to create JOBID
		String select = "SELECT PLANT_NO" + " FROM " + plantTableName + " WHERE PLANT_ID = ?";
		PreparedStatement psSelect = null;
		ResultSet result = null;
		psSelect = connTrk.prepareStatement(select);
		psSelect.setString(1, plant.trim().toUpperCase());
			
		result = psSelect.executeQuery();
		result.next();
		String plantNUM = result.getString("PLANT_NO");

		result.close();
		psSelect.close();

		String issueNum = issue.substring(issue.length()-2,issue.length());
		String weekNum = week.substring(week.length()-1,week.length());
		String jobID = (mag+issueNum+weekNum+plantNUM+deliverytype);

		// Selects from view to return data for Pallet Roll Totals Interface File
		String select2 = "SELECT BRACE, ROLLID, CONTAINERID, CONTAINERTYPE, COPY_CNT" + " FROM " + tableName + " WHERE JOBID = ?";
		PreparedStatement psSelect2 = null;
		ResultSet result2 = null;
		psSelect2 = connTrk.prepareStatement(select2);
		psSelect2.setString(1, jobID.trim().toUpperCase());

		result2 = psSelect2.executeQuery();
		ResultSetMetaData rsmd = result2.getMetaData();
		int colcount = rsmd.getColumnCount();

		String outputFileName = outputPath.trim();
		
		f = new File(outputFileName);
		FileOutputStream fos = new FileOutputStream(f);

		outputFile = new PrintWriter(new OutputStreamWriter(new FileOutputStream(f),"ASCII"));				

		String s1 = rsmd.getColumnName(1) + '\u0009';

		for(int colnames=2; colnames<=colcount; colnames++){
			s1 = s1 + rsmd.getColumnName(colnames) + '\u0009';
		}

		s1 = s1 + "\n";

		outputFile.print(s1);
			

		while (result2.next()) {
			
			s = result2.getString(1) + '\u0009';
				int i=2;
				for(; i<colcount; i++){
					s = s + result2.getObject(i) + '\u0009';
				}
			s = s + result2.getObject(i) ;
			s = s +"\n";
			outputFile.print(s);
		}
		result2.close();
		psSelect2.close();
		outputFile.close();
		connTrk.close();

	ZipFilePersistent zp = new ZipFilePersistent(outputFileName.substring(0,outputFileName.length()-3).concat("zip"));
	zp.addFile(f);
	zp.finish();
	
	fileComplete = true;

			
	}
	catch (SQLException se) {
		se.printStackTrace();
		LogWriter.writeLog(se);
	}
	catch (Exception e) {
		e.printStackTrace();		
		LogWriter.writeLog(e);
	}finally{
		if(f.exists())
		f.delete();
	}
}
}
