package sybilweb.plant.controller;

import java.io.*;
import java.util.*;
import java.util.zip.*;
import sybil.common.util.*;
import sybil.common.util.SybilIssueCustomerFileParser;

/**
 * Insert the type's description here.
 * Creation date: (5/7/01 10:09:02 AM)
 * @author: Srikanth Bapanapalli
 */
public class MyTestClass {
/**
 * MyTestClass constructor comment.
 */
public MyTestClass() {
	super();
}
	public static long setPreviewRoll(Magazine mag, String rollNumber, String path) {
	long count = 0;

		String file = path+"inputData\\"+mag.getFileName();
		System.out.println(file);
		path = path + "temproll.txt";

		try {		
		
		
		FileOutputStream fos = new FileOutputStream(path);
		
		} catch(Exception ex) { ex.printStackTrace(); }

		System.out.println("File output created");
		
/*		OutputStreamWriter osw = new OutputStreamWriter(fos);
		BufferedWriter bw = new BufferedWriter(osw);
		ZipFile zf = new ZipFile(file);
		InputStream zis = zf.getInputStream(zf.getEntry(rollNumber));
		BufferedReader bfr = new BufferedReader(new InputStreamReader(zis));
//		while (bfr.ready()) {
		String s = null;
		while((s = bfr.readLine()) != null) {
			bw.write(s, 0, s.length());
			bw.newLine();
			count++;
			System.out.println(count);
		}
		
		bfr.close();
		zis.close();
		zf.close();
		
		bw.close();
		osw.close();
		fos.close();
		} catch(Exception ex) { ex.printStackTrace(); }

		*/

	return count;			
}
	public static long setPreviewRoll1(Magazine mag, String rollNumber, String path) {
	long count = 0;

		String file = path+"inputData\\"+mag.getFileName();
		System.out.println(file);
		path = path + "temproll.txt";

		try {		
		
		
		FileOutputStream fos = new FileOutputStream(path);
		OutputStreamWriter osw = new OutputStreamWriter(fos);
		BufferedWriter bw = new BufferedWriter(osw);
		ZipFile zf = new ZipFile(file);
		InputStream zis = zf.getInputStream(zf.getEntry(rollNumber));
		BufferedReader bfr = new BufferedReader(new InputStreamReader(zis));
//		while (bfr.ready()) {
		String s = null;
		while((s = bfr.readLine()) != null) {
			bw.write(s, 0, s.length());
			bw.newLine();
			count++;
			System.out.println(count);
		}
		
		bfr.close();
		zis.close();
		zf.close();
		
		bw.close();
		osw.close();
		fos.close();
		} catch(Exception ex) { ex.printStackTrace(); }	

	return count;			
}
}
