package sybilweb.plant.controller;

import java.io.*;
import java.util.Hashtable;
/**
 *	This class is a generic flat file database access engine.
 *	It provides methods to go forward, backward, and jump to
 *	any point in the file.  Each line of text is considered to
 *	be a record.  An index is built as the filepointer moves
 *	inside the file.  Therefore, the first time access time will
 *	be longer.  Any subsequent access will be close to instantaneous.
 *	An improvement can be a separate thread that builds the index
 *	in the background while allowing user access in the meantime.
 *
 *	Used in a plant to allow a user to view a roll of customers.
 *
 *	@author Jun Ying
 */
public class FileRecordReader {
	private Hashtable lineLens;
	private RandomAccessFile raf;
	private long currentRecord;
	private long lastSearch;
	private BufferedReader bfr;
public FileRecordReader(String fileName) {
	lineLens = new Hashtable();
	lineLens.put((new Long(1L)), (new Long(0L)));
	try {
		raf = new RandomAccessFile(fileName, "r");

	} catch (IOException ioe) {
		//CHANGE:
		ioe.printStackTrace();
	}
	currentRecord = 0;
	lastSearch = 1;
}
public void close() throws IOException {
	if (raf != null) {
		raf.close();
	}
}
public String forward() {
	String s = null;
	try {
		s = raf.readLine();
//		System.out.println(s);
		if (s != null) {
			currentRecord++;
			if (!lineLens.containsKey((new Long(currentRecord + 1)))) {
				lineLens.put((new Long(currentRecord + 1)), (new Long(raf.getFilePointer())));
			}
		}
	} catch (IOException ioe) {
		ioe.printStackTrace();
	}
	return s;
}
public long getCurrentNumber() {
	return currentRecord;
}
public String gotoRecord(long desiredRecord) {
	String s = new String();
	if (desiredRecord == (currentRecord + 1)) {
		s = forward();
	}
	else {
		Long longval = (Long) lineLens.get((new Long(desiredRecord)));
		if ((longval == null) || (desiredRecord > currentRecord)) {
			while ((currentRecord != desiredRecord) && (s != null)) {
				s = forward();
			}
		}
		else {
			long offset = longval.longValue();
			try {
				raf.seek(offset);
				s = raf.readLine();
			} catch (Exception e) {
			}
		}
	}
	currentRecord = desiredRecord;
	return s;
}
public static void main(String args[]) {
	FileRecordReader frr = new FileRecordReader(args[0]);
	System.out.println(frr.forward());
	System.out.println(frr.forward());
	System.out.println(frr.forward());
	System.out.println(frr.reverse());
	System.out.println(frr.forward());
	System.out.println(frr.gotoRecord(1));
	System.out.println(frr.reverse());
	System.out.println(frr.reverse());
	System.out.println(frr.forward());
	System.out.println(frr.gotoRecord(2));
	System.out.println(frr.gotoRecord(3));
	System.out.println(frr.gotoRecord(4));
	System.out.println(frr.gotoRecord(5));
	System.out.println(frr.forward());
	System.out.println(frr.gotoRecord(2));
}
public String reverse() {
	String s = null;
	try {
		if (currentRecord > 1) {
			long offset = ((Long) lineLens.get((new Long(--currentRecord)))).longValue();
			raf.seek(offset);
			s = raf.readLine();
		}
	} catch (IOException ioe) {
		ioe.printStackTrace();
	}
	return s;
}
public String searchFor(String s) {
	String record = gotoRecord(++lastSearch);
	while ((record != null) && (record.toLowerCase().indexOf(s.toLowerCase()) == -1)) {
		record = forward();
	}
	lastSearch = currentRecord;
	return record;
}
public String searchFor(String s, long offset) {
	lastSearch = offset - 1;
	String record = gotoRecord(++lastSearch);
	while ((record != null) && (record.toLowerCase().indexOf(s.toLowerCase()) == -1)) {
		record = forward();
	}
	lastSearch = currentRecord;
	return record;
}
}
