package sybilweb.plant.controller;

import java.util.*;
/**
 * Insert the type's description here.
 * Creation date: (12/4/2003 5:33:11 PM)
 * @author: Jay Morgan
 */
public class LabelPositionFileParser {

	public String SignatureName = null;
	public String SignatureNameCode = null;
	public int LabelPosition;
/**
 * LabelPositionFileParser constructor comment.
 */
public LabelPositionFileParser() {
	super();
}
/**
 * Insert the method's description here.
 * Creation date: (12/4/2003 5:38:05 PM)
 * @param signature java.lang.String
 */
public boolean parseLabelPosition(String signature) {


	StringTokenizer st = null;
	try {
		st = new StringTokenizer(signature, String.valueOf(sybilweb.plant.controller.IssueCustomer.TOSTRING_DELIMITER));
		SignatureName = st.nextToken().trim();
		SignatureNameCode = st.nextToken().trim();
		LabelPosition = Integer.valueOf(st.nextToken().trim()).intValue();
		             
		return true;
		
	} catch (Exception e) {
			LogWriter.writeLog(e);
	}
			
	return false;
}
}
