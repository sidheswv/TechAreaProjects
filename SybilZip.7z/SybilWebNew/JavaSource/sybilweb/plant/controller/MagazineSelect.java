package sybilweb.plant.controller;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.sql.*;

/**
 * Insert the type's description here.
 * Creation date: (6/13/01 2:49:44 PM)
 * @author: Srikanth Bapanapalli
 */
public class MagazineSelect extends HttpServlet {
	public void destroy(){
		super.destroy();
		}
	public void init(ServletConfig config) throws ServletException {

		super.init(config);
		
		}
/**
 * service method comment.
 */
public void service(ServletRequest req, ServletResponse res) throws ServletException, java.io.IOException {

	res.setContentType("text/html");
	PrintWriter out = res.getWriter();
	
	String plantid = req.getParameter("PlantID");

	out.println(plantid);
	out.close();
	
	}
}
