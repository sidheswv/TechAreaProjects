package sybilweb.plant.controller;

/**
 * Insert the type's description here.
 * Creation date: (2/23/01 8:59:47 AM)
 * @author: Srikanth Bapanapalli
 */
public class CustomerGroupEntry {

		public final static char FIELD_DELIMITER = '\u001D';
	
	// constants identifying what state a CustomerGroupEntry is
	public final static byte UNPROCESSED = 0;
	public final static byte PREPARED = 1;
	public final static byte DONE = 2;
	public final static byte ERROR = 3;

	public String braceID = null, dopID = null,rollID = null, controllerFormat = null, fileName = null;
	public int controllerFormatKey;
	private int groupID = 0, sequence = 0;
	public int copyCount = 0;
	public byte state = UNPROCESSED;
//	public boolean selected = false;
	public String magazine = null;
	
/**
 * CustomerGroupEntry constructor comment.
 */
public CustomerGroupEntry() {
	super();
}
public int getGroupID() {
	return groupID;
}
public String getProgressDisplay() {

//	public int groupID;
 	StringBuffer data = new StringBuffer(50);

	data.append(StringFunctions.fixSize(String.valueOf(groupID),3,' ',StringFunctions.LEFT));
	data.append(" "); 
	data.append(StringFunctions.fixSize(braceID,4,' ',StringFunctions.LEFT));
	data.append(" ");
	data.append(StringFunctions.fixSize(dopID,6,' ',StringFunctions.LEFT));
	data.append(" ");
	data.append(StringFunctions.fixSize("ROLL" + rollID,8,' ',StringFunctions.LEFT));
	data.append(" ");
	data.append(StringFunctions.fixSize(String.valueOf(copyCount),5,' ',StringFunctions.LEFT));
	data.append(" ");
	data.append(StringFunctions.fixSize(getStateString(),12,' ',StringFunctions.LEFT));
	data.append(" ");
	data.append(StringFunctions.fixSize(controllerFormat,6,' ',StringFunctions.LEFT));

	return data.toString();
}
public int getSequence() {
	return sequence;
}
public String getStateString() {
	String stateString = null;
	switch (state) {
		case (UNPROCESSED): stateString = "Not Ready"; break;
		case (PREPARED):   stateString = "Working"; break;
		case (DONE):   stateString = "Done"; break;
		case (ERROR):  stateString = "ERROR"; break;
	}
	return stateString;
}
public static String getStateString(int i) {
	String stateString = null;
	switch (i) {
		case (UNPROCESSED): stateString = "Not Ready"; break;
		case (PREPARED):   stateString = "Working"; break;
		case (DONE):   stateString = "Done"; break;
		case (ERROR):  stateString = "ERROR"; break;
	}
	return stateString;
}
public void setGroupID(int i) {
	
	groupID = i;
	
}
public void setSequence(int i) {
	sequence = i;
}
/** * This method was created by a SmartGuide.
 * @return java.lang.String
 */
public String toString ( ) {

	StringBuffer buffer = new StringBuffer();

	buffer.append(String.valueOf(groupID));
	buffer.append(String.valueOf(FIELD_DELIMITER));

	if (braceID != null && braceID.length() > 0) {
		buffer.append(braceID.trim());
	}else {
		buffer.append(" ");
	}		
	buffer.append(String.valueOf(FIELD_DELIMITER));


	if (dopID != null && dopID.length() > 0) {
		buffer.append(dopID.trim());
	}else {
		buffer.append(" ");
	}		
	buffer.append(String.valueOf(FIELD_DELIMITER));

	if (rollID != null && rollID.length() > 0) {
		buffer.append(rollID.trim());
	}else {
		buffer.append(" ");
	}		
	buffer.append(String.valueOf(FIELD_DELIMITER));
	
	buffer.append(String.valueOf(copyCount));
	buffer.append(String.valueOf(FIELD_DELIMITER));
	
	if (controllerFormat != null && controllerFormat.length() > 0) {
		buffer.append(controllerFormat.trim());
	}else {
		buffer.append(" ");
	}		
	buffer.append(String.valueOf(FIELD_DELIMITER));
	
	buffer.append("\n");
		
  return buffer.toString();
}
}
