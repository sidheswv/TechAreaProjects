package sybilweb.plant.controller;

public class TextLine implements java.io.Serializable {
	private int m_length;
	private int m_LineNumber;
	private String m_text;
	private int m_justification;

public TextLine() {

}
public TextLine(int length, int just, int number, String text) {

	m_length = length;
	m_justification = just;
	m_LineNumber = number;
	m_text = text;


}
public void changeMessageLineFontPitch() {

}
public void clear() {

	char tmp_buf [] = new char[m_length];

	for (int i = 0; i < m_length; i++) {
	    tmp_buf[i] =  ' ';
	}

	m_text = tmp_buf.toString();
}
public int getJustification() {
	return m_justification;

}
public int getLength() {
	return m_length;

}
public int getNumber() {
	return m_LineNumber;

}
public String getText() {
	return m_text;

}
/**
 * This method was created by a SmartGuide.
 * @param buffer java.lang.String
 * @param start int
 * @param end int
 */
public void insertText(String buffer, int start, int numOfCharsToCopy ) {

	int textLen = buffer.length();
	int currPos = start;
	int numCharsCopied = 0;

	char [] tempStr = m_text.toCharArray();

	while ((numCharsCopied < textLen) && (numCharsCopied < numOfCharsToCopy))
		tempStr[currPos++] = buffer.charAt(numCharsCopied++);

	m_text = String.valueOf(tempStr);

	return;
}
/**
 * This method was created by a SmartGuide.
 */
public void justify( ) {

	char [] buf = new char[m_length];
	int act_length = (m_text.trim()).length();
	int pos = 0, i = 0, start_pos;
	int justification = m_justification;

	if (m_justification == StringFunctions.USE_DEFAULT) {
		justification = StringFunctions.LEFT;
		act_length = m_text.length();
	}

	switch (justification) {

		case StringFunctions.RIGHT:

			start_pos = m_length - act_length;

			for (i = 0; i < m_length; i++) {

				if (i < start_pos)
					buf[i] = ' ';
				else
					buf[i] = m_text.charAt(pos++);
			}

			break;

		case StringFunctions.LEFT:

			start_pos = act_length;

			for (i = 0; i < m_length; i++) {

			if (i < start_pos)
					buf[i] = m_text.charAt(pos++);
				else
					buf[i] = ' ';
			}

			break;

		case StringFunctions.CENTER:

			start_pos = (m_length - act_length) / 2;

			for (i = 0; i < (start_pos + act_length); i++) {
				if (i < start_pos)
					buf[i] = ' ';
				else
					buf[i] = m_text.charAt(pos++);
			}

			// fill rest of string with spaces

			for (i = (start_pos + act_length); i < m_length; i++)
				buf[i] = ' ';

			break;

		default:

			start_pos = m_justification;

			for (i = 0; i < (start_pos + act_length); i++) {
				if (i < start_pos)
					buf[i] = ' ';
				else
					buf[i] = m_text.charAt(pos++);
			}

			// fill rest of string with spaces

			for (i = (start_pos + act_length); i < m_length; i++)
				buf[i] = ' ';

			break;
	}

	m_text = String.valueOf(buf);


	return;
}
/**
 * This method was created by a SmartGuide.
 * @param textSize int
 */
public void justify (int textSize ) {

	char [] buf = new char[m_length];
	int pos = 0, i = 0, start_pos;
	int justification = m_justification;

	if (m_justification == StringFunctions.USE_DEFAULT) {
		justification = StringFunctions.LEFT;
	}

	switch (justification) {

		case StringFunctions.RIGHT:

			start_pos = m_length - textSize;

			for (i = 0; i < m_length; i++) {

				if (i < start_pos)
					buf[i] = ' ';
				else
					buf[i] = m_text.charAt(pos++);
			}

			break;

		case StringFunctions.LEFT:

			start_pos = textSize;

			for (i = 0; i < m_length; i++) {

			if (i < start_pos)
					buf[i] = m_text.charAt(pos++);
				else
					buf[i] = ' ';
			}

			break;

		case StringFunctions.CENTER:

			start_pos = (m_length - textSize) / 2;

			for (i = 0; i < (start_pos + textSize); i++) {
				if (i < start_pos)
					buf[i] = ' ';
				else
					buf[i] = m_text.charAt(pos++);
			}

			// fill rest of string with spaces

			for (i = (start_pos + textSize); i < m_length; i++)
				buf[i] = ' ';

			break;

		default:

			start_pos = m_justification;

			for (i = 0; i < (start_pos + textSize); i++) {
				if (i < start_pos)
					buf[i] = ' ';
				else
					buf[i] = m_text.charAt(pos++);
			}

			// fill rest of string with spaces

			for (i = (start_pos + textSize); i < m_length; i++)
				buf[i] = ' ';

			break;
	}

	m_text = String.valueOf(buf);


	return;
}
public void setJustification(int justification) {

		m_justification = justification;

}
public void setLength(int i) {

	m_length = i;

}
public void setNumber(int i) {

	m_LineNumber = i;

}
public void setText(String s) {

	m_text = s;
	m_length = s.length();

}
/**
 * This method was created by a SmartGuide.
 * @return java.lang.String
 */
public String toString() {
	if (m_text == null) {
		return " ";
	}
	else {
		return m_text;
	}

}
}
