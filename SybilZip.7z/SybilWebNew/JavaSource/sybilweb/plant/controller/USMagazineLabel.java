package sybilweb.plant.controller;

import java.text.DateFormat;
import java.util.Date;


public class USMagazineLabel extends MagazineLabel{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public static final String Class_Version_Number = "OMS_11.4";

    public USMagazineLabel()
    {
    }

    public void format()
    {
        LabelLine8 = PropertyBroker.getProperty("LabelLine8");
        LL8Override = PropertyBroker.getProperty("LL8Override");
        nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
        String oldLL8 = PropertyBroker.getProperty("oldLL8");
        RLL5value = "false";
        
        String LabelLine8 = PropertyBroker.getProperty("LabelLine8");
        
        if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(Plant_ID.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
        {
            if(Plant_ID.equals("CLK")){
                for(int i = 0; i < 8; i++){
                    m_TextLine[i] = new TextLine();
                }

                m_TextLine[0].setText(formatLine1());
                m_TextLine[1].setText(formatLine2());
                m_TextLine[2].setText(formatLabelDropIn());
                m_TextLine[3].setText(formatLine3());
                m_TextLine[4].setText(formatLine4());
                m_TextLine[5].setText(formatLine5());
                m_TextLine[6].setText(formatLine6());
                m_TextLine[7].setText(formatBlank());
            } else {
                for(int i = 0; i < 8; i++){
                    m_TextLine[i] = new TextLine();
                }

                m_TextLine[0].setText(formatBarcodeLine());
                m_TextLine[1].setText(formatLine1());
                m_TextLine[2].setText(formatLine2());
                m_TextLine[3].setText(formatLabelDropIn());
                m_TextLine[4].setText(formatLine3());
                if(Plant_ID.equals("WAS")){
                    m_TextLine[5].setText(formatLine4WAS());
                } else{
                    m_TextLine[5].setText(formatLine4());
                }
                m_TextLine[6].setText(formatLine5());
                m_TextLine[7].setText(formatLine6());
            }
        } else {
            for(int j = 0; j < 6; j++){
                m_TextLine[j] = new TextLine();
            }

            m_TextLine[0].setText(formatLine1());
            m_TextLine[1].setText(formatLine2());
            m_TextLine[2].setText(formatLine3());
            if(Plant_ID.equals("WAS")){
                m_TextLine[3].setText(formatLine4WAS());
            } else if(Plant_ID.equals("STR")){
                    m_TextLine[3].setText(formatLine4STR());   
            } else {
                m_TextLine[3].setText(formatLine4());
            }
            m_TextLine[4].setText(formatLine5());
            m_TextLine[5].setText(formatLine6());
        }
    }

    private String formatBlank()
    {
        StringBuffer labelLine = new StringBuffer("                                      ");
        return labelLine.toString();
    }

    private String formatLine1() {
        
    	StringBuffer labelLine = new StringBuffer();
    	
        String schoolBundling = PropertyBroker.getProperty("schoolBundling", "false");
        if(publicationCode.equals(""))
            labelLine.append("        ");
        else if(publicationCode.length() != 8) 
            labelLine.append(StringFunctions.fixSize(publicationCode, 8, ' ', StringFunctions.LEFT));
        else 
            labelLine.append(publicationCode);
        
        
        if(endorsementLine.equals("")) 
            labelLine.append("                             ");
        else {
            labelLine.append(" ");
            labelLine.append(StringFunctions.fixSize(endorsementLine, 28, '*', StringFunctions.RIGHT));
        }
        labelLine.append(" ");
        
        if(magCode.equalsIgnoreCase("TK")) {
            if(schoolBundling.equalsIgnoreCase("true")) {
                if(endSchoolFlag) {
                    labelLine.append(TK_Bundle);
                    labelLine.append(TK_Bundle);
                } else {
                    labelLine.append("  ");
                }
            } else {
                labelLine.append("  ");
            }
        }
        return labelLine.toString();
    }

    private String formatLine4() {
        
    	StringBuffer labelLine = new StringBuffer();
        String schoolBundling = PropertyBroker.getProperty("schoolBundling", "false");
        
        if(addressLine2.equals("")) 
            labelLine.append("                              ");
        else if(addressLine2.length() != 30) 
            labelLine.append(StringFunctions.fixSize(addressLine2, 30, ' ', StringFunctions.LEFT));
        else 
            labelLine.append(addressLine2);
        
        labelLine.append(" ");
        
        if(suppressSequenceNumber) 
            labelLine.append("      ");
        else {
            labelLine.append("#");
            if(magCode.equalsIgnoreCase("TK")) 
                labelLine.append(StringFunctions.fixSize6(String.valueOf(SchoolCopyCount), 5, '0', StringFunctions.RIGHT));
            else 
                labelLine.append(StringFunctions.fixSize6(String.valueOf(labelNumber), 5, '0', StringFunctions.RIGHT));
        }
        
        if(endofPalletSackIndicator) 
            labelLine.append("#");
        else 
            labelLine.append(" ");
        
        
        if(magCode.equalsIgnoreCase("TK")) {
            if(schoolBundling.equalsIgnoreCase("true")) {
                if(endSchoolFlag) {
                    labelLine.append(TK_Bundle);
                    labelLine.append(TK_Bundle);
                } else {
                    labelLine.append("  ");
                }
            } else {
                labelLine.append("  ");
            }
        }
        return labelLine.toString();
    }

//  This is currently being used by US (Us Weekly magazine only)

    private String formatLine4STR() {
        
    	StringBuffer labelLine = new StringBuffer();
        
        if(addressLine2.equals("")) 
            labelLine.append("                              ");
        else if(addressLine2.length() != 30) 
            labelLine.append(StringFunctions.fixSize(addressLine2, 30, ' ', StringFunctions.LEFT));
        else 
            labelLine.append(addressLine2);
        
        labelLine.append(" ");
        
        if(suppressSequenceNumber) 
            labelLine.append("     ");
        else {
            labelLine.append(StringFunctions.fixSize6(String.valueOf(labelNumber), 5, '0', StringFunctions.RIGHT));
        }
        
        if(endofPalletSackIndicator) 
            labelLine.append(" #");
        else 
            labelLine.append("  ");
        return labelLine.toString();
	}      
        
    private String formatLine4WAS() {
        
    	StringBuffer labelLine = new StringBuffer();
        if(addressLine2.equals("") || addressLine2.length() == 0) {
            labelLine.append("                            ");
        } else {
            labelLine.append(StringFunctions.fixSize(addressLine2, 28, ' ', StringFunctions.LEFT));
        }
        
        String pack_num = StringFunctions.fixSize(String.valueOf(packageNumber), 6, ' ', StringFunctions.RIGHT);
        String package_count = StringFunctions.fixSize(String.valueOf(pack_count), 2, '0', StringFunctions.RIGHT);
        String packNumCount = (new StringBuilder(String.valueOf(pack_num))).append("-").append(package_count).toString();
        labelLine.append(StringFunctions.fixSize(packNumCount, 9, ' ', StringFunctions.LEFT));
        
        if(endofPalletSackIndicator) {
            labelLine.append("#");
        } else {
            labelLine.append(" ");
        }
        return labelLine.toString();
    }

    private String formatLine6() {
        
    	StringBuffer labelLine = new StringBuffer();
        String cityStateZip = null;
        String nCity = null;
        String nZip = null;
        String City = city.equals("") ? "               " : city;
        String State = state.equals("") ? "  " : state;
        String ZipCode = USzipCode.equals("") ? "     " : USzipCode;
        String ZipPlus = zipPlus4.equals("") ? "    " : zipPlus4;
        
        if(City.equals("               ")) {
            nCity = City.concat("  ");
        } else {
            nCity = City.concat(" .");
        }
        
        if(ZipCode.equals("     ")) {
            nZip = ZipCode.concat(" ");
        } else {
            nZip = ZipCode.concat("-");
        }
        
        if(barcode != null && barcode.length() > 0) {
            cityStateZip = (new StringBuilder(String.valueOf(City))).append("  ").append(State).append("  ").append(ZipCode).append("-").append(ZipPlus).toString();
        } else {
            cityStateZip = (new StringBuilder(String.valueOf(nCity))).append(State).append("  ").append(nZip).append(ZipPlus).toString();
        }
        
        labelLine.append(StringFunctions.fixSize(cityStateZip, 30, ' ', StringFunctions.LEFT));
        labelLine.append("        ");
        
        if(magCode.equalsIgnoreCase("TK")) {
            labelLine.append("  ");
        }
        return labelLine.toString();
    }

    public void setLengthOfRunBookFields(String name, Address addr, String rollID) {
        
    	String LORBedition = editionCode;
        String pallet = palletSackNumber;
        clear();
        DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 2);
        makeupCode = rollID;
        endorsementLine = "PROFILE COPY";
        palletSackNumber = pallet;
        acsKeyline = dateFormat.format(new Date());
        publicationCode = LORBedition;
        customerName = name;
        addressLine1 = addr.getLine1();
        addressLine2 = rollID;
        city = addr.getCity();
        USzipCode = addr.getZipCode();
        state = addr.getState();
        zipPlus4 = addr.getZipPlus4();
        barcode = Integer.toString(addr.getBarcode());
    }

    public void setPostalBookLabelFields(String edition, int postalbooknumber, int copycount, int numberOfCopies, String ZipCode, String palletSackNumber) {
        
    	clear();
        publicationCode = "********";
        endorsementLine = "POSTAL BOOK";
        customerName = (new StringBuilder("POSTAL BOOK ")).append(postalbooknumber).toString();
        addressLine1 = (new StringBuilder("EDITION - ")).append(edition).toString();
        addressLine2 = "C/O DOMESTIC MAIL UNIT";
        city = (new StringBuilder("COPY ")).append(copycount).append(" OF ").append(numberOfCopies).toString();
        USzipCode = ZipCode;
        this.palletSackNumber = palletSackNumber;
    }

    public void setStorageBookLabelFields(String edition, int copycount, int numberOfCopies, String ZipCode, String palletSackNumber) {
        
    	clear();
        publicationCode = "********";
        endorsementLine = "STORAGE BOOK";
        customerName = "********STORAGE BOOK********";
        addressLine1 = (new StringBuilder("EDITION - ")).append(edition).toString();
        addressLine2 = "NOT FOR MAIL STREAM";
        city = (new StringBuilder("COPY ")).append(copycount).append(" OF ").append(numberOfCopies).toString();
        USzipCode = ZipCode;
        this.palletSackNumber = palletSackNumber;
    }
}
