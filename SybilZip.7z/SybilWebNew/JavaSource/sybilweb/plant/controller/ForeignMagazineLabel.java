package sybilweb.plant.controller;

import java.text.DateFormat;
import java.util.Date;
import java.util.StringTokenizer;

 
public class ForeignMagazineLabel extends MagazineLabel {

	/// VERSION OF CLASS IN PRODUCTION ////
	public static final String Class_Version_Number = "PR_6.2_REL9.4";


/**
 * format method comment.
 */
public void format() {

	LabelLine8 = (String)PropertyBroker.getProperty("LabelLine8");
	LL8Override = (String)PropertyBroker.getProperty("LL8Override");
	nonLL8Plant = (String)PropertyBroker.getProperty("nonLL8Plant");
	RLL5value = "false";
	
		String LabelLine8 = PropertyBroker.getProperty("LabelLine8");
		StringTokenizer stMagCode = new StringTokenizer(LabelLine8, ",");
		boolean LL8MagCode = false;
		int numofTokens = stMagCode.countTokens();
		for (int magCodeCounter = 0; magCodeCounter < numofTokens; magCodeCounter++) {
			if (stMagCode.nextToken().trim().equals(magCode.trim())) {
				LL8MagCode = true;
			 	break;
			}
		}
	if ((LabelLine8.indexOf(magCode)>=0) && (LL8Override.equals("false")) && !(nonLL8Plant.indexOf(Plant_ID.toUpperCase())>=0) && (RLL5value.equalsIgnoreCase("false")) || (oldLL8.indexOf(magCode)>=0)){
		for (int i = 0; i < 8; i++) {
			m_TextLine[i] = new TextLine();
		}	
		m_TextLine[0].setText(formatBarcodeLine());
		m_TextLine[1].setText(formatLine1());
		m_TextLine[2].setText(formatLine2());
		m_TextLine[3].setText(formatLine3());
		m_TextLine[4].setText(formatLabelDropIn());
		if (Plant_ID =="WAS") {
			m_TextLine[5].setText(formatLine4WAS());
		}
		else {
			m_TextLine[5].setText(formatLine4());
		}
		m_TextLine[6].setText(formatLine5());
		m_TextLine[7].setText(formatLine6());

		}
	else {

		for (int j = 0; j < 6; j++) {
			m_TextLine[j] = new TextLine();
		}	
		m_TextLine[0].setText(formatLine1());
		m_TextLine[1].setText(formatLine2());
		m_TextLine[2].setText(formatLine3());
		if (Plant_ID == "WAS") {
			m_TextLine[3].setText(formatLine4WAS());
		}
		else {
			m_TextLine[3].setText(formatLine4());
		}
		m_TextLine[4].setText(formatLine5());
		m_TextLine[5].setText(formatLine6());

	}
}
/**
 * This method was created by a SmartGuide.
 */
private String formatLine1( ) {

	StringBuffer labelLine =  new StringBuffer();
	String schoolBundling = (String)PropertyBroker.getProperty("schoolBundling","false");	
// publicationCode 8 characters
	if (publicationCode.equals("")) // suppressed, fill with spaces
		labelLine.append("        ");
	else if (publicationCode.length() != 8)
		labelLine.append(StringFunctions.fixSize(publicationCode,8,' ',StringFunctions.LEFT));
	else
		labelLine.append(publicationCode);

// endorsementLine 30 characters total
	if (endorsementLine.equals("")) // suppressed, fill with spaces
		labelLine.append("                              ");
	else {
		labelLine.append(" ");
		labelLine.append(StringFunctions.fixSize(endorsementLine,28,'*',StringFunctions.LEFT));
	}	
	labelLine.append(" ");


// appends the bot marks for TK if end of school making label 40 chars, all other mags stay at 38 chars
	if (magCode.equalsIgnoreCase("TK")){
		if (schoolBundling.equalsIgnoreCase("true")) {
			if (endSchoolFlag) {
				labelLine.append(TK_Bundle);
				labelLine.append(TK_Bundle);

			}else {
				labelLine.append("  ");
			}
		}else {
			labelLine.append("  ");
		}
	}
	

	return labelLine.toString();

}
/**
 * This method was created by a SmartGuide.
 */
private String formatLine4 () {

	StringBuffer labelLine =  new StringBuffer();
	String schoolBundling = (String)PropertyBroker.getProperty("schoolBundling","false");

// addressLine2 30 characters
	if (addressLine2.equals("")) // suppressed, fill with spaces
		labelLine.append("                              ");
	else if (addressLine2.length() != 30)
		labelLine.append(StringFunctions.fixSize(addressLine2,30,' ',StringFunctions.LEFT));
	else
		labelLine.append(addressLine2);
	
	labelLine.append(" ");
	if (suppressSequenceNumber)
		labelLine.append("      ");
	else {
		labelLine.append("#");
		labelLine.append(StringFunctions.fixSize(String.valueOf(labelNumber),5,'0',StringFunctions.RIGHT));					// sequence number
	}	

// endOfPalletSackIndicator 1 characters
	if (endofPalletSackIndicator) 
		labelLine.append("#");
	else
		labelLine.append(" ");

// appends the bot marks for TK if end of school making label 40 chars, all other mags stay at 38 chars
	if (magCode.equalsIgnoreCase("TK")){
		if (schoolBundling.equalsIgnoreCase("true")) {
			if (endSchoolFlag) {
				labelLine.append(TK_Bundle);
				labelLine.append(TK_Bundle);

			}else {
				labelLine.append("  ");
			}
		}else {
			labelLine.append("  ");
		}
	}
	

	
	return labelLine.toString();
	
}
	private String formatLine4WAS () {

	StringBuffer labelLine =  new StringBuffer();


// addressLine2 30 characters
	if ((addressLine2.equals(""))||(addressLine2.length()==0)) // suppressed, fill with spaces
		labelLine.append("                            ");
	else 
		labelLine.append(StringFunctions.fixSize(addressLine2,28,' ',StringFunctions.LEFT));
	
			
	
	String pack_num = StringFunctions.fixSize(String.valueOf(packageNumber),6,' ',StringFunctions.RIGHT);
			
	String package_count =  StringFunctions.fixSize(String.valueOf(pack_count),2,'0',StringFunctions.RIGHT);
	String packNumCount = pack_num+"-"+pack_count;

	labelLine.append(StringFunctions.fixSize(packNumCount,9,' ',StringFunctions.RIGHT));

// endOfPalletSackIndicator 1 characters
	if (endofPalletSackIndicator) 
		labelLine.append("#");
	else
		labelLine.append(" ");
	
	return labelLine.toString();
	
}
/**
 * This method was created by a SmartGuide.
 */
private String formatLine6( ) {

	StringBuffer labelLine =  new StringBuffer();

// 990701 - SWC - Special note:  For foreign labels, the 'city/state/zip' field contains
//	the address line 6 info.  It is not intended to be parsed into city, state, zip, etc.
//	Therefore, City is assumed to be 30 characters long, and state, zip and zip4 are
//	disregarded.
	
// city 30 characters
	if (city.equals("")) // suppressed, fill with spaces
		labelLine.append("                              ");
	else if (city.length() != 30)
		labelLine.append(StringFunctions.fixSize(city,30,' ',StringFunctions.LEFT));
	else
		labelLine.append(city);

	labelLine.append("  ");
/*		
// state 2 characters
	if (state.equals("")) // suppressed, fill with spaces
		labelLine.append("  ");
	else if (state.length() != 2)
		labelLine.append(StringFunctions.fixSize(state,2,' ',StringFunctions.LEFT));
	else
		labelLine.append(state);
	
	labelLine.append(" ");

// zipcode 5 characters
	if (USzipCode.equals("")) // suppressed, fill with spaces
		labelLine.append("     ");
	else if (USzipCode.length() != 5)
		labelLine.append(StringFunctions.fixSize(USzipCode,5,' ',StringFunctions.LEFT));
	else
		labelLine.append(USzipCode);

// zipPlus4 5 characters includes dash
	if (zipPlus4.equals("")) // suppressed, fill with spaces
		labelLine.append("     ");
	else if (zipPlus4.length() != 4){
		labelLine.append("-");
		labelLine.append(StringFunctions.fixSize(zipPlus4,4,' ',StringFunctions.LEFT));
	} else {
		labelLine.append("-");
		labelLine.append(zipPlus4);
	}			
*/
	labelLine.append("        ");

	if (magCode.equalsIgnoreCase("TK")){
			labelLine.append("  ");
	}

	
	return labelLine.toString();

}
/**
 * setLengthOfRunBookFields method comment.
 */
public void setLengthOfRunBookFields(String name, Address addr, String rollID) {

	String LORBedition = editionCode;
	String pallet = palletSackNumber;
	
	
	clear();
	
  DateFormat dateFormat = DateFormat.getDateTimeInstance (DateFormat.MEDIUM, DateFormat.MEDIUM);

   	makeupCode = rollID;
	endorsementLine = "PROFILE COPY";
	palletSackNumber = pallet;
	acsKeyline = dateFormat.format (new Date());
	publicationCode = LORBedition;
	customerName = name;
	addressLine1 = addr.getLine1();
	addressLine2 = rollID;
//	addressLine2 = addr.getLine2();
	city = addr.getCity();
	USzipCode = addr.getZipCode();
	state = addr.getState();	

	return;	
}
	public void setPostalBookLabelFields (String edition, int postalbooknumber, int copycount, int numberOfCopies, String ZipCode, String palletSackNumber) {
		return;
	}
	public void setStorageBookLabelFields (String edition, int copycount, int numberOfCopies, String ZipCode, String palletSackNumber) {
		return;
	}
}
