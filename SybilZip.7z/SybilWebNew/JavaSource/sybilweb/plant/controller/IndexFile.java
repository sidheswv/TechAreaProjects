package sybilweb.plant.controller;

/**
 * Insert the type's description here.
 * Creation date: (12/13/2002 11:50:06 AM)
 * @author: Srikanth Bapanapalli
 */

 import java.util.*;
 import java.io.*;
 import java.util.zip.*;
 
public class IndexFile {
	public Magazine selectedMagazine = null;

	Vector IndexFileFields = new Vector();

	String Roll = null;
	String rnwl_eff_key = null;
	String rnwl_lttr = null;
	String fam_1_msg_id = null;
	String fam_1_warning_ind = null;		
	String fam_1_demo_nme = null;
	String fam_2_msg_id = null;
	String fam_2_warning_ind = null;		
	String fam_2_demo_nme =null;
	String fam_3_msg_id = null;
	String fam_3_warning_ind = null;		
	String fam_3_demo_nme = null;

/**
 * IndexFile constructor comment.
 */
public IndexFile() {
	super();
}
/**
 * Insert the method's description here.
 * Creation date: (12/17/2002 10:17:36 AM)
 * @return java.util.Vector
 * @exception java.lang.Exception The exception description.
 */
public Vector getFieldNames() throws java.lang.Exception {
	Vector fields = new Vector();
	try{
		String commonIniPath = PropertyBroker.getProperty("SybiliniPath");
		String plantIniPath = commonIniPath.concat(new String("SybilPlant").concat(selectedMagazine.getPlant().toUpperCase())).concat(".ini");
		SybilWebPropertyBroker swp = new SybilWebPropertyBroker();
		swp.load(plantIniPath);
		String indexFilePath = swp.getProperty("OLDFILEDIR");
		indexFilePath = indexFilePath.concat(selectedMagazine.getFullPrefix()).concat(".zip");
	
		ZipFile zf = new ZipFile(indexFilePath);

		Enumeration e = zf.entries();
		while(e.hasMoreElements()){
			ZipEntry ze = (ZipEntry)e.nextElement();
			if(ze.getName().toUpperCase().indexOf(new String("CREF").toUpperCase())==0) {
				if( ( (ze.getName().toUpperCase().indexOf(new String("INDEX").toUpperCase())==-1) && (ze.getName().toUpperCase().indexOf(new String("Rolls").toUpperCase())==-1) ) ){
					fields.addElement(ze.getName());
				}
			}	
		}

		zf.close();
	}catch(Exception ex){ ex.printStackTrace(); LogWriter.writeLog(ex); }
	
	return fields;
}
/**
 * Insert the method's description here.
 * Creation date: (12/17/2002 9:49:43 AM)
 * @return int
 * @exception java.lang.Exception The exception description.
 */
public int getFieldsCount() throws java.lang.Exception {
	int count = -1;
	String commonIniPath = PropertyBroker.getProperty("SybiliniPath");
	String plantIniPath = commonIniPath.concat(new String("SybilPlant").concat(selectedMagazine.getPlant().toUpperCase())).concat(".ini");
	SybilWebPropertyBroker swp = new SybilWebPropertyBroker();
	swp.load(plantIniPath);
	String indexFilePath = swp.getProperty("OLDFILEDIR");
	indexFilePath = indexFilePath.concat(selectedMagazine.getFullPrefix()).concat(".zip");
	
	ZipFile zf = new ZipFile(indexFilePath);
	count = zf.size();
	zf.close();
	
	return count;
}
/**
 * Insert the method's description here.
 * Creation date: (12/20/2002 2:22:58 PM)
 * @return java.util.Vector
 * @param Fields java.util.Hashtable
 */
public Vector getMatchedRolls(Vector Fields) throws Exception {
	Vector MatchedRolls = new Vector();
	ZipFile zf = null;
	BufferedReader bfr = null;
	try{
		
		String commonIniPath = PropertyBroker.getProperty("SybiliniPath");
		String plantIniPath = commonIniPath.concat(new String("SybilPlant").concat(selectedMagazine.getPlant().toUpperCase())).concat(".ini");
		SybilWebPropertyBroker swp = new SybilWebPropertyBroker();
		swp.load(plantIniPath);
		String indexFilePath = swp.getProperty("OLDFILEDIR");
		indexFilePath = indexFilePath.concat(selectedMagazine.getFullPrefix()).concat(".zip");
	
		zf = new ZipFile(indexFilePath);
		InputStream zis = zf.getInputStream(zf.getEntry("CREF_INDEX"));
		bfr = new BufferedReader(new InputStreamReader(zis, "ASCII"));
	
		int count =0;
		String s = null;
		int counter =0;
		int FieldsCount = Fields.size();

		while((s = bfr.readLine()) != null) {
			counter=counter+1;
			parseIndexFile(s);

			int j = 0;
			int i = 0;
			Vector newFields = new Vector();

			while(i<FieldsCount){
					if(((String)Fields.elementAt(i)).equals(" ")){
						newFields.addElement(IndexFileFields.elementAt(i));		
					}else{
						newFields.addElement(Fields.elementAt(i));		
					}
					i++;
				}


				if(((String)newFields.elementAt(0)).trim().equals(((String)IndexFileFields.elementAt(0)).trim())){
					if(((String)newFields.elementAt(1)).trim().equals(((String)IndexFileFields.elementAt(1)).trim())){
						if(((String)newFields.elementAt(2)).trim().equals(((String)IndexFileFields.elementAt(2)).trim())){
							if(((String)newFields.elementAt(3)).trim().equals(((String)IndexFileFields.elementAt(3)).trim())){
								if(((String)newFields.elementAt(4)).trim().equals(((String)IndexFileFields.elementAt(4)).trim())){
									if(((String)newFields.elementAt(5)).trim().equals(((String)IndexFileFields.elementAt(5)).trim())){
										if(((String)newFields.elementAt(6)).trim().equals(((String)IndexFileFields.elementAt(6)).trim())){
											if(((String)newFields.elementAt(7)).trim().equals(((String)IndexFileFields.elementAt(7)).trim())){
												if(((String)newFields.elementAt(8)).trim().equals(((String)IndexFileFields.elementAt(8)).trim())){
													if(((String)newFields.elementAt(9)).trim().equals(((String)IndexFileFields.elementAt(9)).trim())){
														if(((String)newFields.elementAt(10)).trim().equals(((String)IndexFileFields.elementAt(10)).trim())){
																		if(!MatchedRolls.contains(Roll))
																		MatchedRolls.addElement(Roll);
														}	
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}	
			

		}
		
		bfr.close();
		zf.close();
		
	}catch(Exception ex){ ex.printStackTrace(); bfr.close(); zf.close(); }

	return MatchedRolls;
}
public Vector getReqFields(Hashtable req_fieldnameValues) {

	Vector req_fields = new Vector();

	req_fields.add(" ");
	req_fields.add(req_fieldnameValues.get("CREF_RNWL_EFF_KEY"));
	req_fields.add(req_fieldnameValues.get("CREF_RNWL_LTTR"));	
	req_fields.add(req_fieldnameValues.get("CREF_MSG_FAM_1_MSG_ID"));
	//req_fields.add(req_fieldnameValues.get("CREF_MSG_FAM_1_WARNING_IND"));	
	req_fields.add(req_fieldnameValues.get("CREF_MSG_FAM_1_DEMO_CAT"));	
	req_fields.add(req_fieldnameValues.get("CREF_MSG_FAM_2_MSG_ID"));
	//req_fields.add(req_fieldnameValues.get("CREF_MSG_FAM_2_WARNING_IND"));		
	req_fields.add(req_fieldnameValues.get("CREF_MSG_FAM_2_DEMO_CAT"));
	req_fields.add(req_fieldnameValues.get("CREF_MSG_FAM_3_MSG_ID"));
	//req_fields.add(req_fieldnameValues.get("CREF_MSG_FAM_3_WARNING_IND"));		
	req_fields.add(req_fieldnameValues.get("CREF_MSG_FAM_3_DEMO_CAT"));	
return req_fields;		      

}
/**
 * Insert the method's description here.
 * Creation date: (12/13/2002 11:53:50 AM)
 * @return java.util.Vector
 */
public java.util.Vector getRnwlLttr() throws Exception {
	Vector RnwlLttr = new Vector();
	try{
		
		String commonIniPath = PropertyBroker.getProperty("SybiliniPath");
		String plantIniPath = commonIniPath.concat(new String("SybilPlant").concat(selectedMagazine.getPlant().toUpperCase())).concat(".ini");
		SybilWebPropertyBroker swp = new SybilWebPropertyBroker();
		swp.load(plantIniPath);
		StringTokenizer RnwlLttrTokens = new StringTokenizer(swp.getProperty("RNWL_LTTR","RNWL_LTTR_NOTDEFINED"),",");
	
		while(RnwlLttrTokens.hasMoreTokens()){
			String token = RnwlLttrTokens.nextToken();
			RnwlLttr.addElement(token);
		}
	}catch(Exception ex){ ex.printStackTrace(); }
	
	return RnwlLttr;
}
/**
 * Insert the method's description here.
 * Creation date: (12/16/2002 10:08:19 AM)
 * @return java.util.Vector
 * @param Field java.lang.String
 */
public Vector getSearchFieldValues(String Field) {
	Vector FieldValues = new Vector();
	try{
		
		String commonIniPath = PropertyBroker.getProperty("SybiliniPath");
		String plantIniPath = commonIniPath.concat(new String("SybilPlant").concat(selectedMagazine.getPlant().toUpperCase())).concat(".ini");
		SybilWebPropertyBroker swp = new SybilWebPropertyBroker();
		swp.load(plantIniPath);
		String indexFilePath = swp.getProperty("OLDFILEDIR");
		indexFilePath = indexFilePath.concat(selectedMagazine.getFullPrefix()).concat(".zip");
		ZipFile zf = new ZipFile(indexFilePath);
		InputStream zis = zf.getInputStream(zf.getEntry(Field.trim()));
		BufferedReader bfr = new BufferedReader(new InputStreamReader(zis, "ASCII"));
	
		int count =0;
		String s = null;
		int counter =0;
		while((s = bfr.readLine()) != null) {
			counter=counter+1;
			FieldValues.addElement(s);
		}
		

		bfr.close();
		zf.close();
	}catch(Exception ex){ ex.printStackTrace(); }
	
	return FieldValues;
}
/**
 * Insert the method's description here.
 * Creation date: (12/20/2002 2:28:44 PM)
 * @param indexFileRecord java.lang.String
 */
public void parseIndexFile(String indexFileRecord) {

	StringTokenizer st = new StringTokenizer(indexFileRecord,String.valueOf(IssueCustomer.TOSTRING_DELIMITER));

			 Roll = st.nextToken();
			 rnwl_eff_key = st.nextToken();
			 rnwl_lttr = st.nextToken();
			 fam_1_msg_id = st.nextToken();
			 fam_1_warning_ind = st.nextToken();			 
			 fam_1_demo_nme = st.nextToken();
			 fam_2_msg_id = st.nextToken();
			 fam_2_warning_ind = st.nextToken();			 
	    	 fam_2_demo_nme = st.nextToken();
			 fam_3_msg_id = st.nextToken();
			 fam_3_warning_ind = st.nextToken();			 
		     fam_3_demo_nme = st.nextToken();
		     
			
		     IndexFileFields = new Vector();	
		     IndexFileFields.add(Roll);
		     IndexFileFields.add(rnwl_eff_key);
		     IndexFileFields.add(rnwl_lttr);		     
		     IndexFileFields.add(fam_1_msg_id);
		     IndexFileFields.add(fam_1_warning_ind);		     		     
		     IndexFileFields.add(fam_1_demo_nme);		     
		     IndexFileFields.add(fam_2_msg_id);
		     IndexFileFields.add(fam_2_warning_ind);		     		     
		     IndexFileFields.add(fam_2_demo_nme);		     
		     IndexFileFields.add(fam_3_msg_id);
		     IndexFileFields.add(fam_3_warning_ind);		     		     
		     IndexFileFields.add(fam_3_demo_nme);		     

	}
/**
 * Insert the method's description here.
 * Creation date: (12/13/2002 11:51:19 AM)
 * @param mag sybilweb.plant.controller.Magazine
 */
public void setSelectedMagazine(Magazine mag) {
	selectedMagazine = mag;
	}
}
