package sybilweb.plant.controller;

/**
 * This type was created in VisualAge.
 */
import java.util.*;

public class MessageFamily {
	public String familyNumber;
	public int size;
	public int numLines;
	private Vector maximumLineLengths = null;
/**
 * MessageFamily constructor comment.
 */
public MessageFamily() {
	super();
}
public void addLineLength(int length) {

	if (maximumLineLengths == null)
		maximumLineLengths = new Vector();

	maximumLineLengths.addElement(new Integer(length));
}
/**
 * This method was created in VisualAge.
 * @return int
 * @param linenum int
 */
public int getLineLength(int linenum) {

	Integer i = (Integer)maximumLineLengths.elementAt(linenum);
	return i.intValue();
}
}
