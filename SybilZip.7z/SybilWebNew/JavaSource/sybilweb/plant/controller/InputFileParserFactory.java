package sybilweb.plant.controller;

public class InputFileParserFactory {
	public static final String GTRF = "GTRF";
	public static final String OMS2 = "OMS2";
	public static final String GBIN = "GBIN";
	public static final String OfficeCopy = "OFCE";
	public static final String StorageBooks = "STORBOOK";
	public static final String PostalBooks = "POBOOK";
	public static final String StorageBooks2 = "STORBK2";
	public static final String PostalBooks2 = "POBOOK2";

	private String m_inputFileType;
	public InputFileParser m_InputFileParser;

public InputFileParserFactory() {

	this (InputFileParserFactory.GTRF);

}
public InputFileParserFactory(String fileType) {

	setInputFileType (fileType);

}
public InputFileParser createInputFileParser() {

	m_InputFileParser = null;
	String newClass = "sybil.common.util." + m_inputFileType + "InputFileParser";
	try {
		m_InputFileParser = (InputFileParser) Class.forName(newClass).newInstance();
	} catch (Exception e) {
//		LogWriter.writeLog (e);
	}

	return m_InputFileParser;

}
private void setInputFileType(String fileType) {

	String type = fileType.trim();

	if ((type.equalsIgnoreCase(GTRF)) ||
		(type.equalsIgnoreCase(OMS2)) ||
		(type.equalsIgnoreCase(GBIN)) ||
		(type.equalsIgnoreCase(OfficeCopy)) ||
		(type.equalsIgnoreCase(StorageBooks)) ||
		(type.equalsIgnoreCase(PostalBooks)) ||
		(type.equalsIgnoreCase(StorageBooks2)) ||
		(type.equalsIgnoreCase(PostalBooks2)) ) {
		m_inputFileType = type;
	} else {
//		LogWriter.writeLog("Invalid input file type specified <" + type +
//			">. Job is aborting");
		System.exit(1);
	}

}
}
