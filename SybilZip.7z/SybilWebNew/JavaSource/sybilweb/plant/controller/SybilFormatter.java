package sybilweb.plant.controller;

/**
 * Insert the type's description here.
 * Creation date: (8/14/01 9:12:13 AM)
 * @author: Srikanth Bapanapalli
 */


import java.io.*;
import java.util.*;

 
public class SybilFormatter implements Runnable {
	public SybilMagazine mag = null;
	public Vector rolls = new Vector();

	public int ctrlfmtkey = 0;
	public String controlformatkey = null;
	public String ctrlfmt = null;
	public String magazine = null;
	public String magazinefilename = null;
	public String outputfilename = null;
	public String FormatCtlFiledir = null;
	public String logFilePath = null;
	public Vector Groups = null; 
	public static String inipath = null;
	public String plant = null;

	public String FormattedFile = null;

	// process control
	private static String processCode = null;
	private static String processPlant = null;
	
/**
 * SybilFormatter constructor comment.
 */
public SybilFormatter() {
	super();
}
/**
 * SybilFormatter constructor comment.
 */
public SybilFormatter(String Plant) {
	
	plant = Plant.trim();

	try {
		PropertyBroker.load(inipath);
		String LogMessagesToFile = PropertyBroker.getProperty("LogMessagesToFile");
		LogWriter.writeLog("I", Plant.trim().toUpperCase() , "", " Loaded "+inipath+"file");
	} 
	catch(Exception e){ 
		LogWriter.writeLog("E", Plant.trim().toUpperCase() , "", " Unable to Load "+inipath+"file");
		LogWriter.writeLog(e); 
	}

	initializeLogFile();
	LogWriter.writeLog("I","","","==== === === === === === === === === === ====");
	LogWriter.writeLog("I","","","=== === SybilFormatter.SybilFormatter === ===");
	LogWriter.writeLog("I","","","==== === === === === === === === === === ====");

	processCode = PropertyBroker.getProperty("PROCESS_CODE");
	processPlant = PropertyBroker.getProperty("PLANTID");
	if ((processCode != null) && (processPlant != null)) {}
	else {
		LogWriter.writeLog("E",Plant.trim().toUpperCase() ,"","SybilFormatter.SybilFormatter: Error ... property PROCESS_CODE and/or PLANTID not specified.");
		LogWriter.writeLog(new Exception("SybilFormatter.SybilFormatter: Error ... property PROCESS_CODE and/or PLANTID not specified."));
		System.exit(1);
	}
	ProcessTracker.initProcessTracker();
	
	savePid();

	SybilFormatter sfmt = new SybilFormatter();
	Thread t = new Thread(sfmt);
	t.start();
	
	FormatCtlFiledir = PropertyBroker.getProperty("FormatterControlPath");
	if(FormatCtlFiledir == null){
		LogWriter.writeLog("E", Plant.trim().toUpperCase(), "", "SybilFormatter. Error ... property FormatCtlFiledir not specified.");
		LogWriter.writeLog(new Exception("SybilFormatter: Error ... property FormatCtlFiledir not specified."));
		System.exit(1);
	}

	try{
		lookup();
	}catch(Exception ex){
		ex.printStackTrace();
	}
}
/**
 * Insert the method's description here.
 * Creation date: (4/18/2002 4:13:24 PM)
 */
private static void initializeLogFile() {
	String prop = null;
	boolean writeLog = false;
	long maxFileSize = 0;
	String fPath;
	String logFilename;
	
	// Get "LogMessages" switch.  If not 'true', don't go any further.
	if ((prop = PropertyBroker.getProperty("LogMessagesToFile")) != null) {
		prop.toLowerCase();
		if (prop.equals("true")) {
			writeLog = true;
		}	
	}
	
	// Get "LogFileDirectory"
	if ((prop = PropertyBroker.getProperty("LogFileDirectory")) != null) {
		fPath = prop;
	} else {
		System.out.println("Error: Log File Path not specified.  Assuming none");
		fPath = null;
	}


	// Get "LogFileName"
	if ((prop = PropertyBroker.getProperty("LogFileName")) != null) {
		logFilename = prop;
	} else {
		System.out.println("Error: Log Filename not specified.  Assuming none");
		logFilename = null;
	}
		
	
	// Get "LogFilemaxSize"
	if ((prop = PropertyBroker.getProperty("LogFileMaxSize")) != null) {
		maxFileSize = Integer.parseInt(prop);
	} else {
		maxFileSize = 100000;		// Default to 100K
	}

	LogWriter.initialize (writeLog, maxFileSize, fPath, logFilename);
	
	return;
}
/**
 * Insert the method's description here.
 * Creation date: (9/6/01 9:17:00 AM)
 * @exception java.lang.Exception The exception description.
 */
public void lookup() throws Exception {

// Rename .001 to .000

	File updatedir = new File(FormatCtlFiledir);
	FilenameFilter updateFilenameFilter = new OnlyExt("001");
	String updateFilelist[] = updatedir.list(updateFilenameFilter);

	if(updateFilelist.length>0) {
		for(int m=0; m<updateFilelist.length; m++)	{
		renameFile(updateFilelist[m].trim(),"000");
		}
	}


// Delete Abandoned .tmp files from the Send Folder

	String DataOutputPath = PropertyBroker.getProperty("DataOutputPath");

	File tempOutputDir = new File(DataOutputPath);
	FilenameFilter tempFileFilter = new OnlyExt("tmp");
	String tmpFilelist[] = tempOutputDir.list(tempFileFilter);

	if(tmpFilelist.length>0) {
		for(int tempCounter=0; tempCounter<tmpFilelist.length; tempCounter++){
			String tmpAbsoluteFile = DataOutputPath + tmpFilelist[tempCounter];
			File tmpFile = new File(tmpAbsoluteFile);
			if(tmpFile.delete())
				LogWriter.writeLog("I", plant.trim().toUpperCase(), "Deleting Abandoned temporary File", tmpAbsoluteFile);
			else
				LogWriter.writeLog("I", plant.trim().toUpperCase(), "Unable to Delete Abandoned temporary File", tmpAbsoluteFile);	
		}
	}

		
		

// loop to check the Files with .000 rename to .001 and format particular Rolls

	while(true){

			File RunningThreadsDir = new File(FormatCtlFiledir);
			FilenameFilter RunningThreadsFileFilter = new OnlyExt("001");
			String RunningThreads[] = RunningThreadsDir.list(RunningThreadsFileFilter);
			String RunningThreadsLimit = PropertyBroker.getProperty("RunningThreadsLimit","1");
			

//						if(RunningThreads.length == 0)
//					Thread.sleep(Integer.parseInt(PropertyBroker.getProperty("Formatter_Sleep_0","60000")));					

//				if(RunningThreads.length <= Integer.valueOf(RunningThreadsLimit).intValue() )
//					Thread.sleep(Integer.parseInt(PropertyBroker.getProperty("Formatter_Sleep_x","30000")));

		if(RunningThreads.length < Integer.valueOf(RunningThreadsLimit).intValue() ){

		File SybilFormatDir = new File(FormatCtlFiledir);
		FilenameFilter only = new OnlyExt("000");
//		String s[] = SybilFormatDir.list(only);

		File[] fmtFiles = SybilFormatDir.listFiles(only);
		for(int us=0; us<fmtFiles.length; us++){
			File max_val = fmtFiles[us];
			int max_loc = us;
			for(int j=(us+1); j<fmtFiles.length; j++){
				if(fmtFiles[j].lastModified() < max_val.lastModified()) {
					max_loc = j;
					max_val = fmtFiles[j];
				}
			}

			File temp = fmtFiles[us];
			fmtFiles[us] = fmtFiles[max_loc];
			fmtFiles[max_loc] = temp;
		}

		String sortedFormatFiles[] = new String[fmtFiles.length];

		for(int dir3=0; dir3<fmtFiles.length; dir3++){
			String fmtFileString = fmtFiles[dir3].toString().trim();
			sortedFormatFiles[dir3] =fmtFileString.substring(fmtFileString.lastIndexOf("/")+1,fmtFileString.length());			
		}		
		

	try {

		if(sortedFormatFiles.length>0) {
			int Num_Files_to_fmt = Integer.parseInt(RunningThreadsLimit) - RunningThreads.length;
						
			if(sortedFormatFiles.length <= Num_Files_to_fmt)
			   Num_Files_to_fmt =  sortedFormatFiles.length;
			for(int k=0; k<Num_Files_to_fmt; k++)	{		

			/////
		
			String InputData = PropertyBroker.getProperty("OLDFILEDIR");
			if(InputData == null){
				LogWriter.writeLog("E", plant.trim().toUpperCase(), "", "SybilFormatter. Error ... property OLDFILEDIR not specified.");
				LogWriter.writeLog(new Exception("SybilFormatter: Error ... property OLDFILEDIR not specified."));
				System.exit(1);
			}

			
			boolean ReRunFlag = false;
			File InputDataDir = new File(InputData);
			FilenameFilter BeginLoadOnly = new OnlyExt("BEGINLOAD");
			String BeginLoadFiles[] = InputDataDir.list(BeginLoadOnly);

			FilenameFilter EndLoadOnly = new OnlyExt("ENDLOAD");
			String EndLoadFiles[] = InputDataDir.list(EndLoadOnly);
			
			
			for(int l=0; l<BeginLoadFiles.length; l++){
				sybilweb.plant.controller.Magazine sm = new sybilweb.plant.controller.Magazine(BeginLoadFiles[l]);
				if(sm.getPrefix().equals((sortedFormatFiles[k].toString()).trim().substring(0,(sortedFormatFiles[k].toString()).trim().indexOf("."))))
					ReRunFlag = true;					
			}	

			for(int l=0; l<EndLoadFiles.length; l++){
				sybilweb.plant.controller.Magazine sm = new sybilweb.plant.controller.Magazine(EndLoadFiles[l]);
				if(sm.getPrefix().equals((sortedFormatFiles[k].toString()).trim().substring(0,(sortedFormatFiles[k].toString()).trim().indexOf("."))))
					ReRunFlag = true;					
			}	


			if(!ReRunFlag){
			//			
			
			//	this code is for limiting the number of threads
			


//			if(RunningThreads.length < Integer.valueOf(RunningThreadsLimit).intValue() ) {

			//			
//			LogWriter.writeLog(s[k].toString());
			sybilweb.plant.controller.BinderyLineSequenceMgr blsm = new  sybilweb.plant.controller.BinderyLineSequenceMgr(sortedFormatFiles[k].trim(), plant.trim().toUpperCase());			 

			if(blsm.customerGroups != null) {
		  	Thread processThread = new Thread (blsm);
	 		processThread.start();
			}

			//		
					
//			}
			
			//

			} else{
				String filename = PropertyBroker.getProperty("FormatterControlPath") + sortedFormatFiles[k].trim();
				File rf = new File(filename);
				rf.delete();
				if(rf.exists())
						LogWriter.writeLog("E",plant.trim().toUpperCase(),"", " Unable to Deleting the Formatter Flag File "+ filename +" due to rerun");	
				else
						LogWriter.writeLog("I", plant.trim().toUpperCase(),"", " Deleting the Formatter Flag File "+ filename +" due to rerun");
			}
			
				
			}
		}





		} catch(Exception e) {  e.printStackTrace(); }
		}


		Thread.sleep(Integer.parseInt(PropertyBroker.getProperty("Formatter_Sleep_0","30000")));					

	}
}
/**
 * Insert the method's description here.
 * Creation date: (8/14/01 9:19:33 AM)
 * @param args java.lang.String[]
 */
public static void main(String[] args) {

	String plantid = args[0];
	inipath = args[1];
	SybilFormatter sf = new SybilFormatter(args[0].trim());

	}
/**
 * Insert the method's description here.
 * Creation date: (9/6/01 9:39:42 AM)
 * @param filename java.lang.String
 */
public void renameFile(String name, String ext) {

			String filename = FormatCtlFiledir + "/" + name;
			File rf = new File(filename);
			String newfile = name.substring(0,name.length()-3);
			newfile = newfile.concat(ext);
			String newfilepath = FormatCtlFiledir + "/" + newfile;
			rf.delete();

			try {
					FileWriter f = new FileWriter(newfilepath);
				} catch(Exception ex) { ex.printStackTrace(); System.out.println("Could not able to create Formatter flag file"); }
	}
/**
 * Insert the method's description here.
 * Creation date: (4/18/2002 4:00:42 PM)
 */
public void run() {
	String sleepIntervalString = PropertyBroker.getProperty("PROCESS_CONTROL_SLEEP", "120000");
	long sleepInterval = Long.parseLong(sleepIntervalString);
	
	while (true) {
		try {
			Thread.sleep(sleepInterval);
		} 
		catch (InterruptedException ie) {
			LogWriter.writeLog(ie);
			//LogWriter.writeLog("I","","","SybilFormatter.run ... sleep interrupted");
			if (ProcessTracker.checkStop(processCode,processPlant)) {
				LogWriter.writeLog("I","","","SybilFormatter.run ... stop now");
				ProcessTracker.trackProcessStatus(processCode,processPlant,"stopped");
				System.exit(0);
			}
			else {
				//LogWriter.writeLog("I","","","SybilFormatter.run ... keep going");
			}
		}
		//LogWriter.writeLog("I","","","SybilFormatter.run ... sleep expired");
		if (ProcessTracker.checkStop(processCode,processPlant)) {
			LogWriter.writeLog("I","","","SybilFormatter.run ... stop now");
			ProcessTracker.trackProcessStatus(processCode,processPlant,"stopped");
			System.exit(0);
		}
		else {
			//LogWriter.writeLog("I","","","SybilFormatter.run ... keep going");
		}
			
	} // while (true)
}
/**
 * Insert the method's description here.
 * Creation date: (4/18/2002 4:11:17 PM)
 */
private static void savePid() {
	String pidDirProp = PropertyBroker.getProperty("PidFileDirectory", "false");
	String pidJobFileProp = PropertyBroker.getProperty("PidJobAndFileName", "false");
	String pidJobDescProp = PropertyBroker.getProperty("PidJobDesc", "false");
	if (pidDirProp.equals("false") || pidJobFileProp.equals("false") || pidJobDescProp.equals("false")) {
		LogWriter.writeLog("I","","","SybilFormatter.savePid: Pid properties missing. No Pid save will occur.");
	}
	else {
		String filename = pidDirProp + "Pid." + pidJobFileProp + ".txt";
		LogWriter.writeLog("I","","","SybilFormatter.savePid: Pid properties present. Pid save will occur to " + filename);
		sybil.common.util.Pid pid = new sybil.common.util.Pid();
		pid.loadPid();
		int pidnum = pid.getPid();
		
		String pidString = String.valueOf(pidnum);
		ProcessTracker.trackProcessStatus(processCode,processPlant,"started", pidString);
		
		String jobline = "  " + pidJobFileProp + " " + pidnum + " " + pidJobDescProp;
		try {
			FileOutputStream fos = new FileOutputStream(filename);
			OutputStreamWriter osw = new OutputStreamWriter(fos);
			BufferedWriter bw = new BufferedWriter(osw);
			bw.write(jobline, 0, jobline.length());
			bw.newLine();
			bw.close();
			osw.close();
			fos.close();
		}
		catch (Exception e) {
			LogWriter.writeLog("I","","","SybilFormatter.savePid Exception: "+ e);
		}
	}	
}
}
