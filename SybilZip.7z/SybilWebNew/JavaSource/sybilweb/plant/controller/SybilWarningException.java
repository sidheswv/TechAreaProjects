package sybilweb.plant.controller;

/**
 * Insert the type's description here.
 * Creation date: (2/22/01 10:48:03 AM)
 * @author: Srikanth Bapanapalli
 */
public class SybilWarningException extends Exception {
/**
 * SybilWarningException constructor comment.
 */
public SybilWarningException() {
	super();
}
/**
 * SybilWarningException constructor comment.
 * @param s java.lang.String
 */
public SybilWarningException(String s) {
	super(s);
}
}
