package sybilweb.plant.controller;

/**
 * Insert the type's description here.
 * Creation date: (2/23/01 9:04:05 AM)
 * @author: Srikanth Bapanapalli
 */

import java.util.*;
 
public class CustomerGroup  implements java.io.Serializable{

		public	int outputFormat;
	public	int outputDestination;
	private	Vector groupEntries = new Vector();
	
/**
 * CustomerGroup constructor comment.
 */
public CustomerGroup() {
	super();
}
/**
 * This method was created by a SmartGuide.
 * @param e sybil.plant.model.CustomerGroupEntry
 */
public void addCustomerGroupEntry (CustomerGroupEntry e ) {
	groupEntries.addElement(e);
	return;
}
/**
 * This method was created by a SmartGuide.
 * @return sybil.plant.model.CustomerGroupEntry
 * @param index int
 */
public sybilweb.plant.controller.CustomerGroupEntry getGroupEntry (int index ) {
	return ((sybilweb.plant.controller.CustomerGroupEntry)groupEntries.elementAt(index));
}
/**
 * This method was created by a SmartGuide.
 * @return int
 */
public int getNumberOfGroupEntries ( ) {
	return groupEntries.size();
}
/**
 * This method was created by a SmartGuide.
 * @param controllerFormat java.lang.String
 */
public void setControllerFormat(String controllerFormat, int controllerFormatKey ) {
	outputFormat = controllerFormatKey;
	int size = groupEntries.size();
	
	for (int i = 0; i < size; i++) {
		
		CustomerGroupEntry cge = getGroupEntry(i);
		cge.controllerFormat = controllerFormat;
		cge.controllerFormatKey = controllerFormatKey;
	}	
	return;
}
/**
 * This method was created by a SmartGuide.
 */
public void setGroupNumber (int g) {

	int size = 0;
	
	size = groupEntries.size();
	System.out.println(size);
	
	for (int i = 0; i < size; i++) {
		sybilweb.plant.controller.CustomerGroupEntry cge = getGroupEntry(i);
		cge.setGroupID(g);
		cge.setSequence(i);
	}	
	
	
	return;
}
/**
 * This method was created by a SmartGuide.
 * @return java.lang.String
 */
public String toString( ) {
	
	int size = groupEntries.size();
	
	StringBuffer buffer = new StringBuffer();
	
	for (int i = 0; i < size; i++) {
		
		buffer.append(getGroupEntry(i).toString());
		
	}	
	
	
	return buffer.toString();
}
}
