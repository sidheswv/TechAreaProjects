package sybilweb.plant.controller;

import java.util.Vector;


public class Message implements java.io.Serializable {

	private int m_numberOfTextLines;
	private int m_longestLineLength;
	private String messageFamily;
	private String messageNumber;

	public Vector m_TextLines = new Vector();
	public Message() {

	}
public void format(MessageParameter msgp) {

	int size = m_TextLines.size();
	TextLine tl = null;
	int newLineSize = 0;

// if justification in msgp file is LEFT the set to USE_DEFAULT
// if CENTER and DOUBLESTOKE then have number of spaces and
//  recenter.  This is currently not implemented.

	for (int i = 0; i < size; i++) {

		newLineSize = msgp.getLineLength(i);
		tl = (TextLine)m_TextLines.elementAt(i);
  		tl.setLength(newLineSize);
		tl.setJustification(StringFunctions.USE_DEFAULT);

		tl.justify();

	}
}
	public int getLongestLineLength() {
		return m_longestLineLength;

	}
/**
 * This method was created by a SmartGuide.
 * @return int
 */
public String getMessageFamily() {
	return messageFamily;
}
/**
 * This method was created by a SmartGuide.
 * @return int
 */
public String getMessageNumber() {
	return messageNumber;
}
	public int getNumberOfTextLines() {
		return m_numberOfTextLines;

	}
	public TextLine getTextLine(int i) {
		return (TextLine) m_TextLines.elementAt(i);

	}
	public Vector getTextLines() {
		return m_TextLines;

	}
public void setLongestLineLength( int i ) {
	m_longestLineLength = i;
}
public void setMessageFamily (String fam) {

	messageFamily = fam;

}
public void setMessageNumber(String num) {

	messageNumber = num;

}
public void setNumberOfTextLines(int i) {
	m_numberOfTextLines = i;
}
public void setTextLines(Vector msgLines) {
	m_TextLines = msgLines;
}
/**
 * This method was created by a SmartGuide.
 * @return java.lang.String
 */
public String toString() {

	StringBuffer buf = new StringBuffer(250);

	if (messageFamily != null && messageFamily.length() > 0) {			// Message Family
		buf.append(messageFamily);
	}
	else {
		buf.append(" ");
		}
	buf.append(sybilweb.plant.controller.IssueCustomer.TOSTRING_DELIMITER);

	if (messageNumber != null && messageNumber.length() > 0) {			// Message Number
		buf.append(messageNumber);
	}
	else {
		buf.append(" ");
		}
	buf.append(sybilweb.plant.controller.IssueCustomer.TOSTRING_DELIMITER);

	buf.append(m_numberOfTextLines);						// Number of text lines
	buf.append(sybilweb.plant.controller.IssueCustomer.TOSTRING_DELIMITER);

	for (int i = 0; i < m_numberOfTextLines; i++) {
		TextLine tl = (TextLine) m_TextLines.elementAt(i);
		buf.append(tl.toString());								// TextLine (see TextLine.toString())
		buf.append(sybilweb.plant.controller.IssueCustomer.TOSTRING_DELIMITER);
	}

	return buf.toString();
}
}
