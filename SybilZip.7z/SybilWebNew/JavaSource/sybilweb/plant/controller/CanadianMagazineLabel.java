package sybilweb.plant.controller;

import java.text.DateFormat;
import java.util.Date;


public class CanadianMagazineLabel extends MagazineLabel
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final String Class_Version_Number = "Sybil April 19 2010";

    public CanadianMagazineLabel()
    {
    }

    public void format() {
        
    	LabelLine8 = PropertyBroker.getProperty("LabelLine8");
        LL8Override = PropertyBroker.getProperty("LL8Override");
        nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
        RLL5value = "false";
        String LabelLine8 = PropertyBroker.getProperty("LabelLine8");
        
        if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(Plant_ID.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
        {
        	for(int i = 0; i < 8; i++) {
                m_TextLine[i] = new TextLine();
            }
        	
            if(Plant_ID.equals("CLK")) {
            	m_TextLine[0].setText(formatCanadianLine1());
                m_TextLine[1].setText(formatCanadianLine2());
                m_TextLine[2].setText(formatCanadianLine3());
                m_TextLine[3].setText(formatCanadianLine4());
                m_TextLine[4].setText(formatCanadianLine5());
                m_TextLine[5].setText(formatCanadianLine6());
                m_TextLine[6].setText(formatCanadianLine7());
                m_TextLine[7].setText(formatBlank());
            } else {
            	m_TextLine[0].setText(formatBarcodeLine());
                m_TextLine[1].setText(formatCanadianLine1());
                m_TextLine[2].setText(formatCanadianLine2());
                m_TextLine[3].setText(formatCanadianLine3());
                m_TextLine[4].setText(formatCanadianLine4());
                m_TextLine[5].setText(formatCanadianLine5());                
                m_TextLine[6].setText(formatCanadianLine6());
                m_TextLine[7].setText(formatCanadianLine7());
            }
        }
    }

    
    private String formatBlank() {
        StringBuffer labelLine = new StringBuffer();
        
        labelLine.append(StringFunctions.fixSize(" ", 38, ' ', StringFunctions.LEFT));
        
        return labelLine.toString();
    }

    private String formatCanadianLine1() {
        
    	StringBuffer labelLine = new StringBuffer();
        if(canadianOEL.equals("") || canadianOEL == null) {
        	labelLine.append(StringFunctions.fixSize(" ", 38, ' ', StringFunctions.LEFT));
        } else {
            labelLine.append(StringFunctions.fixSize(canadianOEL, 38, ' ', StringFunctions.LEFT));
        }
        
        return labelLine.toString();
    }
		
	private String formatCanadianLine2(){
		
		StringBuffer labelLine = new StringBuffer();
        String schoolBundling = PropertyBroker.getProperty("schoolBundling", "false");
        
        if(line2Type.equals("k")){
        	
            if(acsKeyline.equals(""))
            	labelLine.append(StringFunctions.fixSize(" ", 19, ' ', StringFunctions.LEFT));
            else if(acsKeyline.length() != 19)
                labelLine.append(StringFunctions.fixSize(acsKeyline, 19, ' ', StringFunctions.LEFT));
            else 
                labelLine.append(acsKeyline);
            
            labelLine.append(StringFunctions.fixSize(" ", 1, ' ', StringFunctions.LEFT));
            
            if(magCode.equals(""))
            	labelLine.append(StringFunctions.fixSize(" ", 2, ' ', StringFunctions.LEFT));
            else 
                labelLine.append(magCode);
            
            
            if(continentID.equals(""))
            	labelLine.append(StringFunctions.fixSize(" ", 1, ' ', StringFunctions.LEFT));
            else 
                labelLine.append(continentID);
            
            
            if(editionCode.equals("")) 
            	labelLine.append(StringFunctions.fixSize(" ", 9, ' ', StringFunctions.LEFT));
            else 
                labelLine.append(StringFunctions.fixSize(editionCode, 9, ' ', StringFunctions.RIGHT));
            
            labelLine.append(StringFunctions.fixSize(" ", 1, ' ', StringFunctions.LEFT));
            
            if(alphaExpireDate.equals(""))
            	labelLine.append(StringFunctions.fixSize(" ", 5, ' ', StringFunctions.LEFT));
            else if(alphaExpireDate.length() != 5)
                labelLine.append(StringFunctions.fixSize(alphaExpireDate, 5, ' ', StringFunctions.LEFT));
            else
                labelLine.append(alphaExpireDate);
            
            
            if(magCode.equalsIgnoreCase("TK")){
                if(schoolBundling.equalsIgnoreCase("true")){
                    if(endSchoolFlag){
                        labelLine.append(TK_Bundle);
                        labelLine.append(TK_Bundle);
                    } else{
                        labelLine.append("  ");
                    }
                } else{
                    labelLine.append("  ");
                }
            }
            
            return labelLine.toString();
        } else {
        	
        	if(acsKeyline.equals(""))
        		labelLine.append(StringFunctions.fixSize(" ", 15, ' ', StringFunctions.LEFT));
        	else if(acsKeyline.length() != 15)
        		labelLine.append(StringFunctions.fixSize(acsKeyline, 15, ' ', StringFunctions.LEFT));
        	else 
        		labelLine.append(acsKeyline);
        	
        
        if(labelMagCode.equals("")) 
        	labelLine.append(StringFunctions.fixSize(" ", 2, ' ', StringFunctions.LEFT));
        else
            labelLine.append(labelMagCode);
        
        labelLine.append(StringFunctions.fixSize(" ", 1, ' ', StringFunctions.LEFT));
        
        if(rideAlongIND.equals(""))
        	labelLine.append(StringFunctions.fixSize(" ", 1, ' ', StringFunctions.LEFT));
        else
            labelLine.append(rideAlongIND);
        
        
        if(editionCode.equals(""))
        	labelLine.append(StringFunctions.fixSize(" ", 9, ' ', StringFunctions.LEFT));
        else
            labelLine.append(StringFunctions.fixSize(editionCode, 9, ' ', StringFunctions.RIGHT));
        
        labelLine.append(StringFunctions.fixSize(" ", 1, ' ', StringFunctions.LEFT));
        
        if(GeoComboName.equals(""))
        	labelLine.append(StringFunctions.fixSize(" ", 2, ' ', StringFunctions.LEFT));
        else
            labelLine.append(StringFunctions.fixSize(GeoComboName, 2, ' ', StringFunctions.LEFT));
        
        labelLine.append(StringFunctions.fixSize(" ", 1, ' ', StringFunctions.LEFT));
        
        if(alphaExpireDate.equals(""))
        	labelLine.append(StringFunctions.fixSize(" ", 5, ' ', StringFunctions.LEFT));
        else if(alphaExpireDate.length() != 5)
            labelLine.append(StringFunctions.fixSize(alphaExpireDate, 5, ' ', StringFunctions.LEFT));
        else
            labelLine.append(alphaExpireDate);
        
        labelLine.append(StringFunctions.fixSize(" ", 1, ' ', StringFunctions.LEFT));
        
        	if(magCode.equalsIgnoreCase("TK")){
        		if(schoolBundling.equalsIgnoreCase("true")){
        			if(endSchoolFlag){
        				labelLine.append(TK_Bundle);
        				labelLine.append(TK_Bundle);
        			} else{
        				labelLine.append("  ");
        			}
        		} else{
        			labelLine.append("  ");
        		}
        	}
        	
            return labelLine.toString();
        } 
    }
    
	private String formatCanadianLine3() {
		
		StringBuffer labelLine =  new StringBuffer();
		String schoolBundling = (String)PropertyBroker.getProperty("schoolBundling","false");

//	 packageNumber 7 characters
		if (packageNumber.equals("")) 
			labelLine.append(StringFunctions.fixSize(" ", 7, ' ', StringFunctions.LEFT));
		else {
			String buf = new String(StringFunctions.fixSize(packageNumber,6,'0',StringFunctions.RIGHT));
			String pkgNumberOne = buf.substring(0,2);
			String pkgNumberTwo = buf.substring(2,6);
			if (pkgNumberOne.equals("00")) {
				labelLine.append(StringFunctions.fixSize(packageNumber,7,'0',StringFunctions.RIGHT));
			}else {
				labelLine.append(pkgNumberOne);
				labelLine.append("/");
				labelLine.append(pkgNumberTwo);
			}
		}
		labelLine.append(StringFunctions.fixSize(" ", 1, ' ', StringFunctions.LEFT));
		
//	 CANADIAN SPECIFIC EndorsementLine Info
		/*if (endorsementLine.equals("PROFILE COPY")) {
			labelLine.append(endorsementLine);
			labelLine.append("   ");
		}*/
		if (endorsementLine.equals("")){
			labelLine.append(StringFunctions.fixSize(" ", 15, ' ', StringFunctions.LEFT));
		}else{
			labelLine.append("   ");
			labelLine.append(endorsementLine);
			labelLine.append("  ");
		}
			

//	 canadianCarrierLiteral 2 characters
		if (canadianCarrierLiteral.equals("")) 
			labelLine.append("  ");
		else
			labelLine.append(canadianCarrierLiteral);

		labelLine.append(" ");

//	 canadianNonDirect 2 characters
	  	if (canadianNonDirect.equals("")) 
			labelLine.append("  ");
		else if (canadianNonDirect.length() != 2) {
			labelLine.append(" ");
			labelLine.append(canadianNonDirect);
		}else
			labelLine.append(canadianNonDirect);

		labelLine.append(" ");


//	 carrierRouteNumber 4 characters
		if (carrierRouteNumber.equals(""))
			labelLine.append("    ");
		else if (carrierRouteNumber.length() != 4)
			labelLine.append(StringFunctions.fixSize(carrierRouteNumber,4,' ',StringFunctions.RIGHT));
		else
			labelLine.append(carrierRouteNumber);

		labelLine.append(" ");

//	 canadianMonthCode 3 characters i.e. (F)
		if (canadianMonthCode.equals("")) 
			labelLine.append(StringFunctions.fixSize(" ", 3, ' ', StringFunctions.LEFT));
		else{
			labelLine.append("(");
			labelLine.append(canadianMonthCode);
			labelLine.append(")");
		}		
		
		labelLine.append(StringFunctions.fixSize(" ", 1, ' ', StringFunctions.LEFT));


		if (magCode.equalsIgnoreCase("TK")){
			if (schoolBundling.equalsIgnoreCase("true")) {
				if (endSchoolFlag) {
					labelLine.append(TK_Bundle);
					labelLine.append(TK_Bundle);

				}else {
					labelLine.append("  ");
				}
			}else {
				labelLine.append("  ");
			}
		}
		
		return labelLine.toString();
	}
	
	
	private String formatCanadianLine4 () {
		
		StringBuffer labelLine =  new StringBuffer();
		String schoolBundling = (String)PropertyBroker.getProperty("schoolBundling","false");
		
				
		if(addressLine2.equals("") || addressLine2 == null ){
			if (LabelDropIn == null)
				labelLine.append(StringFunctions.fixSize(" ", 30, ' ', StringFunctions.LEFT));
			else
				labelLine.append(StringFunctions.fixSize(LabelDropIn,30,' ',StringFunctions.LEFT));
		} else {
			if(customerName.equals("") || customerName == null )
				labelLine.append(StringFunctions.fixSize(" ", 30, ' ', StringFunctions.LEFT));
			else
				labelLine.append(StringFunctions.fixSize(customerName, 30, ' ', StringFunctions.LEFT));
		}
		
		labelLine.append(StringFunctions.fixSize(" ", 3, ' ', StringFunctions.LEFT));
		        
        if(makeupCode.equals(""))
        	labelLine.append(StringFunctions.fixSize(" ", 4, ' ', StringFunctions.LEFT));
        else 
            labelLine.append(StringFunctions.fixSize(makeupCode, 4, '0', StringFunctions.RIGHT));
				
		if(endOfPackageIndicator)
	    	labelLine.append("#");
	    else
	    	labelLine.append(" ");
		
		if (magCode.equalsIgnoreCase("TK")){
			if (schoolBundling.equalsIgnoreCase("true")) {
				if (endSchoolFlag) {
					labelLine.append(TK_Bundle);
					labelLine.append(TK_Bundle);
				} else {
					labelLine.append("  ");
				}
			} else {
				labelLine.append("  ");
			}
		}
		
		return labelLine.toString();
	}
    
	
	private String formatCanadianLine5() {
		
		StringBuffer labelLine =  new StringBuffer();
		
		if(addressLine2.equals("") || addressLine2 == null){
			if(customerName.equals("") || customerName == null )
				labelLine.append(StringFunctions.fixSize(" ", 30, ' ', StringFunctions.LEFT));
		    else 
		        labelLine.append(StringFunctions.fixSize(customerName, 30, ' ', StringFunctions.LEFT));
			
			labelLine.append(StringFunctions.fixSize(" ",1,' ',StringFunctions.LEFT));
		} else {
			if (addressLine2.length() != 30)
				labelLine.append(StringFunctions.fixSize(addressLine2,30,' ',StringFunctions.LEFT));
			else
				labelLine.append(addressLine2); 
			
			labelLine.append(StringFunctions.fixSize(" ",1,' ',StringFunctions.LEFT));
		}
		
		labelLine.append(StringFunctions.fixSize(String.valueOf(labelNumber),6,'0',StringFunctions.RIGHT));
		
		if (endofPalletSackIndicator)
			labelLine.append("#");
		else
			labelLine.append(" ");
		
		
		return labelLine.toString();
	}
	
	private String formatCanadianLine6(){
		
        StringBuffer labelLine = new StringBuffer();
        String schoolBundling = PropertyBroker.getProperty("schoolBundling", "false");
        
        if(addressLine1.equals(""))
            labelLine.append("                              ");
        else if(addressLine1.length() != 30)
            labelLine.append(StringFunctions.fixSize(addressLine1, 30, ' ', StringFunctions.LEFT));
        else
            labelLine.append(addressLine1);
        
        labelLine.append(StringFunctions.fixSize(" ", 1, ' ', StringFunctions.LEFT));
        
        if(palletSackIndicator.equals(""))
        	labelLine.append(StringFunctions.fixSize(" ", 1, ' ', StringFunctions.LEFT));
        else
            labelLine.append(palletSackIndicator.charAt(0));
        
        if (palletSackNumber.equals("-1")) 
        	labelLine.append(StringFunctions.fixSize(" ", 5, ' ', StringFunctions.LEFT));
    	else 
    		labelLine.append(StringFunctions.fixSize(palletSackNumber,5,'0',StringFunctions.RIGHT));
        
        labelLine.append(StringFunctions.fixSize(" ", 1, ' ', StringFunctions.LEFT));
        
        if(magCode.equalsIgnoreCase("TK")){
            if(schoolBundling.equalsIgnoreCase("true")){
                if(endSchoolFlag){
                    labelLine.append(TK_Bundle);
                    labelLine.append(TK_Bundle);
                } else{
                    labelLine.append("  ");
                }
            } else{
                labelLine.append("  ");
            }
        }
        
        return labelLine.toString();
    }
        

    private String formatCanadianLine7() {
        
    	StringBuffer labelLine = new StringBuffer();
        String City = city.equals("") ? "               " : city;
        String State = state.equals("") ? "  " : state;
        String traffic = StringFunctions.fixSize(canadianZipCode, 6, ' ', StringFunctions.LEFT);
        String cityStateZip = City + " " + State + "  " + traffic.substring(0,3) + " " + traffic.substring(3,6);
        
        labelLine.append(StringFunctions.fixSize(cityStateZip, 38, ' ', StringFunctions.LEFT));
        
        if(magCode.equalsIgnoreCase("TK")) {
            labelLine.append("  ");
        }
        
        return labelLine.toString();
    }

    public void setLengthOfRunBookFields(String name, Address addr, String rollID) {
        
    	String LORBedition = editionCode;
        String pallet = palletSackNumber;
        clear();
        DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM);
        makeupCode = rollID;
        endorsementLine = "PROFILE COPY";
        palletSackNumber = pallet;
        acsKeyline = dateFormat.format(new Date());
        editionCode = LORBedition;
        customerName = name;
        addressLine1 = addr.getLine1();
        addressLine2 = rollID;
        city = addr.getCity();
        state = addr.getState();
        if(addr.getZipCode().length() < 6) {
            canadianZipCode = StringFunctions.fixSize(addr.getZipCode(), 6, ' ', StringFunctions.LEFT);
        } else {
            canadianZipCode = addr.getZipCode();
        }
    }

    public void setPostalBookLabelFields (String edition, int postalbooknumber, int copycount, int numberOfCopies, String ZipCode, String palletSackNumber) {
		return;
	}
	public void setStorageBookLabelFields (String edition, int copycount, int numberOfCopies, String ZipCode, String palletSackNumber) {
		return;
	}
}
