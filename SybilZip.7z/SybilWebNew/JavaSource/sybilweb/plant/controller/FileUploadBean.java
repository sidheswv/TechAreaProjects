package sybilweb.plant.controller;

import java.io.*;
import java.util.*;
import javax.servlet.http.*;
/**
 * Insert the type's description here.
 * Creation date: (7/20/01 2:17:58 PM)
 * @author: Srikanth Bapanapalli
 */
public class FileUploadBean {
	  private String filename;
	  public boolean emptyfile = true;
	  public boolean wrongformat = false;
public void doUpload(HttpServletRequest request,String Plant) throws IOException {


	javax.servlet.ServletInputStream in = request.getInputStream();
	InputStreamReader newin = new InputStreamReader(in, "ASCII");

	BufferedReader bis = new BufferedReader(newin);

	String line = null;
	PrintWriter pw = null;

	line = bis.readLine();
	String endFile = line;
	line = bis.readLine();

	  if (line.startsWith("Content-Disposition: form-data; name=\"")) {
			int pos = 0;
		 if ((pos = line.indexOf("filename=\"")) != -1) {

			setFilename(line);
		 }
		  }


	
	String inipath = sybilweb.plant.controller.PropertyBroker.getProperty("SybiliniPath");
	inipath = inipath.concat("SybilPlant");
	inipath = inipath.concat(Plant.trim().toUpperCase());
	inipath = inipath.concat(".ini");
	try {
	sybilweb.plant.controller.PropertyBroker.load(inipath);
	} catch(Exception e){ sybilweb.plant.controller.LogWriter.writeLog("E", Plant.trim(), "" , " could not load "+inipath+"file in FileUploadBean Class");
		sybilweb.plant.controller.LogWriter.writeLog(e);
	 }


	String path = PropertyBroker.getProperty("DriverCodeFilePath");
	path = path.concat(filename);

	sybilweb.plant.controller.LogWriter.writeLog("I", Plant.trim(), ""," Uploading "+ path);	

 	pw = new PrintWriter(new BufferedWriter(new FileWriter(path)));
	File DRCDErrorFile = new File(path.concat(".bad"));
	File DRCDProcessedFile = new File(path.concat(".processed"));

	if(DRCDErrorFile.exists()){
		DRCDErrorFile.delete();
		sybilweb.plant.controller.LogWriter.writeLog("I", Plant.trim(), ""," Deleting "+ DRCDErrorFile.getAbsolutePath());	
	}	

	if(DRCDProcessedFile.exists()){
		DRCDProcessedFile.delete();
		sybilweb.plant.controller.LogWriter.writeLog("I", Plant.trim(), ""," Deleting "+ DRCDProcessedFile.getAbsolutePath());	
	} 	

 	bis.readLine();
 	String newLine = bis.readLine();		 	

	while ((line = bis.readLine()) != null)  {	

			if(line.equals(newLine)){
				sybilweb.plant.controller.LogWriter.writeLog("I", Plant.trim(), ""," drivercode newline");
			 break;
			} 
			if(line.equals(endFile)){
				sybilweb.plant.controller.LogWriter.writeLog("I", Plant.trim(), ""," drivercode endfile");
			 break;
			} 

			StringTokenizer st = new StringTokenizer(line, String.valueOf(","));
			if (st.countTokens() != 2) {
				wrongformat = true;
				emptyfile = false;
				pw.println(line);
				sybilweb.plant.controller.LogWriter.writeLog("I", Plant.trim(), ""," drivercode st.countTokens() != 2 ");				
				break;
			}	
			 	
			pw.println(line);
			emptyfile = false;
			sybilweb.plant.controller.LogWriter.writeLog("I", Plant.trim(), ""," Uploaded drivercode "+ emptyfile);
			
		}

	if(emptyfile){
		File f = new File(path);
		sybilweb.plant.controller.LogWriter.writeLog("I", Plant.trim(), ""," Uploaded empty drivercode file.  renaming "+ path+" to "+ path.concat(".bad"));			
		f.renameTo(new File(path.concat(".bad")));
		f = null;
	}

	if(wrongformat){
		File f = new File(path);
		sybilweb.plant.controller.LogWriter.writeLog("I", Plant.trim(), ""," Uploaded bad drivercode file.  renaming "+ path+" to "+ path.concat(".bad"));			
		f.renameTo(new File(path.concat(".bad")));
		f = null;
	}

	pw.close();


	
}
public boolean getemptystatus() throws IOException {

	return emptyfile;

}
public boolean getwrongformatstatus() throws IOException {

	return wrongformat;

}
/**
 * Insert the method's description here.
 * Creation date: (8/27/01 12:18:43 PM)
 * Modified Date: (4/26/2010 2:25 PM)
 * @param s java.lang.String
 */
	private void setFilename(String s) {
		
		if (s==null)
			return;
		
		int pos = s.indexOf("filename=\"");
		if (pos != -1) {
			pos = s.lastIndexOf("\\");
			if (pos != -1) {
				filename = s.substring(pos + 1,s.length()-1);
			} else {
				pos = s.lastIndexOf("=\"") + 1;
				if (pos != -1)
					filename = s.substring(pos + 1,s.length()-1);
				else
					filename = s;
			}
		}
	}
}
