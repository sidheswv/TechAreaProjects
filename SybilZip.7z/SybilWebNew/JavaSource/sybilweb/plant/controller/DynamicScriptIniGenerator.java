package sybilweb.plant.controller;

/**
 * Insert the type's description here.
 * Creation date: (5/11/01 10:47:41 AM)
 * @author: Srikanth Bapanapalli
 */
// {args0} {outputfile} {plant} {inputfile}
import java.util.*;
import java.io.*;
import java.sql.*;
import javax.sql.*;
import com.ibm.ejs.dbm.jdbcext.*;
import javax.naming.*;
import sybilweb.plant.persistence.*;


public class DynamicScriptIniGenerator{

private static void initializeLogFile() {
	String prop = null;
	boolean writeLog = false;
	long maxFileSize = 0;
	String fPath;
	String logFilename;
	
	// Get "LogMessages" switch.  If not 'true', don't go any further.
	if ((prop = PropertyBroker.getProperty("DynamicScriptLogMessagesToFile")) != null) {
		prop.toLowerCase();
		if (prop.equals("true")) {
			writeLog = true;
		}	
	}
	
	// Get "LogFileDirectory"
	if ((prop = PropertyBroker.getProperty("DynamicScriptLogFileDirectory")) != null) {
		fPath = prop;
	} else {
		System.out.println("Error: Log File Path not specified.  Assuming none");
		fPath = null;
	}


	// Get "LogFileName"
	if ((prop = PropertyBroker.getProperty("DynamicScriptLogFileName")) != null) {
		logFilename = prop;
	} else {
		System.out.println("Error: Log Filename not specified.  Assuming none");
		logFilename = null;
	}
		
	
	// Get "LogFilemaxSize"
	if ((prop = PropertyBroker.getProperty("DynamicScriptLogFileMaxSize")) != null) {
		maxFileSize = Integer.parseInt(prop);
	} else {
		maxFileSize = 100000;		// Default to 100K
	}

	LogWriter.initialize (writeLog, maxFileSize, fPath, logFilename);
	
	return;
}
 /* Starts the application.
 * @param args an array of command-line arguments
 */
public static void main(java.lang.String[] args) {

	try{
		PropertyBroker.load(args[0]);
		LogWriter.writeLog("loaded args[0] "+args[0]);
		initializeLogFile();
		PropertyBroker.load(PropertyBroker.getProperty("PARAMFILE"));
		LogWriter.writeLog("loaded "+PropertyBroker.getProperty("PARAMFILE"));

		FileInputStream skelnamesfile = new FileInputStream (PropertyBroker.getProperty("SKEL_LIST"));
		BufferedReader skelfilelistreader =new BufferedReader(new InputStreamReader(skelnamesfile));

		Vector skelfiles = new Vector();
		String tempskelfile = null;
		int skeletonlist = 0;
		while((tempskelfile = skelfilelistreader.readLine()) != null){
			skeletonlist++;
			skelfiles.addElement(tempskelfile);
			LogWriter.writeLog("skeleton file "+skeletonlist+ "  " +tempskelfile);
		}


		for(int skelfilecounter=0; skelfilecounter<skelfiles.size(); skelfilecounter++){

		String filename = (String)skelfiles.elementAt(skelfilecounter);
		String actualfile = filename.substring(0,filename.lastIndexOf("."));
		String fileext;
		if(actualfile.indexOf(".") >=0)
			fileext = actualfile.substring(actualfile.indexOf("."),actualfile.length());
		else
			fileext = "";	
		boolean multiplant = false;
		String filenameextrachar = "";

		if(filename.indexOf("PPP") != -1) {
			filenameextrachar = filename.substring(filename.indexOf("PPP")+3,filename.indexOf("."));
			filename = filename.substring(0,filename.indexOf("PPP"));
			multiplant = true;
		}

		String plantscodes = PropertyBroker.getProperty("PLANTS");

		String sybilWebPlants = (String)PropertyBroker.getProperty("PLANTS");
		StringTokenizer sybilWebPlantCodes = new StringTokenizer(sybilWebPlants, ",");
		String[]  plants = new String[sybilWebPlantCodes.countTokens()];
		int counter = 0;

			while (sybilWebPlantCodes.hasMoreTokens()) {
			  	String plantid = (String)sybilWebPlantCodes.nextToken();
			  	plants[counter++] = plantid.trim();
			}

		if(multiplant){
		for(int i=0; i<plants.length; i++){
		
		String filename1 = filename.concat(plants[i]).concat(filenameextrachar).concat(fileext);
		File OutputDestinationFile = new File(filename1);
	

		String OutputPath = null;
		if(OutputDestinationFile.getName().endsWith("ini"))
			OutputPath = (String)PropertyBroker.getProperty("INIOUTPUTPATH");
		else
			OutputPath = (String)PropertyBroker.getProperty("SCRIPTOUTPUTPATH");
			
		
		File f = new File(OutputPath.concat(OutputDestinationFile.getName()));

		File ErrorDestinationFile = new File(OutputPath.concat(OutputDestinationFile.getName()).concat(".ERROR"));

		if(ErrorDestinationFile.exists()){
			ErrorDestinationFile.delete();
			LogWriter.writeLog("Deleting "+ ErrorDestinationFile.getName() );
		}


		
		FileOutputStream messageFOS = new FileOutputStream (f); // Open / append
		PrintWriter messagePW = new PrintWriter (new OutputStreamWriter(messageFOS), true);	// Open with autoflush enabled

		FileInputStream messageFIS = new FileInputStream ((String)skelfiles.elementAt(skelfilecounter));
		BufferedReader br=new BufferedReader(new InputStreamReader(messageFIS));

		boolean error = false;

		String s01 = null;
		while((s01=br.readLine()) != null) {
			FileInputStream ParamFileRead = new FileInputStream (PropertyBroker.getProperty("PARAMFILE"));
			BufferedReader paramFile=new BufferedReader(new InputStreamReader(ParamFileRead));
		  while(s01.indexOf("{") != -1){
				String temp = s01.substring(s01.indexOf("{")+1,s01.indexOf("}"));
				int endloc = s01.indexOf("}");
				if(!temp.trim().equals("PPP")){
					s01 = s01.substring(0,s01.indexOf("{")).concat(PropertyBroker.getProperty(temp,"ERROR")).concat(s01.substring(endloc+1,s01.length()));
				}
				else{
					s01 = s01.substring(0,s01.indexOf("{")).concat(plants[i]).concat(s01.substring(endloc+1,s01.length()));
				}	
		  }

		  while(s01.trim().indexOf("[") != -1){
				String s02 = null;
				String listdata = "";
				String predata = "";
				String postdata = "";
				boolean defined = false;				

				while((s02 = paramFile.readLine()) != null){
					if(s02.indexOf("[") != -1){
						String datatemp = s01.substring(s01.indexOf("["),s01.indexOf("]")+1).trim();
						predata = s01.substring(0,s01.indexOf("[")).trim();
						postdata = s01.substring(s01.indexOf("]")+1,s01.length()).trim();
						if(datatemp.trim().equals(s02.trim())) {
							defined = true;
							paramFile.readLine();
							String templistdata = null;
							while(!(templistdata = paramFile.readLine()).trim().equals("//end")){
								listdata = listdata.concat(templistdata);
								listdata = listdata.concat("\n");
							}
							break;
						}
					}
				}

			if(!defined){
				listdata = "ERROR";
			}

				s01 = predata + listdata + postdata;
			}
		if(s01.indexOf("ERROR") != -1){
			error = true;
//			LogWriter.writeLog(s01+(String)skelfiles.elementAt(skelfilecounter));
			LogWriter.writeLog(s01+ "  in "+f.getName());			
		}
		messagePW.println( s01);
		}

		if(error == true)
			f.renameTo(new File(f.getAbsolutePath().concat(".ERROR")));

//		File outPath = new File(PropertyBroker.getProperty("OUTPUTPATH").concat(f.getName()));
		
		}

		}
		else{
		String filename1 = filename.substring(0,filename.lastIndexOf("."));
		File OutputDestinationFile = new File(filename1);
		String OutputPath = null;
		if(OutputDestinationFile.getName().endsWith("ini"))
			OutputPath = (String)PropertyBroker.getProperty("INIOUTPUTPATH");
		else
			OutputPath = (String)PropertyBroker.getProperty("SCRIPTOUTPUTPATH");
		
		File f = new File(OutputPath.concat(OutputDestinationFile.getName()));
		FileOutputStream messageFOS = new FileOutputStream (f); // Open / append

		File ErrorDestinationFile = new File(OutputPath.concat(OutputDestinationFile.getName()).concat(".ERROR"));

		if(ErrorDestinationFile.exists()){
			ErrorDestinationFile.delete();
			LogWriter.writeLog("Deleting "+ ErrorDestinationFile.getName() );
		}


		PrintWriter messagePW = new PrintWriter (new OutputStreamWriter(messageFOS), true);	// Open with autoflush enabled	

		FileInputStream messageFIS = new FileInputStream ((String)skelfiles.elementAt(skelfilecounter));
		BufferedReader br=new BufferedReader(new InputStreamReader(messageFIS));


		boolean error = false;

		String s01 = null;
		while((s01=br.readLine()) != null) {
			FileInputStream ParamFileRead = new FileInputStream (PropertyBroker.getProperty("PARAMFILE"));
			BufferedReader paramFile=new BufferedReader(new InputStreamReader(ParamFileRead));

		  while(s01.indexOf("{") != -1){
				String temp = s01.substring(s01.indexOf("{")+1,s01.indexOf("}"));
				int endloc = s01.indexOf("}");
				if(!temp.trim().equals("PPP"))
					s01 = s01.substring(0,s01.indexOf("{")).concat(PropertyBroker.getProperty(temp,"ERROR")).concat(s01.substring(endloc+1,s01.length()));
				else
					s01 = s01.substring(0,s01.indexOf("{")).concat(PropertyBroker.getProperty(temp,"ERROR")).concat(s01.substring(endloc+1,s01.length()));
			}

		  while(s01.indexOf("[") != -1){
		  		LogWriter.writeLog("s01 "+s01);
				String s02 = null;
				String listdata = "";
				String predata = "";
				String postdata = "";
				boolean defined = false;
				
				while((s02 = paramFile.readLine()) != null){
					if(s02.indexOf("[") != -1){
						String datatemp = s01.substring(s01.indexOf("["),s01.indexOf("]")+1).trim();
						predata = s01.substring(0,s01.indexOf("[")).trim();
						postdata = s01.substring(s01.indexOf("]")+1,s01.length()).trim();
						LogWriter.writeLog("datatemp "+datatemp);
						LogWriter.writeLog("s02 "+s02);
						if(datatemp.trim().equals(s02.trim())) {
							defined = true;
							paramFile.readLine();
							String templistdata = null;
							while(!(templistdata = paramFile.readLine()).trim().equals("//end")){
								listdata = listdata.concat(templistdata);
								listdata = listdata.concat("\n");
							}
							break;
						}
					}
				}

				if(!defined){
					listdata = "ERROR";	
				}
				
				s01 = predata + listdata + postdata;
			}
		if(s01 == null){
			error = true;
			System.out.println("Error"+s01+f);
			
			if(f.exists())
				f.delete();
		}

		if(s01.indexOf("ERROR") != -1){
			error = true;
			LogWriter.writeLog(s01+ "  in "+f.getName());			
		}
		
		messagePW.println( s01);
		}

		if(error == true){
			f.renameTo(new File(f.getAbsolutePath().concat(".ERROR")));
		}
	}


		} 


	}catch(Exception ex) { 
		ex.printStackTrace(); 
		}

}
}
