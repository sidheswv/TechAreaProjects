package sybilweb.plant.controller;

import java.util.*;
import java.io.*;
import java.util.zip.*;
import sybilweb.plant.persistence.*;


/**
 * Insert the type's description here.
 * Creation date: (4/26/01 1:23:45 PM)
 * @author: Srikanth Bapanapalli
 * VERSION-- W4.3_Jay_SIGNAME_POBOOK
 */
public class BinderyLineSequenceMgr implements Runnable {

/// VERSION OF CLASS IN PRODUCTION ////
	public static final String Class_Version_Number = "PR_6.1_REL9.4";
	
	public sybilweb.plant.controller.Magazine mag = null;
	public String inputFileName;

	public PersistentRoll persistenceRoll =null;
	public LabelPositionFileParser lpp = null;

	public String outputFormat = null;

	PersistenceIssueCustomer pic = null;
	PersistenceIssueCustomer keylineCapture = null;

	private Object lock = new Object();
	private Object processData = new Object();
	public Vector customerGroups = null;

	private boolean OMSCustomers = false;
	public static final String OMS_CUSTOMER = "OMS2";
	DriverCodeAssignmentMgr driverCodeAssignmentMgr = null;
	private boolean useDriverCodeAssignment = false;

	private InsertExtraBooksHandler insertExtraBooksHandler = null;

	Hashtable messageParameters = null;
	Vector msgParms = null;
	private Vector loadedLabelPos = null;
	private MessageParameterFileMgr messageParameterFileMgr = null;

	private int LabelPosition;
	
	private int nextLabelNumber = 1;

	public String prop = null;

	public String outputFileExtension = null;
	public String outputFormatFilename = null;
	public String keylineOutputName = null;


	String currentProcessRoll = null;


	private ZipFile zf = null;
	private InputStream zis = null;
	private BufferedInputStream bis = null;
	private DataInputStream dis = null;
	private InputStreamReader isr = null;
	private BufferedReader bfr = null;

	private String NYBranchOfficeDriverCode = null;

	public String OutputFile = null;

	// These two variables are for handling ReRun
	// for passing as parameters to saveRoll and LoadSelectedOutputFileGroups
	int GroupNumber = -1;
	String ActualFileName = null;

	boolean skipExtraLabeltokens = true;
	boolean Remove_LOR_Cust = false;
	boolean LOR_Cust_File_Entry = false;
	boolean Remove_LOR_Cust_Mag = false;

	public BinderyLineSequenceMgr(String FormattedFile, String Plantid) {

	sybilweb.plant.persistence.PersistentRoll pr = new sybilweb.plant.persistence.PersistentRoll();
	// This change is for passing the parameter FILENAME to PersistenceRoll
	// to load the Rolls of the GroupFile, because the FormattedFile passed is
	// of type Mag_NAME.GROUP_NUM.FILENAME.
	// for ex:	SI1908uspsstripcust01.2.SUS81168.000 is stripped to SUS81168.000 
	// this change is for handling ReRun ActualFileName SUS81168
		
	String FormatFile = FormattedFile.substring(FormattedFile.indexOf(".")+1,FormattedFile.length());
	String FormatFile1 = FormatFile.substring(FormatFile.indexOf(".")+1,FormatFile.length());
	GroupNumber = Integer.valueOf(FormatFile.substring(0,FormatFile.indexOf("."))).intValue();
		
	String filename = FormatFile1.substring(0,FormatFile1.length()-4).trim();
	ActualFileName = filename;
	
	Vector Group = null;
		try {
		
	Group = pr.loadSelectedOutputFileGroups(FormattedFile.substring(0,FormattedFile.indexOf(".")), GroupNumber, filename.trim(),Plantid);
		} catch(Exception e ) { e.printStackTrace(); }

	if(Group.size() == 0 ){
		System.out.println("Error in Group"+ filename);
		return;
	}	
	
//		System.out.println("in Group"+ filename);
	String FormatCtlFiledir = PropertyBroker.getProperty("FormatterControlPath");

	String oldFilename = FormatCtlFiledir + "/" + FormattedFile;
	File rf = new File(oldFilename);
	String newfile = FormattedFile.substring(0,FormattedFile.length()-3);
	newfile = newfile.concat("001");
	String newfilepath = FormatCtlFiledir + "/" + newfile;
	rf.delete();

	try {
			FileWriter f = new FileWriter(newfilepath);
		} catch(Exception ex) { LogWriter.writeLog(ex); LogWriter.writeLog("E", "", "", "Could not able to create Formatter flag file"); }


	sybilweb.plant.controller.CustomerGroup cg = (sybilweb.plant.controller.CustomerGroup)(Group.elementAt(0));
	sybilweb.plant.controller.CustomerGroupEntry cge = (sybilweb.plant.controller.CustomerGroupEntry)(cg.getGroupEntry(0));
	String	magazine = cge.magazine;

	String magazinefilename = null;


	String InputdataPath = PropertyBroker.getProperty("OLDFILEDIR");
	File mydir = new File(InputdataPath);
	FilenameFilter only = new OnlyExt("zip");
	String filelist[] = mydir.list(only);

	for(int i=0; i<filelist.length; i++){
		SybilMagazine sm = new SybilMagazine(filelist[i]);
		if(sm.getPrefix().equalsIgnoreCase(magazine.trim())) {
			magazinefilename = filelist[i];
			break;
		}
	}

	mag = new sybilweb.plant.controller.Magazine(new File(magazinefilename));

	String magTrimProp = PropertyBroker.getProperty((mag.getMagCode()).toUpperCase() + "TrimSize");
		
	if (magTrimProp  != null) 
		mag.setTrimSize(Integer.parseInt(magTrimProp.trim()));


	persistenceRoll = new PersistentRoll(); 

	String plant = mag.getPlant().trim();

	try{
	inputFileName = PropertyBroker.getProperty("OLDFILEDIR") + mag.getFullPrefix() + ".zip";
	customerGroups = new Vector();

	try {
		ZipFile zf = new ZipFile(inputFileName);
		if (zf.getEntry(OMS_CUSTOMER) != null)
			OMSCustomers = true;
		else
			OMSCustomers = false;
		zf.close();
	}catch(Exception e) { e.printStackTrace();}


	if (OMSCustomers) {
		driverCodeAssignmentMgr = new OMSDriverCodeAssignmentMgr(mag);
	}else{
		driverCodeAssignmentMgr = new GTRFDriverCodeAssignmentMgr(mag);
	}

	customerGroups = new Vector();
	customerGroups = Group;
	prop = (String)PropertyBroker.getProperty("DataOutputPath").trim();
	outputFileExtension = (String)PropertyBroker.getProperty("DataOutputFileExtension");

	if(PropertyBroker.getProperty("UseKeylineCapture","false").equals("true")) {
	keylineCapture = (new ControllerFormatFactory("KeylineCapture")).createOutputFileFormatter();
	prop = PropertyBroker.getProperty("KeylineDataOutputPath");
	}

	String dirPath = PropertyBroker.getProperty("OLDFILEDIR");
	OutputFile = FormattedFile.trim();

	insertExtraBooksHandler = new InsertExtraBooksHandler(dirPath,mag,OMSCustomers);	
	insertExtraBooksHandler.initLengthOfRunBooks();

	} catch(Exception e) {
		LogWriter.writeLog(e);
		}
 }   
	public void closeInputFile () {
try {
		bfr.close();
	} catch (Exception e) {};
	
	try {
		dis.close();
	} catch (Exception e) {};
	
	try {
		bis.close();
	} catch (Exception e) {};
	
	try {
		zis.close();
	} catch (Exception e) {};
	
	try {
		zf.close();
	} catch (Exception e) {
		// log error and return false indicate failure
// Why???		sybil.common.util.LogWriter.writeLog(e);
	}

	return;
}
	public boolean isDriverCodeAssignmentReady() {
	return driverCodeAssignmentMgr.driverCodeFileExists();
}
	public void loadLabelPosition( ) {

	sybilweb.plant.persistence.PersistentLabelPosition plp = new sybilweb.plant.persistence.PersistentLabelPosition();
	loadedLabelPos = plp.loadLabelPosition(mag);
	return;
}
	private boolean openInputFile (String zipFilename) {

		try {
		zf = new ZipFile(zipFilename);
		if( zf.getEntry("OMS2") != null ){
			if( zf.getEntry("CustFileStructure") == null ){
				skipExtraLabeltokens = false;
			}
		}else{
			skipExtraLabeltokens = false;
		}


		if(zf.getEntry("LORBookFile") != null ) {
				LOR_Cust_File_Entry = true;
		}

		String Remove_LOR_Mags = PropertyBroker.getProperty("REMOVE_LOR_MAGS");
		
		if(Remove_LOR_Mags.toUpperCase().trim().indexOf(mag.getMagCode().toUpperCase().trim())>=0){
			Remove_LOR_Cust_Mag = true;
		}

	} catch (Exception e) {
		e.printStackTrace();
		closeInputFile();
		return false;
	}


	return true;
}
	private boolean openInputFile (String zipFilename, String rollname) {

		try {
		zf = new ZipFile(zipFilename);	
		zis = zf.getInputStream(zf.getEntry(rollname));
		bis = new BufferedInputStream(zis);
		dis = new DataInputStream(bis);
		isr = new InputStreamReader(zis, "ISO8859_1");
		bfr = new java.io.BufferedReader(isr);
	} catch (Exception e) {
		e.printStackTrace();
		closeInputFile();
		return false;
	}
	
	return true;
}
public void processData() throws Exception{


	int numberOfGroups = 0, numberOfGroupEntries = 0;
	CustomerGroupEntry cge = null;
	CustomerGroup cg = null;
	IssueCustomer customer = null;
	Vector customerPackage = null;
	int recordCount = 0;
	int rollRecordCount = 0;
		
	SybilIssueCustomerFileParser inFile = new SybilIssueCustomerFileParser();


	readMessageParameters();
	loadLabelPosition();

	insertExtraBooksHandler.initEarlyStartRolls();
	
	insertExtraBooksHandler.initPostalBooks();
	insertExtraBooksHandler.initStorageBooks();
	insertExtraBooksHandler.initLengthOfRunBooksFromFile();


	if(mag.getDeliveryType().trim().equals("can")) {
		insertExtraBooksHandler.useInkjetFreq(true);
	}else
		insertExtraBooksHandler.useInkjetFreq(false);
	
	if (isDriverCodeAssignmentReady()) {

		driverCodeAssignmentMgr.loadDriverCodes();
		if (driverCodeAssignmentMgr.errormessage != null) {
			
			try {
				driverCodeAssignmentMgr.errormessage = null;
			} catch (Exception e) {
				
			}
			useDriverCodeAssignment = false;
		} else {
			useDriverCodeAssignment = true;
		}
	} else
		{
		useDriverCodeAssignment = false;

		}

		cg = (CustomerGroup) customerGroups.elementAt(0);
		numberOfGroupEntries = cg.getNumberOfGroupEntries();

		
		nextLabelNumber = 1;
		String groupIdentifier = ((cg.getGroupEntry(0)).rollID.trim());


		

		outputFormat = cg.getGroupEntry(0).controllerFormat.toUpperCase().trim();

		pic = (new sybilweb.plant.persistence.ControllerFormatFactory(outputFormat)).createOutputFileFormatter();	
		pic.setMagazine(mag);
		pic.setMessageParameters(msgParms);
		outputFormatFilename = OutputFile.substring(0,OutputFile.length()-4).trim();
		pic.createOutputFile(prop,outputFormatFilename);

	 insertExtraBooksHandler.clearPostalStorageBooks();

	 
 
	boolean ErrorFlag = false;

	openInputFile(inputFileName);

// check to see if RLL5 file is there to determine skip of label drop in
	boolean RLL5fileExists = false;
	String fileName = null;	
	fileName = sybilweb.plant.controller.PropertyBroker.getProperty("OLDFILEDIR") + mag.getFullPrefix() + ".RLL5";
	File RLL5File = new File(fileName);
	if (RLL5File.exists()) {
		RLL5fileExists = true;
	}

	 
	for(int y = 0; y < numberOfGroupEntries; y++) {
		cge = (cg.getGroupEntry(y));
		openInputFile(inputFileName, cge.rollID.trim());
		customer = new IssueCustomer();
		currentProcessRoll = cge.rollID.trim();
		recordCount = 0;
		rollRecordCount = 0;
		
		try {
				
			while(inFile.parseFile(dis, customer, skipExtraLabeltokens, RLL5fileExists)) {
					recordCount++;

					
				if( (customer.getMagazineLabel()).endorsementLine.equals("PROFILE COPY")){
					if( ( LOR_Cust_File_Entry == true ) && ( Remove_LOR_Cust_Mag == true ) ){
						continue;			
					}
				}	
					

				if(mag.isNYBranchOfficeMagazine())
				 	customer.setMakeupCode(NYBranchOfficeDriverCode);

				 if(customerPackage == null)
				 	customerPackage = new Vector();	
				 
				 customerPackage.addElement(customer);

				 if(customer.getEndPackageIndicator()) {

					  if(useDriverCodeAssignment) {
						  	driverCodeAssignmentMgr.assignDriverCode(customerPackage);
					  }

					  try {
							  insertExtraBooksHandler.insertExtraBooks(customerPackage,cge.rollID.trim(),skipExtraLabeltokens,LOR_Cust_File_Entry,RLL5fileExists);
						      
					  } catch(Exception ex) { ex.printStackTrace(); }


					for(int count = 0; count < customerPackage.size(); count++) {
						customer = (IssueCustomer)customerPackage.elementAt(count);
						
						processIssueCustomer(customer,count+1);

					}

				pic.saveData(customerPackage);
				rollRecordCount = rollRecordCount + customerPackage.size();
				customerPackage = null;		
			 }	// if customer.getEndPackageIndicator()
				 	
				 customer = new IssueCustomer();	
	} // while loop close

				closeInputFile();
				cge.state = CustomerGroupEntry.DONE;

				rollRecordCount = rollRecordCount + insertExtraBooksHandler.getCustomerPostalBooks().size();
				rollRecordCount = rollRecordCount + insertExtraBooksHandler.getCustomerStorageBooks().size();
				
				try {
		
						Integer updateCount = persistenceRoll.saveRoll(mag.getPrefix(), GroupNumber, ActualFileName, cge, OutputFile, rollRecordCount, mag.getPlant());

						if(updateCount == null){
						
						// if updateCount == null Connection not available after 5 times	
						// write log record and rename .001 to .000 ; stop thread

							String FormatCtlFiledir = PropertyBroker.getProperty("FormatterControlPath");

							String oldFilename = FormatCtlFiledir + "/" + OutputFile.substring(0,OutputFile.length()-3).concat("001");
							File rf = new File(oldFilename);
							String newfile = OutputFile.substring(0,OutputFile.length()-3);
							newfile = newfile.concat("000");
							String newfilepath = FormatCtlFiledir + "/" + newfile;
							if(!rf.delete())
									LogWriter.writeLog("E", mag.getPlant().trim().toUpperCase(), mag.getPrefix().trim(), " Error in Deleting "+ oldFilename+" Error in updating Roll "+cge.rollID+" status updateCount is null");
							else
										
									LogWriter.writeLog("E", mag.getPlant().trim().toUpperCase(), mag.getPrefix().trim(), " Deleting "+ oldFilename+" Error in updating Roll "+cge.rollID+" status updateCount is null");
							

								try {
									FileWriter f = new FileWriter(newfilepath);
									} catch(Exception ex) { LogWriter.writeLog("E", mag.getPlant().trim(), mag.getPrefix().trim(),ex.toString()); LogWriter.writeLog("E", mag.getPlant().trim(), mag.getPrefix().trim(),"Could not able to create Formatter flag file update count is null"); }

							LogWriter.writeLog("W", mag.getPlant().trim().toUpperCase(), mag.getPrefix().trim()," Error in Saving the status in Group. no Connection rename .001 to .000 "+ GroupNumber);		
										
							ErrorFlag = true;
							break;
						// write log record and rename .001 to .000 ; stop thread

						}
						else if(updateCount.equals(new Integer(0))){

							// if Connection found and updatecount = 0
							// write log record and delete .001 & .tmp files and stop thread							

							String FormatCtlFiledir = PropertyBroker.getProperty("FormatterControlPath");

							String oldFilename = FormatCtlFiledir +  OutputFile.substring(0,OutputFile.length()-3).concat("001");
							File rf = new File(oldFilename);
							if(!rf.delete())
									LogWriter.writeLog("E", mag.getPlant().trim().toUpperCase(), mag.getPrefix().trim(), " Error in Deleting "+ oldFilename);
							else
										
									LogWriter.writeLog("E", mag.getPlant().trim().toUpperCase(), mag.getPrefix().trim(), " Deleting "+ oldFilename+"Roll Update Count is Zero");

							String tmpFiledir = PropertyBroker.getProperty("DataOutputPath");
							String tmpFilename = tmpFiledir +  OutputFile.substring(0,OutputFile.length()-3).concat("tmp");
							File tmpf = new File(tmpFilename);

							FileWriter newFile = new FileWriter(FormatCtlFiledir +  OutputFile.substring(0,OutputFile.length()-3).concat("001"));
							
							if(!tmpf.delete())
									LogWriter.writeLog("E", mag.getPlant().trim().toUpperCase(), mag.getPrefix().trim(), " Error in Deleting "+ tmpFilename);
							else
									LogWriter.writeLog("E", mag.getPlant().trim().toUpperCase(), mag.getPrefix().trim(), " Deleting "+ tmpFilename+"Roll Update Count is Zero");
									
							
							LogWriter.writeLog("W", mag.getPlant().trim(), mag.getPrefix().trim(), " Error in Saving the status in Group Roll not Updated, delete .001 & .tmp files and stop thread and Created the .000 file  "+ GroupNumber);		
							
							// write log record and delete .001 & .tmp files and stop thread

							ErrorFlag = true;
							break;
						}
						
					persistenceRoll.updateTrackingSchd(mag);	
						
					
				} catch(Exception ex){ 
					LogWriter.writeLog(ex);
					LogWriter.writeLog("E", mag.getPlant().trim().toUpperCase(), mag.getPrefix().trim(), " Error in Saving the status in processData"+ GroupNumber);		
					}


		} catch(Exception ex) { 
	        LogWriter.writeLog(ex);		
			cge.state = CustomerGroupEntry.ERROR;
			 try {
			persistenceRoll.saveRoll(mag.getPrefix(), GroupNumber, ActualFileName, cge, OutputFile, rollRecordCount, mag.getPlant());
			 }catch(Exception e){
				 LogWriter.writeLog("E", mag.getPlant().trim().toUpperCase() , mag.getPrefix().trim(), " Error in Roll"+cge.rollID);
				 LogWriter.writeLog(e);
			 }


				// if there is any type of Error ie., Data Error or File i/o Error
				// write log record and delete .001 & .tmp files and stop thread							

							String FormatCtlFiledir = PropertyBroker.getProperty("FormatterControlPath");

							String oldFilename = FormatCtlFiledir +  OutputFile.substring(0,OutputFile.length()-3).concat("001");
							File rf = new File(oldFilename);
							if(!rf.delete())
									LogWriter.writeLog("E", mag.getPlant().trim().toUpperCase(), mag.getPrefix().trim(), " Error in Deleting "+ oldFilename+ cge.rollID+" Data or File Error");
							else
									LogWriter.writeLog("E", mag.getPlant().trim().toUpperCase(), mag.getPrefix().trim(), " Deleting "+ oldFilename + cge.rollID+" Data or File Error");
									
									

							String tmpFiledir = PropertyBroker.getProperty("DataOutputPath");
							String tmpFilename = tmpFiledir +  OutputFile.substring(0,OutputFile.length()-3).concat("tmp");
							File tmpf = new File(tmpFilename);

							FileWriter newFile = new FileWriter(FormatCtlFiledir +  OutputFile.substring(0,OutputFile.length()-3).concat("001"));
							
							if(!rf.delete())
									LogWriter.writeLog("E", mag.getPlant().trim().toUpperCase(), mag.getPrefix().trim(), " Error in Deleting "+ tmpFilename);
							else
									LogWriter.writeLog("E", mag.getPlant().trim().toUpperCase(), mag.getPrefix().trim(), " Deleting "+ tmpFilename + cge.rollID+" Data or File Error");
									
							
							
			// write log record and delete .001 & .tmp files and stop thread
 			 

				ErrorFlag = true;
				break;
		}
	}

	if(ErrorFlag){
		LogWriter.writeLog("E", mag.getPlant().trim() , mag.getPrefix().trim(), " stoping Thread "+GroupNumber);
				// if there is any type of Error ie., Data Error or File i/o Error
				// write log record and delete .001 & .tmp files and stop thread							

							String FormatCtlFiledir = PropertyBroker.getProperty("FormatterControlPath");

							String oldFilename = FormatCtlFiledir +  OutputFile.substring(0,OutputFile.length()-3).concat("001");
							File rf = new File(oldFilename);
							if(rf.exists()){
							if(!rf.delete())
									LogWriter.writeLog("E", mag.getPlant().trim().toUpperCase(), mag.getPrefix().trim(), " Error in Deleting "+ oldFilename);
							}		
									

							String tmpFiledir = PropertyBroker.getProperty("DataOutputPath");
							String tmpFilename = tmpFiledir +  OutputFile.substring(0,OutputFile.length()-3).concat("tmp");
							File tmpf = new File(tmpFilename);

							if(!tmpf.delete())
									LogWriter.writeLog("E", mag.getPlant().trim().toUpperCase(), mag.getPrefix().trim(), " Error in Deleting "+ tmpFilename);									
							
							LogWriter.writeLog("W", mag.getPlant().trim(), mag.getPrefix().trim(), " Error in Saving the status in Group Roll not Updated, delete .001 & .tmp files and stop thread and Created the .000 file  "+ GroupNumber);		
							
			// write log record and delete .001 & .tmp files and stop thread
 		
		return;
	}	

	if (insertExtraBooksHandler.getCustomerPostalBooks().size() != 0) {
		for (int count = 0; count < insertExtraBooksHandler.getCustomerPostalBooks().size(); count++) {
			customer = (IssueCustomer) insertExtraBooksHandler.getCustomerPostalBooks().elementAt(count);
			processIssueCustomer(customer, count+1);
		}
			pic.saveData(insertExtraBooksHandler.getCustomerPostalBooks());
	}

	if (insertExtraBooksHandler.getCustomerStorageBooks().size() != 0) {
		for (int count = 0; count < insertExtraBooksHandler.getCustomerStorageBooks().size(); count++) {
			customer = (IssueCustomer) insertExtraBooksHandler.getCustomerStorageBooks().elementAt(count);
			processIssueCustomer(customer, count+1);
		}
		pic.saveData(insertExtraBooksHandler.getCustomerStorageBooks());
	}
	pic.closeOutputFile();
}
public void processIssueCustomer(IssueCustomer customer, int pack_count) {

	int numberOfMessages = customer.getOrigMessages().size();
	Vector allMessages = customer.getMessages();
	int numberOfMsgTextLines;
	Vector m_TextLines;
	Message m = null;
	String msgfamilyNumber = null;
	MessageParameter msgp = null;
	String LabeLine8 = customer.getMagazineLabel().LabelLine8;

	Vector origMsgs = customer.getOrigMessages();

	allMessages.removeAllElements();

	for (int i = 0; i < numberOfMessages; i++) {

		m = ((Message) origMsgs.elementAt(i));

		msgfamilyNumber = 
			StringFunctions.fixSize(
				String.valueOf(m.getMessageFamily()), 
				3, 
				'0', 
				StringFunctions.LEFT)
				+ StringFunctions.fixSize(
					String.valueOf(m.getMessageNumber()), 
					3, 
					'0', 
					StringFunctions.LEFT); 

		msgp = (MessageParameter) messageParameters.get(msgfamilyNumber);
		
		if ((msgp.isCoverMessage())
			|| (msgp.getOrientation() != StringFunctions.OFF)) {
				allMessages.addElement(m);
			
		}

	}
		
	numberOfMessages = allMessages.size();
	customer.setNumberOfMessages(numberOfMessages);

	for (int v = 0; v < loadedLabelPos.size(); v++) {
		lpp= new LabelPositionFileParser();
		lpp.parseLabelPosition((String) loadedLabelPos.elementAt(v));
		if (lpp.SignatureNameCode.equals(customer.getMagazineLabel().signatureName)) {
			LabelPosition = lpp.LabelPosition;
			break;
		}
	}

	customer.getMagazineLabel().labelJustification = LabelPosition;

	for (int i = 0; i < numberOfMessages; i++) {

		m = ((Message) allMessages.elementAt(i));

		msgfamilyNumber = StringFunctions.fixSize(String.valueOf(m.getMessageFamily()),3,'0',StringFunctions.LEFT)+ 
			StringFunctions.fixSize(String.valueOf(m.getMessageNumber()),3,'0',StringFunctions.LEFT); 
		msgp = (MessageParameter) messageParameters.get(msgfamilyNumber);

		if (msgp == null) {
			continue;
		}

		if (msgp.isCoverMessage()) {

			if (msgp.getOrientation() != StringFunctions.OFF)
				customer.getMagazineLabel().setExtendedLabelAreaMessage(m);
		}

		m.format(msgp);

	}

	customer.getMagazineLabel().setLabelNumber(nextLabelNumber++);
	customer.getMagazineLabel().pack_count = pack_count;
	customer.getMagazineLabel().format();
	customer.getMagazineLabel().expandLabel(mag.getTrimSize());
	if (customer.getMagazineLabel().getExtendedLabelAreaMessage() != null)
		customer.getMagazineLabel().insertExtendedLabelAreaMessage();

	return;

}
public void readMessageParameters ( ) {

	messageParameterFileMgr = new MessageParameterFileMgr();
	 
// add message parameters to hash table for processing
	msgParms = messageParameterFileMgr.readMessageParameters(mag);

	messageParameters = new Hashtable();
	int size = msgParms.size();	
	String messageFamilyNumber = null;
	
	for (int i = 0; i < size; i++) {
		messageFamilyNumber = ((MessageParameter)msgParms.elementAt(i)).getFamilyNumber() + 
									 ((MessageParameter)msgParms.elementAt(i)).getNumber();
		messageParameters.put(messageFamilyNumber,msgParms.elementAt(i));
	}	

	
	return;
}
/**
 * run method comment.
 */
public void run() {
	synchronized (processData) {
	try {
		processData();
	}catch (Exception tde) {
			LogWriter.writeLog(tde);
		}	
	}	
}
	public void setMessageParameterFileManager(MessageParameterFileMgr mp ) {

}
	public void setParserMethod (CustomerGroupingParser groupingParser ) {

}
}
