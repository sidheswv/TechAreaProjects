package sybilweb.plant.controller;

/**
 * Insert the type's description here.
 * Creation date: (4/9/2002 4:11:23 PM)
 * @author: Sybil Administrator
 */
import java.sql.*;
import java.util.*;
import java.io.*;

public class ReportGenerationTracker {
	private static Connection connTrk = null;
	private static String tableName = "TBA_SYB_RPTGENTRK";

	private static PreparedStatement deleteTrk = null;
	private static Statement st = null;

/**
 * Insert the method's description here.
 * Creation date: (4/10/2002 11:31:47 AM)
 */
public ReportGenerationTracker() {
	super();
	String user = PropertyBroker.getProperty("database.login","sybil");
	String pswd = PropertyBroker.getProperty("database.password","sybil");
	tableName = PropertyBroker.getProperty("tablename","TBA_SYB_RPTGENTRK");
	String driver = "";
	String database = "";

	if( connTrk == null) {
		try {
			driver = PropertyBroker.getProperty("SYBILTRACKINGDBDRIVER", "SYBILTRACKINGDBDRIVER not defined");
			database = PropertyBroker.getProperty("SYBILTRACKINGDBCONNSTRING", "SYBILTRACKINGDBCONNSTRING not defined");
			Class.forName(driver);
			connTrk = DriverManager.getConnection(database, user, pswd);
		}
		catch (Exception e) {
			LogWriter.writeLog("RGT.connectToDatabase: Error ... unable to connect to database <" +
			database + "> using driver <" + driver + ">");
			LogWriter.writeLog(e);
			LogWriter.writeLog("Process terminating due to database/sql exception");
			System.exit(1);
		}
	}
}
/**
 * ReportGenerationTracker constructor comment.
 */
public ReportGenerationTracker(String[] args) {
	super();
	String user = PropertyBroker.getProperty("database.login","sybil");
	String pswd = PropertyBroker.getProperty("database.password","sybil");
	String driver = "";
	String database = "";

	if( connTrk == null) {
		try {
			driver = PropertyBroker.getProperty("SYBILTRACKINGDBDRIVER", "SYBILTRACKINGDBDRIVER not defined");
			database = PropertyBroker.getProperty("SYBILTRACKINGDBCONNSTRING", "SYBILTRACKINGDBCONNSTRING not defined");
			Class.forName(driver);
			connTrk = DriverManager.getConnection(database, user, pswd);
		}
		catch (Exception e) {
			LogWriter.writeLog("RGT.connectToDatabase: Error ... unable to connect to database <" +
			database + "> using driver <" + driver + ">");
			LogWriter.writeLog(e);
			LogWriter.writeLog("Process terminating due to database/sql exception");
			System.exit(1);
		}
	}
}
public ReportGenerationTracker(String table) {
	super();
	String user = PropertyBroker.getProperty("database.login","sybil");
	String pswd = PropertyBroker.getProperty("database.password","sybil");
	tableName = PropertyBroker.getProperty("tablename","TBA_SYB_RPTGENTRK");
	String driver = "";
	String database = "";
	this.tableName = table.trim();

	if( connTrk == null) {
		try {
			driver = PropertyBroker.getProperty("SYBILTRACKINGDBDRIVER", "SYBILTRACKINGDBDRIVER not defined");
			database = PropertyBroker.getProperty("SYBILTRACKINGDBCONNSTRING", "SYBILTRACKINGDBCONNSTRING not defined");
			Class.forName(driver);
			connTrk = DriverManager.getConnection(database, user, pswd);
		}
		catch (Exception e) {
			LogWriter.writeLog("RGT.connectToDatabase: Error ... unable to connect to database <" +
			database + "> using driver <" + driver + ">");
			LogWriter.writeLog(e);
			LogWriter.writeLog("Process terminating due to database/sql exception");
			System.exit(1);
		}
	}
}
/**
 * Insert the method's description here.
 * Creation date: (4/9/2002 4:17:22 PM)
 * @return boolean
 */
public static boolean cleanReportGenTrk(String plant, String mag, String issue, String week) {
	String del = null;
	String prop = null;


	if ((plant.length() == 0) && (mag.length() == 0)) {
		LogWriter.writeLog("RGT.cleanReportGenTrk: Either plant, mag, or both must be supplied.");
		System.exit(1);
	}
	if ((issue.length() == 0) && (week.length() != 0)) {
		LogWriter.writeLog("RGT.cleanReportGenTrk: The week cannot be supplied without an issue.");
		System.exit(1);
	}
	if ((issue.length() != 0) && (mag.length() == 0)) {
		LogWriter.writeLog("RGT.cleanReportGenTrk: The issue cannot be supplied without a mag.");
		System.exit(1);
	}

	del = "";
	if (plant.length() != 0) {
		del = del + " plant_id = ?";
	}
	if (mag.length() != 0) {
		if (plant.length() != 0) {
			del = del + " AND";
			del = del + " mag_cd = ?";
		}
		else {
			del = del + " mag_cd = ?";
		}
	}
	if (issue.length() != 0) {
		del = del + " AND";
		del = del + " issue_num = ?";
	}
	if (week.length() != 0) {
		del = del + " AND";
		del = del + " week_num = ?";
	}
	//LogWriter.writeLog("RGT.cleanReportGenTrk: <DELETE FROM " + tableName + " WHERE" + del + ">");

	try {
		deleteTrk = connTrk.prepareStatement("DELETE FROM " + tableName + " WHERE" + del);
	}
	catch (SQLException se) {
		LogWriter.writeLog("RGT.cleanReportGenTrk: Error ... SQLException on prepare delete.");
		LogWriter.writeLog(se);
		if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
			LogWriter.writeLog("Process terminating due to database/sql exception");
			System.exit(1);
		}
	}
	catch (Exception e) {
		LogWriter.writeLog("RGT.cleanReportGenTrk: Error ... Exception on prepare delete.");
		LogWriter.writeLog(e);
		if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
			LogWriter.writeLog("Process terminating due to database/sql exception");
			System.exit(1);
		}
	}

	try {
		if (plant.length() != 0) {
			deleteTrk.setString(1, plant.toUpperCase());
			if (mag.length() != 0) {
				deleteTrk.setString(2, mag.toLowerCase());
				if (issue.length() != 0) {
					deleteTrk.setInt(3, Integer.valueOf(issue).intValue());
				}
				if (week.length() != 0) {
					deleteTrk.setInt(4, Integer.valueOf(week).intValue());
				}
			}
		}
		else {
			deleteTrk.setString(1, mag.toLowerCase());
			if (issue.length() != 0) {
				deleteTrk.setInt(2, Integer.valueOf(issue).intValue());
			}
			if (week.length() != 0) {
				deleteTrk.setInt(3, Integer.valueOf(week).intValue());
			}
		}
	}
	catch (SQLException se) {
		LogWriter.writeLog("RGT.cleanReportGenTrk: Error ... SQLException on set delete.");
		LogWriter.writeLog(se);
		if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
			LogWriter.writeLog("Process terminating due to database/sql exception");
			System.exit(1);
		}
	}
	catch (Exception e) {
		LogWriter.writeLog("RGT.cleanReportGenTrk: Error ... Exception on set delete.");
		LogWriter.writeLog(e);
		if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
			LogWriter.writeLog("Process terminating due to database/sql exception");
			System.exit(1);
		}
	}

	prop = PropertyBroker.getProperty("REPORT_ONLY","false");
	if (prop.equals("true")) {
		LogWriter.writeLog("RGT.cleanReportGenTrk: REPORT_ONLY: <DELETE FROM " +
				tableName + " WHERE" + del + ">");
	}
	else {
		try {
			int rowCount = deleteTrk.executeUpdate();
			st = connTrk.createStatement();
			st.execute("commit");
			LogWriter.writeLog("RGT.cleanReportGenTrk: Successful delete of " + rowCount + " rows: <DELETE FROM " +
				tableName + " WHERE" + del + ">");
			deleteTrk.close();
			deleteTrk = null;
			st.close();
			st = null;
		}
		catch (SQLException se) {
			LogWriter.writeLog("RGT.cleanReportGenTrk: Error ... SQLException on exec delete.");
			LogWriter.writeLog(se);
			if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
				LogWriter.writeLog("Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
		catch (Exception e) {
			LogWriter.writeLog("RGT.cleanReportGenTrk: Error ... Exception on exec delete.");
			LogWriter.writeLog(e);
			if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
				LogWriter.writeLog("Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
	}

	return true;
}
/**
 * Insert the method's description here.
 * Creation date: (4/15/2002 10:28:05 AM)
 */
public static void close() {
	if( connTrk != null) {
		try { connTrk.close(); }catch(Exception sql ){};
		connTrk = null;
	}
}
/**
 * Insert the method's description here.
 * Creation date: (7/23/2002 1:53:46 PM)
 * @return java.util.Vector
 */
public static synchronized Vector getInfo() {
	//LogWriter.writeLog("ReportGenerationTracker.getInfo");
	Vector vectorInfo = new Vector();
	String s = null;
	try {
		String select = "SELECT mag_cd, issue_num, plant_id, rpt_code, week_num, jobid, status, datetime" +
			" FROM " + tableName + " ORDER BY mag_cd, issue_num, plant_id, week_num, rpt_code";
		PreparedStatement psSelect = null;
		ResultSet result = null;
		psSelect = connTrk.prepareStatement(select);
		result = psSelect.executeQuery();
		while (result.next()) {
			s = result.getString(1) + ",";      //mag
			s = s + result.getInt(2) + ",";     //issue
			s = s + result.getString(3) + ",";  //plant
			s = s + result.getString(4) + ",";  //report
			s = s + result.getInt(5) + ", ";    //week
			s = s + result.getString(6) + ",";  //jobid
			s = s + result.getInt(7) + ",";     //status
			s = s + result.getString(8);        //datetime
			//LogWriter.writeLog("ReportGenerationTracker.getInfo ... " + s);
			vectorInfo.addElement(s);
		}
		result.close();
		psSelect.close();
	}
	catch (SQLException se) {
		LogWriter.writeLog("ReportGenerationTracker.getInfo ... SQLException");
		LogWriter.writeLog(se);
		if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
			LogWriter.writeLog("Process terminating due to database/sql exception");
			System.exit(1);
		}
	}
	catch (Exception e) {
		LogWriter.writeLog("ReportGenerationTracker.getInfo ... Exception");
		LogWriter.writeLog(e);
		if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
			LogWriter.writeLog("Process terminating due to database/sql exception");
			System.exit(1);
		}
	}
	if (vectorInfo.size() > 0) {
		return vectorInfo;
	}
	else {
		return null;
	}
}
/**
 * Insert the method's description here.
 * Creation date: (7/24/2002 9:53:17 AM)
 * @return java.util.Vector
 */
public static synchronized Vector getInfoMagIssue(String mag, String issue, String week, String plant, String filenameprefix) {
	//LogWriter.writeLog("ReportGenerationTracker.getInfoMagIssue");
	Vector vectorInfo = new Vector();
	String s = null;
	try {
		String select = "SELECT *" +
			" FROM " + tableName +
//			"";
			" WHERE mag_cd = ? AND issue_num = ? AND  week = ? AND plant_id = ?" +
			" ORDER BY mag_cd, issue_num, plant_id, week";
		PreparedStatement psSelect = null;
		ResultSet result = null;
		psSelect = connTrk.prepareStatement(select);
		psSelect.setString(1, mag.trim().toUpperCase());
		psSelect.setString(2, issue.trim().toUpperCase());
		psSelect.setString(3, week.trim().toUpperCase());
		psSelect.setString(4, plant.trim().toUpperCase());
			
//		int issueInt = Integer.parseInt(issue);
//		psSelect.setInt(2, issueInt);
		result = psSelect.executeQuery();
		ResultSetMetaData rsmd = result.getMetaData();
		int colcount = rsmd.getColumnCount();

		String outputFileName = PropertyBroker.getProperty("INTERFACE_FILES_PATH","/Sybil/Plant/SysTest/AllPlants/");
		outputFileName = outputFileName.concat(filenameprefix);
		
		File f = new File(outputFileName);
		FileOutputStream fos = new FileOutputStream(f);
		

		while (result.next()) {

			s = result.getString(1) + sybilweb.plant.controller.IssueCustomer.TOSTRING_DELIMITER;      //mag
				int i=2;
				for(; i<colcount; i++){
					s = s + result.getObject(i) + sybilweb.plant.controller.IssueCustomer.TOSTRING_DELIMITER;
				}
			s = s + result.getObject(i) ;
			s = s +"\n";
			//LogWriter.writeLog("ReportGenerationTracker.getInfo ... " + s);
			
//			vectorInfo.addElement(s);
			fos.write(s.getBytes());
		}
		result.close();
		psSelect.close();
	}
	catch (SQLException se) {
		LogWriter.writeLog("ReportGenerationTracker.getInfo ... SQLException");
		LogWriter.writeLog(se);
		if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
			LogWriter.writeLog("Process terminating due to database/sql exception");
			System.exit(1);
		}
	}
	catch (Exception e) {
		LogWriter.writeLog("ReportGenerationTracker.getInfo ... Exception");
		LogWriter.writeLog(e);
		if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
			LogWriter.writeLog("Process terminating due to database/sql exception");
			System.exit(1);
		}
	}
	if (vectorInfo.size() > 0) {
		return vectorInfo;
	}
	else {
		return null;
	}
}
/**
 * Insert the method's description here.
 * Creation date: (7/24/2002 9:53:17 AM)
 * @return java.util.Vector
 */
public void getInfoMagIssue(String mag, String issue, String week, String plant, String filenameprefix, String outputPath) {
	//LogWriter.writeLog("ReportGenerationTracker.getInfoMagIssue");
	String s = null;
	try {
		String select = "SELECT *" +
			" FROM " + tableName +
			" WHERE mag_cd = ? AND issue_num = ? AND  week = ? AND plant_id = ?" +
			" ORDER BY mag_cd, issue_num, plant_id, week";
		PreparedStatement psSelect = null;
		ResultSet result = null;
		psSelect = connTrk.prepareStatement(select);
		psSelect.setString(1, mag.trim().toUpperCase());
		psSelect.setString(2, issue.trim().toUpperCase());
		psSelect.setString(3, week.trim().toUpperCase());
		psSelect.setString(4, plant.trim().toUpperCase());
			
		result = psSelect.executeQuery();
		ResultSetMetaData rsmd = result.getMetaData();
		int colcount = rsmd.getColumnCount();

		String outputFileName = outputPath.trim();
		outputFileName = outputFileName.concat(filenameprefix);
		
		File f = new File(outputFileName);
		FileOutputStream fos = new FileOutputStream(f);
		

		while (result.next()) {

			s = result.getString(1) + sybilweb.plant.controller.IssueCustomer.TOSTRING_DELIMITER;      //mag
				int i=2;
				for(; i<colcount; i++){
					s = s + result.getObject(i) + sybilweb.plant.controller.IssueCustomer.TOSTRING_DELIMITER;
				}
			s = s + result.getObject(i) ;
			s = s +"\n";
			
			fos.write(s.getBytes());
		}
		result.close();
		psSelect.close();
	}
	catch (SQLException se) {
		LogWriter.writeLog("ReportGenerationTracker.getInfo ... SQLException");
		LogWriter.writeLog(se);
		if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
			LogWriter.writeLog("Process terminating due to database/sql exception");
			System.exit(1);
		}
	}
	catch (Exception e) {
		LogWriter.writeLog("ReportGenerationTracker.getInfo ... Exception");
		LogWriter.writeLog(e);
		if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
			LogWriter.writeLog("Process terminating due to database/sql exception");
			System.exit(1);
		}
	}
}
/**
 * Insert the method's description here.
 * Creation date: (4/9/2002 4:15:22 PM)
 * @param args java.lang.String[]
 */
public static void main(String[] args) {
	ReportGenerationTracker rgt = new ReportGenerationTracker(args);
}
}
