package sybilweb.plant.controller;

import java.util.*;

/**
 * Insert the type's description here.
 * Creation date: (3/1/01 3:55:13 PM)
 * @author: Srikanth Bapanapalli
 */
public class VectorEnumerator {
	Vector vector;
	int count;

/**
 * VectorEnumerator constructor comment.
 */
public VectorEnumerator() {
	super();
}
	public VectorEnumerator(Vector v) {
	vector = v;
	count = 0;
	}
public Object nextElement() {
	synchronized (vector) {
	    if (count < vector.size()) {
		return vector.elementAt(count++);
	    }
	}
	throw new NoSuchElementException("VectorEnumerator");
	}
}
