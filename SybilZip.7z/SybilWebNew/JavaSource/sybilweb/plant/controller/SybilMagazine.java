package sybilweb.plant.controller;

//import sybil.common.util.*;
/**
 * This type was created in VisualAge.
 */
public class SybilMagazine {


	public final static String PaperLabel = "pl";
	public final static String STRIP = "strip";
	public final static String CUST = "cust";
	public final static String OFFICE = "office";

	public final static String REPORTS = "reports";

// moveable
	public final static String MERGE = "merge";
	public final static String POSTAL = "pobook";
	public final static String STORE = "storbook";
	public final static String REMOVE = "remove";
	public final static String OCCRPT = "occrpt";
	public final static String MAILDAT = "maildat";
	public final static String ROLLSUMMARY = "rollsum";
	public final static String POSTAL2 = "pobook2";
	public final static String STORE2 = "storbk2";
	public final static String LOR = "lorbook2";  // Length Of Run
	public final static String PACKAGE_SUMMARY = "pkgsum";
	public final static String PRESORT_PARAMETERS = "prsrt";
	public final static String DRIVER_CODE_BOOKVERSION = "bkversion";
	public final static String DRIVERCODE = "drivercd";
	public final static String BACKDATE = "bkdt";
	public final static String ISALRPT = "isalrpt";

	private String magCode;
	private String magName;
	private String issue;
	private String plant;
	private String deliveryType;
	private String processType;
	private String dataType;
	private String week;
	private String ext;

	private String inputFileName;
	private int weekNumber;
	private String singleMagCode;

	private int trimSize = 100;

	public static char fileSep = '.';
	public static int NOTSAMEMAGAZINE = -65000;
	private boolean invalidFileName = false;
	private String labelDestination = null;


public SybilMagazine() {
//	codeNameXRef = new java.util.Properties();
}
/**
 * This method was created by a SmartGuide.
 * @param s java.lang.String
 */
public SybilMagazine(java.io.File f) {
	this();
	inputFileName = f.getName();
	parse(inputFileName);
}
/**
 * This method was created by a SmartGuide.
 * @param s java.lang.String
 */
public SybilMagazine(String s) {
	this();
	inputFileName = s;
	parse(inputFileName);
}
/**
 * This constructor takes two strings (mag and issue)
 * and creates a Magazine occurrance
 * @param s java.lang.String
 */
public SybilMagazine(String m, String i) {
//	codeNameXRef = new java.util.Properties();

	// CHANGE: for testing JY
//	codeNameXRef.put("TD", "Time Domestic");
//	codeNameXRef.put("PE", "People");
//	codeNameXRef.put("MO", "Money Magazine");

	setMagCode(m);

	// added JCrisp 7/3/00 to correct cleanup of maildat files
	// which have issue numbers with week appended...
	if (i.length() == 4) {
		// not a maildat, issue number does not have week appended
		setIssue(i);
	}
	if (i.length() > 4) {
		// issue number has week appended - truncate week number
		setIssue(i.substring(0,4));
	}
	if (i.length() < 4) {
		// issue number is too short -
		// log it and let it go ...
//		LogWriter.writeLog("Magazine Constructor: Questionable issue of <" + i + "> for mag <"+ m + "<.");
		setIssue(i);
	}

}
public SybilMagazine(SybilMagazine m) {
	this.magCode = m.getMagCode();
	this.magName = m.getMagName();
	this.issue = m.getIssue();
	this.plant = m.getPlant();
	this.deliveryType = m.getDeliveryType();
	this.processType = m.getProcessType();
	this.dataType = m.getDataType();
//	this.week;
//	this.ext;
}
public boolean equals(Object m) {
	if (!(m instanceof SybilMagazine)) {
		return false;
	}
	else if (magCode.equals(((SybilMagazine) m).getMagCode()) &&
		      magName.equals(((SybilMagazine) m).getMagName()) &&
		      issue.equals(((SybilMagazine) m).getIssue()) &&
		      deliveryType.equals(((SybilMagazine) m).getDeliveryType()) &&
		      processType.equals(((SybilMagazine) m).getProcessType()) &&
		      dataType.equals(((SybilMagazine) m).getDataType()) &&
		      week.equals(((SybilMagazine) m).getWeek())) {
		return true;
	}
	return false;
}
public boolean equals(SybilMagazine m) {
	if (!(m instanceof SybilMagazine)) {
		return false;
	}
	else if (magCode.equals(((SybilMagazine) m).getMagCode()) &&
		      magName.equals(((SybilMagazine) m).getMagName()) &&
		      issue.equals(((SybilMagazine) m).getIssue()) &&
		      deliveryType.equals(((SybilMagazine) m).getDeliveryType()) &&
		      processType.equals(((SybilMagazine) m).getProcessType()) &&
		      dataType.equals(((SybilMagazine) m).getDataType()) &&
		      week.equals(((SybilMagazine) m).getWeek())) {
		return true;
	}
	return false;
}
public String getCommonPrefix() {
	StringBuffer sb = new StringBuffer(50);
	sb.append(magCode.toLowerCase());
	sb.append(fileSep);
	sb.append("i");
	sb.append(issue);
	sb.append(fileSep);
	sb.append(plant);
	sb.append(fileSep);
	sb.append(deliveryType);

	return sb.toString();
}
public String getCommonSuffix() {
	StringBuffer sb = new StringBuffer(50);
	sb.append(week);
	sb.append(fileSep);
	sb.append(ext);
	return sb.toString();
}
public String getDataType() {
	return dataType;
}
public String getDBTableName() {
	StringBuffer sb = new StringBuffer(20);
	sb.append(magCode);
	sb.append(issue);

	return sb.toString();
}
public String getDeliveryType() {
	return deliveryType;
}
public String getExt() {
	return ("." + ext);
}
/**
 * This method was created by a SmartGuide.
 * @return java.lang.String
 */
public String getFileName( ) {

	StringBuffer sb = new StringBuffer(50);
	sb.append(magCode.toLowerCase());
	sb.append(fileSep);
	sb.append("i");
	sb.append(issue);
	sb.append(fileSep);
	sb.append(plant);
	sb.append(fileSep);
	sb.append(deliveryType);
	sb.append(fileSep);
	sb.append(processType);
	sb.append(fileSep);
	sb.append(dataType);
	sb.append(fileSep);
	sb.append(week);
	sb.append(fileSep);
	sb.append(ext);

	return sb.toString();

}
public String getFullMagName() {

	StringBuffer buf = new StringBuffer();
	buf.append(magCode);
	buf.append(" ");
	buf.append(issue);
	buf.append("-");
	buf.append(weekNumber);
	buf.append(" ");

	String s = deliveryType.substring(2).toUpperCase();

	if(deliveryType.toLowerCase().startsWith("pl")){
		if(s.equalsIgnoreCase("forgn"))
			buf.append("FOREIGN");
		else if(s.equalsIgnoreCase("usps"))
			buf.append("USPS");
		else if(s.equalsIgnoreCase("nolab"))
			buf.append("NOLABEL");
		else
			buf.append(s);

		buf.append( " Paper Label");
	}else if (deliveryType.toLowerCase().startsWith("nl")){
		if(s.equalsIgnoreCase("forgn"))
			buf.append("FOREIGN");
		else if(s.equalsIgnoreCase("usps"))
			buf.append("USPS");
		else if(s.equalsIgnoreCase("nolab"))
			buf.append("NOLABEL");
		else
			buf.append(s);

		buf.append(" No Label");

	}else {
		buf.append(deliveryType.toUpperCase());
	}

	buf.append(" " );

	if (!processType.toUpperCase().equals("STRIP"))
		buf.append(processType.toUpperCase());


	return (buf.toString());
}
/**
 * This method was created by a SmartGuide.
 * @return java.lang.String
 */
public String getFullPrefix( ) {

	StringBuffer sb = new StringBuffer(50);
	sb.append(magCode.toLowerCase());
	sb.append(fileSep);
	sb.append("i");
	sb.append(issue);
	sb.append(fileSep);
	sb.append(plant);
	sb.append(fileSep);
	sb.append(deliveryType);
	sb.append(fileSep);
	sb.append(processType);
	sb.append(fileSep);
	sb.append(dataType);
	sb.append(fileSep);
	sb.append(week);

	return sb.toString();

}
public String getIssue() {
	return issue;
}
public String getMagCode() {
	return magCode;
}
public String getMagCodeIssue() {
	return (magCode + issue);
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getMagIssuePlantPrefix() {
	return (magCode + 	fileSep + "i"+issue + fileSep + plant);
}
public String getMagName() {
	return magName;
}
public String getMagNameIssue() {
	StringBuffer buf = new StringBuffer();
	buf.append(magName);
	buf.append(" ");
	buf.append(issue);

	return buf.toString();
}
public String getPlant() {
	return plant;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getPlantMagIssue() {
	return (magCode + issue + plant);
}
/**
 * This method was created by a SmartGuide.
 * @return java.lang.String
 */
public String getPrefix( ) {

	StringBuffer sb = new StringBuffer(50);
	sb.append(magCode);
	sb.append(issue);
	sb.append(deliveryType);
	sb.append(processType);
	sb.append(dataType);
	sb.append(week);

	return sb.toString();

}
public String getProcessType() {
	return processType;
}
public String getSingleMagCode() {
	return singleMagCode.trim();
}
/**
 * This method was created by a SmartGuide.
 * @param size int
 */
public int getTrimSize () {
	return trimSize;
}
public String getWeek() {
	return week;
}
public int getWeekNumber() {
	return weekNumber;
}
/**
 * This method was created in VisualAge.
 */
public boolean isBackDate() {

	if ((processType.length() >= 4) && (processType.substring(0,4)).equalsIgnoreCase(BACKDATE) && dataType.equals(CUST)) {
		return true;
	}
	return false;
}
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean isBookVersionDriverCode() {
	if (dataType.equalsIgnoreCase(REPORTS) &&
		deliveryType.equalsIgnoreCase(DRIVER_CODE_BOOKVERSION)) {
		return true;
	}
	return false;
}
public boolean isCustData() {

	if (isMovableDataOnly() || isReportDataOnly() || isBookVersionDriverCode()){
		return false;
	}

	return true;
}
public boolean isEarlyStart() {
	if (processType.equals(MERGE) && dataType.equals(CUST)) {
		return true;
	}
	return false;
}
/**
 * This method was created in VisualAge.
 */
public boolean isInvalidFileName() {
	return invalidFileName;
}
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean isISALReport() {

		if (dataType.equalsIgnoreCase(REPORTS) &&
		deliveryType.equalsIgnoreCase(ISALRPT)) {
		return true;
	}
	return false;
}
public boolean isLengthOfRun() {
	if (processType.equals(STRIP) && dataType.equals(LOR)) {
		return true;
	}
	return false;
}
public boolean isMailDat() {
	if (dataType.equalsIgnoreCase(MAILDAT)) {
		return true;
	}
	return false;
}
/**
 * This method was created by a SmartGuide.
 */
public boolean isMovableDataOnly ( ) {

	if (isEarlyStart() || isPostalBook() || isStorageBook() || isQuickKill() || isLengthOfRun() ||
		isPostalBook2() || isStorageBook2())
		return true;
	else
		return false;

}
/**
 * This method was created by a SmartGuide.
 * @return boolean
 */
public boolean isNYBranchOfficeMagazine ( ) {
	if (processType.equals(OFFICE) && dataType.equals(CUST))
		return true;

	return false;
}
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean isOCCReport() {
	if (dataType.equalsIgnoreCase(REPORTS) &&
		deliveryType.equalsIgnoreCase(OCCRPT)) {
		return true;
	}
	return false;
}
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean isPackageSummary() {
	if (dataType.equalsIgnoreCase(REPORTS) &&
		deliveryType.equalsIgnoreCase(PACKAGE_SUMMARY)) {
		return true;
	}
	return false;
}
public boolean isPostalBook() {
	if (processType.equals(STRIP) && dataType.equals(POSTAL)) {
		return true;
	}
	return false;
}
public boolean isPostalBook2() {
	if (processType.equals(STRIP) && dataType.equals(POSTAL2)) {
		return true;
	}
	return false;
}
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean isPresortParameters() {
	if (dataType.equalsIgnoreCase(REPORTS) &&
		deliveryType.equalsIgnoreCase(PRESORT_PARAMETERS)) {
		return true;
	}
	return false;
}
public boolean isQuickKill() {
	if (processType.equals(REMOVE) && dataType.equals(CUST)) {
		return true;
	}
	return false;
}
/**
 * This method was created by a SmartGuide.
 */
public boolean isReportDataOnly ( ) {


	if (dataType.equalsIgnoreCase(REPORTS) || isMailDat())
		return true;
	else
		return false;

}
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean isRollSummary() {
	if (dataType.equalsIgnoreCase(REPORTS) &&
		deliveryType.equalsIgnoreCase(ROLLSUMMARY)) {
		return true;
	}
	return false;
}
public boolean isStorageBook() {
	if (processType.equals(STRIP) && dataType.equals(STORE)) {
		return true;
	}
	return false;
}
public boolean isStorageBook2() {
	if (processType.equals(STRIP) && dataType.equals(STORE2)) {
		return true;
	}
	return false;
}
public int olderThan(SybilMagazine m) {

	// Want to delete all data associated with the old magazine and issue
	// Delivery type does not matter.

	if (this.magCode.equals(m.magCode)) {
		return (Integer.parseInt(m.issue) - Integer.parseInt(this.issue));
	}
	else {
		return NOTSAMEMAGAZINE;
	}
}
/**
 * This method parses a file name for magazine information
 * @param s java.lang.String
 */
protected void parse(String s) {
	java.util.StringTokenizer st = new java.util.StringTokenizer(s, ".");

	try{
		setMagCode(st.nextToken().trim());
		issue = st.nextToken().substring(1, 5);
		plant = st.nextToken().trim();
		deliveryType = st.nextToken().trim();
		// check to see if the first 2 characters start with pl
		// if so, populate the labelDestination
		processType = st.nextToken().trim();
		dataType = st.nextToken().trim();
		week = st.nextToken().trim();
		if( st.hasMoreTokens()){
			try{
				weekNumber = Integer.parseInt(week);
			}catch( Exception ex){
				LogWriter.writeLog("E", "","", "Invalid file name format (week) <" + s + ">.");
				LogWriter.writeLog(ex);
				invalidFileName = true;
				return;
			}
			ext = st.nextToken().trim();
		} else {
			ext = week;
			week = "01";
		}

		invalidFileName = false;
	} catch( Exception e) {
		LogWriter.writeLog(e);
		LogWriter.writeLog("E", "", "", "Invalid file name format <" + s + ">.");
		invalidFileName = true;
		return;
	}
}
public void setDataType(String d) {
	dataType = d;
}
public void setDeliveryType(String d) {
	deliveryType = d;
}
public void setExtension(String e) {
	ext = e;
}
public void setIssue(String i) {
	issue = i;
}
public void setMagCode(String m) {
	magCode = m.toUpperCase();
	singleMagCode = magCode.substring(0,1);
}
public void setPlant(String p) {
	plant = p;
}
public void setProcessType(String p) {
	processType = p;
}
/**
 * This method was created by a SmartGuide.
 * @param size int
 */
public void setTrimSize (int size ) {
	trimSize = size;
	return;
}
public void setWeek(String w) {
	week = w;
	weekNumber = Integer.parseInt(week);
}
public String toString() {
	StringBuffer sb = new StringBuffer(50);
	sb.append(magName);
	sb.append(issue);
	sb.append(plant);
	sb.append(deliveryType);
	sb.append(processType);
	sb.append(dataType);
	return sb.toString();
}
}
