package sybilweb.plant.controller;

import java.util.*;
import java.io.*;
import java.util.zip.*;

/**
 *  This class handles all the business logic for inserting
 *  Early Starts, Postal books, Storage books, and
 *  Length of Run books.
 *
 *  Used in <a href=sybil_requirement_1.4.html#InsertExtraBooks>Insert Extra Books</a>
 *
 *
 *  @author Jeff Winks
 */

public class InsertExtraBooksHandler {

/// VERSION OF CLASS IN PRODUCTION ////
	public static final String Class_Version_Number = "PR_6.0_REL9.4";


	public static String EARLY_START_FILE_IDENTIFIER = ".merge.cust.";
	public static String POSTAL_BOOK_FILE_IDENTIFIER = ".strip.pobook.";
	public static String OMS_POSTAL_BOOK_IDENTIFIER = ".strip.pobook2.";
	public static String STORAGE_BOOK_FILE_IDENTIFIER = ".strip.storbook.";
	public static String OMS_STORAGE_BOOK_FILE_IDENTIFIER = ".strip.storbk2.";
	public static String LENGTH_OF_RUN_FILE_IDENTIFIER = ".strip.lorbook2.";

	boolean OMSCustomers = false;

	private boolean insertVirtualBooks = false;
	private int virtualBookCount = 0;

	private Address lengthOfRunBookAddress = null;
	private String LORBName = null;

	private Magazine mag;
	private String dataPath;
	private String rollID = null;


	private boolean isStorageBooksThisRoll = false;
	private boolean isPostalBooksThisRoll = false;
	private boolean isEarlyStartsThisRoll = false;


	private int lengthOfRunBookCounter = 0;
	private int lengthOfRunBookFrequency = -1; // from ini file
	private int noninkjetLengthOfRunBookFrequency = 0; // from ini file
	private int inkjetLengthOfRunBookFrequency = 0; // from ini file
	private int numberOfLengthOfRunBooks = 0;
	private String lengthOfRunFileName = null;

	private int numberOfStorageBooks = 0;
	private int numberOfPostalBooks = 0;

	private Vector postalBookRolls = null; // vector of all rolls that have postal books
	private Hashtable postalBooks = null; // table of postal book entries keyed on edition
	private Vector postalBooksThisRoll = null; // postal book editions for this roll
	private Vector customerPostalBooks = null;

	private Vector storageBookRolls = null;
	private Hashtable storageBooks = null;
	private Vector storageBooksThisRoll = null;
	private Vector customerStorageBooks = null;

	private String earlyStartFileName = null;
	private Vector earlyStartCustomerPackages = null; // keys off package for a given roll
	private Vector earlyStartCustomers = null; // contains all customers for that package for a given roll
	private Vector earlyStartRolls = null;
	private int earlyStartCustomerCount = 0;
	private boolean skipExtraLabeltokens = true;
	private boolean RLL5fileExists = false;
	
	private String studentMakeupCode = null;

/**
 * This method was created by a SmartGuide.
 */
public InsertExtraBooksHandler (String dir, Magazine magazine, boolean OMSCustomers) {
	String s = System.getProperty("file.separator");
	if (dir.endsWith(s)) {
		dataPath = dir;
	} else {
		dataPath = dir + s;
	}
	mag = magazine;
	this.OMSCustomers = OMSCustomers;
	String plant = mag.getPlant().trim();
	
	String virtualBookMags = PropertyBroker.getProperty("VirtualBookMagazines");
	virtualBookCount = Integer.parseInt(PropertyBroker.getProperty("VirtualBookCount","6"));
	
	if (virtualBookMags != null) {
		if ((virtualBookMags.indexOf((mag.getMagCode()+mag.getDeliveryType()+mag.getProcessType()).toUpperCase()) == -1) ||
			(virtualBookMags.startsWith("TK") && plant.equalsIgnoreCase("MCD")))
			insertVirtualBooks = false;
		else
			insertVirtualBooks = true;
	}
}
/**
 * This method was created in VisualAge.
 */
public void clearPostalStorageBooks() {
	customerPostalBooks = new Vector();
	customerStorageBooks = new Vector();
}
/**
 * This method was created by a SmartGuide.
 * @return HashTable
 */
public Hashtable getAllPostalBooks ( ) {
	return postalBooks;
}
/**
 * This method was created by a SmartGuide.
 * @return HashTable
 */
public Hashtable getAllStorageBooks ( ) {
	return storageBooks;
}
/**
 * This method was created in VisualAge.
 * @return java.util.Vector
 */
public Vector getCustomerPostalBooks() {
	return customerPostalBooks;
}
/**
 * This method was created in VisualAge.
 * @return java.util.Vector
 */
public Vector getCustomerStorageBooks() {
	return customerStorageBooks;
}
/**
 * This method was created by a SmartGuide.
 * @return java.util.Vector
 */
public Vector getEarlyStartCustomersThisRoll( ) {
	return earlyStartCustomerPackages;
}
/**
 * This method was created by a SmartGuide.
 * @return java.util.Vector
 */
public Vector getPostalBooksThisRoll( ) {
	return postalBooksThisRoll;
}
/**
 * This method was created by a SmartGuide.
 * @return java.util.Vector
 */
public Vector getStorageBooksThisRoll( ) {
	return storageBooksThisRoll;
}
/**
 * This method was created by a SmartGuide.
 */
public void initEarlyStartRolls () {

	ZipFile zf = null;

	String earlyStartMags = PropertyBroker.getProperty("EarlyStartMagazines");

	if ( (earlyStartMags == null) || (earlyStartMags.indexOf((mag.getMagCode()+mag.getDeliveryType()+mag.getProcessType()).toUpperCase()) == -1))
		return;

	File f = new File(dataPath, mag.getCommonPrefix() + EARLY_START_FILE_IDENTIFIER + mag.getCommonSuffix());

	earlyStartFileName = f.getPath();

	if (!f.exists())
		return;

	earlyStartRolls = new Vector();

	try {
		zf = new ZipFile(earlyStartFileName);
		Enumeration e = zf.entries();
		while (e.hasMoreElements()) {
			ZipEntry ze = (ZipEntry) e.nextElement();
			earlyStartRolls.addElement(ze.getName());
		}
		zf.close();
	} catch (Exception e) {
		LogWriter.writeLog(e);		
		e.printStackTrace();
		return;
	}
	return;
}
/**
 * This method was created by a SmartGuide.
 */
public void initLengthOfRunBooks ( ) {

	numberOfLengthOfRunBooks = Integer.parseInt(PropertyBroker.getProperty("NumberOfLengthOfRunBooks","0"));
	noninkjetLengthOfRunBookFrequency = Integer.parseInt(PropertyBroker.getProperty("LengthOfRunBookFrequency","0"));
	inkjetLengthOfRunBookFrequency = Integer.parseInt(PropertyBroker.getProperty("InkjetLengthOfRunBookFrequency","0"));

	lengthOfRunBookAddress = new Address();

	LORBName = PropertyBroker.getProperty("LORBName","NO LORB NAME");

	lengthOfRunBookAddress.setLine1(PropertyBroker.getProperty("LORBAddress1","NO LORB ADDRESS"));
	lengthOfRunBookAddress.setLine2(PropertyBroker.getProperty("LORBAddress2","NO LORB ADDRESS "));
	lengthOfRunBookAddress.setCity(PropertyBroker.getProperty("LORBCity","NO CITY"));
	lengthOfRunBookAddress.setState(PropertyBroker.getProperty("LORBState","  "));
	lengthOfRunBookAddress.setZipCode(PropertyBroker.getProperty("LORBZip","NOZIP"));
	lengthOfRunBookAddress.setZipPlus4(PropertyBroker.getProperty("LORBZipPlus4",""));

	if(mag.getDeliveryType().trim().equalsIgnoreCase("usps")) {
		String LORBTempBC = ((lengthOfRunBookAddress.getZipCode()) + (lengthOfRunBookAddress.getZipPlus4()));
		int LOR_BarCode = (Integer.valueOf(LORBTempBC).intValue());
		lengthOfRunBookAddress.setBarcode(LOR_BarCode);
	}


	return;
}
/**
 * This method was created by a SmartGuide.
 */
public void initLengthOfRunBooksFromFile() {
	ZipFile zf = null;
	InputStream zis = null;
	BufferedReader bfr = null;
	InputStreamReader isr = null;
	
	int POS_FREQUENCY = 24;
	
	String lorMags = PropertyBroker.getProperty("LengthOfRunMagazines");
	if ((lorMags == null) || (lorMags.indexOf((mag.getMagCode() + mag.getDeliveryType() + mag.getProcessType()).toUpperCase()) == -1)){
		numberOfLengthOfRunBooks = 0;
		return;
	}	
	File f = new File(dataPath, mag.getCommonPrefix() + LENGTH_OF_RUN_FILE_IDENTIFIER + mag.getWeek()+ ".zip");
	lengthOfRunFileName = f.getPath();
	if (!f.exists())
		return;

	try {
		zf = new ZipFile(lengthOfRunFileName);
		Enumeration e = zf.entries();
		if (e.hasMoreElements())
			zis = zf.getInputStream((ZipEntry) e.nextElement());
		else {
			LogWriter.writeLog(new Exception(mag.getCommonPrefix() + ": Length Of Run File Error! There is no file entry in <" + lengthOfRunFileName + ">"));
			zis.close();
			return;
		}

			if (PropertyBroker.getProperty("MVS", "false").equals("true")) {
				
				isr = new InputStreamReader(zis, "ISO8859_1");
			}
			else {
				isr = new InputStreamReader(zis);
			}

		bfr = new BufferedReader(isr);
		//		if( !bfr.ready()) return;
		String line = bfr.readLine();
		if (line != null) {
			int fre;
			try {

				// Set the number of LOR books, frequency for non-inkjet and inkjet
				fre = Integer.parseInt(line.substring(POS_FREQUENCY, POS_FREQUENCY + 7).trim());
			} catch (Exception ee) {
				try {
					bfr.close();
					zis.close();
					zf.close();
				} catch (IOException ioe) {
						ioe.printStackTrace();
					}
				return;
			}
			lengthOfRunBookFrequency = fre;
			noninkjetLengthOfRunBookFrequency = fre;
			inkjetLengthOfRunBookFrequency = fre;
			LogWriter.writeLog("I", mag.getPlant().trim().toUpperCase() , mag.getPrefix().trim(),  ": LOR frequency set to " + fre);
		}

	} catch (EOFException ee) {
		LogWriter.writeLog(ee);
		ee.printStackTrace();
	} catch (Exception ex) {
		LogWriter.writeLog(ex);		
		ex.printStackTrace();
	}
	try {
		bfr.close();
		zis.close();
		zf.close();
	} catch (IOException ioe) {
		LogWriter.writeLog(ioe);		
		ioe.printStackTrace();
	}
	return;
}
/**
 * This method was created by a SmartGuide.
 * @param postalbooks java.util.Hashtable
 */
public void initPostalBooks () {

	SybilIssueCustomerFileParser pb = null;

	BufferedReader fileReader = null;
	ZipFile zf = null;
	InputStream zis = null;
	InputStreamReader isr = null;

	String postalBookCount = PropertyBroker.getProperty((mag.getMagCode()+mag.getDeliveryType()+mag.getProcessType()).toUpperCase() + "PostalBooks");

	if ( postalBookCount != null) {
		numberOfPostalBooks = Integer.parseInt(postalBookCount);  // Need to be able to modify this!
	}else {
		numberOfPostalBooks = -1;
		return;
	}

	File f;

	if( !OMSCustomers)
		f = new File (dataPath, mag.getCommonPrefix() + POSTAL_BOOK_FILE_IDENTIFIER + mag.getWeek()+ ".zip");
	else
		f = new File (dataPath, mag.getCommonPrefix() + OMS_POSTAL_BOOK_IDENTIFIER + mag.getWeek()+ ".zip");


	if (!f.exists()) {
		LogWriter.writeLog("E", mag.getPlant().toUpperCase(), mag.getPrefix(), "PostalBook zip file"+ f +" doesnot exists ");
		return;
	}

		pb = new SybilIssueCustomerFileParser();

		try {
			zf = new ZipFile(f);
			zis = zf.getInputStream(zf.getEntry("POBOOK"));
			if (PropertyBroker.getProperty("MVS", "false").equals("true")) {
				
				isr = new InputStreamReader(zis, "ISO8859_1");
			}
			else {
				isr = new InputStreamReader(zis);
			}
			
			fileReader = new java.io.BufferedReader(isr);
		} catch (Exception e) {
			LogWriter.writeLog(e);			
			e.printStackTrace();
			return;
		}

		StoragePostalBook spb = new StoragePostalBook();
		postalBooks = new Hashtable();
		postalBookRolls = new Vector();

		try {
			while (pb.parseFile(fileReader,spb)) {
				if( !OMSCustomers)
					spb.setCopyCount(numberOfPostalBooks);
				postalBooks.put(spb.getEditionCode(),spb);
				if (!postalBookRolls.contains(spb.getRollNumber())) {
					postalBookRolls.addElement(spb.getRollNumber());
				}
				spb = new StoragePostalBook();

			}
		}catch (EOFException ee) {
			LogWriter.writeLog(ee);
			ee.printStackTrace();
		}catch (Exception ex) {
			LogWriter.writeLog(ex);			
			ex.printStackTrace();
		}

		try {
			fileReader.close();
			zis.close();
			zf.close();
		} catch (Exception e) {
			LogWriter.writeLog(e);	
			e.printStackTrace();	
		}

	return;
}
/**
 * This method was created by a SmartGuide.
 * @param postalbooks java.util.Hashtable
 */
public void initStorageBooks () {


	SybilIssueCustomerFileParser pb = null;
	BufferedReader fileReader = null;
	FileReader fr = null;
	ZipFile zf = null;
	InputStream zis = null;
	InputStreamReader isr = null;

	String storageBookCount = PropertyBroker.getProperty((mag.getMagCode()+mag.getDeliveryType()+mag.getProcessType()).toUpperCase() + "StorageBooks");

	if ( (storageBookCount != null)) {
		numberOfStorageBooks = Integer.parseInt(storageBookCount); // Need to be able to modify this
	} else {
		numberOfStorageBooks = -1;
		return;
	}

	File f;

	if( !OMSCustomers)
		f = new File (dataPath, mag.getCommonPrefix() + STORAGE_BOOK_FILE_IDENTIFIER + mag.getWeek()+ ".zip");
	else
		f = new File (dataPath, mag.getCommonPrefix() + OMS_STORAGE_BOOK_FILE_IDENTIFIER + mag.getWeek()+ ".zip");


	if (!f.exists()){
		LogWriter.writeLog("E", mag.getPlant().toUpperCase(), mag.getPrefix(), "StorageBook zip file"+ f +" doesnot exists ");		
		return;
	}

		pb = new SybilIssueCustomerFileParser();

		try {
			zf = new ZipFile(f);
			zis = zf.getInputStream(zf.getEntry("STORBOOK"));
			if (PropertyBroker.getProperty("MVS", "false").equals("true")) {
				
				isr = new InputStreamReader(zis, "ISO8859_1");
			}
			else {
				isr = new InputStreamReader(zis);
			}
			
			fileReader = new java.io.BufferedReader(isr);
		} catch (Exception e) {
			LogWriter.writeLog(e);		
			e.printStackTrace();
			return;
		}

		StoragePostalBook spb = new StoragePostalBook();
		storageBooks = new Hashtable();
		storageBookRolls = new Vector();

		try {
			while (pb.parseFile(fileReader,spb)) {
				if( !OMSCustomers)
					spb.setCopyCount(numberOfStorageBooks);
				storageBooks.put(spb.getEditionCode(),spb);
				if (!storageBookRolls.contains(spb.getRollNumber()))
					storageBookRolls.addElement(spb.getRollNumber());

				spb = new StoragePostalBook();

			}
		}catch (EOFException ee) {
			LogWriter.writeLog(ee);		
			ee.printStackTrace();
		}catch (Exception ex) {
			LogWriter.writeLog(ex);		
			ex.printStackTrace();
		}
		try {
			fileReader.close();
			zis.close();
			zf.close();
		} catch (Exception e) {
			LogWriter.writeLog(e);		
			e.printStackTrace();
		}

	return;
}
/**
 * This method was created by a SmartGuide.
 */
private void insertEarlyStartCustomers(Vector customerPackage) {
// insert early start customers at beginning of vector

	Vector issueCustomers = null;
	int numberOfCustomers = 0, i = 0;
	IssueCustomer ic = null;

	issueCustomers = (Vector)earlyStartCustomerPackages.elementAt(0);

	numberOfCustomers = issueCustomers.size(); 	// number of customers in package

	for (i = 0; i < numberOfCustomers; i++) {
		ic = (IssueCustomer)issueCustomers.elementAt(i);
		customerPackage.insertElementAt(ic,0);
	}

	earlyStartCustomerCount += i;

	return;

}
/**
 * This method was created by a SmartGuide.
 * @param customerPackage java.util.Vector
 * @param rollID java.lang.String
 */
public void insertExtraBooks (Vector customerPackage, String rollID , boolean skipExtraLabeltokens, boolean LOR_Cust_File_Entry, boolean RLL5fileExists) throws Exception {

	int customerCounter = 0;
	int numberOfCustomers = 0;
	String edition;
	int packageNumber = 0;
	Vector issueCustomers = null;

	this.skipExtraLabeltokens = skipExtraLabeltokens;
	this.RLL5fileExists = RLL5fileExists;	

// if rollID changes, set variables to see if there are early start records, postal books, or storage books
// for the current roll.

	if ((this.rollID == null) || (this.rollID != rollID)) {


		this.rollID = rollID; // set current roll

		isPostalBooksThisRoll = false;
		isStorageBooksThisRoll = false;
		isEarlyStartsThisRoll = false;

		if (postalBookRolls != null) {
			if (postalBookRolls.contains(rollID)) {
				isPostalBooksThisRoll = true;
				loadPostalBooks();
			}
		}

		if (storageBookRolls != null) {
			if (storageBookRolls.contains(rollID)) {
				isStorageBooksThisRoll = true;
				loadStorageBooks();
			}
		}

		if (earlyStartRolls != null) {
			if (earlyStartRolls.contains(rollID)) {
				isEarlyStartsThisRoll = true;
				earlyStartCustomerCount = 0;
				// CHANGE
				try {
					loadEarlyStartCustomers();
				} catch (Exception warning) {
					warning.printStackTrace();
				}
			}
		}

	}


	if (isEarlyStartsThisRoll) {

		packageNumber = (((IssueCustomer)(customerPackage.elementAt(0))).getPackageNumber());
		issueCustomers = (Vector)earlyStartCustomerPackages.elementAt(0);

		if ( ((IssueCustomer)(issueCustomers.elementAt(0))).getPackageNumber() == packageNumber) {
			insertEarlyStartCustomers(customerPackage);
			earlyStartCustomerPackages.removeElementAt(0);
			if (earlyStartCustomerPackages.size() == 0) {
				earlyStartCustomerPackages = null;
				earlyStartCustomers = null;
				isEarlyStartsThisRoll = false;
				LogWriter.writeLog("I", mag.getPlant().trim() , mag.getPrefix().trim(), ": Inserted " + earlyStartCustomerCount + " early start customers into roll " + rollID);
				earlyStartCustomerCount = 0;
			}
		}
	}

	if (insertVirtualBooks)
		insertVirtualBooks(customerPackage,rollID);

	if (isPostalBooksThisRoll || isStorageBooksThisRoll || (numberOfLengthOfRunBooks > 0) ) {
		numberOfCustomers = customerPackage.size();

		for (customerCounter = 0; customerCounter < numberOfCustomers; customerCounter++) {

			if( !OMSCustomers)
				edition = ((IssueCustomer)(customerPackage.elementAt(customerCounter))).getEditionCode();
			else
				edition = ((IssueCustomer)(customerPackage.elementAt(customerCounter))).getBookVersion();


			if (isPostalBooksThisRoll) {
				if (postalBooksThisRoll.contains(edition)) {
 					insertPostalBooks(customerPackage,customerCounter,edition);
					postalBooksThisRoll.removeElement(edition);
					if (postalBooksThisRoll.size() == 0) {
						postalBooksThisRoll = null;
						isPostalBooksThisRoll = false;
					}
				}
			}


			if (isStorageBooksThisRoll) {
				if (storageBooksThisRoll.contains(edition)) {
 					insertStorageBooks(customerPackage,customerCounter,edition);
					storageBooksThisRoll.removeElement(edition);
					if (storageBooksThisRoll.size() == 0) {
						storageBooksThisRoll = null;
						isStorageBooksThisRoll = false;
					}
				}
			}

		}

			  /*
			  	if new LOR_Cust Entry is not there in zip
			  	file insert LOR Cust as old logic
			  */
		
	if(LOR_Cust_File_Entry == false){
			
		if (numberOfLengthOfRunBooks > 0) {
			lengthOfRunBookCounter += customerPackage.size();
			if ((lengthOfRunBookCounter >= lengthOfRunBookFrequency)) {
				insertLengthOfRunBooks(customerPackage);
				lengthOfRunBookCounter = 0;
			}
		}
	}	
}

	return;
}
/**
 * This method was created by a SmartGuide.
 * @param IssueCustomers Vector
 */
private void insertLengthOfRunBooks(Vector issueCustomers) {

	IssueCustomer lengthOfRunBook = null;
	int i = 0;

	for (i = 0; i < numberOfLengthOfRunBooks; i ++) {

		try {
			IssueCustomer ic = (IssueCustomer)(issueCustomers.elementAt(0));
			lengthOfRunBook = (IssueCustomer) ic.clone();
		}catch(Exception e) {
			LogWriter.writeLog(e);			
			e.printStackTrace();
			return;
		}

		lengthOfRunBook.setEndPackageIndicator(true);
		lengthOfRunBook.setTCSKeyline(" ");
		lengthOfRunBook.getMagazineLabel().setLengthOfRunBookFields(LORBName,lengthOfRunBookAddress,rollID);
		issueCustomers.addElement(lengthOfRunBook);
	}

	return;
}
/**
 * This method was created by a SmartGuide.
 * @param IssueCustomers java.util.Vector
 */
private void insertPostalBooks (Vector issueCustomers, int customerNumber, String edition) {


	IssueCustomer postalBook = null;
	int postalBookNumber = 0, i = 0;
	String palletSackNumber = "";
	String USZipCode = "";
	
	if(numberOfPostalBooks == -1) return;

	postalBookNumber = Integer.parseInt(((StoragePostalBook)(postalBooks.get(edition))).getPostalBookNumber());

	numberOfPostalBooks	 = ((StoragePostalBook)(postalBooks.get(edition))).getCopyCount();

	for (i = 0; i < numberOfPostalBooks; i ++) {

		try {
			IssueCustomer ic = (IssueCustomer)(issueCustomers.elementAt(customerNumber));
			palletSackNumber = String.valueOf(ic.getPalletSackNumber());
			USZipCode = ic.getMagazineLabel().USzipCode;			
			postalBook =  (IssueCustomer) ic.clone();
		}catch(Exception e) {
			LogWriter.writeLog(e);
			return;
		}

		postalBook.setEndPackageIndicator(true);
		postalBook.setTCSKeyline(" ");
		postalBook.getMagazineLabel().setPostalBookLabelFields(edition,postalBookNumber,i+1,numberOfPostalBooks,USZipCode,palletSackNumber);
		customerPostalBooks.addElement(postalBook);
	}

//	LogWriter.writeLog("I", mag.getPlant().trim().toUpperCase() , mag.getPrefix().trim(), ":  Inserted " + i + " POSTAL book(s) into roll " + rollID + " with edition " + edition);

return;
}
/**
 * This method was created by a SmartGuide.
 */
private void insertStorageBooks (Vector issueCustomers, int customerNumber, String edition) {

	IssueCustomer storageBook = null;
	int i = 0;
	String palletSackNumber = "";
	String USZipCode = "";

	if( numberOfStorageBooks == -1) return;

	numberOfStorageBooks = ((StoragePostalBook)(storageBooks.get(edition))).getCopyCount();

	for (i = 0; i < numberOfStorageBooks; i ++) {

		try {
			IssueCustomer ic = (IssueCustomer)(issueCustomers.elementAt(customerNumber));
			palletSackNumber = String.valueOf(ic.getPalletSackNumber());
			USZipCode = ic.getMagazineLabel().USzipCode;			
			storageBook = (IssueCustomer) ic.clone();
		}catch(Exception e) {
			LogWriter.writeLog(e);
			e.printStackTrace();
			return;
		}

		storageBook.setEndPackageIndicator(true);
		storageBook.setTCSKeyline(" ");
		storageBook.getMagazineLabel().setStorageBookLabelFields(edition,i+1,numberOfStorageBooks,USZipCode,palletSackNumber);

		customerStorageBooks.addElement(storageBook);
	}

}
/**
 * This method was created in VisualAge.
 * @param customerPackage java.util.Vector
 */
private void insertVirtualBooks(Vector customerPackage, String rollID) {

	int numberOfCustomers = 0, i = 0;
	IssueCustomer virtualCustomer = null, vc = null, lastCust = null, icG = null;  //, icG1 = null;
	String makeupCode = "0000";

	numberOfCustomers = customerPackage.size(); 	// number of customers in package

	if (numberOfCustomers < virtualBookCount) {

		if (numberOfCustomers > 1) {
			icG = (IssueCustomer)(customerPackage.elementAt(1));
			studentMakeupCode =  icG.getMakeupCode();
		}
		virtualCustomer = (IssueCustomer)(customerPackage.elementAt(numberOfCustomers-1));
		lastCust = (IssueCustomer)virtualCustomer.clone();
		
		virtualCustomer.setEndPackageIndicator(false);
		virtualCustomer.setEndPalletSackIndicator(false);
		virtualCustomer.getMagazineLabel().clear();
		if (mag.getPlant().trim().equalsIgnoreCase("MCD"))
			virtualCustomer.setMakeupCode("999");
		else
			virtualCustomer.setMakeupCode(makeupCode);
		
		if (numberOfCustomers == 1)
			virtualCustomer.setMakeupCode(studentMakeupCode);
		
		virtualCustomer.setNumberOfMessages(0);
		virtualCustomer.setCustomerName("VIRTUAL BOOK");


		for (i = numberOfCustomers; i < (virtualBookCount - 1); i++) {
			vc = (IssueCustomer)virtualCustomer.clone();
			customerPackage.addElement(vc);
		}

		lastCust.setEndPackageIndicator(true);
		customerPackage.addElement(lastCust);

	}

	return;

}
/**
 * This method was created by a SmartGuide.
 * @return boolean
 */
public boolean isEarlyStartCustomersThisRoll ( ) {
	return this.isEarlyStartsThisRoll;
}
/**
 * This method was created by a SmartGuide.
 * @return boolean
 */
public boolean isEarlyStartFilePresent ( ) {

	String earlyStartMags = PropertyBroker.getProperty("EarlyStartMagazines");

	if ( (earlyStartMags != null) && (earlyStartMags.indexOf((mag.getMagCode()+mag.getDeliveryType()+mag.getProcessType()).toUpperCase()) != -1)) {
		File f = new File (dataPath, mag.getCommonPrefix() + EARLY_START_FILE_IDENTIFIER + mag.getCommonSuffix());
		return f.exists();
	}else
		return true;

}
/**
 * This method was created by a SmartGuide.
 * @return boolean
 */
public boolean isLengthOfRunFilePresent ( ) {

	String lorMags = PropertyBroker.getProperty("LengthOfRunMagazines");

	if ( (lorMags != null) && (lorMags.indexOf((mag.getMagCode()+mag.getDeliveryType()+mag.getProcessType()).toUpperCase()) != -1)) {
		File f = new File (dataPath, mag.getCommonPrefix() + LENGTH_OF_RUN_FILE_IDENTIFIER + mag.getCommonSuffix());
		return f.exists();
	}else
		return true;


}
/**
 * This method was created by a SmartGuide.
 * @return boolean
 */
public boolean isPostalBookFilePresent ( ) {

	String postalBookCount = PropertyBroker.getProperty((mag.getMagCode()+mag.getDeliveryType()+mag.getProcessType()).toUpperCase() + "PostalBooks");

	if ( (postalBookCount != null) && (Integer.parseInt(postalBookCount) != 0)) {
		numberOfPostalBooks = Integer.parseInt(postalBookCount);

		File f;
		if( !OMSCustomers)
			f = new File (dataPath, mag.getCommonPrefix() + POSTAL_BOOK_FILE_IDENTIFIER + mag.getCommonSuffix());
		else
			f = new File (dataPath, mag.getCommonPrefix() + OMS_POSTAL_BOOK_IDENTIFIER + mag.getCommonSuffix());

		return f.exists();
	}else{
		numberOfPostalBooks = 0;
		return true;
	}

}
/**
 * This method was created by a SmartGuide.
 * @return boolean
 */
public boolean isPostalBooksThisRoll ( ) {
	return this.isPostalBooksThisRoll;
}
/**
 * This method was created by a SmartGuide.
 */
public boolean isStorageBookFilePresent ( ) {

	String storageBookCount = PropertyBroker.getProperty((mag.getMagCode()+mag.getDeliveryType()+mag.getProcessType()).toUpperCase() + "StorageBooks");

	if ( (storageBookCount != null) && (Integer.parseInt(storageBookCount) != 0)) {
		numberOfStorageBooks = Integer.parseInt(storageBookCount);

		File f;
		if( !OMSCustomers)
			f = new File (dataPath, mag.getCommonPrefix() + STORAGE_BOOK_FILE_IDENTIFIER + mag.getCommonSuffix());
		else
			f = new File (dataPath, mag.getCommonPrefix() + OMS_STORAGE_BOOK_FILE_IDENTIFIER + mag.getCommonSuffix());

		return f.exists();
	}else{
		numberOfStorageBooks = 0;
		return true;
	}



}
/**
 * This method was created by a SmartGuide.
 * @return boolean
 */
public boolean isStorageBooksThisRoll ( ) {
	return this.isStorageBooksThisRoll;
}
public boolean lengthOfRunBookFreqSet() {
//	if ( (numberOfLengthOfRunBooks == 0) || (lengthOfRunBookFrequency != -1)) {
	if ( lengthOfRunBookFrequency != -1) {
		return true;
	}
	else {
		initLengthOfRunBooksFromFile();
		if( lengthOfRunBookFrequency != -1)
			return true;
	}

	return false;
}
/**
 * This method was created by a SmartGuide.
 * @param rollID java.lang.String
 */
private void loadEarlyStartCustomers ( ) throws sybilweb.plant.controller.SybilWarningException {

	// open up roll file in zip and read in all customers, storing the package numbers and customers in
	// each package as vectors in a hashtable.

	ZipFile zf = null;
	InputStream zis = null;
	BufferedInputStream bis = null;
	DataInputStream dis = null;
	int oldPackageNumber = -1;
	SybilIssueCustomerFileParser inFile = new SybilIssueCustomerFileParser();

	try {
		zf = new ZipFile(earlyStartFileName);
		zis = zf.getInputStream(zf.getEntry(rollID));
		bis = new BufferedInputStream(zis);
		dis = new DataInputStream(bis);
	} catch (Exception e) {
		e.printStackTrace();
		return;
	}

	IssueCustomer earlyStartCustomer = new IssueCustomer();

	earlyStartCustomers = new Vector();
	earlyStartCustomerPackages = new Vector();

  try {
	while(inFile.parseFile(dis,earlyStartCustomer,skipExtraLabeltokens,RLL5fileExists)) {
		if (oldPackageNumber == -1) // first time
			oldPackageNumber = earlyStartCustomer.getPackageNumber();

		if (oldPackageNumber == earlyStartCustomer.getPackageNumber())
			earlyStartCustomers.addElement(earlyStartCustomer);
		else {
			oldPackageNumber = earlyStartCustomer.getPackageNumber();
			earlyStartCustomerPackages.addElement(earlyStartCustomers);
			earlyStartCustomers = new Vector();
			earlyStartCustomers.addElement(earlyStartCustomer);
		}
		earlyStartCustomer = new IssueCustomer();
	}
  } catch (sybilweb.plant.controller.SybilWarningException warning) {
  		sybilweb.plant.controller.SybilWarningException warn = new sybilweb.plant.controller.SybilWarningException("Error occurred reading " + earlyStartFileName + " at roll " + rollID + ".  " + warning.getMessage());

		try {
			dis.close();
			bis.close();
			zis.close();
			zf.close();
		} catch (Exception e) {
			LogWriter.writeLog(e);		
			e.printStackTrace();
		}
  		throw warn;
  	} catch (Exception e) {
		LogWriter.writeLog(e);		
		e.printStackTrace();
  	}
	if (earlyStartCustomers.size() != 0)
		earlyStartCustomerPackages.addElement(earlyStartCustomers);

	try {
		dis.close();
		bis.close();
		zis.close();
		zf.close();
	} catch (Exception e) {
		LogWriter.writeLog(e);		
		e.printStackTrace();
  }

	return;
}
/**
 * This method was created by a SmartGuide.
 * @param rollID java.lang.String
 */
private void loadPostalBooks() {

	StoragePostalBook pbe = null;

	postalBooksThisRoll = new Vector();

  for (Enumeration e = postalBooks.elements() ; e.hasMoreElements() ;) {

		pbe = (StoragePostalBook)e.nextElement();
		if (pbe.getRollNumber().equals(rollID)) {
			postalBooksThisRoll.addElement(pbe.getEditionCode());
			if(OMSCustomers)
				numberOfPostalBooks = pbe.getCopyCount();
		}

	}

	return;
}
/**
 * This method was created by a SmartGuide.
 * @param rollID java.lang.String
 */
private void loadStorageBooks () {

	StoragePostalBook sbe = null;

	storageBooksThisRoll = new Vector();

  for (Enumeration e = storageBooks.elements() ; e.hasMoreElements() ;) {

		sbe = (StoragePostalBook)e.nextElement();
		if (sbe.getRollNumber().equals(rollID)){
			storageBooksThisRoll.addElement(sbe.getEditionCode());

			if(OMSCustomers)
				numberOfStorageBooks = sbe.getCopyCount();
		}

	}

	return;
}
public void useInkjetFreq(boolean b) {
	if (b) {
		lengthOfRunBookFrequency = inkjetLengthOfRunBookFrequency;
	}
	else {
		lengthOfRunBookFrequency = noninkjetLengthOfRunBookFrequency;
	}

//	LogWriter.writeLog(mag.getPrefix() + ":  Length Of Run Book Frequency set to " + lengthOfRunBookFrequency);
}
}
