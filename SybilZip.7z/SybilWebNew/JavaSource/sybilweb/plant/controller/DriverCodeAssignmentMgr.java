package sybilweb.plant.controller;

/**
 * This type was created in VisualAge.
 */
import java.util.*;
import java.io.*;


public abstract class DriverCodeAssignmentMgr {

	protected Magazine mag;
	protected String driverCodeFileName = null;
	public Vector invalidBV = null;
	public StringBuffer errormessage = null;


/**
 * DriverCodeAssignmentMgr constructor comment.
 */
public DriverCodeAssignmentMgr() {
	super();
}
/**
 * DriverCodeAssignmentMgr constructor comment.
 */
public DriverCodeAssignmentMgr(Magazine mag) {
	super();

	this.mag = mag;



	String plant = mag.getPlant().trim();
	

/*	
	
	try {
		
	   sybilweb.plant.controller.PropertyBroker.load(sybilweb.plant.controller.PropertyBroker.inipath);
	
	} catch(Exception e){ System.out.println("could not able to load ini file in MessageParameterFileMgr"); }
	
	String inipath = PropertyBroker.getProperty("LogFileDirectory");
	
	inipath = inipath.concat(plant.toUpperCase());
	
	inipath = inipath.concat("/SybilPlant");
	
	inipath = inipath.concat(plant.toUpperCase());
	
	inipath = inipath.concat(".ini");

	try {
		
	PropertyBroker.load(inipath);
	
	} catch(Exception e){ System.out.println("could not load "+inipath+"file in MessageParameterFileMgr"); }	


*/
	

	String prop = PropertyBroker.getProperty("DriverCodeFilePath");


	String newFName = (mag.getMagIssuePlantPrefix() + "." +
						SybilMagazine.DRIVER_CODE_BOOKVERSION + "." +
						SybilMagazine.DRIVERCODE + "." +
						SybilMagazine.REPORTS + "." +
						mag.getWeek() +
						".drc.processed").toLowerCase();

	if (prop != null)
		driverCodeFileName = prop + newFName;

}
/**
 * This method was created in VisualAge.
 * @param customer IssueCustomer
 */
public void assignDriverCode(Vector issueCustomers)
{
	int size = issueCustomers.size();

	for (int i = 0; i < size; i++){
		assignDriverCode((IssueCustomer)issueCustomers.elementAt(i));
	}

	return;
}
/**
 * This method was created in VisualAge.
 * @param customer IssueCustomer
 */
public abstract void assignDriverCode(IssueCustomer customer);
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean driverCodeFileExists() {

	if (driverCodeFileName == null || mag.isBackDate())
		return false;
	else
		return (new File(driverCodeFileName)).exists();

}
/**
 * This method was created in VisualAge.
 * @param fileName char
 */
public abstract boolean loadDriverCodes();
}
