package sybilweb.plant.controller;

/**
 * Insert the type's description here.
 * Creation date: (2/22/01 10:38:31 AM)
 * @author: Srikanth Bapanapalli
 */

import java.io.*;
import java.util.*;
 
public class PropertyBroker {

private static Properties props = new Properties();
public static String inipath = null;
public static String maininipath = null;

/**
 * PropertyBroker constructor comment.
 */
public PropertyBroker() {
	super();
}
/**
 * This method was created in VisualAge.
 * @return java.util.Properties
 */
public static Properties getProperties() {
	return props;
}
	/** Get the value of a property.
	 *
	 *  @params  key - the property whose value is desired
	 *  @return  the value of the input property
	 */
	public static String getProperty(String key) {
		return props.getProperty(key);
	}
	/** Get the value of a property. If the property is not found in the
	 *  property file, return the supplied default value.
	 *
	 *  @params  key - the property whose value is desired
	 *  @params  default - the value to return when the property is not
	 *               found in the property list
	 *  @return  the value of the input property
	 */
	public static String getProperty(String key, String defaultValue) {
		return props.getProperty(key, defaultValue);
	}
	/** Load a properties file in the static instance.
	 *
	 *  @params  name - the properties file name
	 */
	public static void load(String name) throws IOException {
		
		props.load(new FileInputStream(name));
				 
	}
/**
 * This method was created by a SmartGuide.
 * @return boolean
 * @param prop java.lang.String
 */
public static boolean validProperty(String key) {
	
	String prop = props.getProperty(key);
	
	if (prop == null) return false;
	else return true;

}
}
