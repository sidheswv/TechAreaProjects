package sybilweb.plant.controller;

import java.io.Serializable;
import sybil.common.util.LogWriter;


public abstract class MagazineLabel implements Serializable, Cloneable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final String Class_Version_Number = "STM_Jay_PSBULK";
	
    public static String LabelLine8 = PropertyBroker.getProperty("LabelLine8");
    public static String oldLL8 = PropertyBroker.getProperty("oldLL8");
    
    public static final int MAGAZINELABELSIZE = 38;
    public static final int TK_MAGAZINELABELSIZE = 40;
    public static final int s_NUM_TEXT_LINES = 8;
    
    private String m_labelJustificationCategory;
    
    private Message extendedLabelAreaMessage = null;
    
    public int labelJustification;
    private String m_labelTypeMedia;
     
    protected TextLine[] m_TextLine = new TextLine[s_NUM_TEXT_LINES];

    public String labelType;
    
    public boolean suppressSequenceNumber;
    public String acsKeyline;
    public String line2Type;
    public String magCode;
    public String continentID;
    public String editionCode;
    public String alphaExpireDate;
    public String customerName;
    public String makeupCode;
    public boolean endOfPackageIndicator;
    
    public String addressLine2;
    protected int labelNumber;
    public boolean endofPalletSackIndicator;
    public String addressLine1;
    public String palletSackIndicator;
    public String palletSackNumber;
    public String packageNumber;
    public String city;
    public String state;
    public String imbBarcode;
    public String imbBarcodeData;
    public String barcode;
    public String barcodeCheckDigit;
    public String LabelDropIn;
    public String Plant_ID;
    public int pack_count;
    public String GeoComboName;
    public String rideAlongIND;
    public String wrhseAcctNum;
    public String rnwlEffKy1;
    public String rnwlLttr;
    public String msg1WarningIND;
    public String fam1MsgID;
    public String fam1DemoNme;
    public String msg2WarningIND;
    public String fam2MsgID;
    public String fam2DemoNme;
    public String msg3WarningIND;
    public String fam3MsgID;
    public String fam3DemoNme;
    public String msg4WarningIND;
    public String fam4MsgID;
    public String fam4DemoNme;
    public String sigNameOrientation;
    public String signatureName;
    public boolean endSchoolFlag;
    public String classSeqNumber;
    public String labelMagCode;
    public String copyCnt;
    
    String LL8Override = null;
	String nonLL8Plant = null;
	String RLL5value = null;
	
    public String publicationCode;
    public String endorsementLine;
    public String USzipCode;
    public String zipPlus4;
    
    public String canadianCarrierLiteral;
    public String canadianNonDirect;
    public String carrierRouteNumber;
    public String canadianMonthCode;
    public String canadianZipCode;
    public String canadianOEL;
    public String SchoolCopyCount;
    
    char barcode_head = '\u007C';
	char barcode_tail = '\u007C';
	char TK_Bundle = '\u005F';
	int barcodeLength = 0;
	
    String length = PropertyBroker.getProperty((new StringBuilder(String.valueOf(magCode))).append("BarcodeSize").toString(), "38");

    public MagazineLabel(){
    }

    public MagazineLabel(String label) {        
    }

    public void checkPreferences(){
    }

    public void clear()
    {
        customerName = "";
        addressLine1 = "";
        addressLine2 = "";
        city = "";
        suppressSequenceNumber = true;
        acsKeyline = "";
        continentID = "";
        editionCode = "";
        alphaExpireDate = "";
        makeupCode = "";
        endOfPackageIndicator = false;
        endofPalletSackIndicator = false;
        palletSackIndicator = "";
        palletSackNumber = "-1";
        packageNumber = "";
        state = "";
        barcode = "";
        imbBarcode = "";
        imbBarcodeData = "";
        barcodeCheckDigit = "";
        LabelDropIn = "";
        publicationCode = "";
        endorsementLine = "";
        USzipCode = "";
        zipPlus4 = "";
        endSchoolFlag = false;
        classSeqNumber = "";
        labelMagCode = "";
        GeoComboName = "";
        copyCnt = "";
        canadianCarrierLiteral = "";
        canadianNonDirect = "";
        carrierRouteNumber = "";
        canadianMonthCode = "";
        canadianZipCode = "";
        canadianOEL = "";
        SchoolCopyCount = "";
        
        return;
    }

    public Object clone()
    {
        MagazineLabel lbl = null;
        try
        {
            lbl = (MagazineLabel)super.clone();
            lbl.m_TextLine = new TextLine[s_NUM_TEXT_LINES];
        }
        catch(Exception e)
        {
            LogWriter.writeLog(e);
        }
        return lbl;
    }

    public void determineJustification()
    {
    }

    public void expandLabel(int newLabelSize) {
        LabelLine8 = PropertyBroker.getProperty("LabelLine8");
        LL8Override = PropertyBroker.getProperty("LL8Override");
        nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
        RLL5value = "false";
        
        if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(Plant_ID.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
        {
            for(int i = 0; i < s_NUM_TEXT_LINES; i++)
            {
                if(i > 8){
                    break;
                }
                
                m_TextLine[i].setLength(newLabelSize);
                
                if (labelJustification == StringFunctions.LEFT || labelJustification == StringFunctions.USE_DEFAULT) {
					m_TextLine[i].setJustification(StringFunctions.LEFT);
				} else {
					if (magCode.equalsIgnoreCase("TK")) {
						m_TextLine[i].setJustification(newLabelSize	- TK_MAGAZINELABELSIZE);
					} else {
						m_TextLine[i].setJustification(newLabelSize - MAGAZINELABELSIZE);
					}
				}
                if(magCode.equalsIgnoreCase("TK")){
                    m_TextLine[i].justify(TK_MAGAZINELABELSIZE);
                } else{
                    m_TextLine[i].justify(MAGAZINELABELSIZE);
                }
            }

        } else {
            for(int j = 0; j < s_NUM_TEXT_LINES; j++) {
                if(j > 5){
                    break;
                }
                
                m_TextLine[j].setLength(newLabelSize);
                if(labelJustification == StringFunctions.LEFT || labelJustification == StringFunctions.USE_DEFAULT)
                {
                    m_TextLine[j].setJustification(StringFunctions.LEFT);
                } else {
                if(magCode.equalsIgnoreCase("TK")){
                    m_TextLine[j].setJustification(newLabelSize - TK_MAGAZINELABELSIZE);
                }
                 else{
                    m_TextLine[j].setJustification(newLabelSize - MAGAZINELABELSIZE);
                 } 
                }
                
                if(magCode.equalsIgnoreCase("TK")){
                    m_TextLine[j].justify(TK_MAGAZINELABELSIZE);
                } else{
                    m_TextLine[j].justify(MAGAZINELABELSIZE);
                }
            }
            
        }
    }

    public abstract void format();

    protected String formatBarcodeLine(){
    	
        StringBuffer labelLine = new StringBuffer();
        barcodeLength = Integer.parseInt(length);
        String LL8BarCodeBlank = PropertyBroker.getProperty("LL8BlankBarCode", " ");
        
        if(LL8BarCodeBlank.indexOf(magCode) >= 0){
            labelLine.append(StringFunctions.fixSize(" ", barcodeLength, ' ', StringFunctions.LEFT));
        }else {
        	if(barcode.length() > 0){
        		String newBarCode = (new StringBuilder(String.valueOf(barcode_head))).append(barcode).append(barcode_tail).toString();
        		if(labelJustification == StringFunctions.LEFT){
        			labelLine.append(StringFunctions.fixSize(newBarCode, barcodeLength, ' ', StringFunctions.LEFT));
        	    }else{
        	    	labelLine.append(StringFunctions.fixSize(newBarCode, barcodeLength, ' ', StringFunctions.LEFT));
        	    	}
        	}else{
        		labelLine.append(StringFunctions.fixSize(" ", barcodeLength, ' ', StringFunctions.LEFT));
        	}
        }
        return labelLine.toString();
    }

    protected String formatLabelDropIn()
    {
        StringBuffer labelLine = new StringBuffer();
        labelLine.append(StringFunctions.fixSize(LabelDropIn, 38, ' ', StringFunctions.LEFT));
        return labelLine.toString();
    }

    protected String formatImbBarcodeLine()
    {
        StringBuffer labelLine = new StringBuffer();
        labelLine.append(StringFunctions.fixSize(imbBarcodeData, 38, ' ', StringFunctions.LEFT));
        return labelLine.toString();
    }

    protected String formatLine2(){
    	
        StringBuffer labelLine = new StringBuffer();
        String schoolBundling = PropertyBroker.getProperty("schoolBundling", "false");
        if(line2Type.equals("k")){
        	
            if(acsKeyline.equals(""))
                labelLine.append("                   ");
            else if(acsKeyline.length() != 19)
                labelLine.append(StringFunctions.fixSize(acsKeyline, 19, ' ', StringFunctions.LEFT));
            else 
                labelLine.append(acsKeyline);
            
            labelLine.append(" ");
            
            if(magCode.equals(""))
                labelLine.append(" ");
            else 
                labelLine.append(magCode);
            
            
            if(continentID.equals(""))
                labelLine.append(" ");
            else 
                labelLine.append(continentID);
            
            
            if(editionCode.equals("")) 
                labelLine.append("         ");
            else 
                labelLine.append(StringFunctions.fixSize(editionCode, 9, ' ', StringFunctions.RIGHT));
            
            labelLine.append(" ");
            
            if(alphaExpireDate.equals(""))
                labelLine.append("     ");
            else if(alphaExpireDate.length() != 5)
                labelLine.append(StringFunctions.fixSize(alphaExpireDate, 5, ' ', StringFunctions.LEFT));
            else
                labelLine.append(alphaExpireDate);
            
            labelLine.append(" ");
            
            if(magCode.equalsIgnoreCase("TK")){
                if(schoolBundling.equalsIgnoreCase("true")){
                    if(endSchoolFlag){
                        labelLine.append(TK_Bundle);
                        labelLine.append(TK_Bundle);
                    } else{
                        labelLine.append("  ");
                    }
                } else{
                    labelLine.append("  ");
                }
            }
            return labelLine.toString();
            
        } else {
        	
        	if(acsKeyline.equals(""))
        		labelLine.append("                   ");
        	else if(acsKeyline.length() != 15)
        		labelLine.append(StringFunctions.fixSize(acsKeyline, 15, ' ', StringFunctions.LEFT));
        	else 
        		labelLine.append(acsKeyline);
        	
        
        if(labelMagCode.equals("")) 
            labelLine.append("  ");
        else
            labelLine.append(labelMagCode);
        
        labelLine.append(" ");
        
        if(rideAlongIND.equals(""))
            labelLine.append(" ");
        else
            labelLine.append(rideAlongIND);
        
        
        if(editionCode.equals(""))
            labelLine.append("         ");
        else
            labelLine.append(StringFunctions.fixSize(editionCode, 9, ' ', StringFunctions.RIGHT));
        
        labelLine.append(" ");
        
        if(GeoComboName.equals(""))
            labelLine.append("  ");
        else
            labelLine.append(StringFunctions.fixSize(GeoComboName, 2, ' ', StringFunctions.LEFT));
        
        labelLine.append(" ");
        
        if(alphaExpireDate.equals(""))
            labelLine.append("     ");
        else if(alphaExpireDate.length() != 5)
            labelLine.append(StringFunctions.fixSize(alphaExpireDate, 5, ' ', StringFunctions.LEFT));
        else
            labelLine.append(alphaExpireDate);
        
        labelLine.append(" ");
        
        	if(magCode.equalsIgnoreCase("TK")){
        		if(schoolBundling.equalsIgnoreCase("true")){
        			if(endSchoolFlag){
        				labelLine.append(TK_Bundle);
        				labelLine.append(TK_Bundle);
        			} else{
        				labelLine.append("  ");
        			}
        		} else{
        			labelLine.append("  ");
        		}
        	}
        }
        return labelLine.toString();
    }


protected String formatLine3(){
    	
        StringBuffer labelLine = new StringBuffer();
        String schoolBundling = PropertyBroker.getProperty("schoolBundling", "false");
        
        if(customerName.equals(""))
            labelLine.append("                              ");
        else if(customerName.length() != 30)
            labelLine.append(StringFunctions.fixSize(customerName, 30, ' ', StringFunctions.LEFT));
        else
            labelLine.append(customerName);
        
        if(magCode.equalsIgnoreCase("US")){
        	labelLine.append(" ");
            if (packageNumber.length() != 5)
            	labelLine.append(StringFunctions.fixSize(packageNumber,5,'0',StringFunctions.RIGHT));
            else
            	labelLine.append(packageNumber);
        } else { 
        	labelLine.append("   ");
        
        	if(makeupCode.equals(""))
        		labelLine.append("    ");
        	else if(makeupCode.length() != 4)
        		labelLine.append(StringFunctions.fixSize(makeupCode, 4, '0', StringFunctions.RIGHT));
        	else
        		labelLine.append(makeupCode);
        
        }
        
        if(magCode.equalsIgnoreCase("US")){
        	if(endOfPackageIndicator)
            	labelLine.append(" #");
            else
            	labelLine.append("  ");
        } else {
            if(endOfPackageIndicator)
               labelLine.append("#");
            else
               labelLine.append(" ");
        }
        if(magCode.equalsIgnoreCase("TK")){
            if(schoolBundling.equalsIgnoreCase("true")){
                if(endSchoolFlag){
                    labelLine.append(TK_Bundle);
                    labelLine.append(TK_Bundle);
                } else{
                    labelLine.append("  ");
                }
            } else{
                labelLine.append("  ");
            }
        }
        
        return labelLine.toString();
    }

 protected String formatLine5(){
    	
        StringBuffer labelLine = new StringBuffer();
        String schoolBundling = PropertyBroker.getProperty("schoolBundling", "false");
        String plant_ID = PropertyBroker.getProperty("PLANTID");
        
        if(addressLine1.equals(""))
            labelLine.append("                              ");
        else if(addressLine1.length() != 30)
            labelLine.append(StringFunctions.fixSize(addressLine1, 30, ' ', StringFunctions.LEFT));
        else
            labelLine.append(addressLine1);
        
        labelLine.append(" ");
        
        if(palletSackIndicator.equals(""))
            labelLine.append(" ");
        else
            labelLine.append(palletSackIndicator.charAt(0));

        if(magCode.equalsIgnoreCase("TK") && plant_ID.toUpperCase().equals("ROK") && palletSackIndicator.equals("")) {
        	labelLine.append("     ");
        } else {
        
        if (palletSackNumber.equals("-1")) 
    		labelLine.append("     ");
    	else if (palletSackNumber.length() != 5)
    		labelLine.append(StringFunctions.fixSize(palletSackNumber,5,'0',StringFunctions.RIGHT));
    	else
    		labelLine.append(palletSackNumber);}
        
        labelLine.append(" ");
        
        if(magCode.equalsIgnoreCase("TK")){
            if(schoolBundling.equalsIgnoreCase("true")){
                if(endSchoolFlag){
                    labelLine.append(TK_Bundle);
                    labelLine.append(TK_Bundle);
                } else{
                    labelLine.append("  ");
                }
            } else{
                labelLine.append("  ");
            }
        }
        
        return labelLine.toString();
    }

    public Message getExtendedLabelAreaMessage(){
        return extendedLabelAreaMessage;
    }

    public int getLabelNumber(){
        return labelNumber;
    }

    public String getLabelType(){
        return labelType;
    }

    public String getLabelTypeMedia(){
        return null;
    }

    public String getLine2Type(){
        return line2Type;
    }

    public int getNumberOfTextLines(){
        return s_NUM_TEXT_LINES;
    }

    public String getTextLine(int line){
        return m_TextLine[line - 1].getText();
    }

    public void insertExtendedLabelAreaMessage(){
        
    	LabelLine8 = PropertyBroker.getProperty("LabelLine8");
        LL8Override = PropertyBroker.getProperty("LL8Override");
        nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
        int maxNumOfCharsToCopy = 0;
        int numberOfTextLines = extendedLabelAreaMessage.getNumberOfTextLines();
        
        if(magCode.equalsIgnoreCase("TK"))
            maxNumOfCharsToCopy = m_TextLine[0].getLength() - TK_MAGAZINELABELSIZE;
        else
            maxNumOfCharsToCopy = m_TextLine[0].getLength() - MAGAZINELABELSIZE;
        
        
        int startPos = 0;
        if(labelJustification == StringFunctions.LEFT){
            if(magCode.equalsIgnoreCase("TK")){
                startPos = TK_MAGAZINELABELSIZE;
            } else{
                startPos = MAGAZINELABELSIZE;
            }
        }
        
        if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(Plant_ID.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") && oldLL8.indexOf(magCode) < 0){
            
        	m_TextLine[0].insertText(" ", startPos, maxNumOfCharsToCopy);
            m_TextLine[1].insertText(extendedLabelAreaMessage.getTextLine(0).getText(), startPos, maxNumOfCharsToCopy);
            m_TextLine[2].insertText(extendedLabelAreaMessage.getTextLine(1).getText(), startPos, maxNumOfCharsToCopy);
            m_TextLine[3].insertText(extendedLabelAreaMessage.getTextLine(2).getText(), startPos, maxNumOfCharsToCopy);
            m_TextLine[4].insertText(" ", startPos, maxNumOfCharsToCopy);
            m_TextLine[5].insertText(extendedLabelAreaMessage.getTextLine(3).getText(), startPos, maxNumOfCharsToCopy);
            m_TextLine[6].insertText(extendedLabelAreaMessage.getTextLine(4).getText(), startPos, maxNumOfCharsToCopy);
            m_TextLine[7].insertText(extendedLabelAreaMessage.getTextLine(5).getText(), startPos, maxNumOfCharsToCopy);
        } else{
            for(int i = 0; i < numberOfTextLines; i++){
                m_TextLine[i].insertText(extendedLabelAreaMessage.getTextLine(i).getText(), startPos, maxNumOfCharsToCopy);
            }

        }
        
        return;
    }

    public void populate(String s){
    }

    public void printLabel(){
    }

    public void setExtendedLabelAreaMessage(Message m){
        extendedLabelAreaMessage = m;
    }

    public void setLabelNumber(int labelNumber){
        this.labelNumber = labelNumber;
    }

    public void setLabelType(String s){
        labelType = s;
    }

    public void setLabelTypeMedia(String s1){
    }

    public abstract void setLengthOfRunBookFields(String name, Address addr, String rollID);

    public void setLine2Type(String s){
        line2Type = s;
    }

    public abstract void setPostalBookLabelFields (String edition, int postalbooknumber, int copycount, int numberOfCopies, String ZipCode, String palletSackNumber);

    public abstract void setStorageBookLabelFields (String edition, int copycount, int numberOfCopies, String ZipCode, String palletSackNumber);

    
    public String toString(){
        
    	String LL8Override = PropertyBroker.getProperty("LL8Override");
        String nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
        String oldLL8 = PropertyBroker.getProperty("oldLL8");
        String plant_ID = PropertyBroker.getProperty("PLANTID");
        StringBuffer buf = new StringBuffer(250);
        buf.append(labelType);
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        buf.append(suppressSequenceNumber);
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(acsKeyline != null && acsKeyline.length() > 0){
            buf.append(acsKeyline);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(continentID != null && continentID.length() > 0){
            buf.append(continentID);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(editionCode != null && editionCode.length() > 0){
            buf.append(editionCode);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(alphaExpireDate != null && alphaExpireDate.length() > 0){
            buf.append(alphaExpireDate);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(customerName != null && customerName.length() > 0){
            buf.append(customerName);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(labelMagCode != null && labelMagCode.length() > 0){
            buf.append(labelMagCode);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(makeupCode != null && makeupCode.length() > 0){
            buf.append(makeupCode);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        buf.append(endOfPackageIndicator);
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        buf.append(endofPalletSackIndicator);
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(palletSackIndicator != null && palletSackIndicator.length() > 0){
            buf.append(palletSackIndicator);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(palletSackNumber != null && palletSackNumber.length() > 0){
            buf.append(palletSackNumber);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(packageNumber != null && packageNumber.length() > 0){
            buf.append(packageNumber);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(addressLine1 != null && addressLine1.length() > 0){
            buf.append(addressLine1);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(addressLine2 != null && addressLine2.length() > 0){
            buf.append(addressLine2);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(city != null && city.length() > 0){
            buf.append(city);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(state != null && state.length() > 0){
            buf.append(state);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(barcode != null && barcode.length() > 0){
            buf.append(barcode);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(barcodeCheckDigit != null && barcodeCheckDigit.length() > 0){
            buf.append(barcodeCheckDigit);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        String LabelLine8 = PropertyBroker.getProperty("LabelLine8");
        String RLL5value = "false";
        if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant_ID.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0){
            buf.append(StringFunctions.fixSize(LabelDropIn, 30, ' ', StringFunctions.LEFT));
            buf.append(IssueCustomer.TOSTRING_DELIMITER);
        }
        
        if(publicationCode != null && publicationCode.length() > 0){
            buf.append(publicationCode);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(endorsementLine != null && endorsementLine.length() > 0){
            buf.append(endorsementLine);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(USzipCode != null && USzipCode.length() > 0){
            buf.append(USzipCode);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(zipPlus4 != null && zipPlus4.length() > 0){
            buf.append(zipPlus4);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(canadianCarrierLiteral != null && canadianCarrierLiteral.length() > 0){
            buf.append(canadianCarrierLiteral);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(canadianNonDirect != null && canadianNonDirect.length() > 0){
            buf.append(canadianNonDirect);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(carrierRouteNumber != null && carrierRouteNumber.length() > 0){
            buf.append(carrierRouteNumber);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(canadianMonthCode != null && canadianMonthCode.length() > 0){
            buf.append(canadianMonthCode);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(canadianZipCode != null && canadianZipCode.length() > 0){
            buf.append(canadianZipCode);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(canadianOEL != null && canadianOEL.length() > 0){
            buf.append(StringFunctions.fixSize(canadianOEL, 38, ' ', StringFunctions.LEFT));
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(imbBarcode != null && imbBarcode.length() > 0){
            buf.append(StringFunctions.fixSize(imbBarcode, 65, ' ', StringFunctions.LEFT));
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(imbBarcodeData != null && imbBarcodeData.length() > 0){
            buf.append(StringFunctions.fixSize(imbBarcodeData, 32, ' ', StringFunctions.LEFT));
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        String OMS2Magazines = PropertyBroker.getProperty("OMSMagazines");
        if(OMS2Magazines.indexOf(magCode) >= 0){
            buf.append(IssueCustomer.TOSTRING_DELIMITER);
            if(wrhseAcctNum != null && wrhseAcctNum.length() > 0){
                buf.append(wrhseAcctNum);
            } else{
                buf.append(" ");
            }
            buf.append(IssueCustomer.TOSTRING_DELIMITER);
            
            if(rnwlEffKy1 != null && rnwlEffKy1.length() > 0){
                buf.append(rnwlEffKy1);
            } else{
                buf.append(" ");
            }
            buf.append(IssueCustomer.TOSTRING_DELIMITER);
            
            if(rnwlLttr != null && rnwlLttr.length() > 0){
                buf.append(rnwlLttr);
            } else{
                buf.append(" ");
            }
            buf.append(IssueCustomer.TOSTRING_DELIMITER);
            
            if(fam1MsgID != null && fam1MsgID.length() > 0){
                buf.append(fam1MsgID);
            } else{
                buf.append(" ");
            }
            buf.append(IssueCustomer.TOSTRING_DELIMITER);
            
            if(msg1WarningIND != null && msg1WarningIND.length() > 0){
                buf.append(msg1WarningIND);
            } else{
                buf.append(" ");
            }
            buf.append(IssueCustomer.TOSTRING_DELIMITER);
            
            if(fam1DemoNme != null && fam1DemoNme.length() > 0){
                buf.append(fam1DemoNme);
            } else{
                buf.append(" ");
            }
            buf.append(IssueCustomer.TOSTRING_DELIMITER);
            
            if(fam2MsgID != null && fam2MsgID.length() > 0){
                buf.append(fam2MsgID);
            } else{
                buf.append(" ");
            }
            buf.append(IssueCustomer.TOSTRING_DELIMITER);
            
            if(msg2WarningIND != null && msg2WarningIND.length() > 0){
                buf.append(msg2WarningIND);
            } else{
                buf.append(" ");
            }
            buf.append(IssueCustomer.TOSTRING_DELIMITER);
            
            if(fam2DemoNme != null && fam2DemoNme.length() > 0){
                buf.append(fam2DemoNme);
            } else{
                buf.append(" ");
            }
            buf.append(IssueCustomer.TOSTRING_DELIMITER);
            
            if(fam3MsgID != null && fam3MsgID.length() > 0){
                buf.append(fam3MsgID);
            } else{
                buf.append(" ");
            }
            buf.append(IssueCustomer.TOSTRING_DELIMITER);
            
            if(msg3WarningIND != null && msg3WarningIND.length() > 0){
                buf.append(msg3WarningIND);
            } else{
                buf.append(" ");
            }
            buf.append(IssueCustomer.TOSTRING_DELIMITER);
            
            if(fam3DemoNme != null && fam3DemoNme.length() > 0){
                buf.append(fam3DemoNme);
            } else{
                buf.append(" ");
            }
            buf.append(IssueCustomer.TOSTRING_DELIMITER);
            
            if(fam4MsgID != null && fam4MsgID.length() > 0){
                buf.append(fam4MsgID);
            } else{
                buf.append(" ");
            }
            buf.append(IssueCustomer.TOSTRING_DELIMITER);
            
            if(msg4WarningIND != null && msg4WarningIND.length() > 0){
                buf.append(msg4WarningIND);
            } else{
                buf.append(" ");
            }
            buf.append(IssueCustomer.TOSTRING_DELIMITER);
            
            if(msg4WarningIND != null && msg4WarningIND.length() > 0){
                buf.append(fam4DemoNme);
            } else{
                buf.append(" ");
            }
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(GeoComboName != null && GeoComboName.length() > 0){
            buf.append(GeoComboName);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(rideAlongIND != null && rideAlongIND.length() > 0){
            buf.append(rideAlongIND);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(sigNameOrientation != null && sigNameOrientation.length() > 0){
            buf.append(sigNameOrientation);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(signatureName != null && signatureName.length() > 0){
            buf.append(signatureName);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        buf.append(endSchoolFlag);
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(classSeqNumber != null && classSeqNumber.length() > 0){
            buf.append(classSeqNumber);
        } else{
            buf.append(" ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(copyCnt != null && copyCnt.length() > 0){
            buf.append(copyCnt);
        } else{
            buf.append("  ");
        }
        buf.append(IssueCustomer.TOSTRING_DELIMITER);
        
        if(SchoolCopyCount != null && SchoolCopyCount.length() > 0){
            buf.append(SchoolCopyCount);
        } else{
            buf.append(" ");
        }
        
        return buf.toString();
    }

}
