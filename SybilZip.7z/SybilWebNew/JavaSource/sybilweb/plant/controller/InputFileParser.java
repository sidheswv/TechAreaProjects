package sybilweb.plant.controller;

//import sybil.common.model.*;
import java.io.*;

/**
 *	This is the base class for all file parsers.  It was originally
 *	intended to be for parsing IssueCustomer only.  With the
 *	introduction of Postal, Storage, and Office books, the interface
 *	of this class has lost its consistency.  One solution would be
 *	to combine the overloaded parseFile method.  A framework would
 *	be a good starting point.  Create a base class ParsableObject.  It
 *	would define a set of method(s) to populate itself.  Then
 *	have IssueCustomer, Postabl, Storage, and Office all inherit from
 *	that.  parseFile method would take an InputStream and a ParsableObject
 *	as argument, read from the stream and populate the ParsableObject.
 *	If an invalid ParsableObject is passed in, an exception can be thrown.
 *
 *	@author Jun Ying
 */

public abstract class InputFileParser {

/// VERSION OF CLASS IN PRODUCTION ////
	public static final String Class_Version_Number = "PR_6.0_REL9.4";

	
	public InputFileParserFactory m_InputFileParserFactory;
	protected InputStream lastIn = null;
	protected String labelType;
	protected Mag magInfo;

/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getLabelType() {
	return labelType;
}
public Mag getMag() {
	return magInfo;
}
public abstract boolean parseFile(BufferedReader bfr, StoragePostalBook poBook)
		throws Exception, java.io.IOException;
public abstract boolean parseFile(DataInputStream in, sybilweb.plant.controller.IssueCustomer issueCust, boolean skipExtraLabeltokens, boolean RLL5fileExists)
		throws Exception, java.io.IOException;
/**
 * This method was created in VisualAge.
 * @param s java.lang.String
 */
public void setLabelType(String s) {
	labelType = s;
}
public void setMag(Mag m) {
	magInfo = m;
}
}
