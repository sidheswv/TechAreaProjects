package sybilweb.plant.controller;

/**
 * Insert the type's description here.
 * Creation date: (3/7/2002 1:53:11 PM)
 * @author: Sybil Administrator
 */
import java.sql.*;
import java.text.*;
import java.util.*;
 
public class ProcessTracker {
	private static boolean processTrackerInit = false;

	private static Connection conn = null;
	private static String controlTableName = "tba_syb_proc_cntl";
	private static PreparedStatement insert;
	private static java.util.Date now = null;
	private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd kk:mm:ss");
	private static String nowString = "";

	private static boolean stop = false;
/**
 * ProcessTracker constructor comment.
 */
public ProcessTracker() {
	super();
	LogWriter.writeLog("I","","","ProcessTracker.ProcessTracker");
}
/**
 * Insert the method's description here.
 * Creation date: (4/17/2002 8:22:59 AM)
 * @return java.util.Vector
 * @param processCode java.lang.String
 */
public static synchronized Vector checkNotStopped(String processCode) {
	Vector vectorPid = new Vector();
	try {
		String select = "SELECT proc_plant, proc_pid_num" +  
			" FROM " + controlTableName + 
			" WHERE proc_name = ? AND proc_status <> ? AND proc_plant <> ?";
		PreparedStatement psSelect = null;
		ResultSet result = null;
		psSelect = conn.prepareStatement(select);
		psSelect.setString(1, processCode);  //proc name
		psSelect.setString(2, "stopped");    //proc status
		psSelect.setString(3, "$$$");        //proc plant ... don't kill the ProcessController itself.
		result = psSelect.executeQuery();
		while (result.next()) {
			String s = String.valueOf(result.getInt(2));
			//LogWriter.writeLog("ProcessTracker.checkNotStopped ... " + s); 
			vectorPid.addElement(s);
		}
		result.close();
		psSelect.close();
	}
	catch (SQLException se) {
		if(se.getSQLState().equals("S1010")) {
		}
		else {
			LogWriter.writeLog("E","","","ProcessTracker.checkNotStopped ... SQLException");
			LogWriter.writeLog(se);
			if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
				LogWriter.writeLog("E","","","Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
	}
	catch (Exception e) {
		LogWriter.writeLog("E","","","ProcessTracker.checkNotStopped ... Exception");
		LogWriter.writeLog(e);
		if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
			LogWriter.writeLog("E","","","Process terminating due to database/sql exception");
			System.exit(1);
		}
	}
	if (vectorPid.size() > 0) {
		return vectorPid;
	}
	else {
		return null;
	}
}
/**
 * Insert the method's description here.
 * Creation date: (4/16/2002 2:00:29 PM)
 * @return java.lang.String
 * @param processCode java.lang.String
 */
public static synchronized Vector checkStart(String processCode) {
	//LogWriter.writeLog("ProcessTracker.checkStart ... processCode = " + processCode);
	Vector vectorPlantId = new Vector();
	try {
		String select = "SELECT proc_plant" +  
			" FROM " + controlTableName + 
			" WHERE proc_name = ? AND proc_status = ? AND proc_plant <> ?";
		PreparedStatement psSelect = null;
		ResultSet result = null;
		psSelect = conn.prepareStatement(select);
		psSelect.setString(1, processCode);  //proc name
		psSelect.setString(2, "restart");    //proc status
		psSelect.setString(3, "$$$");        //proc plant ... don't check the ProcessController itself
		result = psSelect.executeQuery();
		while (result.next()) {
			String s = result.getString(1);
			//LogWriter.writeLog("ProcessTracker.checkStart ... " + s); 
			vectorPlantId.addElement(s);
		}
		result.close();
		psSelect.close();
	}
	catch (SQLException se) {
		if(se.getSQLState().equals("S1010")) {
		}
		else {
			LogWriter.writeLog("E","","","ProcessTracker.checkStart ... SQLException");
			LogWriter.writeLog(se);
			if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
				LogWriter.writeLog("E","","","Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
	}
	catch (Exception e) {
		LogWriter.writeLog("E","","","ProcessTracker.checkStart ... Exception");
		LogWriter.writeLog(e);
		if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
			LogWriter.writeLog("E","","","Process terminating due to database/sql exception");
			System.exit(1);
		}
	}
	if (vectorPlantId.size() > 0) {
		return vectorPlantId;
	}
	else {
		return null;
	}
}
/**
 * Insert the method's description here.
 * Creation date: (4/24/2002 8:35:07 AM)
 * @return java.util.Vector
 */
public static synchronized Vector checkStarted() {
	//LogWriter.writeLog("ProcessTracker.checkStarted);
	Vector vectorPid = new Vector();
	String s = null;
	try {
		String select = "SELECT proc_pid_num, proc_name, proc_plant,  proc_jobname, proc_asidx" +  
			" FROM " + controlTableName + 
			" WHERE proc_status = ?";
		PreparedStatement psSelect = null;
		ResultSet result = null;
		psSelect = conn.prepareStatement(select);
		psSelect.setString(1, "started");    //proc status
		result = psSelect.executeQuery();
		while (result.next()) {
			s = result.getInt(1) + " ";
			s = s + result.getString(2) + " ";
			s = s + result.getString(3) + " ";
			s = s + result.getString(4) + " ";
			s = s + result.getString(5);
			//LogWriter.writeLog("I","","","ProcessTracker.checkStarted ... " + s);
			vectorPid.addElement(s);
		}
		result.close();
		psSelect.close();
	}
	catch (SQLException se) {
		if(se.getSQLState().equals("S1010")) {
		}
		else {
			LogWriter.writeLog("E","","","ProcessTracker.checkStarted ... SQLException");
			LogWriter.writeLog(se);
			if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
				LogWriter.writeLog("E","","","Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
	}
	catch (Exception e) {
		LogWriter.writeLog("E","","","ProcessTracker.checkStarted ... Exception");
		LogWriter.writeLog(e);
		if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
			LogWriter.writeLog("E","","","Process terminating due to database/sql exception");
			System.exit(1);
		}
	}
	if (vectorPid.size() > 0) {
		return vectorPid;
	}
	else {
		return null;
	}
}
/**
 * Insert the method's description here.
 * Creation date: (3/7/2002 2:52:50 PM)
 * @return boolean
 */
public static synchronized boolean checkStop(String name, String plant) {
	//LogWriter.writeLog("ProcessTracker.checkStop ... " + name + " " + plant");
	stop = false;
	try {
		String select = "SELECT proc_status" +  
			" FROM " + controlTableName + 
			" WHERE proc_name = ? AND proc_plant = ? AND proc_plant <> ?";
		PreparedStatement psSelect = null;
		ResultSet result = null;
		psSelect = conn.prepareStatement(select);
		psSelect.setString(1, name);    //proc name
		psSelect.setString(2, plant);   //proc plant
		psSelect.setString(3, "$$$");   //proc plant ... don't check the ProcessController itself
		result = psSelect.executeQuery();
		
		int ctr1 = 0;
		while (result.next()) {
			//LogWriter.writeLog("ProcessTracker.checkStop ... row exists");
			if (result.getString(1).trim().equals("stop")) {
				stop = true;
				//LogWriter.writeLog("ProcessTracker.checkStop ... stop indicated");
			}
			else {
				stop = false;
				//LogWriter.writeLog("ProcessTracker.checkStop ... stop not indicated");
			}
			ctr1++;
		}
		if(ctr1 == 0) {
			LogWriter.writeLog("I","","","ProcessTracker.checkStop ... no row exists");
			stop = false;
		}
		result.close();
		psSelect.close();
	}
	catch (SQLException se) {
		if(se.getSQLState().equals("S1010")) {
		}
		else {
			LogWriter.writeLog("E","","","ProcessTracker.trackProcessStatus ... SQLException");
			LogWriter.writeLog(se);
			if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
				LogWriter.writeLog("E","","","Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
	}
	catch (Exception e) {
		LogWriter.writeLog("E","","","ProcessTracker.trackProcessStatus ... Exception");
		LogWriter.writeLog(e);
		if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
			LogWriter.writeLog("E","","","Process terminating due to database/sql exception");
			System.exit(1);
		}
	}
	
	if (stop) {	return true; } else { return false; }
}
/**
 * Insert the method's description here.
 * Creation date: (3/7/2002 2:06:43 PM)
 */
private static void connectDB() {
	LogWriter.writeLog("I","","","ProcessTracker.connectDB");

	PreparedStatement setSqlId = null;
	Statement commitSqlId = null;
	String x = null;
	String db2owner = null;
	int i = 0;
	
	String user = PropertyBroker.getProperty("processcontrol.login","sybil");
	String pswd = PropertyBroker.getProperty("processcontrol.password","sybil");
	String driver = "";
	String database = "";
	
	if( conn == null) {
		try {
			driver = PropertyBroker.getProperty("processcontrol.driver", "processcontrol.driver not specified in ini");
			database = PropertyBroker.getProperty("processcontrol.server", "processcontrol.server not specified in ini");
			Class.forName(driver);
			conn = DriverManager.getConnection(database, user, pswd);
			
			//
			x = PropertyBroker.getProperty("processcontrol.driver", "processcontrol.driver not specified in ini").toLowerCase();
			i = x.indexOf("db2");
			if (!(i < 0)) {
				try {
					db2owner = PropertyBroker.getProperty("DB2OWNER","dtppsyup");
					setSqlId = conn.prepareStatement("set current sqlid = ?");
					setSqlId.setString(1, db2owner);
					setSqlId.execute();
					commitSqlId = conn.createStatement();
					commitSqlId.execute("commit");
				}
				catch (SQLException se) {
					if(se.getSQLState().equals("S1010")) {
					}
					else {
						LogWriter.writeLog(se);
						LogWriter.writeLog("Error: Set Current SqlId failed.");
						if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
							LogWriter.writeLog("Process terminating due to database/sql exception");
							System.exit(1);
						}
					}
				}
				catch (Exception e) {
					LogWriter.writeLog(e);
					LogWriter.writeLog("Error: Set Current SqlId failed.");
					if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
						LogWriter.writeLog("Process terminating due to database/sql exception");
						System.exit(1);
					}
				}
			}
			//
			
		} 
		catch (Exception e) {
			LogWriter.writeLog("E","","","ProcessTracker.connectDB: Error ... unable to connect to database <" +
				database + "> using driver <" + driver + ">");
			LogWriter.writeLog(e);
			LogWriter.writeLog("E","","","Process terminating due to database/sql exception");
			System.exit(1);
		}
	}
}
/**
 * Insert the method's description here.
 * Creation date: (3/7/2002 2:07:09 PM)
 */
private static void disconnectDB() {
	LogWriter.writeLog("I","","","ProcessTracker.disconnectDB");
	if( conn != null) {		
		try { 
			conn.close(); 
		}
		catch(Exception sql){
		};
		conn = null;
	}
}
/**
 * Insert the method's description here.
 * Creation date: (3/7/2002 2:02:56 PM)
 */
public static synchronized void initProcessTracker() {
	if (processTrackerInit) return;
	processTrackerInit = true;

	connectDB();

}
/**
 * Insert the method's description here.
 * Creation date: (3/7/2002 2:15:29 PM)
 * @param name java.lang.String
 * @param plant java.lang.String
 * @param status java.lang.String
 */
public static synchronized void trackProcessStatus(String name, String plant, String status) {
	//LogWriter.writeLog("I","","","ProcessTracker.trackProcessStatus");
	Statement updStmt = null;
	Statement insStmt = null;
	PreparedStatement psInsert = null;
	int ecDuplicate = -803;
	String ecDuplicateState = "23505";

	try {
		//LogWriter.writeLog("I","","","ProcessTracker.trackProcessStatus ... insert");
		now = new java.util.Date();
		nowString = dateFormat.format(now);
		String insert = "INSERT INTO " + controlTableName + " (proc_name, proc_plant, proc_status, proc_status_date)" + 
			" VALUES (?, ?, ?, ?)";
		psInsert = conn.prepareStatement(insert);
		psInsert.setString(1, name);      //proc name
		psInsert.setString(2, plant);     //plant code
		psInsert.setString(3, status);    //status 
		psInsert.setString(4, nowString); //status date
		psInsert.executeUpdate();
		psInsert.close();
		insStmt = conn.createStatement();
		insStmt.execute("commit");
		insStmt.close();
	}
	catch (SQLException se) {
		int ec = se.getErrorCode();
		//LogWriter.writeLog(""I","","",ProcessTracker.trackProcessStatus ... ErrorCode = <" + ec + ">");
		//LogWriter.writeLog(""I","","",ProcessTracker.trackProcessStatus ... SQLState = <" + se.getSQLState() + ">");
		if (ec == ecDuplicate) {
			try {			
				//LogWriter.writeLog("I","","","ProcessTracker.trackProcessStatus ... update");
				now = new java.util.Date();
				nowString = dateFormat.format(now);
				String update = "UPDATE " + controlTableName + " SET proc_status = '" + status + "', proc_status_date = '" + 
					nowString + "'" + 
					" WHERE proc_name = '" + name + "' AND proc_plant = '" + plant + "'";
				updStmt = conn.createStatement();
				updStmt.executeUpdate(update);
				updStmt.execute("commit");
				updStmt.close();
			}
			catch (SQLException se1) {
				if(se1.getSQLState().equals("S1010")) {
				}
				else {
					LogWriter.writeLog("E","","","ProcessTracker.trackProcessStatus ... SQLException ... update");
					LogWriter.writeLog(se1);
					if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
						LogWriter.writeLog("E","","","Process terminating due to database/sql exception");
						System.exit(1);
					}
				}	
			}
			catch (Exception e1) {
				LogWriter.writeLog("E","","","ProcessTracker.trackProcessStatus ... Exception ... update");
				LogWriter.writeLog(e1);
				if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
					LogWriter.writeLog("E","","","Process terminating due to database/sql exception");
					System.exit(1);
				}
			}
		}
		else {
			if(se.getSQLState().equals("S1010")) {
			}
			else {
				LogWriter.writeLog("E","","","ProcessTracker.trackProcessStatus ... SQLException ... insert");
				LogWriter.writeLog(se);
				if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
					LogWriter.writeLog("E","","","Process terminating due to database/sql exception");
					System.exit(1);
				}
			}
		}	
	}
	catch (Exception e) {
		LogWriter.writeLog("E","","","ProcessTracker.trackProcessStatus ... Exception ... insert");
		LogWriter.writeLog(e);
		if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
			LogWriter.writeLog("E","","","Process terminating due to database/sql exception");
			System.exit(1);
		}
	}
}
/**
 * Insert the method's description here.
 * Creation date: (3/7/2002 3:38:29 PM)
 * @param name java.lang.String
 * @param plant java.lang.String
 * @param status java.lang.String
 * @param pid java.lang.String
 */
public static synchronized void trackProcessStatus(String name, String plant, String status, String pid) {
	//LogWriter.writeLog("I","","","ProcessTracker.trackProcessStatus with pid");
	String parmList = null;
	StringTokenizer jobAndAsidTokens = null;
	String jobAndAsid = null;
	String jobName = null;
	String hexAddrSpaceId = null;
	
	PreparedStatement psInsert = null;
	Statement updStmt = null;
	Statement insStmt = null;
	int ecDuplicate = -803;
	String ecDuplicateState = "23505";
		
	try {	
		sybil.common.util.ProcessChecker pck = new sybil.common.util.ProcessChecker();
		jobAndAsid = pck.checkPid(Integer.valueOf(pid).intValue());
		jobAndAsidTokens = new StringTokenizer(jobAndAsid, " ");
		jobName = jobAndAsidTokens.nextToken().trim();
		hexAddrSpaceId = jobAndAsidTokens.nextToken().trim();
	}
	catch (Exception e) {
		LogWriter.writeLog("E","","","ProcessTracker.trackProcessStatus with pid ... Exception during checkPid");
		LogWriter.writeLog(e);
		System.exit(1);
	}

	try {
		//LogWriter.writeLog("I","","","ProcessTracker.trackProcessStatus with pid ... insert");
		now = new java.util.Date();
		nowString = dateFormat.format(now);
		String insert = "INSERT INTO " + controlTableName + " (proc_name, proc_plant, proc_status, proc_status_date, " + 
			"proc_pid_num, proc_jobname, proc_asidx)" + 
			" VALUES (?, ?, ?, ?, ?, ?, ?)";
		psInsert = conn.prepareStatement(insert);
		psInsert.setString(1, name);      //proc name
		psInsert.setString(2, plant);     //plant code
		psInsert.setString(3, status);    //status 
		psInsert.setString(4, nowString); //status date
		psInsert.setInt(5, Integer.valueOf(pid).intValue());       //pid
		psInsert.setString(6, jobName);
		psInsert.setString(7, hexAddrSpaceId);
		psInsert.executeUpdate();
		psInsert.close();
		insStmt = conn.createStatement();
		insStmt.execute("commit");
		insStmt.close();
	}
	catch (SQLException se) {
		int ec = se.getErrorCode();
		//LogWriter.writeLog("I","","","ProcessTracker.trackProcessStatus with pid ... ErrorCode = <" + ec + ">");
		//LogWriter.writeLog("I","","","ProcessTracker.trackProcessStatus with pid ... SQLState = <" + se.getSQLState() + ">");
		if (ec == ecDuplicate) {
			try {
				//LogWriter.writeLog("I","","","ProcessTracker.trackProcessStatus with pid ... update");
				now = new java.util.Date();
				nowString = dateFormat.format(now);
				String update = "UPDATE " + controlTableName + " SET proc_status = '" + status + "', proc_status_date = '" + 
					nowString + "'" + ", proc_pid_num = " + Integer.valueOf(pid).intValue() + ", proc_jobname = '" + 
					jobName + "'" +	", proc_asidx = '" + hexAddrSpaceId + "'" + 
					" WHERE proc_name = '" + name + "' AND proc_plant = '" + plant + "'";
				updStmt = conn.createStatement();
				updStmt.executeUpdate(update);
				updStmt.execute("commit");
				updStmt.close();
			}
			catch (SQLException se1) {
				if(se1.getSQLState().equals("S1010")) {
				}
				else {
					LogWriter.writeLog("E","","","ProcessTracker.trackProcessStatus with pid ... SQLException ... update");
					LogWriter.writeLog(se1);
					if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
						LogWriter.writeLog("E","","","Process terminating due to database/sql exception");
						System.exit(1);
					}
				}	
			}
			catch (Exception e1) {
				LogWriter.writeLog("E","","","ProcessTracker.trackProcessStatus with pid ... Exception ... update");
				LogWriter.writeLog(e1);
				if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
					LogWriter.writeLog("E","","","Process terminating due to database/sql exception");
					System.exit(1);
				}
			}
		}
		else {
			if(se.getSQLState().equals("S1010")) {
			}
			else {
				LogWriter.writeLog("E","","","ProcessTracker.trackProcessStatus with pid ... SQLException ... insert");
				LogWriter.writeLog(se);
				if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
					LogWriter.writeLog("E","","","Process terminating due to database/sql exception");
					System.exit(1);
				}
			}
		}
	}
	catch (Exception e) {
		LogWriter.writeLog("E","","","ProcessTracker.trackProcessStatus with pid ... Exception ... insert");
		LogWriter.writeLog(e);
		if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
			LogWriter.writeLog("E","","","Process terminating due to database/sql exception");
			System.exit(1);
		}
	}
}

/**
 * Insert the method's description here.
 * Creation date: (7/8/2002 10:50:30 AM)
 * @return java.lang.String
 * @param name java.lang.String
 * @param plant java.lang.String
 */
public static synchronized String getTrackInfo(String name, String plant) {
	//LogWriter.writeLog("I","","","ProcessTracker.getTrackInfo ... " + name + " " + plant);
	String s = null;
	try {
		String select = "SELECT proc_status, proc_pid_num, proc_jobname, proc_asidx" +  
			" FROM " + controlTableName + 
			" WHERE proc_name = ? AND proc_plant = ?";
		PreparedStatement psSelect = null;
		ResultSet result = null;
		psSelect = conn.prepareStatement(select);
		psSelect.setString(1, name);    //proc name
		psSelect.setString(2, plant);   //proc plant
		result = psSelect.executeQuery();
		while (result.next()) {
			s = result.getString(1) + " ";
			if (result.getInt(2) > 0) {
				s = s + result.getInt(2) + " ";
				s = s + result.getString(3) + " ";
				s = s + result.getString(4);
			}
			//LogWriter.writeLog("I","","","ProcessTracker.getTrackInfo ... " + s);
		}
		result.close();
		psSelect.close();
	}
	catch (SQLException se) {
		if(se.getSQLState().equals("S1010")) {
		}
		else {
			LogWriter.writeLog("E","","","ProcessTracker.getTrackInfo ... SQLException");
			LogWriter.writeLog(se);
			if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
				LogWriter.writeLog("E","","","Process terminating due to database/sql exception");
				System.exit(1);
			}
		}
	}
	catch (Exception e) {
		LogWriter.writeLog("E","","","ProcessTracker.getTrackInfo ... Exception");
		LogWriter.writeLog(e);
		if (PropertyBroker.getProperty("AllowDatabaseErrors", "false").equals("false")) {
			LogWriter.writeLog("E","","","Process terminating due to database/sql exception");
			System.exit(1);
		}
	}
	if (s != null) {
		return s;
	}
	else {
		return null;
	}
}
}
