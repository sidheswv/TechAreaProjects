package sybilweb.plant.controller;

/**
 * This type was created in VisualAge.
 */
import java.util.*;
import java.io.*;
import sybil.common.util.*;
import sybil.common.model.*;

public class OMSDriverCodeAssignmentMgr extends DriverCodeAssignmentMgr {

	private static int DRIVER_CODE_MAX = 100000;

	int largestBookVersion = 0;

	int OMSDriverCodes[] = null;

/**
 * This method was created in VisualAge.
 * @param mag sybil.common.model.Magazine
 */
public OMSDriverCodeAssignmentMgr(Magazine mag) {
	super(mag);
}
/**
 * This method was created in VisualAge.
 * @param customer IssueCustomer
 */
public void assignDriverCode(IssueCustomer customer){

	String currBV = customer.getBookVersion();
	int bookVersion = Integer.parseInt(currBV);
	int driverCode = 0;

	if( bookVersion <= largestBookVersion)
		driverCode = (int)OMSDriverCodes[bookVersion];

	if (driverCode > 0) {
		String code = StringFunctions.fixSize(String.valueOf(driverCode),4,'0',StringFunctions.RIGHT);
		customer.setMakeupCode(code);
//		System.out.println("MakeupCode"+ code);
//		if (!(customer.getMagazineLabel().makeupCode.equals("")))
			customer.getMagazineLabel().makeupCode = code;
	} else {
		if( invalidBV == null)
			invalidBV = new Vector();

		if( invalidBV.toString().indexOf(currBV.trim()) < 0){
			invalidBV.addElement(currBV.trim());
		}
	}
}
/**
 * This method was created in VisualAge.
 * @param fileName char
 */
public boolean loadDriverCodes() {

	BufferedReader fileReader = null;
	Vector bookVersions = null;
	Vector driverCodes = null;
	String line = null;

	Integer bookVersion;
	Integer driverCode;

//	File bvdcf = new File(driverCodeFileName);

	try {
//		fileReader = new BufferedReader(new FileReader(bvdcf));
		fileReader = new BufferedReader( new InputStreamReader(new FileInputStream(driverCodeFileName),"ISO-8859-1"));		
	} catch (java.io.FileNotFoundException fnfe) {

		fnfe.printStackTrace();
		LogWriter.writeLog("Driver Code file Could not able to locate");
//		LogWriter.writeLog(fnfe);
//		LogWriter.writeLog(new Exception(mag.getPrefix() + ": Error opening drivercode assignment file: File not found: " + bvdcf.getPath()));
		return false;
	}catch(Exception ex){
		ex.printStackTrace();
		LogWriter.writeLog(ex);
	}

	bookVersions = new Vector();
	driverCodes = new Vector();

	try {
/*		while (fileReader.ready()) {
			try {
				line = fileReader.readLine();
			}catch (java.io.IOException e) {
				if( errormessage == null){
					errormessage = new StringBuffer();
				}

				errormessage.append(" Error! Can't read driver code assignment file. The book version driver code file <" + bvdcf.getName() + "> WILL NOT be used!");
				return false;
			}
*/
		while ((line = fileReader.readLine()) != null) {


			if (line.trim().length() == 0) {
				continue;
			}

			StringTokenizer st = new StringTokenizer(line, String.valueOf(","));
			if (st.countTokens() != 2) {
				if( errormessage == null){
					errormessage = new StringBuffer();
				}
				errormessage.append(" Error! Invalid book version driver code assignment file format. The book version driver code file <" + driverCodeFileName + "> WILL NOT be used!");
				try{
					fileReader.close();
				} catch (IOException ioe){ ioe.printStackTrace(); System.out.println(errormessage); }
				return false;
			}

			try {
				bookVersion = new Integer(st.nextToken().trim());
				driverCode = new Integer(st.nextToken().trim());
			}catch (Exception nfe) {
				if( errormessage == null){
					errormessage = new StringBuffer();
				}
				LogWriter.writeLog(nfe);
				errormessage.append(" Error! Invalid book version driver code assignment file format. The book version driver code file <" + driverCodeFileName + "> WILL NOT be used!");
				System.out.println(errormessage);
				try{
					fileReader.close();
				} catch (IOException ioe){ System.out.println("Could not able to close driver file"); }
				return false;
			}

			if(bookVersions.contains(bookVersion)){
				if( errormessage == null){
					errormessage = new StringBuffer();
					errormessage.append(" Error! Duplicate book version entry for [" + bookVersion );
				} else {
					errormessage.append("," + bookVersion);
				}
			}

			bookVersions.addElement(bookVersion);
			driverCodes.addElement(driverCode);
			if (bookVersion.intValue() > largestBookVersion)
				largestBookVersion = bookVersion.intValue();

		}


	}	catch(EOFException ee) {
	}	catch(Exception re) {
		re.printStackTrace();
//		LogWriter.writeLog(re);
	}

	try{
		fileReader.close();
	} catch (IOException ioe){ System.out.println("Could not close driver file");}

	if( errormessage != null) {
		errormessage.append("].  The book version driver code file <" + driverCodeFileName + "> WILL NOT be used!" );
	}

	OMSDriverCodes = new int[largestBookVersion+1];

	 for (int x = 0; x < bookVersions.size(); x++ ) {
		 OMSDriverCodes[((Integer)bookVersions.elementAt(x)).intValue()] =
	       	            ((Integer)driverCodes.elementAt(x)).intValue();

	 }


	bookVersions = null;
	driverCodes = null;

		System.out.println("OMS loadDriverCodes() size of DriverCodes"+ OMSDriverCodes.length);
	return true;

}
}
