package sybilweb.plant.controller;

import java.util.*;

public class IssueCustomer implements java.io.Serializable, Cloneable {

	public final static char TOSTRING_DELIMITER = '\u001D';
	private String m_editionCode;
	private String m_palletSackIndicator;
	private int m_palletSackNumber;
	private int m_packageNumber;
	private boolean m_endPackageIndicator;
	private boolean m_endPalletSackIndicator;

	/**
	The following fields are used for OMS2 produced customers.
	They will not be populated for non-OMS2 customers (i.e. = null)
	*/
	private int numberCopies;	// Hard-coded to '1' for non-oms customers.
	private String bookVersion;	// Maximum of 5 digits alpha-numeric
	private String marketID;	// Market Code of customer (OMS2 only)
	private long geoHash;		// This is equivalent to xsheet book number
	private long demoHash;		// This is called 'prelim driver code' by oms
	private String custGroup;	// Customer Group
	private String custConsolidationType;		// Consolidation Type
	private String custConsolidationSubType;	// Consolidation Sub Type
	
	/**
	Endorsement line contains the sortation level information for the
	package that contains the label.  It represents the least common
	denominator of all magazines in the package.
	*/
	private String m_alphaExpireDate;
	private String m_customerName;
	private int m_numberOfMessages;
	private String m_makeupCode;
	
	private String continentCode;
	private String dest;
	private String dopID;
	private String braceID;
	private String rollID;
	private String alphaPlantCode;
	private String canadaCarrierRouteCode;
	private String canadaDeliveryMonth;
	private String consolidationLevel;
	private String trafficCode;
	

	// Contained Business Objects
//	private MailStripContentParameters m_MailstripInfo;
	public MagazineLabel m_MagazineLabel;
	private Address m_address;

//	private Message message = new Message();
	private Vector allMessages = new Vector();
	private Vector origMessages = null;
	private String tcsKeyline;

	private String customerType;
	private String customerGroup;
	private String customerSubGroup;

	/**
	CREF file fields
	*/

	private String wrhse_acc_num;
	private String rnwl_eff_key;
	private String rnwl_lttr;
	private String fam_1_msg_id;
	private String fam_1_warning_ind;
	private String fam_1_demo_nme;
	private String fam_2_msg_id;
	private String fam_2_warning_ind;	
	private String fam_2_demo_nme;
	private String fam_3_msg_id;
	private String fam_3_warning_ind;	
	private String fam_3_demo_nme;
	private String fam_4_msg_id;
	private String fam_4_warning_ind;	
	private String fam_4_demo_nme;

public IssueCustomer() {

	m_address = new Address();

}
public void clear() {

}
/**
 * This method was created by a SmartGuide.
 * @return sybil.common.model.IssueCustomer
 */
public Object clone ( ) {

	IssueCustomer customer = null;
	MagazineLabel lbl = null;
	Address addr = null;
	
	try{
		customer = (IssueCustomer)super.clone();
		lbl = (MagazineLabel)(this.getMagazineLabel().clone());
		addr = (Address)(this.getAddress().clone());
	}catch (Exception e) {
//		sybil.common.util.LogWriter.writeLog(e);
	}	

	customer.setMagazineLabel(lbl);
	customer.setAddress(addr);
		
	return customer;
}
/**
	Create a label for the customer.
*/
public MagazineLabel createLabel(String label) {

	return null;

}
public void createMessage() {

}
public Address getAddress() {

	return m_address;

}
public String getAlphaExpireDate() {

	return m_alphaExpireDate;

}
public String getalphaPlantCode() {
	return alphaPlantCode;
}
/**
 * This method was created by a SmartGuide.
 * @return java.lang.String
 */
public String getBookVersion() {
	return bookVersion;
}
public String getbraceID() {
	return braceID;
}
public String getCanadaCarrCode() {
	return canadaCarrierRouteCode;
}
public String getCanadaDeliveryMonth() {
	return canadaDeliveryMonth;
}
public String getconsolidationLevel() {
	return consolidationLevel;
}
public String getConsolidationSubType() {
	return custConsolidationSubType;
}
public String getConsolidationType() {
	return custConsolidationType;
}
public String getcontinentCode() {
	return continentCode;
}
public String getCustGroup() {
	return custGroup;
}
public String getCustomerName() {

	return m_customerName;

}
public long getDemoHash() {
	return demoHash;
}
public String getDest() {
	return dest;
}
public String getdopID() {
	return dopID;
}
public String getEditionCode() {

	return m_editionCode;

}
public boolean getEndPackageIndicator() {

	return m_endPackageIndicator;

}
public boolean getEndPalletSackIndicator() {

	return m_endPalletSackIndicator;

}
	public String getFam1DemoName(){
		return fam_1_demo_nme;		
	}
	public String getFam1MsgId(){
		return fam_1_msg_id;
	}
	public String getFam1WarningInd() {
	return fam_1_warning_ind;
	}	
	public String getFam2DemoName(){
		return fam_2_demo_nme;		
	}
	public String getFam2MsgId(){
		return fam_2_msg_id;
	}
	public String getFam2WarningInd() {
	return fam_2_warning_ind;
	}
	public String getFam3DemoName(){
		return fam_3_demo_nme;		
	}
	public String getFam3MsgId(){
		return fam_3_msg_id;
	}
	public String getFam3WarningInd() {
	return fam_3_warning_ind;
	}
		public String getFam4DemoName(){
		return fam_4_demo_nme;		
	}
public String getFam4MsgId(){
		return fam_4_msg_id;
	}
	public String getFam4WarningInd() {
	return fam_4_warning_ind;
	}
public long getGeoHash() {
	return geoHash;
}
public MagazineLabel getMagazineLabel() {

	return m_MagazineLabel;

}
/**
 * This method was created by a SmartGuide.
 * @return int
 */
public String getMakeupCode ( ) {
	return m_makeupCode ;
}
public String getMarketID () {
	return marketID;
}
public Vector getMessages() {

	return allMessages;

}
/**
 * This method was created by a SmartGuide.
 * @return int
 */
public int getNumberCopies() {
	return numberCopies;
}
public int getNumberOfMessages() {

	return m_numberOfMessages;

}
public Vector getOrigMessages() {

	return origMessages;

}
public int getPackageNumber() {

	return m_packageNumber;

}
public String getPalletSackIndicator() {

	return m_palletSackIndicator;

}
public int getPalletSackNumber() {

	return m_palletSackNumber;

}
/**
 * Insert the method's description here.
 * Creation date: (12/19/2002 10:35:32 AM)
 * @return java.lang.String
 */
public String getRnwlEffKey() {
	return rnwl_eff_key;
}
/**
 * Insert the method's description here.
 * Creation date: (12/19/2002 10:40:47 AM)
 * @return java.lang.String
 */
public String getRnwlLttr() {
	return rnwl_lttr;
}
public String getrollID() {
	return rollID;
}
/**
 * This method was created by a SmartGuide.
 * @return java.lang.String
 */
public String getTCSKeyline() {
	return tcsKeyline;
}
public String gettrafficCode() {
	return trafficCode;
}
/**
 * Insert the method's description here.
 * Creation date: (12/19/2002 10:12:38 AM)
 * @return int
 */
public String getWrhseAccNum() {
	return wrhse_acc_num;
}
public void setAddress(Address a) {
	m_address = a;

}
public void setAlphaExpireDate(String s) {
	m_alphaExpireDate = s.trim();

}
public void setalphaPlantCode(String s) {
	alphaPlantCode = s.trim();
}
/**
 * This method was created by a SmartGuide.
 * @param bv java.lang.String
 */
public void setBookVersion(String bv) {
	bookVersion = bv;
	return;
}
public void setbraceID(String s) {
	braceID = s.trim();
}
public void setCanadaCarrCode(String s) {
	canadaCarrierRouteCode = s.trim();
}
public void setCanadaDeliveryMonth(String s) {
	canadaDeliveryMonth = s.trim();
}
public void setConsolidationLevel(String s) {
	consolidationLevel = s.trim();
}
public void setConsolidationSubType(String s) {
	custConsolidationSubType = s;
}
public void setConsolidationType(String s) {
	custConsolidationType = s;
}
public void setcontinentCode(String s) {
	continentCode = s.trim();
}
public void setCustGroup(String s) {
	custGroup = s;
}
public void setCustomerName(String s) {
	m_customerName = s.trim();

}
public void setDemoHash(long i) {
	demoHash = i;
}
public void setDest(String d) {
	dest = d;
}
public void setdopID(String s) {
	dopID = s.trim();
}
public void setEditionCode(String s) {
	m_editionCode = s.trim();

}
public void setEndPackageIndicator(boolean b) {
	m_endPackageIndicator = b;

}
public void setEndPalletSackIndicator(boolean b) {
	m_endPalletSackIndicator = b;

}
	public void setFam1DemoName(String Fam1DemoName){
		fam_1_demo_nme = Fam1DemoName;
	}
/**
 * Insert the method's description here.
 * Creation date: (12/19/2002 1:53:13 PM)
 * @param Fam1MsgId java.lang.String
 */
public void setFam1MsgId(String Fam1MsgId) {
	if(Fam1MsgId == null)
		Fam1MsgId = " ";
	fam_1_msg_id  = Fam1MsgId;
	}
	public void setFam1WarningInd(String warningInd) {
	fam_1_warning_ind = warningInd;
	}
	public void setFam2DemoName(String Fam2DemoName){
		if(Fam2DemoName == null)
			Fam2DemoName = " ";
		fam_2_demo_nme = Fam2DemoName;
	}
	public void setFam2MsgId(String Fam2MsgId) {
	if(Fam2MsgId == null)
		Fam2MsgId = " ";
	fam_2_msg_id  = Fam2MsgId;
	}
	public void setFam2WarningInd(String warningInd) {
	fam_2_warning_ind = warningInd;
	}
	public void setFam3DemoName(String Fam3DemoName){
		fam_3_demo_nme = Fam3DemoName;
	}
	public void setFam3MsgId(String Fam3MsgId) {
	fam_3_msg_id  = Fam3MsgId;
	}
	public void setFam3WarningInd(String warningInd) {
	fam_3_warning_ind = warningInd;
	}
		public void setFam4DemoName(String Fam4DemoName){
		fam_4_demo_nme = Fam4DemoName;
	}
	public void setFam4MsgId(String Fam4MsgId) {
	fam_4_msg_id  = Fam4MsgId;
	}
	public void setFam4WarningInd(String warningInd) {
	fam_4_warning_ind = warningInd;
	}
public void setGeoHash(long i) {
	geoHash = i;
}
public void setMagazineLabel(MagazineLabel m) {
	m_MagazineLabel = m;

}
/**
 * This method was created by a SmartGuide.
 */
public void setMakeupCode(String makeUpCode ) {
	m_makeupCode = makeUpCode.trim();
	return;
}
public void setMarketID (String m) {
	marketID = m;
}
public void setMessages(Vector msgs) {
	allMessages = msgs;

}
/**
 * This method was created by a SmartGuide.
 * @param cp int
 */
public void setNumberCopies(int cp) {

	numberCopies = cp;
					
	return;
}
public void setNumberOfMessages(int i) {
	m_numberOfMessages = i;

}
public void setOrigMessages(Vector msgs) {

	origMessages = msgs;

}
public void setPackageNumber(int i) {
	m_packageNumber = i;

}
public void setPalletSackIndicator(String s) {
	m_palletSackIndicator = s.trim();

}
public void setPalletSackNumber(int i) {
	m_palletSackNumber = i;

}
/**
 * Insert the method's description here.
 * Creation date: (12/19/2002 10:28:35 AM)
 * @param RnwlEffKey java.lang.String
 */
public void setRnwlEffKey(String RnwlEffKey) {
	rnwl_eff_key = RnwlEffKey;
	}
/**
 * Insert the method's description here.
 * Creation date: (12/19/2002 10:30:18 AM)
 * @param RnwlLttr java.lang.String
 */
public void setRnwlLttr(String RnwlLttr) {
	rnwl_lttr = RnwlLttr;
	}
public void setrollID(String s) {
	rollID = s.trim();
}
/**
 * This method was created by a SmartGuide.
 * @param kl java.lang.String
 */
public void setTCSKeyline(String kl) {
	tcsKeyline = kl.trim();
	return;
}
public void settrafficCode(String s) {
	trafficCode = s.trim();
}
/**
 * Insert the method's description here.
 * Creation date: (12/19/2002 10:09:20 AM)
 * @param wrhseaccnum java.lang.String
 */
public void setWrhseAccNum(String wrhseaccnum) {
		wrhse_acc_num = wrhseaccnum;
	}


public String toString() {

	StringBuffer buf = new StringBuffer(512);

		
	if (continentCode != null && continentCode.length() > 0) {		// Continent Code
		buf.append(continentCode);
	}
	else {
		buf.append(" ");
	}	

	buf.append(IssueCustomer.TOSTRING_DELIMITER);
	if (m_makeupCode != null && m_makeupCode.length() > 0) {			// Makeup Code
		buf.append(m_makeupCode);
	}
	else {
		buf.append(" ");
	}	
	
	buf.append(IssueCustomer.TOSTRING_DELIMITER);
	if (m_editionCode != null && m_editionCode.length() > 0) {		// Edition Code
		buf.append(m_editionCode);
	}
	else {
		buf.append(" ");
	}		
	
	buf.append(IssueCustomer.TOSTRING_DELIMITER);

	if( bookVersion != null)
		buf.append(bookVersion);			// Book Version (valid for OMS2 only)
	else
		buf.append("0");

	buf.append(IssueCustomer.TOSTRING_DELIMITER);
	buf.append(numberCopies);						// Number of Copies (i.e. bulk subs)
	
	buf.append(IssueCustomer.TOSTRING_DELIMITER);
	if (m_palletSackIndicator != null && m_palletSackIndicator.length() > 0) { // Pallet/Sack Ind
		buf.append(m_palletSackIndicator);
	}
	else {
		buf.append(" ");
	}		

	buf.append(IssueCustomer.TOSTRING_DELIMITER);
	buf.append(m_palletSackNumber);						// Pallet / Sack Number
	buf.append(IssueCustomer.TOSTRING_DELIMITER);
	buf.append(m_packageNumber);							// Package Number
	buf.append(IssueCustomer.TOSTRING_DELIMITER);
	buf.append(m_endPackageIndicator);					// End Package Indicator
	buf.append(IssueCustomer.TOSTRING_DELIMITER);
	buf.append(m_endPalletSackIndicator);				// End Pallet Indicator

	buf.append(IssueCustomer.TOSTRING_DELIMITER);
	if (m_alphaExpireDate != null && m_alphaExpireDate.length() > 0) {								// Alpha Expire Date
		buf.append(m_alphaExpireDate);
	}
	else {
		buf.append(" ");
	}		

	buf.append(IssueCustomer.TOSTRING_DELIMITER);
	if (m_customerName != null && m_customerName.length() > 0) {		// Customer Name
		buf.append(m_customerName);
	}
	else {
		buf.append(" ");
	}		

	buf.append(IssueCustomer.TOSTRING_DELIMITER);
	if (braceID != null && braceID.length() > 0) {					// Brace
		buf.append(braceID);
	}
	else {
		buf.append(" ");
	}		

	buf.append(IssueCustomer.TOSTRING_DELIMITER);
	if (dopID != null && dopID.length() > 0) {					// Drop-Off (DOP)
		buf.append(dopID);
	}
	else {
		buf.append(" ");
	}		

	buf.append(IssueCustomer.TOSTRING_DELIMITER);
	if (rollID != null && rollID.length() > 0) {				// Roll 
		buf.append(rollID);
	}
	else {
		buf.append(" ");
	}		

	buf.append(IssueCustomer.TOSTRING_DELIMITER);
	if (alphaPlantCode != null && alphaPlantCode.length() > 0) {	// Plant
		buf.append(alphaPlantCode);
	}
	else {
		buf.append(" ");
	}		

	buf.append(IssueCustomer.TOSTRING_DELIMITER);
	if (trafficCode != null && trafficCode.length() > 0) {		// Traffic Code
		buf.append(trafficCode);
	}
	else {
		buf.append(" ");
	}		
	
	buf.append(IssueCustomer.TOSTRING_DELIMITER);
	if (tcsKeyline != null && tcsKeyline.length() > 0) {		// TCS Keyline
		buf.append(tcsKeyline);
	}
	else {
		buf.append(" ");
	}
	

	buf.append(IssueCustomer.TOSTRING_DELIMITER);
	buf.append(m_numberOfMessages);								// Number of Messages

// ===================================================================================
// Aggregate objects are serialized below (address, label, messages)

	buf.append(IssueCustomer.TOSTRING_DELIMITER);			// Address (see Address.toString())
	if (m_address != null) {
		buf.append(m_address.toString());
	}
	else {
		buf.append(" ");
	}		

	buf.append(IssueCustomer.TOSTRING_DELIMITER);			// MagazineLabel (see MagazineLabel.toString())
	if (m_MagazineLabel != null) {
		buf.append(m_MagazineLabel.toString());			// Hopefully, it will never be null!
	}
	else {
		buf.append(" ");
	}		

	buf.append(IssueCustomer.TOSTRING_DELIMITER);			// MagazineLabel (see MagazineLabel.toString())
	for (int i = 0; i < m_numberOfMessages; i++) {			// Message (see Message.toString())
		Message thisMessage = (Message) allMessages.elementAt(i);
		buf.append(thisMessage.toString());		// Message has delimiter at end already
	}

	return buf.toString();

}
}
