package sybilweb.plant.controller;

import java.io.*;
/**
 * This type was created in VisualAge.
 */
public class OnlyExt implements FilenameFilter {
	String ext;
	String name;
/**
 * OnlyExt constructor comment.
 */
public OnlyExt() {
	super();
}
/**
 * OnlyExt constructor comment.
 */
public OnlyExt(String ext) {
	this.ext = "." + ext;
}
/**
 * OnlyExt constructor comment.
 */
public OnlyExt(String name, String ext) {
	this.ext = "." + ext;
	this.name = name;
	System.out.println(this.name);
}
/**
 * accept method comment.
 */
public boolean accept(File dir, String filename) {

	boolean fileOk = true;

	if(name != null)
	fileOk &= filename.startsWith(name);

	if(ext != null)
	fileOk &= filename.endsWith(ext);

	return fileOk;

}
}
