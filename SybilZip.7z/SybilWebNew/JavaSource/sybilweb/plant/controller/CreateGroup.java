package sybilweb.plant.controller;


import java.io.FileWriter;
import java.util.Vector;
import sybilweb.plant.persistence.PersistentRoll;


/**
 * Insert the type's description here.
 * Creation date: (7/10/01 11:38:02 AM)
 * @author: Srikanth Bapanapalli
 *
 *	This Class is used to create status file .000 in Formatter directory and
 *  Update the TBA_MAG_INFO table according to the data it received from Client
 */
public class CreateGroup {
	
	public Vector rolls = null;
	public String controllerformatkey = null;
	public String controllerformat = null;
	public String magazine = null;
	public CustomerGroup scg = null;
	public String outputFileExtension = ".000";
/**
 * CreateGroup constructor comment.
 */
public CreateGroup() {
	super();
}


	public Vector getCustGroup(Vector rolls, String ctlfmtkey, String ctlfmt, String MagazineFilename, String outputfilename){
		
		this.rolls = rolls;
		controllerformatkey = ctlfmtkey;
		controllerformat = ctlfmt;

		sybilweb.plant.controller.SybilMagazine sm = new sybilweb.plant.controller.SybilMagazine(MagazineFilename);
	    this.magazine = sm.getPrefix();

	    String plant = sm.getPlant().trim();

	    Vector selectedGroupVector = null;


		try {
			PersistentRoll selectedGroupPr = new PersistentRoll();

			selectedGroupVector = selectedGroupPr.loadSelectedGroups(this.magazine,plant.toUpperCase());

		} catch(Exception ex) {  ex.printStackTrace(); }


		return 	selectedGroupVector;		
	}

	public void setCustGroup(Vector rolls, String ctlfmt, String MagazineFilename, String outputfilename, int grpID){
		this.rolls = rolls;
//		controllerformatkey = ctlfmtkey;
		controllerformat = ctlfmt;
		sybilweb.plant.controller.SybilMagazine sm = new sybilweb.plant.controller.SybilMagazine(MagazineFilename);
	    this.magazine = sm.getPrefix();
	    String plant = sm.getPlant().trim();

		try {
			PersistentRoll pr = new PersistentRoll();
			
			System.out.println(this.magazine.trim());
			System.out.println(rolls);
			System.out.println(grpID);
			System.out.println(controllerformat.trim());
			System.out.println(outputfilename.trim());
			System.out.println(plant.trim());	
			pr.saveRollID(this.magazine.trim(), rolls, grpID, controllerformat.trim(), outputfilename.trim(), plant.trim());
			String formatPath = PropertyBroker.getProperty("FormatterControlPath");
			formatPath = formatPath.concat(sm.getPrefix().concat(".").concat(String.valueOf(grpID)).concat(".").concat(outputfilename).concat(outputFileExtension));

			try {
				FileWriter f = new FileWriter(formatPath);
				} catch(Exception ex) { ex.printStackTrace(); System.out.println("Could not able to create Formatter flag file"); }
				
		} catch(Exception ex) {  ex.printStackTrace(); }
	}

	public void setCustGroup(Vector rolls, String ctlfmt, String MagazineFilename, String outputfilename, int grpID, String formatPath){
		this.rolls = rolls;
//		controllerformatkey = ctlfmtkey;
		controllerformat = ctlfmt;
		sybilweb.plant.controller.SybilMagazine sm = new sybilweb.plant.controller.SybilMagazine(MagazineFilename);
	    this.magazine = sm.getPrefix();
	    String plant = sm.getPlant().trim();

		try {
			PersistentRoll pr = new PersistentRoll();
			
			System.out.println(this.magazine.trim());
			System.out.println(rolls);
			System.out.println(grpID);
			System.out.println(controllerformat.trim());
			System.out.println(outputfilename.trim());
			System.out.println(plant.trim());	
			pr.saveRollID(this.magazine.trim(), rolls, grpID, controllerformat.trim(), outputfilename.trim(), plant.trim());
//			String formatPath = PropertyBroker.getProperty("FormatterControlPath");
			formatPath = formatPath.concat(sm.getPrefix().concat(".").concat(String.valueOf(grpID)).concat(".").concat(outputfilename).concat(outputFileExtension));

			try {
				FileWriter f = new FileWriter(formatPath);
				} catch(Exception ex) { ex.printStackTrace(); System.out.println("Unable to create Formatter flag file "+ formatPath); }
				
		} catch(Exception ex) {  ex.printStackTrace(); }
	}
}
