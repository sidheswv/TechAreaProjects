package sybilweb.plant.persistence;

/**
 * Insert the type's description here.
 * Creation date: (7/14/2004 2:43:56 PM)
 * @author: Jay Morgan
 */

import java.io.*;
import java.util.*;
import sybilweb.plant.controller.*;

public class BUHRSPersistenceIssueCustomer extends PersistenceIssueCustomer{

/// VERSION OF CLASS IN PRODUCTION ////
	public static final String Class_Version_Number = "PR_6.1_REL9.4";


	
	int rec_count = 1;
	int recordLength = 0;
	int blockLength = 0;
	int numMsgLines = 0;
	int numInkjetLines = 0;
	private static final int EIBSizeWAS = 34;
	
	GregorianCalendar c = new GregorianCalendar();

	String linelength;
	int [] lineLengths = new int[24];  // 24 since max is currently 24 lines of print
	int familyNum = 0;
	MessageFamily mf = null;
	private static final int MESSAGE_SIZE = 77;


	/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
private String createEIBBlock() {

	StringBuffer buf = new StringBuffer(blockLength);
//	int recSize = 0;

// EIB Descriptors define how the event indicators are used //

// Consolidation Level (EI 01)
	buf.append("0100102");


// End of Zone (package) (EI 02)
	buf.append("0200301");


// End of pallet/sack (EI 03)
	buf.append("0300401");


// Zip Code (EI 04)
	buf.append("0400511");

// State Code (EI 05)
	buf.append("0501602");


// Sequence Number (EI 06)
	buf.append("0601806");


// BCT Code (EI 07)
	buf.append("0702404");


// Pallet/Sack Number (EI 09)
	buf.append("0902806");


// Divert Flag (EI 10)
//	buf.append("1003401");


// Stop Line Flag (EI 11)
//	buf.append("1103401");



// Pad record out to blockLength
	for (int x = buf.length(); x < blockLength; x++) {
		buf.append(" ");
	}
	int z = buf.length();

	return buf.toString();

}
private String createEOV() {

		StringBuffer buf = new StringBuffer(1024);

// Derive fileVolID from current date hash algorithm
	String dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
	String fileVolID = StringFunctions.fixSize(dayOfYear,3,'0',StringFunctions.RIGHT) +
		outputFileName.substring(outputFileName.length()-3,outputFileName.length());

// creation date
	String year = String.valueOf(c.get(Calendar.YEAR)).substring(2,4);
	String creationDate = StringFunctions.fixSize(year,3,'0',StringFunctions.RIGHT) +
		StringFunctions.fixSize(dayOfYear,3,'0',StringFunctions.RIGHT);

		/*  End of File 1  */

// HDR1 4 characters
	buf.append("EOF1");

// file id 12 characters
	buf.append("SYBIL.SE163      "); // 17 chr (5-21)

// file set id 6 characters
	buf.append(fileVolID);		// (22-27)

// file section number, file sequence number, generation number all 4 characters
	buf.append("000100010001");

// filler 2 characters
	buf.append("00");

// creation date
	buf.append(creationDate);	// 6 chars (42-47)

// expire date
	c.add(Calendar.DAY_OF_YEAR,7);	// 6 chars (48-53)
	year = String.valueOf(c.get(Calendar.YEAR)).substring(2,4);
	buf.append(StringFunctions.fixSize(year,3,'0',StringFunctions.RIGHT));
	dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
	buf.append(StringFunctions.fixSize(dayOfYear,3,'0',StringFunctions.RIGHT));

// filler
	buf.append(" ");

// block count 6 characters
	buf.append("000000");	// (55-60)

// owner id 14 characters
	buf.append("Time, Inc. SBT");

// filler 6 characters
	buf.append(StringFunctions.fixSize(" ",6,' ',StringFunctions.LEFT)); // filler


	/*  End of File 2  */

// header 2
	buf.append("EOF2");

// record format
	buf.append("F");

// block length - 6 chars (6-10)
	buf.append(StringFunctions.fixSize(String.valueOf(blockLength),5,'0',StringFunctions.RIGHT));

// record Length - 6 chars (11-15)
	buf.append(StringFunctions.fixSize(String.valueOf(recordLength),5,'0',StringFunctions.RIGHT));

// filler
	buf.append(StringFunctions.fixSize(" ",35,' ',StringFunctions.LEFT)); // filler

// buffer offset length
	buf.append("00");

// filler
	buf.append(StringFunctions.fixSize(" ",28,' ',StringFunctions.LEFT)); // filler




	return buf.toString();
}
private String createHeader() {

	StringBuffer buf = new StringBuffer(1024);
	String PlantID = mag.getPlant();
	int j;
	String oldLL8 = (String)sybilweb.plant.controller.PropertyBroker.getProperty("oldLL8");
	LL8Override = (String)PropertyBroker.getProperty("LL8Override");
	nonLL8Plant = (String)PropertyBroker.getProperty("nonLL8Plant");

	// special trim size for BUHRS formatter....
	trimSize = 45;

	
// Derive fileVolID from current date hash algorithm
	String dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
	String fileVolID = StringFunctions.fixSize(dayOfYear,3,'0',StringFunctions.RIGHT) +
		outputFileName.substring(outputFileName.length()-3,outputFileName.length());

// creation date
	String year = String.valueOf(c.get(Calendar.YEAR)).substring(2,4);
	String creationDate = StringFunctions.fixSize(year,3,'0',StringFunctions.RIGHT) +
		StringFunctions.fixSize(dayOfYear,3,'0',StringFunctions.RIGHT);

//***  MAY NEED TO ADD SOME CODE HERE FOR 8 LINE LABLES ******

// Sets the number of Label lines based on whether it is a LL8 mag or not
	int numOfLabelLines = 0;
	magCode = mag.getMagCode();
	LabelLine8 = (String)PropertyBroker.getProperty("LabelLine8");
	if ((LabelLine8.indexOf(magCode)>=0) && (LL8Override.equals("false")) && !(nonLL8Plant.indexOf(plant.toUpperCase())>=0) && (RLL5value.equalsIgnoreCase("false")) || (oldLL8.indexOf(magCode)>=0)){
		numOfLabelLines = 7;
	}else{
		numOfLabelLines = 5;
	}	
	
//	End of check for nummber of Label Lines 

	for (int x = 0; x < 24; x++) {
		if ((x >= 0) && (x <= numOfLabelLines)) // label lines
			lineLengths[x] = trimSize;
		else{ // message lines
			if((messageFamilies.size() != 0) && (familyNum < messageFamilies.size())) {
				mf = (MessageFamily)messageFamilies.elementAt(familyNum);
				for (j = 0; j < mf.numLines; j++)
					lineLengths[x++] = MESSAGE_SIZE;
				x--;
				numMsgLines += mf.numLines;
				familyNum++;
			}else
				lineLengths[x] = 0;
		}
	}

	for (int x = 0; x < 24; x++) {
		if (lineLengths[x] > 0) numInkjetLines = x+1;
		recordLength += lineLengths[x];
	}

//***  MAY NEED TO ADD SOME CODE ABOVE FOR * LINE LABLES ******



// increase record length by size of control information for each record
	recordLength = recordLength + EIBSizeWAS;
	blockLength = recordLength;


	/*  Volume Label  */

// VOL1 4 characters
	buf.append("VOL1");

// volume id 6 characters
	buf.append(fileVolID);

// filler 27 characters
	buf.append(StringFunctions.fixSize(" ",27,' ',StringFunctions.LEFT));

// owner id 14 characters
	buf.append("Time, Inc. SBT");

// filler 36 characters
	buf.append(StringFunctions.fixSize(" ",28,' ',StringFunctions.LEFT)); // filler

// label standard version 3 characters
	buf.append("3");


/*  Header 1  */

// HDR1 4 characters
	buf.append("HDR1");

// file id 12 characters
	buf.append("SYBIL.SE163 BUHRS"); // 17 chr (5-21)

// file set id 6 characters
	buf.append(fileVolID);		// (22-27)

// file section number, file sequence number, generation number all 4 characters
	buf.append("000100010001");

// filler 2 characters
	buf.append("00");

// creation date
	buf.append(creationDate);	// 6 chars (42-47)

// expire date
	c.add(Calendar.DAY_OF_YEAR,7);	// 6 chars (48-53)
	year = String.valueOf(c.get(Calendar.YEAR)).substring(2,4);
	buf.append(StringFunctions.fixSize(year,3,'0',StringFunctions.RIGHT));
	dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
	buf.append(StringFunctions.fixSize(dayOfYear,3,'0',StringFunctions.RIGHT));

// filler
	buf.append(" ");

// block count 6 characters
	buf.append("000000");	// (55-60)

// owner id 14 characters
	buf.append("Time, Inc. SBT");

// filler 6 characters
	buf.append(StringFunctions.fixSize(" ",6,' ',StringFunctions.LEFT)); // filler


	/*  Header 2  */
// header 2
	buf.append("HDR2");

// record format
	buf.append("F");

// block length - 6 chars (6-10)
	buf.append(StringFunctions.fixSize(String.valueOf(blockLength),5,'0',StringFunctions.RIGHT));

// record Length - 6 chars (11-15)
	buf.append(StringFunctions.fixSize(String.valueOf(recordLength),5,'0',StringFunctions.RIGHT));

// filler
	buf.append(StringFunctions.fixSize(" ",35,' ',StringFunctions.LEFT)); // filler

// buffer offset length
	buf.append("00");

// filler
	buf.append(StringFunctions.fixSize(" ",28,' ',StringFunctions.LEFT)); // filler

	/*  User Header Label 1  */

// line descriptors describe the text output

	buf.append("UHL1");
// Line Descriptor Block Count
	buf.append("01");
// Line Descriptor Count
	buf.append(StringFunctions.fixSize(String.valueOf(numInkjetLines + 1),3,'0',StringFunctions.RIGHT));
// Event Indicator Block Count
	buf.append("01");
// Event Indicator Count
	buf.append("008");
// Standard Message Block Count
	buf.append("00");
// Standard Message Count
	buf.append("000");
// Book Configuration Type Block Count
	buf.append("00");
// Book Configuration Type Count
	buf.append("0000");
// Book Configuration Type Signature Map Size
	buf.append("000");
// Starting Sequence Number
	buf.append("000000001");
// Ending Sequence Number
	buf.append("000000000");
// Production Tape Number
	buf.append("0001");
// filler
	buf.append(StringFunctions.fixSize(" ",29,' ',StringFunctions.LEFT)); // filler
// Tape Revision Character
	buf.append("J");

	/*  User Header Label 2  */

	buf.append("UHL2");
// miminum stack size
	buf.append("##");
// max stack size
	buf.append("###");
//  over stack limit
	buf.append("###");
// compensate count
	buf.append("##");
// format
	buf.append("1");
// filler
	buf.append(StringFunctions.fixSize(" ",65,' ',StringFunctions.LEFT)); // filler

	return buf.toString();


}
/**
 * This method was created in VisualAge.
 * @return
 */
private String createLineBlock() {

	StringBuffer buf = new StringBuffer(blockLength);
	int recSize = 0;
	String PlantID = mag.getPlant();
	

// line descriptors describes how the record is fragmented //



// Build LDB descriptor for each inkjet line
	for (int x = 0; x < numInkjetLines; x++) {

	// LDN Number
		buf.append (StringFunctions.fixSize(String.valueOf(x+1),
			3,'0',StringFunctions.RIGHT));

		buf.append("0000000000");

	// Length of text line
		buf.append (StringFunctions.fixSize(String.valueOf(lineLengths[x]),3,'0',StringFunctions.RIGHT));
		buf.append("000FR");
		recSize += 21;
	}		
// line desc 901 - Event Indicator Block Definition (beginning of each record)
	buf.append("9010000000000");
	buf.append(StringFunctions.fixSize(String.valueOf(EIBSizeWAS),3,'0',StringFunctions.RIGHT));
	buf.append("00000");
	recSize += 21;

// Pad record out to blockLength
	for (int x = recSize; x < blockLength; x++) {
		buf.append(" ");
	}


	return buf.toString();
}
	/**
 * This method was created by a SmartGuide.
 * @param outputFileName java.lang.String
 */
public void createOutputFile(String prop, String outputFileName ) {
	this.outputFileName = outputFileName;
	outFileName = outputFileName;

	useShortFileName = PropertyBroker.getProperty("useShortFileName","false");
	shortFileName = outputFileName.substring(0,outputFileName.lastIndexOf("/")+1).concat(outputFileName.substring(outputFileName.lastIndexOf(".")+1, outputFileName.length()));
	plant = mag.getPlant().toUpperCase();
	rec_count = 1;
	String FormatterFileConcatText = null;
	FormatterFileConcatText = PropertyBroker.getProperty("FormatterFileConcatText");

	// get value from RLL5 file in input data
	String fileName = null;	
	fileName = sybilweb.plant.controller.PropertyBroker.getProperty("OLDFILEDIR") + mag.getFullPrefix() + ".RLL5";
	File f = new File(fileName);
	BufferedReader fileReader = null;
	if (f.exists()){
		try {
			fileReader = new BufferedReader(new FileReader(fileName));
		} catch (java.io.FileNotFoundException fnfe) {
			sybilweb.plant.controller.LogWriter.writeLog(new Exception(mag.getPrefix() + ": Error opening RLL5 file: File not found: " + fileName));
			return;
		}
	
		try{
			RLL5value = fileReader.readLine();
			sybilweb.plant.controller.LogWriter.writeLog("RLL5value = "+RLL5value);
		}catch(EOFException ee) {
		}	catch(Exception re) {
			sybilweb.plant.controller.LogWriter.writeLog(re);
		}
	}else {
		RLL5value = "false";
	}
// end of RLL5 file code


	if(FormatterFileConcatText == null)
		FormatterFileConcatText = "";
	if (useShortFileName.equals("true"))
		formatShortFileName = true;

		// sets file name based upon whether short or long file name
	if (formatShortFileName){
		shortOutputFileName = prop+shortFileName;

	}else {
		longOutputFileName = prop+mag.getLongFileName()+fileSep+shortFileName;
	}

	//creates temp file based on short or long file name	
	if (formatShortFileName){
			tmpFile = new File(prop + outputFileName + FormatterFileConcatText +".tmp");
	}else {
			tmpFile = new File(longOutputFileName + FormatterFileConcatText +".tmp");
	}


			
	try {
		outputFile = new OutputStreamWriter(new FileOutputStream(tmpFile),"ISO8859_1");				
	}catch (IOException e){
		LogWriter.writeLog(new SybilWarningException(mag.getPrefix() + ": Error creating output file: " + e.getMessage()));
		return;
	}


	// This change is for creating file FileName.add 
	// The outputFileName passed is Mag_name.Group_Num.FileName for handling ReRun
	// for ex: which was passed as TD1884uspsstripcust01.00020.TUS41233 for Rerun changes
	// the output File is created as TUS41233.add for the short name or in.i022104.brb.usps.strip.IUS14347 for the loing name


	if (formatShortFileName){
		shortOutputFileName = prop+shortFileName;

	}else {
		longOutputFileName = prop+mag.getLongFileName()+fileSep+shortFileName;
	}

	
	// Uses different file extension that the WTL plant
	
	if (formatShortFileName){
		newFile = new File(shortOutputFileName + FormatterFileConcatText +".DAT");
	}else {
		newFile = new File(longOutputFileName + FormatterFileConcatText +".DAT");
	}
	
	
	if (newFile.exists())
		newFile.delete(); 

//	LogWriter.writeLog("I",mag.getPlant().toUpperCase() , newoutputFileName, "Started Formatting");		
		
	String header = createHeader();
	PrintWriter headerFile;
	try {
		if (formatShortFileName){
			headerFile = new PrintWriter(new OutputStreamWriter(new FileOutputStream(shortOutputFileName + FormatterFileConcatText + ".hdr"), "ISO8859_1"));
		}else{
			headerFile = new PrintWriter(new OutputStreamWriter(new FileOutputStream(longOutputFileName + FormatterFileConcatText + ".hdr"), "ISO8859_1"));
		}
		headerFile.print(header);
		headerFile.flush();
		headerFile.close();
	}catch (IOException e){
		LogWriter.writeLog(mag.getPrefix() + ": Error creating output file: " + e.getMessage());
		return;
	}

	try {
		outputFile.write(createLineBlock());
		outputFile.write(createEIBBlock());
	} catch (IOException e) {
		e.printStackTrace();
	}
	

	return;
}
protected String formatData(sybilweb.plant.controller.IssueCustomer ic) {


	StringBuffer buf = new StringBuffer(1024);
	String tmpbuf = null;
	LabelLine8 = (String)PropertyBroker.getProperty("LabelLine8");
	LL8Override = (String)PropertyBroker.getProperty("LL8Override");
	nonLL8Plant = (String)PropertyBroker.getProperty("nonLL8Plant");
	String oldLL8 = (String)PropertyBroker.getProperty("oldLL8");

	magCode = mag.getMagCode();
	String PlantID = mag.getPlant();
	String labelLine = null;

// record control information



// label data
/************************************************************************************/
//***** This is used if there is 8 labels lines, otherwise it uses 6 (see below)****//
/***********************************************************************************/
	if ((LabelLine8.indexOf(magCode)>=0) && (LL8Override.equals("false")) && !(nonLL8Plant.indexOf(plant.toUpperCase())>=0) && (RLL5value.equalsIgnoreCase("false")) || (oldLL8.indexOf(magCode)>=0)){
		for (int i = 1; i <= 8; i++) {
			labelLine = StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(i).trim(),45,' ',StringFunctions.LEFT);
			buf.append(labelLine);
		}
	}else {
		for (int i = 1; i <= 6; i++) {
			labelLine = StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(i).trim(),45,' ',StringFunctions.LEFT);
			buf.append(labelLine);
		}
	}
/************************************************************************************/
//***** *******************END OF LABEL DATA***************************************//
/***********************************************************************************/

// message data
	int numberOfMessages = ic.getNumberOfMessages();

	Vector allMessages = ic.getMessages();

	int numberOfMsgTextLines;
	Vector m_TextLines;
	Message m = null;
	String msgfamilyNumber = null;
	MessageParameter msgp = null;
	MessageFamily mf = null;
	int i = 0;

	for (int j = 0; j < messageFamilies.size(); j++) {
		mf = (MessageFamily)messageFamilies.elementAt(j);

		if (numberOfMessages == 0) {
			for (int padding = 0; padding < mf.numLines; padding++)
				buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
		}else {
			if (i >= numberOfMessages ) {
			   for (int padding = 0; padding < mf.numLines; padding++)
					buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
			}else{
				m = ((Message)allMessages.elementAt(i));
				msgfamilyNumber = m.getMessageFamily() + m.getMessageNumber();
				msgp = (MessageParameter)msgparms.get(msgfamilyNumber);

				if (!msgp.isCoverMessage()) {
					
					if (m.getMessageFamily().equals(mf.familyNumber)) {
						numberOfMsgTextLines = m.getNumberOfTextLines();
						m_TextLines = m.getTextLines();
						int k = 0;
					for (k = 0; k < numberOfMsgTextLines; k++) {
							TextLine tl = (TextLine) m_TextLines.elementAt(k);
							buf.append(StringFunctions.fixSize(tl.toString(),MESSAGE_SIZE,' ',StringFunctions.LEFT));
						}
					// pad out text lines to maximum for family
					for (int pad = k; pad < mf.numLines; pad++) {
						int z= 0;
						buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
						z++;
					}
						i++;
					} else{    // doesn't have this family? insert a blank one
						for (int lineNum = 0; lineNum < mf.numLines; lineNum++) {
							buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
				  		}
					}
				}else{
					j--;
					i++;
				}
			}
		}
	}


// consolidation level
	buf.append ("00");

// end of package and one-up indicators
	if (ic.getEndPackageIndicator())
		buf.append("*");
	else
		buf.append(" ");

	if (ic.getEndPalletSackIndicator())
		buf.append("*");
	else
		buf.append(" ");

// Zip Code
	if (ic.getMagazineLabel().barcode.length() > 0) {
		String barcode = ic.getMagazineLabel().barcode;
		buf.append(StringFunctions.fixSize(barcode,11,' ',StringFunctions.LEFT));
	}else
		buf.append("           ");

// State Code
	buf.append (StringFunctions.fixSize(ic.getMagazineLabel().state,
		2,' ', StringFunctions.LEFT));

// rec_count
	buf.append(StringFunctions.fixSize(String.valueOf(rec_count++),
		6,'0',StringFunctions.RIGHT));

// Driver Code
	buf.append(StringFunctions.fixSize(ic.getMakeupCode(),4,'0',StringFunctions.RIGHT)+ " ");

// Pallet/Sack Number
	buf.append(StringFunctions.fixSize(ic.getMagazineLabel().palletSackNumber,
		6,'0',StringFunctions.RIGHT));

// Divert Flag
//	buf.append(" ");  //currently not used.

// Stop Line Flag
//	buf.append(" ");  //currently not used.


	return buf.toString();
	
}
}
