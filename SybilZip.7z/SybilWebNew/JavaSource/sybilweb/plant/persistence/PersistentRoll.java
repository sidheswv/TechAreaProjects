package sybilweb.plant.persistence;

/**
 * Insert the type's description here.
 * Creation date: (5/3/01 11:00:53 AM)
 * @author: Srikanth Bapanapalli
 */
import java.io.File;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.Vector;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import sybilweb.plant.controller.CustomerGroupEntry;
import sybilweb.plant.controller.LogWriter;
import sybilweb.plant.controller.Magazine;
import sybilweb.plant.controller.PropertyBroker;

/**
 * This is the persistent counter part of Roll. It provides methods to find
 * rolls by different criteria.
 * 
 * @author Srikanth Bapanapalli
 */

public class PersistentRoll {
	public static String tableName = "TBA_MAG_INFO";
	public String SYBILPROCESS = null;

	private PreparedStatement selectAll = null;
	private PreparedStatement selected = null;
	private PreparedStatement unselected = null;
	private PreparedStatement insertRoll = null;
	private PreparedStatement refreshRolls = null;
	private PreparedStatement saveRoll = null;
	private PreparedStatement deleteTable = null;
	private PreparedStatement createTable = null;
	private PreparedStatement findLargestGroup = null;
	private PreparedStatement deselectGroups = null;
	private PreparedStatement setGroupFilename = null;
	private PreparedStatement findFilenameofGroup = null;
	private PreparedStatement selectProcessRec = null;
	private PreparedStatement selectMagKeyRec = null;

	public DataSource ds =null;
	public Connection conn = null;

	public String db2owner = null;

	public String formatterstandalone = null;

	// table names for each function to minimize preparing statements
public PersistentRoll() {
	try {
		db2owner = sybilweb.plant.controller.PropertyBroker.getProperty("DB2OWNER");
		formatterstandalone = sybilweb.plant.controller.PropertyBroker.getProperty("Standalone");
		String SybilDBPool = sybilweb.plant.controller.PropertyBroker.getProperty("SybilDBPool","true");

		if(SybilDBPool.equalsIgnoreCase("true")) {
		Hashtable parms = new Hashtable();
		parms.put(Context.INITIAL_CONTEXT_FACTORY, "com.ibm.ejs.ns.jndi.CNInitialContextFactory");
		Context ctx = new InitialContext(parms);
		ds = (DataSource)ctx.lookup("jdbc/sybil");
	 	db2owner = 	sybilweb.plant.controller.PropertyBroker.getProperty("DB2OWNER");
		} 
	} catch (Exception e) {
		e.printStackTrace();
	}
}
public synchronized void clearAllRecords(String magName) throws SQLException {
	deleteTable.setString(1,magName);
	deleteTable.executeUpdate();
}
public void close() {
	try {
		conn.close();
	} catch (Exception e) {
	}
	conn = null;
}
public synchronized void createTable(String magName) {

	try {
		createTable.executeUpdate();
	} catch (Exception e) {
		try {
			clearAllRecords(magName);
		}catch(Exception clearEx) {
//			sybilweb.plant.controller.LogWriter.writeLog(clearEx);
		}
	}
}
/**
 * Set all the rolls in the groups specified to unselected
 */
public synchronized void deselectGroups(String magName, int [] groupNums) throws Exception {
	try {
		
		if( ds != null) {
		conn = ds.getConnection();
		} else {

			String user = sybilweb.plant.controller.PropertyBroker.getProperty("database.login","sybil");
			String pswd = sybilweb.plant.controller.PropertyBroker.getProperty("database.password","sybil");
			
			Class.forName(sybilweb.plant.controller.PropertyBroker.getProperty("SYBILDBDRIVER","oracle.jdbc.driver.OracleDriver") );
			conn = DriverManager.getConnection(sybilweb.plant.controller.PropertyBroker.getProperty("SYBILDBCONNSTRING","jdbc:oracle:thin:@localhost:1521:orcl"), user, pswd);
		}
		
		db2owner = 	sybilweb.plant.controller.PropertyBroker.getProperty("DB2OWNER");
		
		deselectGroups = conn.prepareStatement("update " +db2owner+"."+ tableName + " set STATE = " + sybilweb.plant.controller.CustomerGroupEntry.UNPROCESSED + ", FILENAME = ' '  where GROUP_NUM = ? and MAG_NAME = ?");
		
		for (int i = 0; i < groupNums.length; i++) {
			deselectGroups.setInt(1, groupNums[i]);
			deselectGroups.setString(2,magName);
			deselectGroups.execute();
		}
	deselectGroups.close();
	
	} catch (Exception e) {
		e.printStackTrace();
	}

	finally {

		if (conn != null) {
			
//		deselectGroups.close();
		conn.close();
//		System.out.println("Connection Closed");
	}  // if close
	
	} // finally close
}
protected void finalize( ) throws Exception {
	try {
		conn.close();
	} catch (Exception e) {
	}
	conn = null;
}
	public synchronized String findFilenameofGroup(int groupnum) throws Exception {
	String result = null;
	ResultSet rs = null;
	try {

		if( ds != null) {
		conn = ds.getConnection();
		} else {

			String user = sybilweb.plant.controller.PropertyBroker.getProperty("database.login","sybil");
			String pswd = sybilweb.plant.controller.PropertyBroker.getProperty("database.password","sybil");
			
			Class.forName(sybilweb.plant.controller.PropertyBroker.getProperty("SYBILDBDRIVER","oracle.jdbc.driver.OracleDriver") );
			conn = DriverManager.getConnection(sybilweb.plant.controller.PropertyBroker.getProperty("SYBILDBCONNSTRING","jdbc:oracle:thin:@localhost:1521:orcl"), user, pswd);
		}
		
		db2owner = 	sybilweb.plant.controller.PropertyBroker.getProperty("DB2OWNER");
		
		findFilenameofGroup = conn.prepareStatement("select FILENAME from " +db2owner+"."+ tableName + " where GROUP_NUM = ?");
		
		findFilenameofGroup.setInt(1,groupnum);
		rs = findFilenameofGroup.executeQuery();
		rs.next();
		result = rs.getString(1);

		findFilenameofGroup.close();
		
	} catch (Exception e) {
		sybilweb.plant.controller.LogWriter.writeLog(e);
	}

	// closes the Connection

	finally {
		if (conn != null) {
		
//		findLargestGroup.close();
		
		conn.close();
//		System.out.println("Connection Closed in PersistenceRoll");
	}  // if close
	
	} // finally close
	return result;
}
	public synchronized String findFilenameofGroup(String groupnum) throws Exception {
	String result = null;
	ResultSet rs = null;
	try {

		if( ds != null) {
		conn = ds.getConnection();
		} else {

			String user = sybilweb.plant.controller.PropertyBroker.getProperty("database.login","sybil");
			String pswd = sybilweb.plant.controller.PropertyBroker.getProperty("database.password","sybil");
			
			Class.forName(sybilweb.plant.controller.PropertyBroker.getProperty("SYBILDBDRIVER","oracle.jdbc.driver.OracleDriver") );
			conn = DriverManager.getConnection(sybilweb.plant.controller.PropertyBroker.getProperty("SYBILDBCONNSTRING","jdbc:oracle:thin:@localhost:1521:orcl"), user, pswd);
		}
		
		db2owner = 	sybilweb.plant.controller.PropertyBroker.getProperty("DB2OWNER");
		
		findFilenameofGroup = conn.prepareStatement("select FILENAME from " +db2owner+"."+ tableName + " where GROUP_NUM = ?");
		
		findFilenameofGroup.setString(1,groupnum);
		rs = findFilenameofGroup.executeQuery();
		rs.next();
		result = rs.getString(1);

		findFilenameofGroup.close();
		
	} catch (Exception e) {
		sybilweb.plant.controller.LogWriter.writeLog(e);
	}

	// closes the Connection

	finally {
		if (conn != null) {
		
//		findLargestGroup.close();
		
		conn.close();
//		System.out.println("Connection Closed in PersistenceRoll");
	}  // if close
	
	} // finally close
	return result;
}
/**
 * This method was created by a SmartGuide.
 */
private static void initializeLogFile()  {

	String prop = null;
	boolean writeLog = false;
	long maxFileSize = 0;
	String fPath;
	String fName;
	try {
		
//	sybilweb.plant.controller.PropertyBroker.load(sybilweb.plant.controller.PropertyBroker.inipath);

//		System.out.println(sybilweb.plant.controller.PropertyBroker.inipath);

		}catch(Exception e) { e.printStackTrace(); }
	
	// Get "LogMessages" switch. If not 'true', don't go any further.
	if ((prop = sybilweb.plant.controller.PropertyBroker.getProperty("LogFileDirectory")) != null) {
		prop.toLowerCase();
		if (prop.equals("true")) {
			writeLog = true;
		}
	}


//	System.out.println("LogFileDirectory"+sybilweb.plant.controller.PropertyBroker.getProperty("LogFileDirectory"));

	// Get "LogFileDirectory"
	if ((prop = sybilweb.plant.controller.PropertyBroker.getProperty("LogFileDirectory")) != null) {
		fPath = prop;
	} else {
//		System.out.println("Error: Log File Path not specified. Assuming none");
		fPath = null;
	}


	// Get "LogFileName"
	if ((prop = sybilweb.plant.controller.PropertyBroker.getProperty("LogFileName")) != null) {
		fName = prop;
	} else {
//		System.out.println("Error: Log File Name not specified. Assuming
// <logfile.log>");
		fName = "logfile.log";
	}

	// Get "LogFilemaxSize"
	if ((prop = sybilweb.plant.controller.PropertyBroker.getProperty("LogFileMaxSize")) != null) {
		maxFileSize = Integer.parseInt(prop);
	} else {
		maxFileSize = 100000;		// Default to 100K
	}

	sybilweb.plant.controller.LogWriter.initialize (writeLog, maxFileSize, fPath);

	return;
}
/**
 * This method was created by a SmartGuide.
 * 
 * @param args
 *            java.lang.String[]
 */
public static void main(String args[]) {

	java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("MM/dd/yy");
	try{
		sdf.parse("03/07/00");
	}catch (Exception e) {}

	java.util.GregorianCalendar now = new java.util.GregorianCalendar();
	now.add(Calendar.DAY_OF_YEAR, 300);
	java.util.Calendar cal = sdf.getCalendar();
	if(cal.after(now))
		System.out.println(cal.getTime().toString() + " after " + now.getTime().toString());
	else
		System.out.println(cal.getTime().toString() + " before " + now.getTime().toString());
}
	static boolean printSQLWarnings(SQLWarning w){
		if(w != null) {
				while(w != null) {
//					sybilweb.plant.controller.LogWriter.writeLog("SQLState: "+ w.getSQLState());
//					sybilweb.plant.controller.LogWriter.writeLog(" Code: "+ w.getErrorCode());
//					sybilweb.plant.controller.LogWriter.writeLog("Message: "+ w.getMessage());
					w = w.getNextWarning();
				}
				return true;
		}
		else {
			return false;
		}
	}
/**
 * This method was created by a SmartGuide.
 * 
 * @param filename
 *            java.lang.String
 */
public void setGroupFilename (String magName, int groupID, String filename ) throws Exception{
	try {
		setGroupFilename = conn.prepareStatement("update " + tableName + " set Filename = ? where GROUP_NUM = ? and MAG_NAME = ?");
		
		setGroupFilename.setString(1, filename);
		setGroupFilename.setInt(2, groupID);
		setGroupFilename.setString(3,magName);
		setGroupFilename.execute();
	} catch (Exception e) {
		System.out.println("Error in Updating the Database for the filename in Magazine information");
	}

	finally {
		if (conn != null) {

		setGroupFilename.close();
		
		conn.close();
//		System.out.println("Connection Closed");
		}  // if close
	
	} // finally close
	
	
	return;
}
public synchronized void updateRolls(String magName, Vector rolls) throws Exception {
	try {

		if( ds != null) {
		conn = ds.getConnection();
		} else {

			String user = sybilweb.plant.controller.PropertyBroker.getProperty("database.login","sybil");
			String pswd = sybilweb.plant.controller.PropertyBroker.getProperty("database.password","sybil");
			
			Class.forName(sybilweb.plant.controller.PropertyBroker.getProperty("SYBILDBDRIVER","oracle.jdbc.driver.OracleDriver") );
			conn = DriverManager.getConnection(sybilweb.plant.controller.PropertyBroker.getProperty("SYBILDBCONNSTRING","jdbc:oracle:thin:@localhost:1521:orcl"), user, pswd);
		}

		

		
/*
 * String db2owner =
 * sybilweb.plant.controller.PropertyBroker.getProperty("DB2OWNER"); String
 * query = "update " +db2owner+"."+ tableName + " set GROUP_NUM = ?, Sequence = ?,
 * BraceID = ?, DOP_ID = ?, RollID = ?, COPY_CNT = ?, CONTROLLER_FMT = ?,
 * CONTROLLER_FMT_KY = ?, OUTPUT_DEST = ?, OUTPUT_DEST_KEY = ?, SELECTED_FLAG = ?,
 * State = ?, FILENAME = ? where RollID = ? and MAG_NAME = ?";
 * 
 * 
 * 
 * saveRoll = conn.prepareStatement(query);
 * 
 * saveRoll.setInt(1, cge.getGroupID()); // CHANGE: have CustomerGroupWindowMgr
 * set sequence on rolls JY saveRoll.setInt(2, cge.getSequence());
 * saveRoll.setString(3, cge.braceID); saveRoll.setString(4, cge.dopID);
 * saveRoll.setString(5, cge.rollID); saveRoll.setInt(6, cge.copyCount);
 * saveRoll.setString(7, cge.controllerFormat);
 * saveRoll.setInt(8,cge.controllerFormatKey);
 * saveRoll.setString(9,cge.outputDestination);
 * saveRoll.setInt(10,cge.outputDestinationKey); if (cge.selected == true) {
 * saveRoll.setString(11, "T"); } else if (cge.selected == false) {
 * saveRoll.setString(11, "F"); } saveRoll.setByte(12, cge.state);
 * System.out.println("in saveRoll method filename is"+cge.fileName);
 * saveRoll.setString(13, cge.fileName); saveRoll.setString(14, cge.rollID);
 * saveRoll.setString(15,magName); saveRoll.execute();
 */
		
	} catch (Exception e) {

		System.out.println("save Roll Error");
		e.printStackTrace();
		
	}

	finally {
		if (conn != null) {
			
		saveRoll.close();
		
		conn.close();
//		System.out.println("Connection Closed");
	 }  // if close
	} // finally close

}

/**
 * Set all the rolls in the groups specified to unselected
 */
public synchronized void deselectGroups(String magName, int [] groupNums, String plant) throws Exception {
	try {
		
		if( ds != null) {
		conn = ds.getConnection();
		} else {

			String user = sybilweb.plant.controller.PropertyBroker.getProperty("database.login","sybil");
			String pswd = sybilweb.plant.controller.PropertyBroker.getProperty("database.password","sybil");
			
			Class.forName(sybilweb.plant.controller.PropertyBroker.getProperty("SYBILDBDRIVER","oracle.jdbc.driver.OracleDriver") );
			conn = DriverManager.getConnection(sybilweb.plant.controller.PropertyBroker.getProperty("SYBILDBCONNSTRING","jdbc:oracle:thin:@localhost:1521:orcl"), user, pswd);
		}
		
		db2owner = 	sybilweb.plant.controller.PropertyBroker.getProperty("DB2OWNER");
		
		deselectGroups = conn.prepareStatement("update " +db2owner+"."+ tableName + " set STATE = " + sybilweb.plant.controller.CustomerGroupEntry.UNPROCESSED + ", FILENAME = ' '  where GROUP_NUM = ? and MAG_NAME = ? and plant = ?");
		
		for (int i = 0; i < groupNums.length; i++) {
			deselectGroups.setInt(1, groupNums[i]);
			deselectGroups.setString(2,magName);
			deselectGroups.setString(3,plant);
			deselectGroups.execute();
		}
	deselectGroups.close();
	
	} catch (Exception e) {
		e.printStackTrace();
	}

	finally {

		if (conn != null) {
			
//		deselectGroups.close();
		conn.close();
//		System.out.println("Connection Closed");
	}  // if close
	
	} // finally close
}

/**
 * Selects out all the grouped unprocessed CustomerGroupEntry
 */
public synchronized Vector loadAllGroups(String magName, String plant) throws Exception{
	int groupID = 0;
	int oldGroupID = 0;
	sybilweb.plant.controller.CustomerGroup cg = new sybilweb.plant.controller.CustomerGroup();
	Vector v = new Vector();
	ResultSet rs = null;
	boolean firstRow = true;

	try {
		if( ds != null) {
		conn = ds.getConnection();
		} else {

			String user = sybilweb.plant.controller.PropertyBroker.getProperty("database.login","sybil");
			String pswd = sybilweb.plant.controller.PropertyBroker.getProperty("database.password","sybil");
			
			Class.forName(sybilweb.plant.controller.PropertyBroker.getProperty("SYBILDBDRIVER","oracle.jdbc.driver.OracleDriver") );
			conn = DriverManager.getConnection(sybilweb.plant.controller.PropertyBroker.getProperty("SYBILDBCONNSTRING","jdbc:oracle:thin:@localhost:1521:orcl"), user, pswd);
		}
		
		db2owner = 	sybilweb.plant.controller.PropertyBroker.getProperty("DB2OWNER");
			
		selectAll = conn.prepareStatement("select GROUP_NUM, Sequence, BraceID, DOP_ID, RollID, COPY_CNT, CONTROLLER_FMT, CONTROLLER_FMT_KY, State from " +db2owner+"."+ tableName + " where MAG_NAME = ? and PLANT = ? ORDER BY RollID");
		
		selectAll.setString(1,magName);
		selectAll.setString(2,plant);		
		rs = selectAll.executeQuery();
		
		
		while (rs.next()) {
			sybilweb.plant.controller.CustomerGroupEntry cge = new sybilweb.plant.controller.CustomerGroupEntry();
			cge.setGroupID(rs.getInt("GROUP_NUM"));

			oldGroupID = groupID;
			groupID = cge.getGroupID();
			if (firstRow) {
				firstRow = false;
				oldGroupID = groupID;
			}
			cge.setSequence(rs.getInt("Sequence"));
			cge.braceID = rs.getString("BraceID").trim();
			cge.dopID = rs.getString("DOP_ID").trim();
			cge.rollID = rs.getString("RollID").trim();
			String s = rs.getString("CONTROLLER_FMT");
			if (s == null) {
				s = "";
			}
			cge.controllerFormat = s.trim();
			cge.controllerFormatKey = rs.getInt("CONTROLLER_FMT_KY");
			cge.copyCount = rs.getInt("COPY_CNT");
			cge.state = rs.getByte("State");
			// CHANGE: add error handling for something not "T" or "F"
			cg.outputFormat = cge.controllerFormatKey;
			if (groupID != oldGroupID) {
				v.addElement(cg);
				cg = new sybilweb.plant.controller.CustomerGroup();
			}
			cg.addCustomerGroupEntry(cge);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}

	// Finally Close the Connection and return it to the Pool
	
	finally {
		if (conn != null) {
		selectAll.close();
		conn.close();
		}
	} 
	
	if (cg.getNumberOfGroupEntries() > 0) 
		v.addElement(cg);
	
	


	return v;
}

/**
 * Selects out all the grouped unprocessed CustomerGroupEntry
 */
public synchronized Vector loadSelectedGroups(String magName, String plant) throws Exception {
	int groupID = 0;
	int oldGroupID = 0;
	sybilweb.plant.controller.CustomerGroup cg = new sybilweb.plant.controller.CustomerGroup();
	Vector v = new Vector();
	ResultSet rs = null;
	boolean firstRow = true;

	try {
		if( ds != null) {
		conn = ds.getConnection();
		} else {

			String user = sybilweb.plant.controller.PropertyBroker.getProperty("database.login","sybil");
			String pswd = sybilweb.plant.controller.PropertyBroker.getProperty("database.password","sybil");
			
			Class.forName(sybilweb.plant.controller.PropertyBroker.getProperty("SYBILDBDRIVER","oracle.jdbc.driver.OracleDriver") );

			conn = DriverManager.getConnection(sybilweb.plant.controller.PropertyBroker.getProperty("SYBILDBCONNSTRING","jdbc:oracle:thin:@localhost:1521:orcl"), user, pswd);
		}

		db2owner = 	sybilweb.plant.controller.PropertyBroker.getProperty("DB2OWNER");
		
		selected = conn.prepareStatement("select GROUP_NUM, Sequence, BraceID, DOP_ID, RollID, COPY_CNT, CONTROLLER_FMT, CONTROLLER_FMT_KY, State, FILENAME from " +db2owner+"."+ tableName + " where MAG_NAME = ? and FILENAME <> ' ' and PLANT = ? ORDER BY GROUP_NUM, Sequence with UR");

		
		selected.setString(1,magName);
		selected.setString(2,plant.trim());		
		rs = selected.executeQuery();


		
		while (rs.next()) {
			sybilweb.plant.controller.CustomerGroupEntry cge = new sybilweb.plant.controller.CustomerGroupEntry();
			cge.setGroupID(rs.getInt("GROUP_NUM"));
//			System.out.println(cge.getGroupID());
			oldGroupID = groupID;
			groupID = cge.getGroupID();
			if (firstRow) {
				firstRow = false;
				oldGroupID = groupID;
			}
			cge.setSequence(rs.getInt("Sequence"));
			cge.braceID = rs.getString("BraceID").trim();
			cge.dopID = rs.getString("DOP_ID").trim();
			cge.rollID = rs.getString("RollID").trim();
//			System.out.println(cge.rollID);
			String s = rs.getString("CONTROLLER_FMT");
			if (s == null) {
				s = "";
			}
			cge.controllerFormat = s.trim();
			cge.controllerFormatKey = rs.getInt("CONTROLLER_FMT_KY");
			cge.copyCount = rs.getInt("COPY_CNT");
			cge.state = rs.getByte("State");
			cge.fileName = rs.getString("FILENAME");

			// CHANGE: add error handling for something not "T" or "F"
			cg.outputFormat = cge.controllerFormatKey;
//			cg.outputDestination = cge.outputDestinationKey;

			if (groupID != oldGroupID) {
				v.addElement(cg);
				cg = new sybilweb.plant.controller.CustomerGroup();
			}
			cg.addCustomerGroupEntry(cge);
		}
	} catch (Exception e) {
		sybilweb.plant.controller.LogWriter.writeLog(e);
	}

	finally {

		if (conn != null) {

		selected.close();
		
		conn.close();
//		System.out.println("Connection Closed");
		}  // if close
	
	} // finally close
	
	if (cg.getNumberOfGroupEntries() > 0) {
		v.addElement(cg);
	}


	return v;
}

/**
 * Selects out all the grouped unprocessed CustomerGroupEntry
 */
public synchronized Vector loadUnselectedGroups(String magName, String plant) throws Exception {
	int groupID = 0;
	int oldGroupID = 0;
	sybilweb.plant.controller.CustomerGroup cg = new sybilweb.plant.controller.CustomerGroup();
	Vector v = new Vector();
	ResultSet rs = null;
	boolean firstRow = true;

	
	try {
		if( ds != null) {
		conn = ds.getConnection();
		} else {

			String user = sybilweb.plant.controller.PropertyBroker.getProperty("database.login","sybil");
			String pswd = sybilweb.plant.controller.PropertyBroker.getProperty("database.password","sybil");
			
			Class.forName(sybilweb.plant.controller.PropertyBroker.getProperty("SYBILDBDRIVER","oracle.jdbc.driver.OracleDriver") );
			conn = DriverManager.getConnection(sybilweb.plant.controller.PropertyBroker.getProperty("SYBILDBCONNSTRING","jdbc:oracle:thin:@localhost:1521:orcl"), user, pswd);
		}
		
		db2owner = 	sybilweb.plant.controller.PropertyBroker.getProperty("DB2OWNER");
		
		unselected = conn.prepareStatement("select GROUP_NUM, Sequence, BraceID, DOP_ID, RollID, COPY_CNT, CONTROLLER_FMT, CONTROLLER_FMT_KY, State from " +db2owner+"."+ tableName + " where MAG_NAME = ? and FILENAME = ' ' and PLANT = ? ORDER BY BraceID, DOP_ID, RollID with UR");
		
		unselected.setString(1,magName);
		unselected.setString(2,plant);		
		rs = unselected.executeQuery();
		while (rs.next()) {
			sybilweb.plant.controller.CustomerGroupEntry cge = new sybilweb.plant.controller.CustomerGroupEntry();
			cge.setGroupID(rs.getInt("GROUP_NUM"));
			oldGroupID = groupID;
			groupID = cge.getGroupID();
			if (firstRow) {
				firstRow = false;
				oldGroupID = groupID;
			}
			cge.setSequence(rs.getInt("Sequence"));
			cge.braceID = rs.getString("BraceID").trim();
			cge.dopID = rs.getString("DOP_ID").trim();
			cge.rollID = rs.getString("RollID").trim();
			String s = rs.getString("CONTROLLER_FMT");
			if (s == null) {
				s = "";
			}
			cge.controllerFormat = s.trim();
			cge.controllerFormatKey = rs.getInt("CONTROLLER_FMT_KY");
			cge.copyCount = rs.getInt("COPY_CNT");
			cge.state = rs.getByte("State");


			cg.outputFormat = cge.controllerFormatKey;
//			cg.outputDestination = cge.outputDestinationKey;

			if (groupID != oldGroupID) {
				v.addElement(cg);
				cg = new sybilweb.plant.controller.CustomerGroup();
			}
			cg.addCustomerGroupEntry(cge);
		}
	} catch (Exception e) {
			e.printStackTrace();
//		sybilweb.plant.controller.LogWriter.writeLog(e);
	}

  finally {

		if (conn != null) {

		unselected.close();
		
		conn.close();
//		System.out.println("Connection Closed");
	}  // if close
	
	} // finally close


	
	if (cg.getNumberOfGroupEntries() > 0) {
		v.addElement(cg);
	}

	return v;
}

	public synchronized void saveRollID(String magName, Vector rolls, int grpID, String ctlFmt, String fileName, String plant) throws Exception {
	try {

		if( ds != null) {
		conn = ds.getConnection();
		} else {

			String user = sybilweb.plant.controller.PropertyBroker.getProperty("database.login","sybil");
			String pswd = sybilweb.plant.controller.PropertyBroker.getProperty("database.password","sybil");
				
			Class.forName(sybilweb.plant.controller.PropertyBroker.getProperty("SYBILDBDRIVER","oracle.jdbc.driver.OracleDriver") );
			conn = DriverManager.getConnection(sybilweb.plant.controller.PropertyBroker.getProperty("SYBILDBCONNSTRING","jdbc:oracle:thin:@localhost:1521:orcl"), user, pswd);
		}

		db2owner = 	sybilweb.plant.controller.PropertyBroker.getProperty("DB2OWNER");

		java.util.Date now = new java.util.Date();
		java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("yyyy.MM.dd kk:mm:ss");

		
		String query = "update " +db2owner+"."+ tableName + " set GROUP_NUM = ?, Sequence = ?, CONTROLLER_FMT = ?, FILENAME = ?, UPDATE_DATETIME = ? where RollID = ? and MAG_NAME = ? and PLANT = ?";
		saveRoll = conn.prepareStatement(query);

		for(int rollCounter=0; rollCounter<rolls.size(); rollCounter++) {
			
			saveRoll.setInt(1, grpID);
			saveRoll.setInt(2, rollCounter);
			saveRoll.setString(3, ctlFmt);
			saveRoll.setString(4,fileName);
			saveRoll.setString(5,dateFormat.format(now));
			saveRoll.setString(6,((String)rolls.elementAt(rollCounter)).trim());
			saveRoll.setString(7,magName);
			saveRoll.setString(8,plant.trim().toUpperCase());			
	
			saveRoll.execute();
		}

	
	} catch (Exception e) {
		LogWriter.writeLog(e);
		e.printStackTrace();
	}

	finally {
		if (conn != null) {
		saveRoll.close();
		conn.close();

	 }  
	} 

}

public synchronized int findLargestGroup(String magName, String Plantid) throws Exception {
	int result = 0;
	ResultSet rs = null;
	try {

		if( ds != null) {
		conn = ds.getConnection();
		} else {

			String user = sybilweb.plant.controller.PropertyBroker.getProperty("database.login","sybil");
			String pswd = sybilweb.plant.controller.PropertyBroker.getProperty("database.password","sybil");
			
			Class.forName(sybilweb.plant.controller.PropertyBroker.getProperty("SYBILDBDRIVER","oracle.jdbc.driver.OracleDriver") );

			conn = DriverManager.getConnection(sybilweb.plant.controller.PropertyBroker.getProperty("SYBILDBCONNSTRING","jdbc:oracle:thin:@localhost:1521:orcl"), user, pswd);

		}
		
		db2owner = 	sybilweb.plant.controller.PropertyBroker.getProperty("DB2OWNER");
		
		findLargestGroup = conn.prepareStatement("select MAX(GROUP_NUM) from " +db2owner+"."+ tableName + " where MAG_NAME = ? and PLANT = ?");
		
		findLargestGroup.setString(1,magName);
		findLargestGroup.setString(2,Plantid);
		rs = findLargestGroup.executeQuery();
		rs.next();
		result = rs.getInt(1);

		findLargestGroup.close();
		
	} catch (Exception e) {
		sybilweb.plant.controller.LogWriter.writeLog(e);
	}

	// closes the Connection

	finally {
		if (conn != null) {
		
//		findLargestGroup.close();
		
		conn.close();
//		System.out.println("Connection Closed in PersistenceRoll");
	}  // if close
	
	} // finally close
	return result;
}

/**
 * Selects out all the grouped unprocessed CustomerGroupEntry
 */
public synchronized Vector loadSelectedOutputFileGroups(String MagName, int GroupNumber, String outputFile, String Plantid) throws Exception {
	int groupID = 0;
	int oldGroupID = 0;
	sybilweb.plant.controller.CustomerGroup cg = new sybilweb.plant.controller.CustomerGroup();
	Vector v = new Vector();
	ResultSet rs = null;
	boolean firstRow = true;
	Connection tempConn = null;
	PreparedStatement tempUnselected = null;
	ResultSet temprs = null;
		
	try {
			String user = sybilweb.plant.controller.PropertyBroker.getProperty("database.login","sybil");
			String pswd = sybilweb.plant.controller.PropertyBroker.getProperty("database.password","sybil");

			Class.forName(sybilweb.plant.controller.PropertyBroker.getProperty("SYBILDBDRIVER","oracle.jdbc.driver.OracleDriver") );
			long starttime = new java.util.Date().getTime();
			long timeout = 3000;
			int counter = 0;
			while(  ((tempConn = DriverManager.getConnection(sybilweb.plant.controller.PropertyBroker.getProperty("SYBILDBCONNSTRING","jdbc:oracle:thin:@localhost:1521:orcl"), user, pswd)) == null) && (counter<5)) {
					wait(timeout);
					counter++;
			}

		if(tempConn == null){ return null; }else {
			LogWriter.writeLog("I", Plantid.trim().toUpperCase(), MagName," Opened Connection for Group # "+GroupNumber+" loadSelectedOutputFileGroups method ");
		}
		
		printSQLWarnings(tempConn.getWarnings());
			
		db2owner = 	sybilweb.plant.controller.PropertyBroker.getProperty("DB2OWNER");

		tempUnselected = tempConn.prepareStatement("select MAG_NAME, GROUP_NUM, Sequence, BraceID, DOP_ID, RollID, COPY_CNT, CONTROLLER_FMT, CONTROLLER_FMT_KY, State, FILENAME from " +db2owner+"."+ tableName + " where MAG_NAME = ? and GROUP_NUM = ? and FILENAME = ? and PLANT = ? ORDER BY Sequence with UR");
		tempUnselected.setString(1,MagName.trim());
		tempUnselected.setInt(2,GroupNumber);		
		tempUnselected.setString(3,outputFile.trim());
		tempUnselected.setString(4,Plantid.trim().toUpperCase());

		temprs = tempUnselected.executeQuery();

		boolean sqlcode100 = true;
		
		while (temprs.next()) {
			sqlcode100 = false;
			sybilweb.plant.controller.CustomerGroupEntry cge = new sybilweb.plant.controller.CustomerGroupEntry();

			cge.magazine = temprs.getString("MAG_NAME");

			cge.setGroupID(temprs.getInt("GROUP_NUM"));
			oldGroupID = groupID;
			groupID = cge.getGroupID();
			if (firstRow) {
				firstRow = false;
				oldGroupID = groupID;
			}
			cge.setSequence(temprs.getInt("Sequence"));
			cge.braceID = temprs.getString("BraceID").trim();
			cge.dopID = temprs.getString("DOP_ID").trim();
			cge.rollID = temprs.getString("RollID").trim();
			String s = temprs.getString("CONTROLLER_FMT");
			if (s == null) {
				s = "";
			}
			cge.controllerFormat = s.trim();
			cge.controllerFormatKey = temprs.getInt("CONTROLLER_FMT_KY");
			cge.copyCount = temprs.getInt("COPY_CNT");
			cge.state = temprs.getByte("State");

			cge.fileName = temprs.getString("FILENAME");

			cg.outputFormat = cge.controllerFormatKey;
//			cg.outputDestination = cge.outputDestinationKey;

			if (groupID != oldGroupID) {
				v.addElement(cg);
				cg = new sybilweb.plant.controller.CustomerGroup();
			}
			cg.addCustomerGroupEntry(cge);


		}

		if(sqlcode100){
				String FormatCtlFiledir = PropertyBroker.getProperty("FormatterControlPath");
				String Filename = FormatCtlFiledir + MagName.trim() + "." + GroupNumber + "." + outputFile.trim().concat(".000");
				sybilweb.plant.controller.LogWriter.writeLog("E", "", "", "SQLException ErrorCode 100 deleting file"+Filename);				
				File rf = new File(Filename);
				rf.delete();
		}
		
		
	} 
	catch(SQLException sqle){
		sybilweb.plant.controller.LogWriter.writeLog(sqle);
		sybilweb.plant.controller.LogWriter.writeLog("E", "", "", "SQLException ErrorCode"+String.valueOf(sqle.getErrorCode()));
		
	}
	catch (Exception e) {
		sybilweb.plant.controller.LogWriter.writeLog("E", "", "", "loadSelectedOutputFileGroups");		
		sybilweb.plant.controller.LogWriter.writeLog(e);
	}

  finally {

		if (tempConn != null) {

		try {
		temprs.close();		
		tempUnselected.close();
		tempConn.close();
		LogWriter.writeLog("I", Plantid.trim().toUpperCase(), MagName, " Closed Connection for Group # "+GroupNumber+" loadSelectedOutputFileGroups method "+ tempConn.isClosed());
		tempConn = null;
			} catch(Exception ex) { 
				ex.printStackTrace();
				sybilweb.plant.controller.LogWriter.writeLog(ex);
				}
//		System.out.println("Connection Closed");
	}  
	
	} 


	
	if (cg.getNumberOfGroupEntries() > 0) {
		v.addElement(cg);
	}

	return v;
}

public synchronized Integer saveRoll(String MagName, int GroupNumber, String ActualFileName, sybilweb.plant.controller.CustomerGroupEntry cge, String OutputFile, int rollRecordCount, String Plant) throws Exception {

	Connection tempConn = null;
	PreparedStatement tempSaveRoll = null;
	Integer updateCount = null;
	String dataOutputPath = sybilweb.plant.controller.PropertyBroker.getProperty("DataOutputPath");
	String fileconcattest = sybilweb.plant.controller.PropertyBroker.getProperty("FormatterFileConcatText");
	String longOutputFileName = dataOutputPath.concat(OutputFile.substring(0,OutputFile.length()-4).concat(fileconcattest).concat(".tmp"));
	File longOutputFile = new File(longOutputFileName);
//	if(!longOutputFile.exists())
//			sybilweb.plant.controller.LogWriter.writeLog("I", Plant.trim().toUpperCase(),
// longOutputFileName, " outputfile in SaveRoll");
	java.util.Date now = new java.util.Date();
	java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("yyyy.MM.dd kk:mm:ss");

	
	try {
			String user = sybilweb.plant.controller.PropertyBroker.getProperty("database.login","sybil");
			String pswd = sybilweb.plant.controller.PropertyBroker.getProperty("database.password","sybil");
			
			Class.forName(sybilweb.plant.controller.PropertyBroker.getProperty("SYBILDBDRIVER","oracle.jdbc.driver.OracleDriver") );
			long starttime = new java.util.Date().getTime();
			long timeout = 3000;
			int counter = 0;
			while( ((tempConn = DriverManager.getConnection(sybilweb.plant.controller.PropertyBroker.getProperty("SYBILDBCONNSTRING","jdbc:oracle:thin:@localhost:1521:orcl"), user, pswd)) == null) && (counter<5) ) {
					wait(timeout);
					counter++;
			}

		if(tempConn == null){ return null; }else{
		LogWriter.writeLog("I", Plant.trim().toUpperCase(), MagName, " Opened Connection for Group # "+GroupNumber+" saveRoll method ");
		}
		
		db2owner = 	sybilweb.plant.controller.PropertyBroker.getProperty("DB2OWNER");
		String query = "update " +db2owner+"."+ tableName + " set State = ?, FILE_SIZE = ?, UPDATE_DATETIME = ?, RECORD_COUNT = ?  where MAG_NAME = ? and GROUP_NUM = ? and FILENAME = ? and ROLLID = ? and PLANT = ?";
	
		tempSaveRoll = tempConn.prepareStatement(query);
		tempSaveRoll.setByte(1, cge.state);
		tempSaveRoll.setInt(2,(new Long(longOutputFile.length()).intValue()));
		tempSaveRoll.setString(3,String.valueOf(dateFormat.format(now)));
		tempSaveRoll.setInt(4,rollRecordCount);		
		tempSaveRoll.setString(5,MagName);
		tempSaveRoll.setInt(6,GroupNumber);
		tempSaveRoll.setString(7,ActualFileName);
		tempSaveRoll.setString(8, cge.rollID);
		tempSaveRoll.setString(9, Plant.trim().toUpperCase());
		

		int saverollcounter = 0;
		updateCount = new Integer(0);
		
		while( (updateCount.intValue() <= 0) && (saverollcounter < 5) ) {
			tempSaveRoll.execute();
			updateCount = new Integer(tempSaveRoll.getUpdateCount());
			wait(timeout);
			saverollcounter++;
		}


		if(updateCount.equals(new Integer(0))){
			sybilweb.plant.controller.LogWriter.writeLog("E", Plant.trim().toUpperCase(), MagName, "Connection Found but could not able to update Roll status");

				String FormatCtlFiledir = PropertyBroker.getProperty("FormatterControlPath");
				String Filename = FormatCtlFiledir + MagName.trim() + "." + GroupNumber + "." + ActualFileName.trim().concat(".001");
				File rf = new File(Filename);
				String newfile = Filename.substring(0,Filename.length()-3);
				newfile = newfile.concat("000");
				String newfilepath = FormatCtlFiledir + "/" + newfile;
				rf.delete();
					try {
						FileWriter f = new FileWriter(newfilepath);
					} catch(Exception ex) { LogWriter.writeLog(ex); LogWriter.writeLog("E", "", MagName, "Unable to create Formatter flag file "+ newfilepath); }
		}else if(updateCount.intValue() > 0){
			LogWriter.writeLog("I", Plant.trim().toUpperCase(), MagName, " Updated Roll "+ cge.rollID+" to "+ cge.state +" in GroupNumber " +GroupNumber+" for "+OutputFile);
		}
		
		
	} catch (Exception e) {
		LogWriter.writeLog("E", Plant.trim().toUpperCase(), MagName, " Error in updating the status "+ cge.rollID+" GroupNumber " +GroupNumber);									
		LogWriter.writeLog(e);
	}

	finally {
		if (tempConn != null) {
		tempSaveRoll.close();
		tempConn.close();
		LogWriter.writeLog("I", Plant.trim().toUpperCase(), MagName," Closed Connection for Group # "+GroupNumber+" saveRoll method "+ tempConn.isClosed());
		tempConn = null;
	 }
		
	}
	return updateCount;
}
public synchronized void updateTrackingSchd(Magazine mag) throws Exception {
	
	String TracktableName = "TBA_LBL_TRK_SCHD";
	ResultSet resultset = null;
	PreparedStatement updateTrackSchd = null; 
	boolean NOREC = true;
	int copyCount = 0, magKey = 0;
	byte DONE = 2;

	try {
		if (ds != null) {
			conn = ds.getConnection();
		}
		else {
			String user = sybilweb.plant.controller.PropertyBroker.getProperty("database.login","sybil");
			String pswd = sybilweb.plant.controller.PropertyBroker.getProperty("database.password","sybil");
			
			Class.forName(sybilweb.plant.controller.PropertyBroker.getProperty("SYBILDBDRIVER","oracle.jdbc.driver.OracleDriver") );

			conn = DriverManager.getConnection(sybilweb.plant.controller.PropertyBroker.getProperty("SYBILDBCONNSTRING","jdbc:oracle:thin:@localhost:1521:orcl"), user, pswd);

		}
		db2owner = sybilweb.plant.controller.PropertyBroker.getProperty("DB2OWNER");

		selectProcessRec = conn
				.prepareStatement("select COPY_CNT, State from "
						+ db2owner
						+ "."
						+ tableName
						+ " where MAG = ? and PLANT = ? and ISSUE = ? and WEEK_NUM = ? and DELIVERY_TYPE = ? and PROCESS_TYPE = ? and DATA_TYPE = ? and STATE < ? and ROLLID < ?  ");

		LogWriter.writeLog("Select TBD_LBL_TRK_SCHD query " + selectProcessRec);
		selectProcessRec.setString(1, mag.getMagCode());
		selectProcessRec.setString(2, mag.getPlant().trim().toUpperCase());
		selectProcessRec.setString(3, mag.getIssue());
		selectProcessRec.setString(4, mag.getWeek());
		selectProcessRec.setString(5, mag.getDeliveryType());
		selectProcessRec.setString(6, mag.getProcessType());
		selectProcessRec.setString(7, mag.getDataType());
		selectProcessRec.setByte(8, DONE);
		selectProcessRec.setString(9, "9999");
		resultset = selectProcessRec.executeQuery();

		while (resultset.next()) {
			NOREC = false;
			copyCount = (int)resultset.getInt("COPY_CNT");
			if ( resultset.getByte("State") == CustomerGroupEntry.ERROR){
				LogWriter.writeLog("I", mag.getPlant().trim().toUpperCase(),mag.getMagName(), " Process with Error status ");
			}
			else {
//				LogWriter.writeLog("I", mag.getPlant().trim().toUpperCase(),mag.getMagName(), " Process with Error status : " + resultset.getByte("State"));
			}
		}
 
/*  The TBA_LBL_TRK_SCHD table will be updated with processed date only if all the rolls
 *  has been grouped. 
 * 
 * 
 */	
	Date toDay = new Date(); 
	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd kk:mm:ss"); 
	
	if (NOREC) {
			String magkyquery = "select distinct MAG_KY from " + db2owner +"." + TracktableName+ " WHERE MAG_CODE = '"+mag.getMagCode() +"'";
			LogWriter.writeLog("magkyquery "+ magkyquery);
			selectMagKeyRec = conn.prepareStatement(magkyquery);

//			selectMagKeyRec.setString(1, mag.getMagCode());
			resultset = selectMagKeyRec.executeQuery();
			while (resultset.next()) {
				magKey = (int) resultset.getInt("MAG_KY");
			}

			String SQL = "update " + db2owner + "."
				+ TracktableName
				+ " set ACCESSED_DT_TMST = ? where MAG_KY = ? and MAG_CODE = ? and PLANT = ? and ISS_NUM = ? and ISS_WK_NUM = ? and DELIVERY_TYPE = ? and PROCESS_TYPE = ? and DATA_TYPE = ? ";

			LogWriter.writeLog("update TBD_LBL_TRK_SCHD query " + SQL);
			updateTrackSchd = conn.prepareStatement(SQL);
			updateTrackSchd.setString(1,String.valueOf(dateFormat.format(toDay)));
			updateTrackSchd.setInt(2, magKey);
			updateTrackSchd.setString(3, mag.getMagCode());
			updateTrackSchd.setString(4, mag.getPlant().trim().toUpperCase());
			updateTrackSchd.setInt(5, Integer.parseInt(mag.getIssue()));
			updateTrackSchd.setInt(6, mag.getWeekNumber());
			updateTrackSchd.setString(7, mag.getDeliveryType().toUpperCase());
			updateTrackSchd.setString(8, mag.getProcessType().toUpperCase());
			updateTrackSchd.setString(9, mag.getDataType().toUpperCase());
			
			int noRecUpdate = updateTrackSchd.executeUpdate();
			
			if (noRecUpdate > 0) {
				LogWriter.writeLog("I", mag.getPlant().trim().toUpperCase(),mag.getMagName(), " Process updated Tracking Schedule Access date ");
			}
			else{
				LogWriter.writeLog("I", mag.getPlant().trim().toUpperCase(),mag.getMagName(), " Process not updated any Tracking Schedule");
			}
		}		
	}	
	catch(Exception e){
		e.printStackTrace();
	}
	finally {
		if (conn != null) {
/*			updateTrackSchd.close();
			selectProcessRec.close();
			selectMagKeyRec.close();
*/			conn.close(); 
			}
		} 
	}
 }
