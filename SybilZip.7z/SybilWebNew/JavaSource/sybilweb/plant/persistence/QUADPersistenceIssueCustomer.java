package sybilweb.plant.persistence;

import java.io.*;
import java.util.Vector;
import sybilweb.plant.controller.*;



public class QUADPersistenceIssueCustomer extends PersistenceIssueCustomer {

    public static final String Class_Version_Number = "PR_6.2_REL9.4";
    
	private static final String profileBarData = "1003810076600000000095348430709";
    
    int rec_count = 1;
	int unique_id = 1;
	String LabelLine8;
	char barcode_head = '\u007C';
	char barcode_tail = '\u007C';
	int packageCount = 1;
	int TKSeqnum;

    public QUADPersistenceIssueCustomer() {  
    	TKSeqnum = 1;
    }

    public void createOutputFile(String prop, String outputFileName) {
        
    	this.outputFileName = outputFileName;
        outFileName = outputFileName;
        
        useShortFileName = PropertyBroker.getProperty("useShortFileName", "false");
        shortFileName = outputFileName.substring(0, outputFileName.lastIndexOf("/") + 1).concat(outputFileName.substring(outputFileName.lastIndexOf(".") + 1, outputFileName.length()));
        
        plant = mag.getPlant().toUpperCase();
        rec_count = 1;
        String FormatterFileConcatText = null;
        FormatterFileConcatText = PropertyBroker.getProperty("FormatterFileConcatText");
        
        String fileName = null;
        fileName = (new StringBuilder(String.valueOf(PropertyBroker.getProperty("OLDFILEDIR")))).append(mag.getFullPrefix()).append(".RLL5").toString();
        File f = new File(fileName);
        BufferedReader fileReader = null;
        
        if(f.exists()) {
            try
            {
                fileReader = new BufferedReader(new FileReader(fileName));
            }
            catch(FileNotFoundException fnfe) {
                LogWriter.writeLog(new Exception((new StringBuilder(String.valueOf(mag.getPrefix()))).append(": Error opening RLL5 file: File not found: ").append(fileName).toString()));
                return;
            }
            
            try
            {
                RLL5value = fileReader.readLine();
                LogWriter.writeLog((new StringBuilder("RLL5value = ")).append(RLL5value).toString());
            }
            catch(EOFException eofexception) { }
            catch(Exception re) {
                LogWriter.writeLog(re);
            }
        } else {
            RLL5value = "false";
        }
        
        if(FormatterFileConcatText == null) {
            FormatterFileConcatText = "";
        }
        
        if(useShortFileName.equals("true")) {
            formatShortFileName = true;
        }
        
        if(formatShortFileName) {
            shortOutputFileName = (new StringBuilder(String.valueOf(prop))).append(shortFileName).toString();
            tmpFile = new File((new StringBuilder(String.valueOf(prop))).append(outputFileName).append(FormatterFileConcatText).append(".tmp").toString());
        } else {
            longOutputFileName = (new StringBuilder(String.valueOf(prop))).append(mag.getLongFileName()).append(fileSep).append(shortFileName).toString();
            tmpFile = new File((new StringBuilder(String.valueOf(longOutputFileName))).append(FormatterFileConcatText).append(".tmp").toString());
        }
        
        LogWriter.writeLog((new StringBuilder("outputFileName = ")).append(outputFileName).toString());
        LogWriter.writeLog((new StringBuilder("prop = ")).append(prop).toString());
        LogWriter.writeLog((new StringBuilder("tmpFile = ")).append(tmpFile).toString());
        
        try
        {
            outputFile = new OutputStreamWriter(new FileOutputStream(tmpFile), "ISO8859_1");
        }
        catch(IOException e) {
            LogWriter.writeLog(new SybilWarningException((new StringBuilder(String.valueOf(mag.getPrefix()))).append(": Error creating output file: ").append(e.getMessage()).toString()));
            return;
        }
        
        if(formatShortFileName) {
            shortOutputFileName = (new StringBuilder(String.valueOf(prop))).append(shortFileName).toString();
            newFile = new File((new StringBuilder(String.valueOf(shortOutputFileName))).append(FormatterFileConcatText).append(".add").toString());
        } else {
            longOutputFileName = (new StringBuilder(String.valueOf(prop))).append(mag.getLongFileName()).append(fileSep).append(shortFileName).toString();
            newFile = new File((new StringBuilder(String.valueOf(longOutputFileName))).append(FormatterFileConcatText).append(".add").toString());
        }
        
        if(newFile.exists()) {
            newFile.delete();
        }
        LogWriter.writeLog("I", mag.getPlant().toUpperCase(), mag.getPrefix(), (new StringBuilder(String.valueOf(outputFileName))).append(" Started Formatting").toString());
    }

    protected String formatData(IssueCustomer ic) {
        
    	String data = null;
        data = formatDataIMB(ic);
        return data;
    }

    protected String formatDataNonIMB(IssueCustomer ic) {
        
    	StringBuffer buf = new StringBuffer(1024);
        String labelLine = null;
        
        String magCode = mag.getMagCode();
        
        LabelLine8 = PropertyBroker.getProperty("LabelLine8");
        LL8Override = PropertyBroker.getProperty("LL8Override");
        nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
        String oldLL8 = PropertyBroker.getProperty("oldLL8");
        
        
      //*************RECORD CONTROL INFORMATION***********************//
        
        
     // ZIP CODE 
        try
        {
            if(ic.getMagazineLabel().labelType.equalsIgnoreCase("USPS")) {
                buf.append(StringFunctions.fixSize(ic.getMagazineLabel().USzipCode, 5, '0', StringFunctions.RIGHT));
            } else if(ic.getMagazineLabel().labelType.equalsIgnoreCase("CAN")) {
                buf.append(StringFunctions.fixSize(ic.getMagazineLabel().canadianZipCode, 5, '0', StringFunctions.RIGHT));
            } else {
                buf.append("00000");
            }
        }
        catch(Exception exception) { }
        
     // PALLET/Sack Number
        if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY") || ic.getMagazineLabel().endorsementLine.equals("POSTAL BOOK") || ic.getMagazineLabel().endorsementLine.equals("STORAGE BOOK"))
        {
            buf.append("ZZZZ");
        } else {
            buf.append(StringFunctions.fixSize(ic.getMagazineLabel().palletSackNumber, 4, '0', StringFunctions.RIGHT));
        }
        
     // increment every time there is an end of Package changes//
        if(ic.getEndPackageIndicator()) {
            buf.append((new StringBuilder(String.valueOf(StringFunctions.fixSize(String.valueOf(packageCount++), 3, '0', StringFunctions.RIGHT)))).append(" ").toString());
            if(packageCount == 1000) {
                packageCount = 1;
            }
        } else {
            buf.append((new StringBuilder(String.valueOf(StringFunctions.fixSize(String.valueOf(packageCount), 3, '0', StringFunctions.RIGHT)))).append(" ").toString());
        }
     // rec_count
        buf.append((new StringBuilder(String.valueOf(StringFunctions.fixSize(String.valueOf(rec_count++), 6, '0', StringFunctions.RIGHT)))).append(" ").toString());
     // CONSTANT
        buf.append("01 02 00 ");
     // Driver Code
        buf.append((new StringBuilder(String.valueOf(StringFunctions.fixSize(ic.getMakeupCode(), 4, '0', StringFunctions.RIGHT)))).append(" ").toString());
     // First four Characters of the Subscriber name
        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().customerName, 4, ' ', StringFunctions.RIGHT));
     // First four Characters of the address line 1
        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().addressLine1, 4, ' ', StringFunctions.RIGHT));
        
        
        if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
        {
            for(int i = 1; i <= 8; i++) {
                if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                    labelLine = ic.getMagazineLabel().getTextLine(i).substring(0, trimSize);
                } else {
                    labelLine = StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(i), trimSize, ' ', StringFunctions.RIGHT);
                }
                buf.append(labelLine);
            }

          //**************MESSAGE DATA****************************************//
            
            int numberOfMessages = ic.getNumberOfMessages();
    		Vector allMessages = ic.getMessages();
    		int numberOfMsgTextLines;
    		Vector m_TextLines;
    		Message m = null;
    		String msgfamilyNumber = null;
    		MessageParameter msgp = null;
    		MessageFamily mf = null;
    		int i2 = 0;
            
            for(int j2 = 0; j2 < messageFamilies.size(); j2++) {
                
            	mf = (MessageFamily)messageFamilies.elementAt(j2);
                
            	if(numberOfMessages == 0) {
                    buf.append(StringFunctions.fixSize(" ", mf.size, ' ', StringFunctions.LEFT));
                } else {
                	if(i2 >= numberOfMessages) {
                    numberOfMessages = 0;
                    j2--;
                } else {
                    m = (Message)allMessages.elementAt(i2);
                    msgfamilyNumber = (new StringBuilder(String.valueOf(m.getMessageFamily()))).append(m.getMessageNumber()).toString();
                    msgp = (MessageParameter)msgparms.get(msgfamilyNumber);
                    
                    if(!msgp.isCoverMessage()) {
                        if(m.getMessageFamily().equals(mf.familyNumber)) {
                            numberOfMsgTextLines = m.getNumberOfTextLines();
                            m_TextLines = m.getTextLines();
                            int k2 = 0;
                            for(k2 = 0; k2 < numberOfMsgTextLines; k2++) {
                                TextLine tl = (TextLine)m_TextLines.elementAt(k2);
                                buf.append(tl.toString());
                            }

                            for(int pad = k2; pad < mf.numLines; pad++) {
                                TextLine tl = new TextLine(msgp.getLineLength(pad), StringFunctions.USE_DEFAULT, pad, " ");
                                tl.justify();
                                buf.append(tl.toString());
                            }

                            i2++;
                        } else {
                            buf.append(StringFunctions.fixSize(" ", mf.size, ' ', StringFunctions.LEFT));
                        }
                    } else {
                        j2--;
                        i2++;
                    }
                }
             }
           }

           buf.append("\n");
           return buf.toString();

        } else {
        	for(int i = 1; i <= 6; i++) {
        		if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                    labelLine = ic.getMagazineLabel().getTextLine(i).substring(0, trimSize);
                } else {
                    labelLine = StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(i), trimSize, ' ', StringFunctions.RIGHT);
                }
                buf.append(labelLine);
        	}
        	
        	if(ic.getMagazineLabel().barcode.length() > 0) {
                String barcode = (new StringBuilder(String.valueOf(barcode_head))).append(ic.getMagazineLabel().barcode).append(barcode_tail).toString();
                if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                    buf.append(StringFunctions.fixSize(barcode, barcodeLength, ' ', StringFunctions.LEFT));
                } else {
                    buf.append(StringFunctions.fixSize(barcode, barcodeLength, ' ', StringFunctions.RIGHT));
                }
            } else {
                buf.append(StringFunctions.fixSize(" ", barcodeLength, ' ', StringFunctions.LEFT));
            }
        	
        	int numberOfMessages = ic.getNumberOfMessages();

    		Vector allMessages = ic.getMessages();

    		int numberOfMsgTextLines;
    		Vector m_TextLines;
    		Message m = null;
    		String msgfamilyNumber = null;
    		MessageParameter msgp = null;
    		MessageFamily mf = null;
    		int i = 0;
    		
    		for(int j = 0; j < messageFamilies.size(); j++) {
                mf = (MessageFamily)messageFamilies.elementAt(j);
                
                if (numberOfMessages == 0) {
                    buf.append(StringFunctions.fixSize(" ", mf.size, ' ', StringFunctions.LEFT));
                } else {
                	if (i >= numberOfMessages ) {
                		numberOfMessages = 0;
                		j--;
                } else {
                    m = (Message)allMessages.elementAt(i);
                    msgfamilyNumber = (new StringBuilder(String.valueOf(m.getMessageFamily()))).append(m.getMessageNumber()).toString();
                    msgp = (MessageParameter)msgparms.get(msgfamilyNumber);
                    
                    if(!msgp.isCoverMessage()) {
                        if(m.getMessageFamily().equals(mf.familyNumber)) {
                            numberOfMsgTextLines = m.getNumberOfTextLines();
                            m_TextLines = m.getTextLines();
                            int k = 0;
                            for(k = 0; k < numberOfMsgTextLines; k++) {
                                TextLine tl = (TextLine)m_TextLines.elementAt(k);
                                buf.append(tl.toString());
                            }

                            for(int pad = k; pad < mf.numLines; pad++) {
                                TextLine tl = new TextLine(msgp.getLineLength(pad), StringFunctions.USE_DEFAULT, pad, " ");
                                tl.justify();
                                buf.append(tl.toString());
                            }

                            i++;
                        } else {
                            buf.append(StringFunctions.fixSize(" ", mf.size, ' ', StringFunctions.LEFT));
                        }
                    } else {
                        j--;
                        i++;
                    }
                }
              }
    		}
    		
    		buf.append("\n");
            return buf.toString();	
        }
    }

    protected String formatDataIMB(IssueCustomer ic) {
        
    	StringBuffer buf = new StringBuffer(1024);
        String labelLine = null;
        String magCode = mag.getMagCode();
        LabelLine8 = PropertyBroker.getProperty("LabelLine8");
        LL8Override = PropertyBroker.getProperty("LL8Override");
        nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
        String oldLL8 = PropertyBroker.getProperty("oldLL8");
        
        try
        {
            if(ic.getMagazineLabel().labelType.equalsIgnoreCase("USPS")) {
                buf.append(StringFunctions.fixSize(ic.getMagazineLabel().USzipCode, 5, '0', StringFunctions.RIGHT));
            } else if(ic.getMagazineLabel().labelType.equalsIgnoreCase("CAN")) {
                buf.append(StringFunctions.fixSize(ic.getMagazineLabel().canadianZipCode, 5, '0', StringFunctions.RIGHT));
            } else {
                buf.append("00000");
            }
        }
        catch(Exception exception) { }
        
        
        if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY") || ic.getMagazineLabel().endorsementLine.equals("POSTAL BOOK") || ic.getMagazineLabel().endorsementLine.equals("STORAGE BOOK"))
        {
            buf.append("ZZZZ");
        } else {
            buf.append(StringFunctions.fixSize(ic.getMagazineLabel().palletSackNumber, 4, '0', StringFunctions.RIGHT));
        }
        
        if(ic.getEndPackageIndicator()) {
            buf.append((new StringBuilder(String.valueOf(StringFunctions.fixSize(String.valueOf(packageCount++), 3, '0', StringFunctions.RIGHT)))).append(" ").toString());
            if(packageCount == 1000) {
                packageCount = 1;
            }
        } else {
            buf.append((new StringBuilder(String.valueOf(StringFunctions.fixSize(String.valueOf(packageCount), 3, '0', StringFunctions.RIGHT)))).append(" ").toString());
        }
        
        buf.append((new StringBuilder(String.valueOf(StringFunctions.fixSize(String.valueOf(rec_count++), 6, '0', StringFunctions.RIGHT)))).append(" ").toString());
        
        if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
            buf.append("01 02 00 ");
        } else {
            buf.append("11 02 00 ");
        }
        
        buf.append((new StringBuilder(String.valueOf(StringFunctions.fixSize(ic.getMakeupCode(), 4, '0', StringFunctions.RIGHT)))).append(" ").toString());
        
        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().customerName, 4, ' ', StringFunctions.RIGHT));
        
        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().addressLine1, 4, ' ', StringFunctions.RIGHT));
        
        if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
        	buf.append(StringFunctions.fixSize(profileBarData, trimSize, ' ', StringFunctions.LEFT));
        } else {
        	buf.append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcodeData, trimSize, ' ', StringFunctions.LEFT));
        }
        
        
        if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
        {
            for(int i = 2; i <= 8; i++) {
                if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                    labelLine = ic.getMagazineLabel().getTextLine(i).substring(0, trimSize);
                } else {
                    labelLine = StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(i), trimSize, ' ', StringFunctions.RIGHT);
                }
                buf.append(labelLine);
            }
            
            if(ic.getMagazineLabel().barcode.length() > 0) {
                String barcode = (new StringBuilder(String.valueOf(barcode_head))).append(ic.getMagazineLabel().barcode).append(barcode_tail).toString();
                if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                    buf.append(StringFunctions.fixSize(barcode, barcodeLength, ' ', StringFunctions.LEFT));
                } else {
                    buf.append(StringFunctions.fixSize(barcode, barcodeLength, ' ', StringFunctions.RIGHT));
                }
            } else {
                buf.append(StringFunctions.fixSize(" ", barcodeLength, ' ', StringFunctions.LEFT));
            }
// ************  FOR TK/BP ONLY -- START (5/9/12 J.Guiang)   ********************************	
            if(ic.getMagazineLabel().magCode.equalsIgnoreCase("TK")){	
            	int packageNumber = ic.getPackageNumber();
                String buff = null;	
                if(packageNumber < 1000) {	
                    buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);	
                } else {	
                    buff = String.valueOf(packageNumber);	
                }
                if(ic.getMakeupCode().startsWith("999")){
                	String classSeqNum = new String(StringFunctions.fixSize(String.valueOf(TKSeqnum), 12, '0', -2));	
                    String dispC = (new StringBuilder(String.valueOf(classSeqNum.substring(6)))).append("/").append(buff).toString();
                    buf.append(StringFunctions.fixSize(" ", trimSize, ' ', StringFunctions.LEFT));
                    buf.append(StringFunctions.fixSize(dispC, trimSize, ' ', StringFunctions.LEFT));
                } else {
                String classSeqNum = new String(StringFunctions.fixSize(String.valueOf(TKSeqnum++), 12, '0', -2));
                String dispC = (new StringBuilder(String.valueOf(classSeqNum.substring(6)))).append("/").append(buff).toString();
                buf.append(StringFunctions.fixSize(" ", trimSize, ' ', StringFunctions.LEFT));
                buf.append(StringFunctions.fixSize(dispC, trimSize, ' ', StringFunctions.LEFT));
                }
                	
// ************  FOR TK/BP ONLY -- END (5/9/12 J.Guiang)  ********************************	
            } else {
            
            int numberOfMessages = ic.getNumberOfMessages();
    		Vector allMessages = ic.getMessages();
    		int numberOfMsgTextLines;
    		Vector m_TextLines;
    		Message m = null;
    		String msgfamilyNumber = null;
    		MessageParameter msgp = null;
    		MessageFamily mf = null;
    		int i2 = 0;
    		
            
            for(int j2 = 0; j2 < messageFamilies.size(); j2++) {
                
            	mf = (MessageFamily)messageFamilies.elementAt(j2);
                if(numberOfMessages == 0) {
                    buf.append(StringFunctions.fixSize(" ", mf.size, ' ', StringFunctions.LEFT));
                } else {
                	if(i2 >= numberOfMessages){
                		numberOfMessages = 0;
                        j2--;
                	} else {
                		m = (Message)allMessages.elementAt(i2);
                        msgfamilyNumber = (new StringBuilder(String.valueOf(m.getMessageFamily()))).append(m.getMessageNumber()).toString();
                        msgp = (MessageParameter)msgparms.get(msgfamilyNumber);
                        if(!msgp.isCoverMessage()) {
                            if(m.getMessageFamily().equals(mf.familyNumber)) {
                                numberOfMsgTextLines = m.getNumberOfTextLines();
                                m_TextLines = m.getTextLines();
                                int k2 = 0;
                                for(k2 = 0; k2 < numberOfMsgTextLines; k2++) {
                                    TextLine tl = (TextLine)m_TextLines.elementAt(k2);
                                    buf.append(tl.toString());
                                }

                                for(int pad = k2; pad < mf.numLines; pad++) {
                                    TextLine tl = new TextLine(msgp.getLineLength(pad), StringFunctions.USE_DEFAULT, pad, " ");
                                    tl.justify();
                                    buf.append(tl.toString());
                                }

                                i2++;
                            } else {
                                buf.append(StringFunctions.fixSize(" ", mf.size, ' ', StringFunctions.LEFT));
                            }
                        } else {
                            j2--;
                            i2++;
                        }
                    }
                }
            }
            }
            buf.append("\n");
            return buf.toString();
        } else {
        	for(int i = 1; i <= 6; i++) {
                if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                    labelLine = ic.getMagazineLabel().getTextLine(i).substring(0, trimSize);
                } else {
                    labelLine = StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(i), trimSize, ' ', StringFunctions.RIGHT);
                }
                buf.append(labelLine);
            }
        	
        	if(ic.getMagazineLabel().barcode.length() > 0) {
                String barcode = (new StringBuilder(String.valueOf(barcode_head))).append(ic.getMagazineLabel().barcode).append(barcode_tail).toString();
                if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                    buf.append(StringFunctions.fixSize(barcode, barcodeLength, ' ', StringFunctions.LEFT));
                } else {
                    buf.append(StringFunctions.fixSize(barcode, barcodeLength, ' ', StringFunctions.RIGHT));
                }
            } else {
                buf.append(StringFunctions.fixSize(" ", barcodeLength, ' ', StringFunctions.LEFT));
            }
// ************  FOR TK/BP ONLY -- START (5/9/12 J.Guiang)   ********************************	
            if(ic.getMagazineLabel().magCode.equalsIgnoreCase("TK")){	
            	int packageNumber = ic.getPackageNumber();
                String buff = null;	
                if(packageNumber < 1000) {	
                    buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);	
                } else {	
                    buff = String.valueOf(packageNumber);	
                }	
                if(ic.getMakeupCode().startsWith("999")){
                	String classSeqNum = new String(StringFunctions.fixSize(String.valueOf(TKSeqnum), 12, '0', -2));
                    String dispC = (new StringBuilder(String.valueOf(classSeqNum.substring(6)))).append("/").append(buff).toString();
                    buf.append(StringFunctions.fixSize(" ", trimSize, ' ', StringFunctions.LEFT));
                    buf.append(StringFunctions.fixSize(dispC, trimSize, ' ', StringFunctions.LEFT));
                } else {
                String classSeqNum = new String(StringFunctions.fixSize(String.valueOf(TKSeqnum++), 12, '0', -2));
                String dispC = (new StringBuilder(String.valueOf(classSeqNum.substring(6)))).append("/").append(buff).toString();
                buf.append(StringFunctions.fixSize(" ", trimSize, ' ', StringFunctions.LEFT));
                buf.append(StringFunctions.fixSize(dispC, trimSize, ' ', StringFunctions.LEFT));
                }		
// ************  FOR TK/BP ONLY -- END (5/9/12 J.Guiang)  ********************************	
            } else {       	
        	int numberOfMessages = ic.getNumberOfMessages();
    		Vector allMessages = ic.getMessages();
    		int numberOfMsgTextLines;
    		Vector m_TextLines;
    		Message m = null;
    		String msgfamilyNumber = null;
    		MessageParameter msgp = null;
    		MessageFamily mf = null;
    		int i = 0;
    		
    		for (int j = 0; j < messageFamilies.size(); j++) {	

    			mf = (MessageFamily)messageFamilies.elementAt(j);
    			
    			if (numberOfMessages == 0) 
    				buf.append(StringFunctions.fixSize(" ",mf.size,' ',StringFunctions.LEFT));
    			else {

    			if (i >= numberOfMessages ) {
    				numberOfMessages = 0;
    				j--;
    			} else{
    	
    				m = ((Message)allMessages.elementAt(i));
    				msgfamilyNumber = m.getMessageFamily() + m.getMessageNumber();
    				msgp = (MessageParameter)msgparms.get(msgfamilyNumber);
    			
    				if (!msgp.isCoverMessage()) {

    					if (m.getMessageFamily().equals(mf.familyNumber)) {
    				
    						numberOfMsgTextLines = m.getNumberOfTextLines();
    				
    						m_TextLines = m.getTextLines();
    				
    						int k = 0;
    				
    						for (k = 0; k < numberOfMsgTextLines; k++) {	
    							TextLine tl = (TextLine) m_TextLines.elementAt(k);
    							buf.append(tl.toString());								
    						}	
    				
    					// pad out text lines to maximum for family
    				
    						for (int pad = k; pad < mf.numLines; pad++) {
    							TextLine tl = new TextLine(msgp.getLineLength(pad),StringFunctions.USE_DEFAULT,pad," ");
    							tl.justify();
    							buf.append(tl.toString());
    						}
    						i++;
    					} else
    						buf.append(StringFunctions.fixSize(" ",mf.size,' ',StringFunctions.LEFT));
    				}else{
    					j--;
    					i++;
    				}
    			}
    		}
        }
            }
    		buf.append("\n");
            return buf.toString();
    		
     }
   }

}


