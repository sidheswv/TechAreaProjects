package sybilweb.plant.persistence;

import java.io.File;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.Hashtable;
import java.util.Vector;
import sybilweb.plant.controller.*;


public abstract class PersistenceIssueCustomer {

/// VERSION OF CLASS IN PRODUCTION ////
	public static final String Class_Version_Number = "PR_6.0_REL9.4";

	String outputFileName = null;
	OutputStreamWriter outputFile = null;
	Hashtable msgparms = null;
	Vector messageParameters = null;
	Vector messageFamilies = null;
	int trimSize = 100;
	File tmpFile = null;
	File newFile = null;
	Magazine mag = null;
	int barcodeLength = 0;
	String outFileName = null;		// output Filename without extension
	String magCode = null;
//	String newoutputFileName = null;
	String shortOutputFileName = null;
	String longOutputFileName = null;
	String useShortFileName = null;
	String shortFileName = null;
	String plant = null;
	boolean formatShortFileName = false;
	public static char  fileSep = '.';
	String LabelLine8 = null;
	String nonLL8Plant = null;
	String LL8Override = null;
	String RLL5value = null;

	
/**
 * PersistenceIssueCustomer constructor comment.
 */
public PersistenceIssueCustomer() {
	super();

}
/**
 * This method was created by a SmartGuide.
 */
public void closeOutputFile ( ) {

	if (outputFile != null) {
		try {
			outputFile.flush();
			outputFile.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	if (newFile != null) {

		if (newFile.exists())
			newFile.delete();

		tmpFile.renameTo(newFile);

		



	String prop = sybilweb.plant.controller.PropertyBroker.getProperty("FormatterControlPath");
	outFileName = outFileName.concat(".001");

	int pos = outFileName.lastIndexOf("/");

	String originalFileName = prop.concat(outFileName.substring(pos+1,outFileName.length()));

				
	File oldFile = new File(originalFileName);
		if(oldFile.exists())
				oldFile.delete();

	try {
	LogWriter.writeLog("I", mag.getPlant().toUpperCase(), mag.getPrefix(), originalFileName.substring(originalFileName.lastIndexOf("/")+1,originalFileName.length()-4)+ " Formatting Completed ");
	} catch(Exception e) { e.printStackTrace(); }
		
		
	}

	outputFile = null;
	newFile = null;
	tmpFile = null;

	return;
}
/**
 * This method was created in VisualAge.
 * @param filename java.lang.String
 */
public abstract void createOutputFile (String prop, String filename);
/**
 * This method was created by a SmartGuide.
 * @param filename java.lang.String
 */
public void deleteFile () {

	if (newFile != null)
		newFile.delete();

	return;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 * @param ic sybil.common.model.IssueCustomer
 */
protected abstract String formatData(IssueCustomer ic);
/**
 * This method was created by a SmartGuide.
 * @param v Vector
 */
public void saveData(Vector v ) {

	int size = v.size();
	
	for (int i = 0; i < size; i++)
		saveData((IssueCustomer)v.elementAt(i));

	return;
}
/**
 * This method was created by a SmartGuide.
 * @param dataBuffer java.lang.String
 */
public void saveData (IssueCustomer customer) {

	String formatdata = null;

	formatdata = formatData(customer);
	String encoding = "ISO8859_1";
	
	try {
		String reconsituted = new String(formatdata.getBytes(encoding), encoding );
		outputFile.write(reconsituted,0,reconsituted.length());
		outputFile.flush();
	} catch(Exception e) { e.printStackTrace(); }
	return;
}
/**
 * This method was created in VisualAge.
 * @param trimSize int
 */
public void setMagazine(Magazine mag) {
	this.mag = mag;

	String length = PropertyBroker.getProperty(mag.getMagCode() + "BarcodeSize","72");
	barcodeLength = Integer.parseInt(length);
	trimSize = mag.getTrimSize();
	
}
/**
 * This method was created in VisualAge.
 * @param msgParms java.util.Vector
 */
public void setMessageParameters(Vector parms) {

	messageParameters = parms;
	messageFamilies = new Vector();

	String oldFamily = "",currFamily;

	for (int i = 0; i < parms.size(); i++) {
		MessageParameter m = (MessageParameter)parms.elementAt(i);
		if (!m.isCoverMessage()) {
			if (!oldFamily.equals(m.getFamilyNumber())) {
				MessageFamily f = new MessageFamily();
				f.familyNumber = m.getFamilyNumber();
				f.numLines = m.getMaxNumOfLinesForFamily();
				f.size = 0;
				for (int j = 0; j < f.numLines; j++) {
					f.size += m.getLineLength(j);
					f.addLineLength(m.getLineLength(j));
				}

				messageFamilies.addElement(f);

				oldFamily = m.getFamilyNumber();
			}
		}
	}

	msgparms = new Hashtable();
	int size = parms.size();
	String messageFamilyNumber = null;

	for (int i = 0; i < size; i++) {
		messageFamilyNumber = ((MessageParameter)parms.elementAt(i)).getFamilyNumber() +
									 ((MessageParameter)parms.elementAt(i)).getNumber();
		msgparms.put(messageFamilyNumber,parms.elementAt(i));
	}

}
}
