package sybilweb.plant.persistence;

import java.io.*;
import java.util.Vector;
import sybilweb.plant.controller.*;


public class VIPPersistenceIssueCustomer extends PersistenceIssueCustomer {

	public static final String Class_Version_Number = "PR_6.4_8LL_TOR";
	
	private static final String profileBar = "TADFDFDAAFFADFDATTDTTTFDATADFDTDTTAATDATATTAAFADFATDDFATAFFDAAFTF";
	private static final String profileBarData = "1003810076600000000095348430709";

	int QC_Book=0;
	int rec_count = 1;

	private static char REC_SEP = '\u001E';
	private static char GRP_SEP = '\u001D';
	private static char AUX_SEP = '\u001F';
	private static char UNIT_SEP = '\u001F';
	private static char BAR_CODE_SEP = '\u000B';
	private static final int MESSAGE_SIZE = 77;
	

    public VIPPersistenceIssueCustomer() {
        
    }

    public void createOutputFile(String prop, String outputFileName) {
        
    	this.outputFileName = outputFileName;
        outFileName = outputFileName;
        useShortFileName = PropertyBroker.getProperty("useShortFileName", "false");
        shortFileName = outputFileName.substring(0, outputFileName.lastIndexOf("/") + 1).concat(outputFileName.substring(outputFileName.lastIndexOf(".") + 1, outputFileName.length()));
        plant = mag.getPlant().toUpperCase();
        rec_count = 1;
        String FormatterFileConcatText = null;
        FormatterFileConcatText = PropertyBroker.getProperty("FormatterFileConcatText");
        String fileName = null;
        fileName = (new StringBuilder(String.valueOf(PropertyBroker.getProperty("OLDFILEDIR")))).append(mag.getFullPrefix()).append(".RLL5").toString();
        File f = new File(fileName);
        BufferedReader fileReader = null;
        
        if(f.exists()) {
            try {
                fileReader = new BufferedReader(new FileReader(fileName));
            }
            catch(FileNotFoundException fnfe) {
                LogWriter.writeLog(new Exception((new StringBuilder(String.valueOf(mag.getPrefix()))).append(": Error opening RLL5 file: File not found: ").append(fileName).toString()));
                return; }
            
            try {
                RLL5value = fileReader.readLine();
            }
            catch(EOFException eofexception) { }
            catch(Exception re) {
                LogWriter.writeLog(re);
            }
        } else {
            RLL5value = "false";
        }
        
        if(FormatterFileConcatText == null) {
            FormatterFileConcatText = "";
        }
        if(useShortFileName.equals("true")) {
            formatShortFileName = true;
        }
        
        if(formatShortFileName) {
            shortOutputFileName = (new StringBuilder(String.valueOf(prop))).append(shortFileName).toString();
        } else {
            longOutputFileName = (new StringBuilder(String.valueOf(prop))).append(mag.getLongFileName()).append(fileSep).append(shortFileName).toString();
        }
        
        if(formatShortFileName) {
            tmpFile = new File((new StringBuilder(String.valueOf(prop))).append(outputFileName).append(FormatterFileConcatText).append(".tmp").toString());
        } else {
            tmpFile = new File((new StringBuilder(String.valueOf(longOutputFileName))).append(FormatterFileConcatText).append(".tmp").toString());
        }
        
        try {
            outputFile = new OutputStreamWriter(new FileOutputStream(tmpFile), "ISO8859_1");
        }
        catch(IOException e) {
            LogWriter.writeLog(new SybilWarningException((new StringBuilder(String.valueOf(mag.getPrefix()))).append(": Error creating output file: ").append(e.getMessage()).toString()));
            return;
        }
        
        if(formatShortFileName) {
            shortOutputFileName = (new StringBuilder(String.valueOf(prop))).append(shortFileName).toString();
        } else {
            longOutputFileName = (new StringBuilder(String.valueOf(prop))).append(mag.getLongFileName()).append(fileSep).append(shortFileName).toString();
        }
        
        if(formatShortFileName) {
            newFile = new File((new StringBuilder(String.valueOf(shortOutputFileName))).append(FormatterFileConcatText).append(".dat").toString());
        } else {
            newFile = new File((new StringBuilder(String.valueOf(longOutputFileName))).append(FormatterFileConcatText).append(".dat").toString());
        }
        
        if(newFile.exists()) {
            newFile.delete();
        }
        LogWriter.writeLog("I", mag.getPlant().toUpperCase(), mag.getPrefix(), (new StringBuilder(String.valueOf(outputFileName))).append(" Started Formatting").toString());
    }

    protected String formatData(IssueCustomer ic) {
        
    	String PlantID = mag.getPlant();
        String data = null;
        if(PlantID.toUpperCase().equals("CLK")) {
            data = formatDataCLK(ic);
        }
        if(PlantID.toUpperCase().equals("EGV")) {
            data = formatDataEGV(ic);
        }
        if(PlantID.toUpperCase().equals("TOR")) {
            data = formatDataTOR(ic);
        }
        if(PlantID.toUpperCase().equals("DAL")) {
            data = formatDataDAL(ic);
        }
        if(PlantID.toUpperCase().equals("WAS")) {
            data = formatDataWAS(ic);
        }
        if(PlantID.toUpperCase().equals("FLA")) {
            data = formatDataFLA(ic);
        }
        if(PlantID.toUpperCase().equals("EFF")) {
            data = formatDataEFF(ic);
        }
        if(PlantID.toUpperCase().equals("GLG")) {
            data = formatDataGLG(ic);
        }
        if(PlantID.toUpperCase().equals("DNV")) {
            data = formatDataDNV(ic);
        }
        if(PlantID.toUpperCase().equals("LNS")) {
            data = formatDataLNS(ic);
        }
        return data;
    }

    protected String formatDataCLK(IssueCustomer ic) {
        
    	StringBuffer buf = new StringBuffer(1024);
        try
        {
            LabelLine8 = PropertyBroker.getProperty("LabelLine8");
            LL8Override = PropertyBroker.getProperty("LL8Override");
            nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
            String oldLL8 = PropertyBroker.getProperty("oldLL8");
            magCode = mag.getMagCode();
            
            buf.append(REC_SEP);
            buf.append("10");
            buf.append(StringFunctions.fixSize(String.valueOf(rec_count++), 9, '0', StringFunctions.RIGHT));
            buf.append(UNIT_SEP);
            String zipcode = StringFunctions.fixSize(ic.getAddress().getZipCode(), 6, ' ', StringFunctions.LEFT);
            
            if(!ic.getcontinentCode().equals("")) {
                if(ic.getcontinentCode().charAt(0) >= 'A' && ic.getcontinentCode().charAt(0) <= 'Y') {
                    buf.append(StringFunctions.fixSize(zipcode, 10, ' ', StringFunctions.LEFT));
                } else {
                    buf.append(StringFunctions.fixSize(zipcode.substring(0, 5), 10, ' ', StringFunctions.LEFT));
                }
            } else {
                buf.append(StringFunctions.fixSize(zipcode.substring(0, 5), 10, ' ', StringFunctions.LEFT));
            }
            
            String sort_stacker = null;
            if(!ic.getEndPackageIndicator() && !ic.getEndPalletSackIndicator()) {
                sort_stacker = "00";
            } else {
            	if(ic.getEndPalletSackIndicator()) {
            		sort_stacker = "21";
            	} else {
            		sort_stacker = "11";
            	}
            }
            
            buf.append(sort_stacker);
            buf.append(" ");
            buf.append(StringFunctions.fixSize(ic.getMakeupCode(), 4, '0', StringFunctions.RIGHT));
            buf.append(AUX_SEP);
            buf.append(StringFunctions.fixSize("0", 31, '0', StringFunctions.LEFT));
         // quality buzzer
            buf.append("0");
            
            String deliveryType = mag.getDeliveryType().toUpperCase().trim();
            
            if(deliveryType.equalsIgnoreCase("USPS")) {
                if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
                		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBar, trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize("", trimSize, ' ', StringFunctions.LEFT)).toString());
                	} else {
                		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize("", trimSize, ' ', StringFunctions.LEFT)).toString());
                	}
                } else {
                	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
                		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize("", trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBar.toUpperCase(), trimSize, ' ', StringFunctions.LEFT)).toString());
                	} else {
                		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize("", trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), trimSize, ' ', StringFunctions.LEFT)).toString());
                	}                    
                }
            }
            
            if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
            {
                if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                    if(!deliveryType.equalsIgnoreCase("USPS")) {
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(1).substring(0, trimSize)).toString());
                    }
                    
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(2).substring(0, trimSize)).toString());
                    int packageNumber = ic.getPackageNumber();
                    String buff = null;
                    if(packageNumber < 1000) {
                        buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                    } else {
                        buff = String.valueOf(packageNumber);
                    }
                    
                    buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(3).substring(0, trimSize)).toString());
                    
                    if(!deliveryType.equalsIgnoreCase("USPS")) {
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(4).substring(0, trimSize)).toString());
                    }
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(5).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(6).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(7).substring(0, trimSize)).toString());
                    
                    if(!deliveryType.equalsIgnoreCase("CAN")) {
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(8).substring(0, trimSize)).toString());
                    }
                    
                    if(ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append(GRP_SEP);
                        buf.append(BAR_CODE_SEP);
                        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode, 14, ' ', StringFunctions.LEFT));
                        buf.append(BAR_CODE_SEP);
                    } else {
                        buf.append(GRP_SEP);
                        buf.append(BAR_CODE_SEP);
                        buf.append("              ");
                        buf.append(BAR_CODE_SEP);
                    }
                } else {
                    if(!deliveryType.equalsIgnoreCase("USPS")) {
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    }
                    
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    int packageNumber = ic.getPackageNumber();
                    String buff = null;
                    if(packageNumber < 1000) {
                        buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                    } else {
                        buff = String.valueOf(packageNumber);
                    }
                    buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    
                    if(!deliveryType.equalsIgnoreCase("USPS")) {
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    }
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(7), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    
                    if(!deliveryType.equalsIgnoreCase("CAN")) {
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(8), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    }
                    
                    if(ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append(GRP_SEP);
                        buf.append(BAR_CODE_SEP);
                        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode, 14, ' ', StringFunctions.RIGHT));
                        buf.append(BAR_CODE_SEP);
                    } else {
                        buf.append(GRP_SEP);
                        buf.append(BAR_CODE_SEP);
                        buf.append("              ");
                        buf.append(BAR_CODE_SEP);
                    }
                }
            } else {
            	if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(1).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(2).substring(0, trimSize)).toString());
                    int packageNumber = ic.getPackageNumber();
                    String buff = null;
                    if(packageNumber < 1000) {
                        buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                    } else {
                        buff = String.valueOf(packageNumber);
                    }
                    buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(3).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(4).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(5).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(6).substring(0, trimSize)).toString());
                    if(ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append(GRP_SEP);
                        buf.append(BAR_CODE_SEP);
                        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode, 14, ' ', StringFunctions.LEFT));
                        buf.append(BAR_CODE_SEP);
                    } else {
                        buf.append(GRP_SEP);
                        buf.append(BAR_CODE_SEP);
                        buf.append("              ");
                        buf.append(BAR_CODE_SEP);
                    }
                } else {
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    int packageNumber = ic.getPackageNumber();
                    String buff = null;
                    if(packageNumber < 1000) {
                        buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                    } else {
                        buff = String.valueOf(packageNumber);
                    }
                    buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    if(ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append(GRP_SEP);
                        buf.append(BAR_CODE_SEP);
                        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode, 14, ' ', StringFunctions.RIGHT));
                        buf.append(BAR_CODE_SEP);
                    } else {
                        buf.append(GRP_SEP);
                        buf.append(BAR_CODE_SEP);
                        buf.append("              ");
                        buf.append(BAR_CODE_SEP);
                    }
                }

            }
            
            int numberOfMessages = ic.getNumberOfMessages();
            Vector allMessages = ic.getMessages();
            Message m = null;
            String msgfamilyNumber = null;
            MessageParameter msgp = null;
            MessageFamily mf = null;
            int i = 0;
            
            for(int j = 0; j < messageFamilies.size(); j++) {
                mf = (MessageFamily)messageFamilies.elementAt(j);
                if(numberOfMessages == 0) {
                    for(int padding = 0; padding < mf.numLines; padding++) {
                        buf.append(GRP_SEP);
                        buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                    }

                } else {
                    if(i >= numberOfMessages) {
                        for(int padding = 0; padding < mf.numLines; padding++) {
                            buf.append(GRP_SEP);
                            buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                        }

                    } else {
                        m = (Message)allMessages.elementAt(i);
                        msgfamilyNumber = (new StringBuilder(String.valueOf(m.getMessageFamily()))).append(m.getMessageNumber()).toString();
                        msgp = (MessageParameter)msgparms.get(msgfamilyNumber);
                        if(!msgp.isCoverMessage()) {
                            if(m.getMessageFamily().equals(mf.familyNumber)) {
                                int numberOfMsgTextLines = m.getNumberOfTextLines();
                                Vector m_TextLines = m.getTextLines();
                                int k = 0;
                                for(k = 0; k < numberOfMsgTextLines; k++) {
                                    TextLine tl = (TextLine)m_TextLines.elementAt(k);
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(tl.toString(), MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                }

                                for(int pad = k; pad < mf.numLines; pad++) {
                                    int z = 0;
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                    z++;
                                }

                                i++;
                            } else {
                                for(int lineNum = 0; lineNum < mf.numLines; lineNum++) {
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                }

                            }
                        } else {
                            j--;
                            i++;
                        }
                    }
                }

            }

        }
        catch(Exception ex) {
            LogWriter.writeLog(ex);
        }
        return buf.toString();
    }

    protected String formatDataDAL(IssueCustomer ic) {
        
    	StringBuffer buf = new StringBuffer(1024);
        try
        {
            LabelLine8 = PropertyBroker.getProperty("LabelLine8");
            LL8Override = PropertyBroker.getProperty("LL8Override");
            nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
            String oldLL8 = PropertyBroker.getProperty("oldLL8");
            magCode = mag.getMagCode();
            String schoolBundling = PropertyBroker.getProperty("schoolBundling", "false");
            
            buf.append(REC_SEP);
            buf.append("10");
            
            buf.append(StringFunctions.fixSize(String.valueOf(rec_count++), 9, '0', StringFunctions.RIGHT));
            buf.append(UNIT_SEP);
            
            String zipcode = StringFunctions.fixSize(ic.getAddress().getZipCode(), 6, ' ', StringFunctions.LEFT);
            
            if(!ic.getcontinentCode().equals("")) {
                if(ic.getcontinentCode().charAt(0) >= 'A' && ic.getcontinentCode().charAt(0) <= 'Y') {
                    buf.append(StringFunctions.fixSize(zipcode, 10, ' ', StringFunctions.LEFT));
                } else {
                    buf.append(StringFunctions.fixSize(zipcode.substring(0, 5), 10, ' ', StringFunctions.LEFT));
                }
            } else {
                buf.append(StringFunctions.fixSize(zipcode.substring(0, 5), 10, ' ', StringFunctions.LEFT));
            }
            
            String sort_stacker = null;
            if(!ic.getEndPackageIndicator() && !ic.getEndPalletSackIndicator()) {
                sort_stacker = "00";
            } else {
            	if(ic.getEndPalletSackIndicator()) {
                    sort_stacker = "21";
                } else {
                    sort_stacker = "11";
                }
            }
            
            buf.append(sort_stacker);
            
            buf.append(" ");
            buf.append(StringFunctions.fixSize(ic.getMakeupCode(), 4, '0', StringFunctions.RIGHT));
            buf.append(AUX_SEP);
            
            buf.append(StringFunctions.fixSize("0", 31, '0', StringFunctions.LEFT));
         // quality buzzer
            buf.append("0");
            
            if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
            	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
            		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBar.toUpperCase(), trimSize, ' ', StringFunctions.LEFT)).toString());
            	} else {
            		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), trimSize, ' ', StringFunctions.LEFT)).toString());
            	}
            } else {
            	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
            		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBar.toUpperCase(), trimSize, ' ', StringFunctions.RIGHT)).toString());
            	} else {
            		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), trimSize, ' ', StringFunctions.RIGHT)).toString());
            	}
            }
            
            if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
            {
                if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(2).substring(0, trimSize)).toString());
                    int packageNumber = ic.getPackageNumber();
                    String buff = null;
                    if(packageNumber < 1000) {
                        buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                    } else {
                        buff = String.valueOf(packageNumber);
                    }
                    if(ic.getMagazineLabel().magCode.equalsIgnoreCase("TK") && schoolBundling.equalsIgnoreCase("true")) {
                        buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().classSeqNumber, 9, ' ', StringFunctions.RIGHT)).toString());
                        buf.append("/");
                        buf.append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT));
                    } else {
                        buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                    }
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(3).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(4).substring(0, trimSize)).toString());
                    if(ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append(UNIT_SEP);
                        buf.append(ic.getMagazineLabel().barcode);
                    } else {
                        buf.append(UNIT_SEP);
                        buf.append("              ");
                    }
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(5).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(6).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(7).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(8).substring(0, trimSize)).toString());
                } else {
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    int packageNumber = ic.getPackageNumber();
                    String buff = null;
                    if(packageNumber < 1000) {
                        buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                    } else {
                        buff = String.valueOf(packageNumber);
                    }
                    if(ic.getMagazineLabel().magCode.equalsIgnoreCase("TK") && schoolBundling.equalsIgnoreCase("true")) {
                        buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().classSeqNumber, 9, ' ', StringFunctions.RIGHT)).toString());
                        buf.append("/");
                        buf.append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT));
                    } else {
                        buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                    }
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    
                    if(ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append(UNIT_SEP);
                        buf.append(ic.getMagazineLabel().barcode);
                    } else {
                        buf.append(UNIT_SEP);
                        buf.append("              ");
                    }
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(7), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(8), trimSize, ' ', StringFunctions.RIGHT)).toString());
                }
            } else {
            	if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(1).substring(0, trimSize)).toString());
                    int packageNumber = ic.getPackageNumber();
                    String buff = null;
                    if(packageNumber < 1000) {
                        buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                    } else {
                        buff = String.valueOf(packageNumber);
                    }
                    if(ic.getMagazineLabel().magCode.equalsIgnoreCase("TK")) {
                        buf.append(UNIT_SEP);
                        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().classSeqNumber, 9, ' ', StringFunctions.RIGHT));
                        buf.append("/");
                        buf.append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT));
                    } else {
                        buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                    }
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(2).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(3).substring(0, trimSize)).toString());
                    if(ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append(UNIT_SEP);
                        buf.append(ic.getMagazineLabel().barcode);
                    } else {
                        buf.append(UNIT_SEP);
                        buf.append("              ");
                    }
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(4).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(5).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(6).substring(0, trimSize)).toString());
                } else {
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    int packageNumber = ic.getPackageNumber();
                    String buff = null;
                    if(packageNumber < 1000) {
                        buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                    } else {
                        buff = String.valueOf(packageNumber);
                    }
                    if(ic.getMagazineLabel().magCode.equalsIgnoreCase("TK")) {
                        buf.append(UNIT_SEP);
                        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().classSeqNumber, 9, ' ', StringFunctions.RIGHT));
                        buf.append("/");
                        buf.append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT));
                    } else {
                        buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                    }
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    
                    if(ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append(UNIT_SEP);
                        buf.append(ic.getMagazineLabel().barcode);
                    } else {
                        buf.append(UNIT_SEP);
                        buf.append("              ");
                    }
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6), trimSize, ' ', StringFunctions.RIGHT)).toString());
                }
            	
            }
            
            
            int numberOfMessages = ic.getNumberOfMessages();
            Vector allMessages = ic.getMessages();
            Message m = null;
            String msgfamilyNumber = null;
            MessageParameter msgp = null;
            MessageFamily mf = null;
            int i = 0;
            for(int j = 0; j < messageFamilies.size(); j++) {
                mf = (MessageFamily)messageFamilies.elementAt(j);
                if(numberOfMessages == 0) {
                    for(int padding = 0; padding < mf.numLines; padding++) {
                        buf.append(GRP_SEP);
                        buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                    }

                } else {
                    if(i >= numberOfMessages) {
                        for(int padding = 0; padding < mf.numLines; padding++) {
                            buf.append(GRP_SEP);
                            buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                        }

                    } else {
                        m = (Message)allMessages.elementAt(i);
                        msgfamilyNumber = (new StringBuilder(String.valueOf(m.getMessageFamily()))).append(m.getMessageNumber()).toString();
                        msgp = (MessageParameter)msgparms.get(msgfamilyNumber);
                        if(!msgp.isCoverMessage()) {
                            if(m.getMessageFamily().equals(mf.familyNumber)) {
                                int numberOfMsgTextLines = m.getNumberOfTextLines();
                                Vector m_TextLines = m.getTextLines();
                                int k = 0;
                                for(k = 0; k < numberOfMsgTextLines; k++) {
                                    TextLine tl = (TextLine)m_TextLines.elementAt(k);
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(tl.toString(), MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                }

                                for(int pad = k; pad < mf.numLines; pad++) {
                                    int z = 0;
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                    z++;
                                }

                                i++;
                            } else {
                                for(int lineNum = 0; lineNum < mf.numLines; lineNum++) {
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                }

                            }
                        } else {
                            j--;
                            i++;
                        }
                    }
                }

            }

        }
        catch(Exception ex) {
            LogWriter.writeLog(ex);
        }
        return buf.toString();
    }

    protected String formatDataEFF(IssueCustomer ic) {
        
    	StringBuffer buf = new StringBuffer(1024);
        try
        {
            LabelLine8 = PropertyBroker.getProperty("LabelLine8");
            LL8Override = PropertyBroker.getProperty("LL8Override");
            nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
            String oldLL8 = PropertyBroker.getProperty("oldLL8");
            magCode = mag.getMagCode();
            
            buf.append(REC_SEP);
            buf.append("10");
            
            buf.append(StringFunctions.fixSize(String.valueOf(rec_count++), 9, '0', StringFunctions.RIGHT));
            buf.append(UNIT_SEP);
            
            String zipcode = StringFunctions.fixSize(ic.getAddress().getZipCode(), 6, ' ', StringFunctions.LEFT);
            
            if(!ic.getcontinentCode().equals("")) {
                if(ic.getcontinentCode().charAt(0) >= 'A' && ic.getcontinentCode().charAt(0) <= 'Y') {
                    buf.append(StringFunctions.fixSize(zipcode, 10, ' ', StringFunctions.LEFT));
                } else {
                    buf.append(StringFunctions.fixSize(zipcode.substring(0, 5), 10, ' ', StringFunctions.LEFT));
                }
            } else {
                buf.append(StringFunctions.fixSize(zipcode.substring(0, 5), 10, ' ', StringFunctions.LEFT));
            }
            
            String sort_stacker = null;
            if(!ic.getEndPackageIndicator() && !ic.getEndPalletSackIndicator()) {
                sort_stacker = "00";
            } else {
            	if(ic.getEndPalletSackIndicator()) {
                    sort_stacker = "21";
                } else {
                    sort_stacker = "11";
                }
            }
            
            buf.append(sort_stacker);
            
            buf.append(" ");
            
            buf.append(StringFunctions.fixSize(ic.getMakeupCode(), 4, '0', StringFunctions.RIGHT));
            buf.append(AUX_SEP);
            
            buf.append(StringFunctions.fixSize("0", 31, '0', StringFunctions.LEFT));
            buf.append("0");
            
            if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
            	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
            		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBar.toUpperCase(), trimSize, ' ', StringFunctions.LEFT)).toString());
            	} else {
            		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), trimSize, ' ', StringFunctions.LEFT)).toString());
            	}
            } else {
            	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
            		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBar.toUpperCase(), trimSize, ' ', StringFunctions.RIGHT)).toString());
            	} else {
            		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), trimSize, ' ', StringFunctions.RIGHT)).toString());
            	}
            }
            
            if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
            {
                if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(2).substring(0, trimSize)).toString());
                    int packageNumber = ic.getPackageNumber();
                    String buff = null;
                    if(packageNumber < 1000) {
                        buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                    } else {
                        buff = String.valueOf(packageNumber);
                    }
                    buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(3).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(4).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(5).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(6).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(7).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(8).substring(0, trimSize)).toString());
                    
                    if(ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append(GRP_SEP);
                        buf.append(BAR_CODE_SEP);
                        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode, 14, ' ', StringFunctions.LEFT));
                        buf.append(BAR_CODE_SEP);
                    } else {
                        buf.append(GRP_SEP);
                        buf.append(BAR_CODE_SEP);
                        buf.append("              ");
                        buf.append(BAR_CODE_SEP);
                    }
                } else {
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    int packageNumber = ic.getPackageNumber();
                    String buff = null;
                    if(packageNumber < 1000) {
                        buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                    } else {
                        buff = String.valueOf(packageNumber);
                    }
                    buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(7), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(8), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    
                    if(ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append(GRP_SEP);
                        buf.append(BAR_CODE_SEP);
                        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode, 14, ' ', StringFunctions.RIGHT));
                        buf.append(BAR_CODE_SEP);
                    } else {
                        buf.append(GRP_SEP);
                        buf.append(BAR_CODE_SEP);
                        buf.append("              ");
                        buf.append(BAR_CODE_SEP);
                    }
                }
            } else {
            	if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                     buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(1).substring(0, trimSize)).toString());
                     buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(2).substring(0, trimSize)).toString());
                     int packageNumber = ic.getPackageNumber();
                     String buff = null;
                     if(packageNumber < 1000) {
                         buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                     } else {
                         buff = String.valueOf(packageNumber);
                     }
                     buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                     buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(3).substring(0, trimSize)).toString());
                     buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(4).substring(0, trimSize)).toString());
                     buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(5).substring(0, trimSize)).toString());
                     buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(6).substring(0, trimSize)).toString());
                     
                     if(ic.getMagazineLabel().barcode.length() > 0) {
                         buf.append(GRP_SEP);
                         buf.append(BAR_CODE_SEP);
                         buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode, 14, ' ', StringFunctions.LEFT));
                         buf.append(BAR_CODE_SEP);
                     } else {
                         buf.append(GRP_SEP);
                         buf.append(BAR_CODE_SEP);
                         buf.append("              ");
                         buf.append(BAR_CODE_SEP);
                     }
                 } else {
                     buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1), trimSize, ' ', StringFunctions.RIGHT)).toString());
                     buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2), trimSize, ' ', StringFunctions.RIGHT)).toString());
                     int packageNumber = ic.getPackageNumber();
                     String buff = null;
                     if(packageNumber < 1000) {
                         buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                     } else {
                         buff = String.valueOf(packageNumber);
                     }
                     buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                     buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3), trimSize, ' ', StringFunctions.RIGHT)).toString());
                     buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4), trimSize, ' ', StringFunctions.RIGHT)).toString());
                     buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5), trimSize, ' ', StringFunctions.RIGHT)).toString());
                     buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6), trimSize, ' ', StringFunctions.RIGHT)).toString());
                     
                     if(ic.getMagazineLabel().barcode.length() > 0) {
                         buf.append(GRP_SEP);
                         buf.append(BAR_CODE_SEP);
                         buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode, 14, ' ', StringFunctions.RIGHT));
                         buf.append(BAR_CODE_SEP);
                     } else {
                         buf.append(GRP_SEP);
                         buf.append(BAR_CODE_SEP);
                         buf.append("              ");
                         buf.append(BAR_CODE_SEP);
                     }
                 }
            	
            }
            
            
            
            int numberOfMessages = ic.getNumberOfMessages();
            Vector allMessages = ic.getMessages();
            Message m = null;
            String msgfamilyNumber = null;
            MessageParameter msgp = null;
            MessageFamily mf = null;
            int i = 0;
            
            for(int j = 0; j < messageFamilies.size(); j++) {
                mf = (MessageFamily)messageFamilies.elementAt(j);
                if(numberOfMessages == 0) {
                    for(int padding = 0; padding < mf.numLines; padding++) {
                        buf.append(GRP_SEP);
                        buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                    }

                } else {
                    if(i >= numberOfMessages) {
                        for(int padding = 0; padding < mf.numLines; padding++) {
                            buf.append(GRP_SEP);
                            buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                        }

                    } else {
                        m = (Message)allMessages.elementAt(i);
                        msgfamilyNumber = (new StringBuilder(String.valueOf(m.getMessageFamily()))).append(m.getMessageNumber()).toString();
                        msgp = (MessageParameter)msgparms.get(msgfamilyNumber);
                        if(!msgp.isCoverMessage()) {
                            if(m.getMessageFamily().equals(mf.familyNumber)) {
                                int numberOfMsgTextLines = m.getNumberOfTextLines();
                                Vector m_TextLines = m.getTextLines();
                                int k = 0;
                                for(k = 0; k < numberOfMsgTextLines; k++) {
                                    TextLine tl = (TextLine)m_TextLines.elementAt(k);
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(tl.toString(), MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                }

                                for(int pad = k; pad < mf.numLines; pad++) {
                                    int z = 0;
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                    z++;
                                }

                                i++;
                            } else {
                                for(int lineNum = 0; lineNum < mf.numLines; lineNum++) {
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                }

                            }
                        } else  {
                            j--;
                            i++;
                        }
                    }
                }
            }

        }
        catch(Exception ex)
        {
            LogWriter.writeLog(ex);
        }
        return buf.toString();
    }

    protected String formatDataEGV(IssueCustomer ic) {
        
    	StringBuffer buf = new StringBuffer(1024);
        try
        {
            LabelLine8 = PropertyBroker.getProperty("LabelLine8");
            LL8Override = PropertyBroker.getProperty("LL8Override");
            nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
            String oldLL8 = PropertyBroker.getProperty("oldLL8");
            magCode = mag.getMagCode();
            
            buf.append(REC_SEP);
            buf.append("10");
            
            buf.append(StringFunctions.fixSize(String.valueOf(rec_count++), 9, '0', StringFunctions.RIGHT));
            buf.append(UNIT_SEP);
            
            String zipcode = StringFunctions.fixSize(ic.getAddress().getZipCode(), 6, ' ', StringFunctions.LEFT);
            
            if(!ic.getcontinentCode().equals("")) {
                if(ic.getcontinentCode().charAt(0) >= 'A' && ic.getcontinentCode().charAt(0) <= 'Y') {
                    buf.append(StringFunctions.fixSize(zipcode, 10, ' ', StringFunctions.LEFT));
                } else {
                    buf.append(StringFunctions.fixSize(zipcode.substring(0, 5), 10, ' ', StringFunctions.LEFT));
                }
            } else {
                buf.append(StringFunctions.fixSize(zipcode.substring(0, 5), 10, ' ', StringFunctions.LEFT));
            }
            
            String sort_stacker = null;
            
            if(!ic.getEndPackageIndicator() && !ic.getEndPalletSackIndicator()) {
                sort_stacker = "00";
            } else {
            	if(ic.getEndPalletSackIndicator()) {
                    sort_stacker = "21";
                } else {
                    sort_stacker = "11";
                }
            }
            
            buf.append(sort_stacker);
            buf.append(" ");
            
            buf.append(StringFunctions.fixSize(ic.getMakeupCode(), 4, '0', StringFunctions.RIGHT));
            buf.append(AUX_SEP);
            
            buf.append(StringFunctions.fixSize("0", 31, '0', StringFunctions.LEFT));
            buf.append("0");
            
            if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
            {
                if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                	
                	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
                		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBarData, trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBar.toUpperCase(), trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", trimSize, ' ', StringFunctions.LEFT)).toString());
                	} else {
                		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcodeData, trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", trimSize, ' ', StringFunctions.LEFT)).toString());
                	}
                    
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(2).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(3).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(4).substring(0, trimSize)).toString());
                    buf.append(UNIT_SEP);
                    if(ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append(ic.getMagazineLabel().barcode);
                    } else {
                        buf.append(" ");
                    }
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(5).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(6).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(7).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(8).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().barcode).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(" ").toString());
                } else {
                	
                	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
                		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBarData, trimSize, ' ', StringFunctions.RIGHT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBar.toUpperCase(), trimSize, ' ', StringFunctions.LEFT)).toString());
                	} else {
                		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcodeData, trimSize, ' ', StringFunctions.RIGHT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), trimSize, ' ', StringFunctions.LEFT)).toString());
                	}
                    
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append(UNIT_SEP);
                    if(ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append(ic.getMagazineLabel().barcode);
                    } else {
                        buf.append(" ");
                    }
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(7), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(8), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(" ").toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().barcode).toString());
                }
            } else {
            	if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
            		
            		if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
            			buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBarData, trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBar.toUpperCase(), trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", trimSize, ' ', StringFunctions.LEFT)).toString());
            		} else {
            			buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcodeData, trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", trimSize, ' ', StringFunctions.LEFT)).toString());
            		}
                    
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(1).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(2).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(3).substring(0, trimSize)).toString());
                    buf.append(UNIT_SEP);
                    if(ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append(ic.getMagazineLabel().barcode);
                    } else {
                        buf.append(" ");
                    }
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(4).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(5).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(6).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().barcode).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(" ").toString());
                } else {
                	
                	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
                		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBarData, trimSize, ' ', StringFunctions.RIGHT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBar.toUpperCase(), trimSize, ' ', StringFunctions.LEFT)).toString());
                	} else {
                		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcodeData, trimSize, ' ', StringFunctions.RIGHT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), trimSize, ' ', StringFunctions.LEFT)).toString());
                	}
                    
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append(UNIT_SEP);
                    if(ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append(ic.getMagazineLabel().barcode);
                    } else {
                        buf.append(" ");
                    }
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(" ").toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().barcode).toString());
                }
            }
            
            
            int numberOfMessages = ic.getNumberOfMessages();
            Vector allMessages = ic.getMessages();
            Message m = null;
            String msgfamilyNumber = null;
            MessageParameter msgp = null;
            MessageFamily mf = null;
            int i = 0;
            
            for(int j = 0; j < messageFamilies.size(); j++) {
                mf = (MessageFamily)messageFamilies.elementAt(j);
                if(numberOfMessages == 0) {
                    for(int padding = 0; padding < mf.numLines; padding++) {
                        buf.append(GRP_SEP);
                        buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                    }

                } else {
                    if(i >= numberOfMessages) {
                        for(int padding = 0; padding < mf.numLines; padding++) {
                            buf.append(GRP_SEP);
                            buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                        }

                    } else {
                        m = (Message)allMessages.elementAt(i);
                        msgfamilyNumber = (new StringBuilder(String.valueOf(m.getMessageFamily()))).append(m.getMessageNumber()).toString();
                        msgp = (MessageParameter)msgparms.get(msgfamilyNumber);
                        if(!msgp.isCoverMessage()) {
                            if(m.getMessageFamily().equals(mf.familyNumber)) {
                                int numberOfMsgTextLines = m.getNumberOfTextLines();
                                Vector m_TextLines = m.getTextLines();
                                int k = 0;
                                for(k = 0; k < numberOfMsgTextLines; k++) {
                                    TextLine tl = (TextLine)m_TextLines.elementAt(k);
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(tl.toString(), MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                }

                                for(int pad = k; pad < mf.numLines; pad++) {
                                    int z = 0;
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                    z++;
                                }

                                i++;
                            } else {
                                for(int lineNum = 0; lineNum < mf.numLines; lineNum++) {
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                }

                            }
                        } else {
                            j--;
                            i++;
                        }
                    }
                }

            }

        }
        catch(Exception ex) {
            LogWriter.writeLog(ex);
        }
        return buf.toString();
    }

    protected String formatDataFLA(IssueCustomer ic) {
        
    	StringBuffer buf = new StringBuffer(1024);
        try
        {
            LabelLine8 = PropertyBroker.getProperty("LabelLine8");
            LL8Override = PropertyBroker.getProperty("LL8Override");
            nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
            String oldLL8 = PropertyBroker.getProperty("oldLL8");
            magCode = mag.getMagCode();
            
            buf.append(REC_SEP);
            buf.append("10");
            
            buf.append(StringFunctions.fixSize(String.valueOf(rec_count++), 9, '0', StringFunctions.RIGHT));
            buf.append(UNIT_SEP);
            
            String zipcode = StringFunctions.fixSize(ic.getAddress().getZipCode(), 6, ' ', StringFunctions.LEFT);
            
            if(!ic.getcontinentCode().equals("")) {
                if(ic.getcontinentCode().charAt(0) >= 'A' && ic.getcontinentCode().charAt(0) <= 'Y') {
                    buf.append(StringFunctions.fixSize(zipcode, 10, ' ', StringFunctions.LEFT));
                } else {
                    buf.append(StringFunctions.fixSize(zipcode.substring(0, 5), 10, ' ', StringFunctions.LEFT));
                }
            } else {
                buf.append(StringFunctions.fixSize(zipcode.substring(0, 5), 10, ' ', StringFunctions.LEFT));
            }
            
            String sort_stacker = null;
            if(!ic.getEndPackageIndicator() && !ic.getEndPalletSackIndicator()) {
                sort_stacker = "00";
            } else {
            	if(ic.getEndPalletSackIndicator()) {
                    sort_stacker = "21";
                } else {
                    sort_stacker = "11";
                }
            }
            
            buf.append(sort_stacker);
            buf.append(" ");
            
            buf.append(StringFunctions.fixSize(ic.getMakeupCode(), 4, '0', StringFunctions.RIGHT));
            buf.append(AUX_SEP);
            
            buf.append(StringFunctions.fixSize("0", 31, '0', StringFunctions.LEFT));
            buf.append("0");
            
            if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
            {
                if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(1).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(2).substring(0, trimSize)).toString());
                    int packageNumber = ic.getPackageNumber();
                    String buff = null;
                    if(packageNumber < 1000) {
                        buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                    } else {
                        buff = String.valueOf(packageNumber);
                    }
                    buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(3).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(4).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(5).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(6).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(7).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(8).substring(0, trimSize)).toString());
                    
                    if(ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append(GRP_SEP);
                        buf.append(BAR_CODE_SEP);
                        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode, 14, ' ', StringFunctions.LEFT));
                        buf.append(BAR_CODE_SEP);
                    } else {
                        buf.append(GRP_SEP);
                        buf.append(BAR_CODE_SEP);
                        buf.append("              ");
                        buf.append(BAR_CODE_SEP);
                    }
                } else {
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    int packageNumber = ic.getPackageNumber();
                    String buff = null;
                    if(packageNumber < 1000) {
                        buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                    } else {
                        buff = String.valueOf(packageNumber);
                    }
                    buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(7), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(8), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    
                    if(ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append(GRP_SEP);
                        buf.append(BAR_CODE_SEP);
                        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode, 14, ' ', StringFunctions.RIGHT));
                        buf.append(BAR_CODE_SEP);
                    } else {
                        buf.append(GRP_SEP);
                        buf.append(BAR_CODE_SEP);
                        buf.append("              ");
                        buf.append(BAR_CODE_SEP);
                    }
                }
            } else {
            	if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(1).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(2).substring(0, trimSize)).toString());
                    int packageNumber = ic.getPackageNumber();
                    String buff = null;
                    if(packageNumber < 1000) {
                        buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                    } else {
                        buff = String.valueOf(packageNumber);
                    }
                    buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(3).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(4).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(5).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(6).substring(0, trimSize)).toString());
                    if(ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append(GRP_SEP);
                        buf.append(BAR_CODE_SEP);
                        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode, 14, ' ', StringFunctions.LEFT));
                        buf.append(BAR_CODE_SEP);
                    } else {
                        buf.append(GRP_SEP);
                        buf.append(BAR_CODE_SEP);
                        buf.append("              ");
                        buf.append(BAR_CODE_SEP);
                    }
                } else {
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    int packageNumber = ic.getPackageNumber();
                    String buff = null;
                    if(packageNumber < 1000) {
                        buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                    } else {
                        buff = String.valueOf(packageNumber);
                    }
                    buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    if(ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append(GRP_SEP);
                        buf.append(BAR_CODE_SEP);
                        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode, 14, ' ', StringFunctions.RIGHT));
                        buf.append(BAR_CODE_SEP);
                    } else {
                        buf.append(GRP_SEP);
                        buf.append(BAR_CODE_SEP);
                        buf.append("              ");
                        buf.append(BAR_CODE_SEP);
                    }
                }
            }
            
            
            int numberOfMessages = ic.getNumberOfMessages();
            Vector allMessages = ic.getMessages();
            Message m = null;
            String msgfamilyNumber = null;
            MessageParameter msgp = null;
            MessageFamily mf = null;
            int i = 0;
            
            for(int j = 0; j < messageFamilies.size(); j++) {
                mf = (MessageFamily)messageFamilies.elementAt(j);
                if(numberOfMessages == 0) {
                    for(int padding = 0; padding < mf.numLines; padding++) {
                        buf.append(GRP_SEP);
                        buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                    }

                } else {
                    if(i >= numberOfMessages) {
                        for(int padding = 0; padding < mf.numLines; padding++) {
                            buf.append(GRP_SEP);
                            buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                        }

                    } else {
                        m = (Message)allMessages.elementAt(i);
                        msgfamilyNumber = (new StringBuilder(String.valueOf(m.getMessageFamily()))).append(m.getMessageNumber()).toString();
                        msgp = (MessageParameter)msgparms.get(msgfamilyNumber);
                        if(!msgp.isCoverMessage()) {
                            if(m.getMessageFamily().equals(mf.familyNumber)) {
                                int numberOfMsgTextLines = m.getNumberOfTextLines();
                                Vector m_TextLines = m.getTextLines();
                                int k = 0;
                                for(k = 0; k < numberOfMsgTextLines; k++) {
                                    TextLine tl = (TextLine)m_TextLines.elementAt(k);
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(tl.toString(), MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                }

                                for(int pad = k; pad < mf.numLines; pad++) {
                                    int z = 0;
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                    z++;
                                }

                                i++;
                            } else {
                                for(int lineNum = 0; lineNum < mf.numLines; lineNum++) {
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                }

                            }
                        } else {
                            j--;
                            i++;
                        }
                    }
                }
            }

        }
        catch(Exception ex) {
            LogWriter.writeLog(ex);
        }
        return buf.toString();
    }

    protected String formatDataGLG(IssueCustomer ic) {
        
    	int GLGtrimSize = 65;
    	String zipCode = null;
        String zipPlus4 = null;
        String zip = null;
        StringBuffer buf = new StringBuffer(1024);
        try
        {
            LabelLine8 = PropertyBroker.getProperty("LabelLine8");
            LL8Override = PropertyBroker.getProperty("LL8Override");
            nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
            String oldLL8 = PropertyBroker.getProperty("oldLL8");
            magCode = mag.getMagCode();
            
            buf.append(REC_SEP);
            buf.append("2");
            buf.append("P");
            
            buf.append(StringFunctions.fixSize(String.valueOf(rec_count++), 9, '0', StringFunctions.RIGHT));
            buf.append(UNIT_SEP);
            
            if(!ic.getEndPackageIndicator() && ic.getEndPalletSackIndicator()) {
                buf.append("2");
            } else if(ic.getEndPackageIndicator() && !ic.getEndPalletSackIndicator()) {
                buf.append("3");
            } else if(ic.getEndPackageIndicator() && ic.getEndPalletSackIndicator()) {
                buf.append("4");
            } else if(!ic.getEndPackageIndicator() && !ic.getEndPalletSackIndicator()) {
                buf.append("0");
            }
            buf.append("0");
            
            if(ic.getMagazineLabel().getLabelType().equalsIgnoreCase("USPS")) {
                zipCode = StringFunctions.fixSize(ic.getAddress().getZipCode(), 5, ' ', StringFunctions.LEFT);
                if(ic.getMagazineLabel().zipPlus4 != null) {
                    zipPlus4 = ic.getMagazineLabel().zipPlus4;
                    zip = (new StringBuilder(String.valueOf(zipCode))).append(zipPlus4).toString();
                } else {
                    zip = zipCode;
                }
            } else {
                zip = StringFunctions.fixSize(ic.getAddress().getZipCode(), 6, ' ', StringFunctions.LEFT);
            }
            
            if(!ic.getcontinentCode().equals("")) {
                if(ic.getcontinentCode().charAt(0) >= 'A' && ic.getcontinentCode().charAt(0) <= 'Y') {
                    buf.append(StringFunctions.fixSize(zip, 12, ' ', StringFunctions.LEFT));
                } else {
                    buf.append(StringFunctions.fixSize(zip, 12, ' ', StringFunctions.LEFT));
                }
            } else {
                buf.append(StringFunctions.fixSize(zip, 12, ' ', StringFunctions.LEFT));
            }
            buf.append(UNIT_SEP);
            
            buf.append(StringFunctions.fixSize(String.valueOf(ic.getPalletSackNumber()), 6, ' ', StringFunctions.RIGHT));
            buf.append(UNIT_SEP);
            
            buf.append(StringFunctions.fixSize(ic.getMakeupCode(), 4, '0', StringFunctions.RIGHT));
            buf.append(UNIT_SEP);
            
            if(QC_Book == 0) {
                buf.append("Q");
                QC_Book++;
            } else if(QC_Book == 6000) {
                buf.append("Q");
                QC_Book = 1;
            } else {
                buf.append(" ");
                QC_Book++;
            }
            buf.append(UNIT_SEP);
            
            buf.append(StringFunctions.fixSize("0", 100, '0', StringFunctions.RIGHT));
            
            String sort_stacker = null;
            
            if(!ic.getEndPackageIndicator() && !ic.getEndPalletSackIndicator()) 
                sort_stacker = "00";
             else {
            	 if(ic.getEndPalletSackIndicator())
            		 sort_stacker = "21";
            	 else
            		 sort_stacker = "11";
             }
            
            buf.append(sort_stacker);
            buf.append(" ");
            
            buf.append(StringFunctions.fixSize(ic.getMakeupCode(), 4, '0', StringFunctions.RIGHT));
            buf.append(AUX_SEP);
            buf.append(StringFunctions.fixSize("0", 31, '0', StringFunctions.LEFT));
            
            buf.append("0");
            
            if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
            {
            	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
            		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBar.toUpperCase(), GLGtrimSize, ' ', StringFunctions.LEFT)).toString());
            	} else {
            		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), GLGtrimSize, ' ', StringFunctions.LEFT)).toString());
            	}
                
            	String line2 = ic.getMagazineLabel().getTextLine(2).trim();
                buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(line2, GLGtrimSize, ' ', StringFunctions.LEFT)).toString());
                int packageNumber = ic.getPackageNumber();
                String buff = null;
                if(packageNumber < 1000) {
                	buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                } else {
                	buff = String.valueOf(packageNumber);
                }
                buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                String line3 = ic.getMagazineLabel().getTextLine(3).trim();
                String line4 = ic.getMagazineLabel().getTextLine(4).trim();
                String line5 = ic.getMagazineLabel().getTextLine(5).trim();
                String line6 = ic.getMagazineLabel().getTextLine(6).trim();
                String line7 = ic.getMagazineLabel().getTextLine(7).trim();
                String line8 = ic.getMagazineLabel().getTextLine(8).trim();
                
                buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(line3, GLGtrimSize, ' ', StringFunctions.LEFT)).toString());
                buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(line4, GLGtrimSize, ' ', StringFunctions.LEFT)).toString());
                buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(line5, GLGtrimSize, ' ', StringFunctions.LEFT)).toString());
                buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(line6, GLGtrimSize, ' ', StringFunctions.LEFT)).toString());
                buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(line7, GLGtrimSize, ' ', StringFunctions.LEFT)).toString());
                buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(line8, GLGtrimSize, ' ', StringFunctions.LEFT)).toString());
            } else {
            	
            	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
            		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBar.toUpperCase(), GLGtrimSize, ' ', StringFunctions.LEFT)).toString());
            	} else {
            		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), GLGtrimSize, ' ', StringFunctions.LEFT)).toString());
            	}
            	
            	String line1 = ic.getMagazineLabel().getTextLine(1).trim();
            	String line2 = ic.getMagazineLabel().getTextLine(2).trim();
            	buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(line1, GLGtrimSize, ' ', StringFunctions.LEFT)).toString());
            	buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(line2, GLGtrimSize, ' ', StringFunctions.LEFT)).toString());
                int packageNumber = ic.getPackageNumber();
                String buff = null;
                if(packageNumber < 1000) {
                	buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                } else {
                	buff = String.valueOf(packageNumber);
                }
                buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                String line3 = ic.getMagazineLabel().getTextLine(3).trim();
                String line4 = ic.getMagazineLabel().getTextLine(4).trim();
                String line5 = ic.getMagazineLabel().getTextLine(5).trim();
                String line6 = ic.getMagazineLabel().getTextLine(6).trim();
                
                buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(line3, GLGtrimSize, ' ', StringFunctions.LEFT)).toString());
                buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(line4, GLGtrimSize, ' ', StringFunctions.LEFT)).toString());
                buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(line5, GLGtrimSize, ' ', StringFunctions.LEFT)).toString());
                buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(line6, GLGtrimSize, ' ', StringFunctions.LEFT)).toString());   
            }
            
            
            int numberOfMessages = ic.getNumberOfMessages();
            Vector allMessages = ic.getMessages();
            Message m = null;
            String msgfamilyNumber = null;
            MessageParameter msgp = null;
            MessageFamily mf = null;
            int i = 0;
            
            for(int j = 0; j < messageFamilies.size(); j++) {
                mf = (MessageFamily)messageFamilies.elementAt(j);
                if(numberOfMessages == 0) {
                    for(int padding = 0; padding < mf.numLines; padding++) {
                        buf.append(GRP_SEP);
                        buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                    }

                } else {
                	if(i >= numberOfMessages) {
                        for(int padding = 0; padding < mf.numLines; padding++) {
                            buf.append(GRP_SEP);
                            buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                        }

                    } else {
                        m = (Message)allMessages.elementAt(i);
                        msgfamilyNumber = (new StringBuilder(String.valueOf(m.getMessageFamily()))).append(m.getMessageNumber()).toString();
                        msgp = (MessageParameter)msgparms.get(msgfamilyNumber);
                        if(!msgp.isCoverMessage()) {
                            if(m.getMessageFamily().equals(mf.familyNumber)) {
                                int numberOfMsgTextLines = m.getNumberOfTextLines();
                                Vector m_TextLines = m.getTextLines();
                                int k = 0;
                                for(k = 0; k < numberOfMsgTextLines; k++) {
                                    TextLine tl = (TextLine)m_TextLines.elementAt(k);
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(tl.toString().replaceAll("�", "^PF17^XS^PF33^X"), MESSAGE_SIZE + 14, ' ', StringFunctions.LEFT));
                                }

                                for(int pad = k; pad < mf.numLines; pad++) {
                                    int z = 0;
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                    z++;
                                }

                                i++;
                            } else {
                                for(int lineNum = 0; lineNum < mf.numLines; lineNum++) {
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                }

                            }
                        } else {
                            j--;
                            i++;
                        }
                    }
                }
            }

        }
        catch(Exception ex) {
            LogWriter.writeLog(ex);
        }
        return buf.toString();
    }

    protected String formatDataDNV(IssueCustomer ic) {
        
    	String zipCode = null;
        String zipPlus4 = null;
        String zip = null;
        StringBuffer buf = new StringBuffer(1024);
        try
        {
            LabelLine8 = PropertyBroker.getProperty("LabelLine8");
            LL8Override = PropertyBroker.getProperty("LL8Override");
            nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
            String oldLL8 = PropertyBroker.getProperty("oldLL8");
            magCode = mag.getMagCode();
            
            buf.append(REC_SEP);
            buf.append("2");
            buf.append("P");
            
            buf.append(StringFunctions.fixSize(String.valueOf(rec_count++), 9, '0', StringFunctions.RIGHT));
            buf.append(UNIT_SEP);
            
            if(!ic.getEndPackageIndicator() && ic.getEndPalletSackIndicator()) {
                buf.append("2");
            } else if(ic.getEndPackageIndicator() && !ic.getEndPalletSackIndicator()) {
                buf.append("3");
            } else if(ic.getEndPackageIndicator() && ic.getEndPalletSackIndicator()) {
                buf.append("4");
            } else if(!ic.getEndPackageIndicator() && !ic.getEndPalletSackIndicator()) {
                buf.append("0");
            }
            buf.append("0");
            
            if(ic.getMagazineLabel().getLabelType().equalsIgnoreCase("USPS")) {
                zipCode = StringFunctions.fixSize(ic.getAddress().getZipCode(), 5, ' ', StringFunctions.LEFT);
                if(ic.getMagazineLabel().zipPlus4 != null) {
                    zipPlus4 = ic.getMagazineLabel().zipPlus4;
                    zip = (new StringBuilder(String.valueOf(zipCode))).append(zipPlus4).toString();
                } else {
                    zip = zipCode;
                }
            } else {
                zip = StringFunctions.fixSize(ic.getAddress().getZipCode(), 6, ' ', StringFunctions.LEFT);
            }
            
            if(!ic.getcontinentCode().equals("")) {
                if(ic.getcontinentCode().charAt(0) >= 'A' && ic.getcontinentCode().charAt(0) <= 'Y') {
                    buf.append(StringFunctions.fixSize(zip, 12, ' ', StringFunctions.LEFT));
                } else {
                    buf.append(StringFunctions.fixSize(zip, 12, ' ', StringFunctions.LEFT));
                }
            } else {
                buf.append(StringFunctions.fixSize(zip, 12, ' ', StringFunctions.LEFT));
            }
            buf.append(UNIT_SEP);
            
            buf.append(StringFunctions.fixSize(String.valueOf(ic.getPalletSackNumber()), 6, ' ', StringFunctions.RIGHT));
            buf.append(UNIT_SEP);
            
            buf.append(StringFunctions.fixSize(ic.getMakeupCode(), 4, '0', StringFunctions.RIGHT));
            buf.append(UNIT_SEP);
            
            if(QC_Book == 0) {
                buf.append("Q");
                QC_Book++;
            } else if(QC_Book == 6000) {
                buf.append("Q");
                QC_Book = 1;
            } else {
                buf.append(" ");
                QC_Book++;
            }
            buf.append(UNIT_SEP);
            
            buf.append(StringFunctions.fixSize("0", 100, '0', StringFunctions.RIGHT));
            
            String sort_stacker = null;
            
            if(!ic.getEndPackageIndicator() && !ic.getEndPalletSackIndicator()) 
                sort_stacker = "00";
             else {
            	 if(ic.getEndPalletSackIndicator())
            		 sort_stacker = "21";
            	 else
            		 sort_stacker = "11";
             }
            
            buf.append(sort_stacker);
            buf.append(" ");
            
            buf.append(StringFunctions.fixSize(ic.getMakeupCode(), 4, '0', StringFunctions.RIGHT));
            buf.append(AUX_SEP);
            buf.append(StringFunctions.fixSize("0", 31, '0', StringFunctions.LEFT));
            
            buf.append("0");
            
            if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
            	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
            		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBar.toUpperCase(), trimSize, ' ', StringFunctions.LEFT)).toString());
            	} else {
            		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), trimSize, ' ', StringFunctions.LEFT)).toString());
            	}
            } else {
            	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
            		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBar.toUpperCase(), trimSize, ' ', StringFunctions.RIGHT)).toString());
            	} else {
            		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), trimSize, ' ', StringFunctions.RIGHT)).toString());
            	}
            }
            
            if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
            {
                if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(2).substring(0, trimSize)).toString());
                    int packageNumber = ic.getPackageNumber();
                    String buff = null;
                    if(packageNumber < 1000) {
                        buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                    } else {
                        buff = String.valueOf(packageNumber);
                    }
                    buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(3).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(4).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(5).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(6).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(7).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(8).substring(0, trimSize)).toString());
                } else {
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    int packageNumber = ic.getPackageNumber();
                    String buff = null;
                    if(packageNumber < 1000) {
                        buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                    } else {
                        buff = String.valueOf(packageNumber);
                    }
                    buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(7), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(8), trimSize, ' ', StringFunctions.RIGHT)).toString());
                }
            } else {
            	if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(1).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(2).substring(0, trimSize)).toString());
                    int packageNumber = ic.getPackageNumber();
                    String buff = null;
                    if(packageNumber < 1000) {
                        buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                    } else {
                        buff = String.valueOf(packageNumber);
                    }
                    buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(3).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(4).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(5).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(6).substring(0, trimSize)).toString());
                } else {
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    int packageNumber = ic.getPackageNumber();
                    String buff = null;
                    if(packageNumber < 1000) {
                        buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                    } else {
                        buff = String.valueOf(packageNumber);
                    }
                    buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6), trimSize, ' ', StringFunctions.RIGHT)).toString());
                }
            }
            
            
            int numberOfMessages = ic.getNumberOfMessages();
            Vector allMessages = ic.getMessages();
            Message m = null;
            String msgfamilyNumber = null;
            MessageParameter msgp = null;
            MessageFamily mf = null;
            int i = 0;
            
            for(int j = 0; j < messageFamilies.size(); j++) {
                mf = (MessageFamily)messageFamilies.elementAt(j);
                if(numberOfMessages == 0) {
                    for(int padding = 0; padding < mf.numLines; padding++) {
                        buf.append(GRP_SEP);
                        buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                    }

                } else {
                	if(i >= numberOfMessages) {
                        for(int padding = 0; padding < mf.numLines; padding++) {
                            buf.append(GRP_SEP);
                            buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                        }

                    } else {
                        m = (Message)allMessages.elementAt(i);
                        msgfamilyNumber = (new StringBuilder(String.valueOf(m.getMessageFamily()))).append(m.getMessageNumber()).toString();
                        msgp = (MessageParameter)msgparms.get(msgfamilyNumber);
                        if(!msgp.isCoverMessage()) {
                            if(m.getMessageFamily().equals(mf.familyNumber)) {
                                int numberOfMsgTextLines = m.getNumberOfTextLines();
                                Vector m_TextLines = m.getTextLines();
                                int k = 0;
                                for(k = 0; k < numberOfMsgTextLines; k++) {
                                    TextLine tl = (TextLine)m_TextLines.elementAt(k);
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(tl.toString(), MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                }

                                for(int pad = k; pad < mf.numLines; pad++) {
                                    int z = 0;
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                    z++;
                                }

                                i++;
                            } else {
                                for(int lineNum = 0; lineNum < mf.numLines; lineNum++) {
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                }

                            }
                        } else {
                            j--;
                            i++;
                        }
                    }
                }
            }

        }
        catch(Exception ex) {
            LogWriter.writeLog(ex);
        }
        return buf.toString();
    }

    protected String formatDataLNS(IssueCustomer ic) {
        
    	String zipCode = null;
        String zipPlus4 = null;
        String zip = null;
        StringBuffer buf = new StringBuffer(1024);
        try
        {
            LabelLine8 = PropertyBroker.getProperty("LabelLine8");
            LL8Override = PropertyBroker.getProperty("LL8Override");
            nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
            String oldLL8 = PropertyBroker.getProperty("oldLL8");
            magCode = mag.getMagCode();
            trimSize = 65;
            
            buf.append(REC_SEP);
            buf.append("2");
            buf.append("P");
            
            buf.append(StringFunctions.fixSize(String.valueOf(rec_count++), 9, '0', StringFunctions.RIGHT));
            buf.append(UNIT_SEP);
            
            if(ic.getEndPackageIndicator() && !ic.getEndPalletSackIndicator()) {
                buf.append("3");
            } else if(ic.getEndPackageIndicator() && ic.getEndPalletSackIndicator()) {
                buf.append("4");
            } else if(!ic.getEndPackageIndicator() && !ic.getEndPalletSackIndicator()) {
                buf.append("0");
            }
            
            buf.append("0");
            
            if(ic.getMagazineLabel().getLabelType().equalsIgnoreCase("USPS")) {
                zipCode = StringFunctions.fixSize(ic.getAddress().getZipCode(), 5, ' ', StringFunctions.LEFT);
                if(ic.getMagazineLabel().zipPlus4 != null) {
                    zipPlus4 = ic.getMagazineLabel().zipPlus4;
                    zip = (new StringBuilder(String.valueOf(zipCode))).append(zipPlus4).toString();
                } else {
                    zip = zipCode;
                }
            } else {
                zip = StringFunctions.fixSize(ic.getAddress().getZipCode(), 6, ' ', StringFunctions.LEFT);
            }
            
            if(!ic.getcontinentCode().equals("")) {
                if(ic.getcontinentCode().charAt(0) >= 'A' && ic.getcontinentCode().charAt(0) <= 'Y') {
                    buf.append(StringFunctions.fixSize(zip, 12, ' ', StringFunctions.LEFT));
                } else {
                    buf.append(StringFunctions.fixSize(zip, 12, ' ', StringFunctions.LEFT));
                }
            } else {
                buf.append(StringFunctions.fixSize(zip, 12, ' ', StringFunctions.LEFT));
            }
            buf.append(UNIT_SEP);
            
            buf.append(StringFunctions.fixSize(String.valueOf(ic.getPalletSackNumber()), 6, ' ', StringFunctions.RIGHT));
            buf.append(UNIT_SEP);
            
            buf.append(StringFunctions.fixSize(ic.getMakeupCode(), 4, '0', StringFunctions.RIGHT));
            buf.append(UNIT_SEP);
            
            if(QC_Book == 0) {
                buf.append("Q");
                QC_Book++;
            } else if(QC_Book == 6000) {
                buf.append("Q");
                QC_Book = 1;
            } else {
                buf.append(" ");
                QC_Book++;
            }
            buf.append(UNIT_SEP);
            buf.append(UNIT_SEP);
            
            if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
            	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
            		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBar.toUpperCase(), trimSize, ' ', StringFunctions.LEFT)).toString());
            	} else {
            		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), trimSize, ' ', StringFunctions.LEFT)).toString());
            	}
            } else {
            	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
            		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBar.toUpperCase(), trimSize, ' ', StringFunctions.RIGHT)).toString());
            	} else {
            		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), trimSize, ' ', StringFunctions.RIGHT)).toString());
            	}
            }
            
            if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
            {
                if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                	buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(2).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(3).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(4).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(5).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(6).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(7).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(8).substring(0, trimSize)).toString());
                } else {
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(7), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(8), trimSize, ' ', StringFunctions.RIGHT)).toString());
                }
            } else {
            	if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(1).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(2).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(3).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(4).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(5).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(6).substring(0, trimSize)).toString());
                } else {
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6), trimSize, ' ', StringFunctions.RIGHT)).toString());
                }
            }
            
            
            int numberOfMessages = ic.getNumberOfMessages();
            Vector allMessages = ic.getMessages();
            Message m = null;
            String msgfamilyNumber = null;
            MessageParameter msgp = null;
            MessageFamily mf = null;
            int i = 0;
            
            for(int j = 0; j < messageFamilies.size(); j++) {
                mf = (MessageFamily)messageFamilies.elementAt(j);
                if(numberOfMessages == 0) {
                    for(int padding = 0; padding < mf.numLines; padding++) {
                        buf.append(GRP_SEP);
                        buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                    }

                } else {
                	if(i >= numberOfMessages) {
                        for(int padding = 0; padding < mf.numLines; padding++) {
                            buf.append(GRP_SEP);
                            buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                        }

                    } else {
                        m = (Message)allMessages.elementAt(i);
                        msgfamilyNumber = (new StringBuilder(String.valueOf(m.getMessageFamily()))).append(m.getMessageNumber()).toString();
                        msgp = (MessageParameter)msgparms.get(msgfamilyNumber);
                        if(!msgp.isCoverMessage()) {
                            if(m.getMessageFamily().equals(mf.familyNumber)) {
                                int numberOfMsgTextLines = m.getNumberOfTextLines();
                                Vector m_TextLines = m.getTextLines();
                                int k = 0;
                                for(k = 0; k < numberOfMsgTextLines; k++) {
                                    TextLine tl = (TextLine)m_TextLines.elementAt(k);
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(tl.toString(), MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                }

                                for(int pad = k; pad < mf.numLines; pad++) {
                                    int z = 0;
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                    z++;
                                }

                                i++;
                            } else {
                                for(int lineNum = 0; lineNum < mf.numLines; lineNum++) {
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                }

                            }
                        } else {
                            j--;
                            i++;
                        }
                    }
                }
            }

        }
        catch(Exception ex) {
            LogWriter.writeLog(ex);
        }
        return buf.toString();
    }

    protected String formatDataTOR(IssueCustomer ic) {
        
    	String IMBbc = null;
    	int IMBbarCodeLength = 65;
    	StringBuffer buf = new StringBuffer(1024);
        try
        {
            LabelLine8 = PropertyBroker.getProperty("LabelLine8");
            LL8Override = PropertyBroker.getProperty("LL8Override");
            nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
            String oldLL8 = PropertyBroker.getProperty("oldLL8");
            magCode = mag.getMagCode();
            
            buf.append(REC_SEP);
            buf.append("10");
            
            buf.append(StringFunctions.fixSize(String.valueOf(rec_count++), 9, '0', StringFunctions.RIGHT));
            buf.append(UNIT_SEP);
            
            String zipcode = StringFunctions.fixSize(ic.getAddress().getZipCode(), 6, ' ', StringFunctions.LEFT);
            
            if(!ic.getcontinentCode().equals("")) {
                if(ic.getcontinentCode().charAt(0) >= 'A' && ic.getcontinentCode().charAt(0) <= 'Y') {
                    buf.append(StringFunctions.fixSize(zipcode, 10, ' ', StringFunctions.LEFT));
                } else {
                    buf.append(StringFunctions.fixSize(zipcode.substring(0, 5), 10, ' ', StringFunctions.LEFT));
                }
            } else {
                buf.append(StringFunctions.fixSize(zipcode.substring(0, 5), 10, ' ', StringFunctions.LEFT));
            }
            String sort_stacker = null;
            
            if(!ic.getEndPackageIndicator() && !ic.getEndPalletSackIndicator()) 
                sort_stacker = "00";
             else {
            	 if(ic.getEndPalletSackIndicator())
            		 sort_stacker = "21";
            	 else
            		 sort_stacker = "11";
             }
            
            buf.append(sort_stacker);
            buf.append(" ");
            
            buf.append(StringFunctions.fixSize(ic.getMakeupCode(), 4, '0', StringFunctions.RIGHT));
            buf.append(AUX_SEP);
            
            buf.append(StringFunctions.fixSize("0", 31, '0', StringFunctions.LEFT));
            buf.append("0");
            
          /*  if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), trimSize, ' ', StringFunctions.LEFT)).toString());
            } else {
                buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), trimSize, ' ', StringFunctions.RIGHT)).toString());
            } */
            
            IMBbc = StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), IMBbarCodeLength, ' ', StringFunctions.LEFT);
            
            if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
            {
                if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                	
                	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
                		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBar.toUpperCase(), IMBbarCodeLength, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", IMBbarCodeLength, ' ', StringFunctions.LEFT)).toString());
                	} else {
                		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(IMBbc).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", IMBbarCodeLength, ' ', StringFunctions.LEFT)).toString());
                	}
                    
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(2).substring(0, trimSize)).toString());
                    int packageNumber = ic.getPackageNumber();
                    String buff = null;
                    if(packageNumber < 1000) {
                        buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                    } else {
                        buff = String.valueOf(packageNumber);
                    }
                    buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                    
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(3).substring(0, trimSize)).toString());
                    
                    if(ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append(UNIT_SEP);
                        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode, 14, ' ', StringFunctions.LEFT));
                    } else {
                        buf.append(UNIT_SEP);
                        buf.append("              ");
                    }
                    
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(4).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(5).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(6).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(7).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(8).substring(0, trimSize)).toString());
                } else {
                	
                	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
                		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", IMBbarCodeLength, ' ', StringFunctions.LEFT)).toString());
                		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBar.toUpperCase(), IMBbarCodeLength, ' ', StringFunctions.LEFT)).toString());
                	} else {
                		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", IMBbarCodeLength, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(IMBbc).toString());
                	}
                	
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    int packageNumber = ic.getPackageNumber();
                    String buff = null;
                    if(packageNumber < 1000) {
                        buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                    } else {
                        buff = String.valueOf(packageNumber);
                    }
                    buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                    
                    if(ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append(UNIT_SEP);
                        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode, 14, ' ', StringFunctions.RIGHT));
                    } else {
                        buf.append(UNIT_SEP);
                        buf.append("              ");
                    }
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(7), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(8), trimSize, ' ', StringFunctions.RIGHT)).toString());
                }
            } else {
            	if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
            		
            		if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
            			buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBar.toUpperCase(), IMBbarCodeLength, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", IMBbarCodeLength, ' ', StringFunctions.LEFT)).toString());
            		} else {
            			buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(IMBbc).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", IMBbarCodeLength, ' ', StringFunctions.LEFT)).toString());
            		}
                    
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(1).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(2).substring(0, trimSize)).toString());
                    int packageNumber = ic.getPackageNumber();
                    String buff = null;
                    if(packageNumber < 1000) {
                        buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                    } else {
                        buff = String.valueOf(packageNumber);
                    }
                    buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(3).substring(0, trimSize)).toString());
                    
                    if(ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append(UNIT_SEP);
                        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode, 14, ' ', StringFunctions.LEFT));
                    } else {
                        buf.append(UNIT_SEP);
                        buf.append("              ");
                    }
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(4).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(5).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(6).substring(0, trimSize)).toString());
                } else {
                	
                	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
                		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", IMBbarCodeLength, ' ', StringFunctions.LEFT)).toString());
                		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBar.toUpperCase(), IMBbarCodeLength, ' ', StringFunctions.LEFT)).toString());
                	} else {
                		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", IMBbarCodeLength, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(IMBbc).toString());
                	}
                    
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    int packageNumber = ic.getPackageNumber();
                    String buff = null;
                    if(packageNumber < 1000) {
                        buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                    } else {
                        buff = String.valueOf(packageNumber);
                    }
                    buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                    
                    if(ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append(UNIT_SEP);
                        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode, 14, ' ', StringFunctions.LEFT));
                    } else {
                        buf.append(UNIT_SEP);
                        buf.append("              ");
                    }
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6), trimSize, ' ', StringFunctions.RIGHT)).toString());
                }
            }
            
            
            int numberOfMessages = ic.getNumberOfMessages();
            Vector allMessages = ic.getMessages();
            Message m = null;
            String msgfamilyNumber = null;
            MessageParameter msgp = null;
            MessageFamily mf = null;
            int i = 0;
            
            for(int j = 0; j < messageFamilies.size(); j++) {
                mf = (MessageFamily)messageFamilies.elementAt(j);
                if(numberOfMessages == 0) {
                    for(int padding = 0; padding < mf.numLines; padding++) {
                        buf.append(GRP_SEP);
                        buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                    }

                } else {
                	if(i >= numberOfMessages) {
                        for(int padding = 0; padding < mf.numLines; padding++) {
                            buf.append(GRP_SEP);
                            buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                        }

                    } else {
                        m = (Message)allMessages.elementAt(i);
                        msgfamilyNumber = (new StringBuilder(String.valueOf(m.getMessageFamily()))).append(m.getMessageNumber()).toString();
                        msgp = (MessageParameter)msgparms.get(msgfamilyNumber);
                        if(!msgp.isCoverMessage()) {
                            if(m.getMessageFamily().equals(mf.familyNumber)) {
                                int numberOfMsgTextLines = m.getNumberOfTextLines();
                                Vector m_TextLines = m.getTextLines();
                                int k = 0;
                                for(k = 0; k < numberOfMsgTextLines; k++) {
                                    TextLine tl = (TextLine)m_TextLines.elementAt(k);
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(tl.toString().replaceAll("�", "^PF17^XS^PF33^X"), MESSAGE_SIZE + 14, ' ', StringFunctions.LEFT));
                                }

                                for(int pad = k; pad < mf.numLines; pad++) {
                                    int z = 0;
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                    z++;
                                }

                                i++;
                            } else {
                                for(int lineNum = 0; lineNum < mf.numLines; lineNum++) {
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                }

                            }
                        } else {
                            j--;
                            i++;
                        }
                    }
                }
            }
        } catch(Exception ex) {
            LogWriter.writeLog(ex);
        }
        return buf.toString();
    }

    protected String formatDataWAS(IssueCustomer ic) {
        
    	StringBuffer buf = new StringBuffer(1024);
        try
        {
            LabelLine8 = PropertyBroker.getProperty("LabelLine8");
            LL8Override = PropertyBroker.getProperty("LL8Override");
            nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
            String oldLL8 = PropertyBroker.getProperty("oldLL8");
            magCode = mag.getMagCode();
            
            String barcodeValue = ic.getMagazineLabel().barcode.trim();
            String checkSumDigit = null;
            boolean test = true;
            String IMBbc = null;
            
            try {
                test = Float.valueOf(barcodeValue).isNaN();
            }
            catch(Exception exception) { }
            
            if(!test) {
                if(barcodeValue.equals("")) {
                    checkSumDigit = "";
                } else {
                    long BCDigit = Long.parseLong(barcodeValue);
                    long BCDSum = 0L;
                    for(int i = 0; i < ic.getMagazineLabel().barcode.length(); i++) {
                        long digit = BCDigit % 10L;
                        long temp = BCDigit / 10L;
                        BCDigit = temp;
                        BCDSum += digit;
                    }

                    String CSDigit = Long.toString(BCDSum);
                    int checkSumValue;
                    if(CSDigit.length() < 2) {
                        int CSTemp = Integer.valueOf(CSDigit).intValue();
                        checkSumValue = 10 - CSTemp;
                    } else {
                        CSDigit = CSDigit.substring(1, 2);
                        int CSTemp = Integer.valueOf(CSDigit.trim()).intValue();
                        checkSumValue = 10 - CSTemp;
                    }
                    if(checkSumValue == 10) {
                        checkSumValue = 0;
                    }
                    checkSumDigit = Integer.toString(checkSumValue);
                }
            }
            
            buf.append(REC_SEP);
            
            buf.append("10");
            
            buf.append(StringFunctions.fixSize(String.valueOf(rec_count++), 9, '0', StringFunctions.RIGHT));
            buf.append(UNIT_SEP);
            
            String zipcode = StringFunctions.fixSize(ic.getAddress().getZipCode(), 6, ' ', StringFunctions.LEFT);
            
            if(!ic.getcontinentCode().equals("")) {
                if(ic.getcontinentCode().charAt(0) >= 'A' && ic.getcontinentCode().charAt(0) <= 'Y') {
                    buf.append(StringFunctions.fixSize(zipcode, 10, ' ', StringFunctions.LEFT));
                } else {
                    buf.append(StringFunctions.fixSize(zipcode.substring(0, 5), 10, ' ', StringFunctions.LEFT));
                }
            } else {
                buf.append(StringFunctions.fixSize(zipcode.substring(0, 5), 10, ' ', StringFunctions.LEFT));
            }
            
            String sort_stacker = null;
            
            if(!ic.getEndPackageIndicator() && !ic.getEndPalletSackIndicator()) 
                sort_stacker = "00";
             else {
            	 if(ic.getEndPalletSackIndicator())
            		 sort_stacker = "21";
            	 else
            		 sort_stacker = "11";
             }
            
            buf.append(sort_stacker);
            buf.append(" ");
            
            buf.append(StringFunctions.fixSize(ic.getMakeupCode(), 4, '0', StringFunctions.RIGHT));
            buf.append(AUX_SEP);
            
            buf.append(StringFunctions.fixSize("0", 31, '0', StringFunctions.LEFT));
            buf.append("0");
            
            IMBbc = StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), trimSize, ' ', StringFunctions.LEFT);
            
            if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
            {
                if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                	
                	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
                		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBarData, trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBar, trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", trimSize, ' ', StringFunctions.LEFT)).toString());
                	} else {
                		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcodeData, trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(IMBbc).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", trimSize, ' ', StringFunctions.LEFT)).toString());
                	}
                    
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(2).substring(0, trimSize)).toString());
                    int packageNumber = ic.getPackageNumber();
                    String buff = null;
                    if(packageNumber < 1000) {
                        buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                    } else {
                        buff = String.valueOf(packageNumber);
                    }
                    buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(3).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(4).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(5).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(6).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(7).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(8).substring(0, trimSize)).toString());
                    buf.append(GRP_SEP);
                    
                    if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT && ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append((new StringBuilder("*")).append(ic.getMagazineLabel().barcode).append(checkSumDigit).append("*").toString());
                    }
                    buf.append(GRP_SEP);
                    if(ic.getMagazineLabel().labelJustification == StringFunctions.RIGHT && ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append((new StringBuilder("*")).append(ic.getMagazineLabel().barcode).append(checkSumDigit).append("*").toString());
                    }
                } else {
                	
                	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
                		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBarData, trimSize, ' ', StringFunctions.RIGHT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBar, trimSize, ' ', StringFunctions.RIGHT)).toString());
                	} else {
                		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcodeData, trimSize, ' ', StringFunctions.RIGHT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(IMBbc).toString());
                	}
                    
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    int packageNumber = ic.getPackageNumber();
                    String buff = null;
                    if(packageNumber < 1000) {
                        buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                    } else {
                        buff = String.valueOf(packageNumber);
                    }
                    buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(7), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(8), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append(GRP_SEP);
                    
                    if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT && ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append((new StringBuilder("*")).append(ic.getMagazineLabel().barcode).append(checkSumDigit).append("*").toString());
                    }
                    buf.append(GRP_SEP);
                    if(ic.getMagazineLabel().labelJustification == StringFunctions.RIGHT && ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append((new StringBuilder("*")).append(ic.getMagazineLabel().barcode).append(checkSumDigit).append("*").toString());
                    }
                }
            } else {
            	if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
            		
            		if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
            			buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBarData, trimSize, ' ', StringFunctions.LEFT)).toString());
            			buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBar, trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", trimSize, ' ', StringFunctions.LEFT)).toString());
            		} else {
            			buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcodeData, trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(IMBbc).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", trimSize, ' ', StringFunctions.LEFT)).toString());
            		}
                    
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(1).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(2).substring(0, trimSize)).toString());
                    int packageNumber = ic.getPackageNumber();
                    String buff = null;
                    if(packageNumber < 1000) {
                        buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                    } else {
                        buff = String.valueOf(packageNumber);
                    }
                    buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(3).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(4).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(5).substring(0, trimSize)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(ic.getMagazineLabel().getTextLine(6).substring(0, trimSize)).toString());
                    
                    buf.append(GRP_SEP);
                    if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT && ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append((new StringBuilder("*")).append(ic.getMagazineLabel().barcode).append(checkSumDigit).append("*").toString());
                    }
                    buf.append(GRP_SEP);
                    if(ic.getMagazineLabel().labelJustification == StringFunctions.RIGHT && ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append((new StringBuilder("*")).append(ic.getMagazineLabel().barcode).append(checkSumDigit).append("*").toString());
                    }
                } else {
                	
                	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
                		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBarData, trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(profileBar, trimSize, ' ', StringFunctions.LEFT)).toString());
                	} else {
                		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcodeData, trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", trimSize, ' ', StringFunctions.LEFT)).toString());
                        buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(IMBbc).toString());
                	}
                    
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    int packageNumber = ic.getPackageNumber();
                    String buff = null;
                    if(packageNumber < 1000) {
                        buff = StringFunctions.fixSize(String.valueOf(packageNumber), 4, '0', StringFunctions.RIGHT);
                    } else {
                        buff = String.valueOf(packageNumber);
                    }
                    buf.append((new StringBuilder(String.valueOf(UNIT_SEP))).append(StringFunctions.fixSize(buff, 7, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6), trimSize, ' ', StringFunctions.RIGHT)).toString());
                    
                    buf.append(GRP_SEP);
                    if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT && ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append((new StringBuilder("*")).append(ic.getMagazineLabel().barcode).append(checkSumDigit).append("*").toString());
                    }
                    buf.append(GRP_SEP);
                    if(ic.getMagazineLabel().labelJustification == StringFunctions.RIGHT && ic.getMagazineLabel().barcode.length() > 0) {
                        buf.append((new StringBuilder("*")).append(ic.getMagazineLabel().barcode).append(checkSumDigit).append("*").toString());
                    }
                }
            }
            
            
            int numberOfMessages = ic.getNumberOfMessages();
            Vector allMessages = ic.getMessages();
            Message m = null;
            String msgfamilyNumber = null;
            MessageParameter msgp = null;
            MessageFamily mf = null;
            int i = 0;
            
            for(int j = 0; j < messageFamilies.size(); j++) {
                mf = (MessageFamily)messageFamilies.elementAt(j);
                if(numberOfMessages == 0) {
                    for(int padding = 0; padding < mf.numLines; padding++) {
                        buf.append(GRP_SEP);
                        buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                    }

                } else {
                	if(i >= numberOfMessages) {
                        for(int padding = 0; padding < mf.numLines; padding++) {
                            buf.append(GRP_SEP);
                            buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                        }

                    } else {
                        m = (Message)allMessages.elementAt(i);
                        msgfamilyNumber = (new StringBuilder(String.valueOf(m.getMessageFamily()))).append(m.getMessageNumber()).toString();
                        msgp = (MessageParameter)msgparms.get(msgfamilyNumber);
                        if(!msgp.isCoverMessage()) {
                            if(m.getMessageFamily().equals(mf.familyNumber)) {
                                int numberOfMsgTextLines = m.getNumberOfTextLines();
                                Vector m_TextLines = m.getTextLines();
                                int k = 0;
                                for(k = 0; k < numberOfMsgTextLines; k++) {
                                    TextLine tl = (TextLine)m_TextLines.elementAt(k);
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(tl.toString(), MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                }

                                for(int pad = k; pad < mf.numLines; pad++) {
                                    int z = 0;
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                    z++;
                                }

                                i++;
                            } else {
                                for(int lineNum = 0; lineNum < mf.numLines; lineNum++) {
                                    buf.append(GRP_SEP);
                                    buf.append(StringFunctions.fixSize(" ", MESSAGE_SIZE, ' ', StringFunctions.LEFT));
                                }

                            }
                        } else {
                            j--;
                            i++;
                        }
                    }
                }
            }

        }
        catch(Exception ex) {
            LogWriter.writeLog(ex);
        }
        return buf.toString();
    }

}
