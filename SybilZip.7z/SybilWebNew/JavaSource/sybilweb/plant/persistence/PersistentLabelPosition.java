package sybilweb.plant.persistence;

/**
 * Insert the type's description here.
 * Creation date: (2/12/02 4:33:17 PM)
 * @author: Srikanth Bapanapalli
 */
import java.io.*;
import sybilweb.plant.controller.*;
import java.util.*;

public class PersistentLabelPosition {
	Vector labelPosition = null;
	

/**
 * This method was created by a SmartGuide.
 * @return int
 * @param mag sybil.common.model.Magazine
 */
public Vector loadLabelPosition (Magazine mag ) {
	FileInputStream fis = null;
	InputStreamReader isr = null;
	BufferedReader br = null;
	labelPosition = new Vector();
	
	String filename = null;
	String labelLine = null;

	String plant = mag.getPlant().trim();

	String CTLFilePath = PropertyBroker.getProperty("OLDFILEDIR");
	CTLFilePath = CTLFilePath.substring(0,CTLFilePath.lastIndexOf("/"));
	CTLFilePath = CTLFilePath.substring(0,CTLFilePath.lastIndexOf("/"));
	CTLFilePath = CTLFilePath.substring(0,CTLFilePath.lastIndexOf("/")+1);
	CTLFilePath = CTLFilePath.concat(plant.toUpperCase());
	CTLFilePath = CTLFilePath.concat("/InputData/");	
	
	filename = CTLFilePath + mag.getFullPrefix()  + ".LABELPOSITION";
	LogWriter.writeLog("persistentlabelposition ctl filename for plant "+plant+" filename "+filename);
	System.out.println("persistentlabelposition ctl filename for plant "+plant+" filename "+filename);
	try {
		fis = new FileInputStream(filename);
		isr = new InputStreamReader(fis,"IBM-1047");
		br = new BufferedReader(isr);
	}	catch (java.io.FileNotFoundException fnfe) {
		fnfe.printStackTrace();
		LogWriter.writeLog(fnfe);
		System.out.println("Error in persistentLabelposition.loadLabelPosition ");
		return null;
	}	catch(UnsupportedEncodingException ee){
		ee.printStackTrace();
		LogWriter.writeLog("Error in persistentLabelposition.loadLabelPosition ");
	}
	
	try {
		 while( (labelLine = br.readLine()) != null){
		 	LogWriter.writeLog(" reading LABELPOSITION file in persistentLabelposition.loadLabelPosition "+ labelLine);
			labelPosition.addElement(labelLine);
		 }
			br.close();
			isr.close();
			fis.close();
	}catch (Exception e) {
  		LogWriter.writeLog(e);
  		e.printStackTrace();
  	}

return labelPosition;
}
/**
 * This method was created by a SmartGuide.
 * @param mag Magazine
 * @param labelPosition int
 */
public void saveLabelPosition (Magazine mag, Vector msgs) {

	String filename = null;
	String plant = mag.getPlant().trim();
	String CTLFilePath = PropertyBroker.getProperty("OLDFILEDIR");
	CTLFilePath = CTLFilePath.substring(0,CTLFilePath.lastIndexOf("/"));
	CTLFilePath = CTLFilePath.substring(0,CTLFilePath.lastIndexOf("/"));
	CTLFilePath = CTLFilePath.substring(0,CTLFilePath.lastIndexOf("/")+1);
	CTLFilePath = CTLFilePath.concat(plant.toUpperCase());
	CTLFilePath = CTLFilePath.concat("/InputData/");	
	
	filename = CTLFilePath + mag.getFullPrefix()  + ".LABELPOSITION";
	
	try {
		FileOutputStream fos = new FileOutputStream(filename);
		OutputStreamWriter osw = new OutputStreamWriter(fos,"IBM-1047");
		BufferedWriter bw = new BufferedWriter(osw);

		for(int i = 0; i<msgs.size(); i++){
			bw.write((String)msgs.elementAt(i));
			if(i!= msgs.size())
				bw.newLine();
		}
		
		bw.close();
		osw.close();
		fos.close();
 	}
	catch (Exception e) {
		e.printStackTrace();
  	}		

	
	return;
}
}
