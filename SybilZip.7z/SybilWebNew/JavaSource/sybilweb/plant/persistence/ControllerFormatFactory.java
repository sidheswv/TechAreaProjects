package sybilweb.plant.persistence;

import sybilweb.plant.controller.*;


public class ControllerFormatFactory {

	private String outputFileType;
	public sybilweb.plant.persistence.PersistenceIssueCustomer persistentIssueCustomer;

public ControllerFormatFactory(String fileType) {

	setOutputFileType (fileType);
}
public PersistenceIssueCustomer createOutputFileFormatter() {

	persistentIssueCustomer = null;
	String newClass = "sybilweb.plant.persistence." + outputFileType + "PersistenceIssueCustomer";
	try {
		persistentIssueCustomer = (sybilweb.plant.persistence.PersistenceIssueCustomer) Class.forName(newClass).newInstance();
	} catch (Exception e) {
		e.printStackTrace();
		System.out.println("Could not able to Object "+newClass);
	}
	return persistentIssueCustomer;
}
private void setOutputFileType(String fileType) {

	outputFileType = fileType.trim();

}
}
