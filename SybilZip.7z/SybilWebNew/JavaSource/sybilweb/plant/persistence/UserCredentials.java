package sybilweb.plant.persistence;

public class UserCredentials {
  private String  user;
  private String  password;
  private String sessionId;
  private String webID;
  private String racfID;

  public UserCredentials( ) {
	user = "";
	password = "";
	sessionId = "";
  }  
  public String getPassword( ) {
	return password;
  }  
	public String getRacf( ) {
	return racfID;
  }  
  public String getSessionId() {
	return sessionId;
  }  
  public String getUser( ) {
	return user;
  }  
   public String getWebID( ) {
	return webID;
  }  
  public void setPassword( String password ) {
	this.password = password;
  }  
   public void setRacfID( String racfID ) {
	this.racfID = racfID;
  }  
  public void setSessionId(String sessionId) {
	this.sessionId = sessionId;
  }  
  public void setUser( String user ) {
	this.user = user;
  }  
 public void setWebID( String webID ) {
	this.webID = webID;
  }  
}
