package sybilweb.plant.persistence;

/**
This is the controller-specific formatter for the TransContinental controller
(Domino DCS1).  The plant will maintain three templates, one for a no-message
(or label only), one for one message and one for 2 messages (a 6, 12 and 18 line
format).  The format follows:

Fld	Field Name	Length	Start	End		Comments

1	Postal Code		6	1		6		Canadian Postal Code (no spaces)
2	Pallet Number	3	7		9		Pallet Number
3	Bag Break Marks	2	10		11		Two digit asterisk indicating bag breaks
4	Bundle Break 	2	12		13		Two digit asterisk indicating bundle breaks
5	Record Number	6	14		19		Sequential label record numbering.
6	Driver Code		4	20		23		BCT code using 4 digits
9	Data Line 1		100	24		123		Address Text line 1 (endorsement line)
10	Data Line 2		100	124		223		Address Text line 2 (ACS and edition info)
11	Data Line 3		100	224		323		Address Text Line 3 (cust name)
12	Data Line 4		100	324		423		Address Text Line 4 (Address line 1)
13	Data Line 5		100	424		523		Address Text Line 5 (address line 2)
14	Data Line 6		100	524		623		Address Text Line 6 (city / province / fsa)
15	Data Line 7		80	624		703		Message Text Line 1
16	Data Line 8		80	704		783		Message Text Line 2
17	Data Line 9		80	784		863		Message Text Line 3
18	Data Line 10	80	864		943		Message Text Line 4
19	Data Line 11	80	944		1023	Message Text Line 5
20	Data Line 12	80	1024	1103	Message Text Line 6
21	Data Line 13	80	1104	1183	Message Text Line 7
22	Data Line 14	80	1184	1263	Message Text Line 8
23	Data Line 15	80	1264	1343	Message Text Line 9
24	Data Line 16	80	1344	1423	Message Text Line 10
25	Data Line 17	80	1424	1503	Message Text Line 11
26	Data Line 18	80	1504	1583	Message Text Line 12

 */
import java.io.*;
import java.util.*;
import sybilweb.plant.controller.*;

public class TRANSCONTPersistenceIssueCustomer extends PersistenceIssueCustomer {

	private static final int MESSAGE_SIZE = 80;	// All non-label messages are 80 chars.

/// VERSION OF CLASS IN PRODUCTION ////
	public static final String Class_Version_Number = "PR_6.2_REL9.4";


	int rec_count = 1;
	int unique_id = 1;

/**
 * This method was created by a SmartGuide.
 * @param outputFileName java.lang.String
 */
public void createOutputFile(String prop, String outputFileName ) {
	this.outputFileName = outputFileName;
	outFileName = outputFileName;
	useShortFileName = PropertyBroker.getProperty("useShortFileName","false");
	shortFileName = outputFileName.substring(0,outputFileName.lastIndexOf("/")+1).concat(outputFileName.substring(outputFileName.lastIndexOf(".")+1, outputFileName.length()));
	plant = mag.getPlant().toUpperCase();


	rec_count = 1;
	unique_id = 1;

	String FormatterFileConcatText = null;
	
	FormatterFileConcatText = PropertyBroker.getProperty("FormatterFileConcatText");

	// get value from RLL5 file in input data
	String fileName = null;	
	fileName = sybilweb.plant.controller.PropertyBroker.getProperty("OLDFILEDIR") + mag.getFullPrefix() + ".RLL5";
	File f = new File(fileName);
	BufferedReader fileReader = null;
	if (f.exists()){
		try {
			fileReader = new BufferedReader(new FileReader(fileName));
		} catch (java.io.FileNotFoundException fnfe) {
			sybilweb.plant.controller.LogWriter.writeLog(new Exception(mag.getPrefix() + ": Error opening RLL5 file: File not found: " + fileName));
			return;
		}
	
		try{
			RLL5value = fileReader.readLine();
			sybilweb.plant.controller.LogWriter.writeLog("RLL5value = "+RLL5value);
		}catch(EOFException ee) {
		}	catch(Exception re) {
			sybilweb.plant.controller.LogWriter.writeLog(re);
		}
	}else {
		RLL5value = "false";
	}
// end of RLL5 file code
	
	if(FormatterFileConcatText == null)
		FormatterFileConcatText = "";
	if (useShortFileName.equals("true"))
		formatShortFileName = true;

		// sets file name based upon whether short or long file name
	if (formatShortFileName){
		shortOutputFileName = prop+shortFileName;

	}else {
		longOutputFileName = prop+mag.getLongFileName()+fileSep+shortFileName;
	}

		
	//creates temp file based on short or long file name	
	if (formatShortFileName){
			tmpFile = new File(prop + outputFileName + FormatterFileConcatText +".tmp");
	}else {
			tmpFile = new File(longOutputFileName + FormatterFileConcatText +".tmp");
	}


	try {
		outputFile = new OutputStreamWriter(new FileOutputStream(tmpFile),"ISO8859_1");		
	}catch (IOException e){
		LogWriter.writeLog(new SybilWarningException(mag.getPrefix() + ": Error creating output file: " + e.getMessage()));
		return;
	}

	// This change is for creating file FileName.add 
	// The outputFileName passed is Mag_name.Group_Num.FileName for handling ReRun
	// for ex: which was passed as TD1884uspsstripcust01.00020.TUS41233 for Rerun changes
	// the output File is created as TUS41233.add for the short name or in.i022104.brb.usps.strip.IUS14347 for the loing name
	

	if (formatShortFileName){
		shortOutputFileName = prop+shortFileName;

	}else {
		longOutputFileName = prop+mag.getLongFileName()+fileSep+shortFileName;
	}

	
	if (formatShortFileName){
		newFile = new File(shortOutputFileName + FormatterFileConcatText +".for");
	}else {
		newFile = new File(longOutputFileName + FormatterFileConcatText +".for");
	}

	if (newFile.exists())
		newFile.delete(); 

	LogWriter.writeLog("I", mag.getPlant().toUpperCase(), mag.getPrefix(), outputFileName +" Started Formatting");



	return;
}
/**
 * formatData method comment. This format needs all records to be padded to the maximum line length.
 */
protected String formatData(sybilweb.plant.controller.IssueCustomer ic) {

	StringBuffer buf = new StringBuffer(1024);
	try{
	String tmpbuf = null;
	LabelLine8 = (String)sybilweb.plant.controller.PropertyBroker.getProperty("LabelLine8");
	LL8Override = (String)sybilweb.plant.controller.PropertyBroker.getProperty("LL8Override");
	nonLL8Plant = (String)sybilweb.plant.controller.PropertyBroker.getProperty("nonLL8Plant");
	String oldLL8 = (String)sybilweb.plant.controller.PropertyBroker.getProperty("oldLL8");

	magCode = mag.getMagCode();
	String labelLine = null;

//zipcode / Canadian postal code
	String zipcode = (StringFunctions.fixSize(ic.getAddress().getZipCode(),6,' ',StringFunctions.LEFT));

	if(!ic.getcontinentCode().equals("")){
		if ((ic.getcontinentCode().charAt(0) >= 'A') && (ic.getcontinentCode().charAt(0) <= 'Y'))
			buf.append(zipcode.substring(0,6));
		else
			buf.append(zipcode.substring(0,5) + " ");
	}else{
		buf.append(zipcode.substring(0,5) + " ");
	}	


/*	if ((ic.getcontinentCode().charAt(0) >= 'A') && (ic.getcontinentCode().charAt(0) <= 'Y'))
		buf.append(zipcode.substring(0,6));
	else
		buf.append(zipcode.substring(0,5) + " ");
*/

// format pallet number
	int pallet = ic.getPalletSackNumber();
	if (pallet == -1) // pallet suppressed, set to zero so that control information will not be affected.
		pallet = 0;

	tmpbuf = StringFunctions.fixSize(String.valueOf(pallet),5,'0',StringFunctions.RIGHT);
	buf.append(tmpbuf.substring(2,5));

// sack break
	if (ic.getEndPalletSackIndicator()) {
		buf.append ("**");
	} else {
		buf.append ("  ");
	}

// package break
	if (ic.getEndPackageIndicator()) {
		buf.append ("**");
	} else {
		buf.append ("  ");
	}

// rec_count
	buf.append(StringFunctions.fixSize(String.valueOf(rec_count++),6,'0',StringFunctions.RIGHT));

// driver code
	buf.append(StringFunctions.fixSize(ic.getMakeupCode(),4,'0',StringFunctions.RIGHT));


/************************************************************************************/
//***** This is used if there is 8 labels lines, otherwise it uses 6 (see below)****//
/***********************************************************************************/

	if ((LabelLine8.indexOf(magCode)>=0) && (LL8Override.equals("false")) && !(nonLL8Plant.indexOf(plant.toUpperCase())>=0) && (RLL5value.equalsIgnoreCase("false")) || (oldLL8.indexOf(magCode)>=0)){
		for (int i = 1; i <= 8; i++) {
			if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT)
				labelLine = ic.getMagazineLabel().getTextLine(i).substring(0,trimSize);
			else {
				labelLine = (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(i),trimSize,' ',StringFunctions.RIGHT));
			}
			buf.append(labelLine);
		}
	}else {
		for (int i = 1; i <= 6; i++) {
			if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT)
				labelLine = ic.getMagazineLabel().getTextLine(i).substring(0,trimSize);
			else {
				labelLine = (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(i),trimSize,' ',StringFunctions.RIGHT));
			}
			buf.append(labelLine);
		}
	}
/************************************************************************************/
//***** *******************END OF LABEL DATA***************************************//
/***********************************************************************************/


// message data	Includes padding for records w/ & w/0 messages. A return line feed is required for all records.

   int numberOfMessages = ic.getNumberOfMessages();		//# of messages per customer

	Vector allMessages = ic.getMessages();						//text of those messages

	int numberOfMsgTextLines;
	Vector m_TextLines;
	Message m = null;
	String msgfamilyNumber = null;
	MessageParameter msgp = null;
	MessageFamily mf = null;
	int i = 0;

	for (int j = 0; j < messageFamilies.size(); j++) {

		mf = (MessageFamily)messageFamilies.elementAt(j);

		if (numberOfMessages == 0) {
			for (int padding = 0; padding < mf.numLines; padding++)
				buf.append(StringFunctions.fixSize(" ",
										MESSAGE_SIZE,' ',StringFunctions.LEFT));
		}else {

			if (i >= numberOfMessages ) {
			   for (int padding = 0; padding < mf.numLines; padding++)
					buf.append(StringFunctions.fixSize(" ",
										MESSAGE_SIZE,' ',StringFunctions.LEFT));
			}else{

			m = ((Message)allMessages.elementAt(i));
				msgfamilyNumber = m.getMessageFamily() + m.getMessageNumber();
				msgp = (MessageParameter)msgparms.get(msgfamilyNumber);

		if (!msgp.isCoverMessage()) {

					if (m.getMessageFamily().equals(mf.familyNumber)) {

						numberOfMsgTextLines = m.getNumberOfTextLines();

						m_TextLines = m.getTextLines();

						int k = 0;

						for (k = 0; k < numberOfMsgTextLines; k++) {
							TextLine tl = (TextLine) m_TextLines.elementAt(k);
							buf.append(StringFunctions.fixSize(tl.toString(),
								MESSAGE_SIZE,' ',StringFunctions.LEFT));
					}

					// pad out text lines so that there are always SIX lines
					for (int pad = k; pad < 6; pad++) {
						buf.append(StringFunctions.fixSize(" ",
								MESSAGE_SIZE,' ',StringFunctions.LEFT));
					}
						i++;
					} else{    // doesn't have this family? insert a blank one.
					for (int lineNum = 0; lineNum < 6; lineNum++) {
						buf.append(StringFunctions.fixSize(" ",
										MESSAGE_SIZE,' ',StringFunctions.LEFT));
					   }
					}
				}else{
					j--;
					i++;
				}
			}
		}
	}
	buf.append("\r\n");
	}catch(Exception ex){ LogWriter.writeLog(ex); }
	return buf.toString();
}
}
