package sybilweb.plant.persistence;

import java.io.*;
import java.util.*;
import sybilweb.plant.controller.*;


public class SE163PersistenceIssueCustomer extends PersistenceIssueCustomer {

    public static final String Class_Version_Number = "FEB 2010";
    
    private static final String profileBar = "TADFDFDAAFFADFDATTDTTTFDATADFDTDTTAATDATATTAAFADFATDDFATAFFDAAFTF";
	private static final String profileBarData = "1003810076600000000095348430709";
    
    int rec_count = 1;
	int recordLength = 0;
	int blockLength = 0;
	int numMsgLines = 0;
	int numInkjetLines = 0;
	
    private static final int EIBSizeWDK = 38;
    private static final int EIBSizeWAS = 38;
    private static final int EIBSizeMIA = 34;
    private static final int EIBSizeDYB = 27;
    private static final int selectiveBindBarCodeSizeWDK = 65;
    
    GregorianCalendar c = new GregorianCalendar();
    
    String linelength;
    int [] lineLengths = new int[24];
    
    int familyNum = 0;
	MessageFamily mf = null;
	boolean WDK8LLRecordLength = true;
	

    public SE163PersistenceIssueCustomer() {
       
    }

    private String createEIBBlock() {
        
    	StringBuffer buf = new StringBuffer(blockLength);
    // Consolidation Level (EI 01)
        buf.append("0100102");
    // End of Zone (package) (EI 02)
        buf.append("0200301");
    // End of pallet/sack (EI 03)
        buf.append("0300401");
    // Zip Code (EI 04)
        buf.append("0400511");
    // State Code (EI 05)
        buf.append("0501602");
    // Sequence Number (EI 06)
        buf.append("0601806");
    // BCT Code (EI 07)
        buf.append("0702404");
    // Pallet/Sack Number (EI 09)
        buf.append("0902806");
   
        for(int x = buf.length(); x < blockLength; x++) {
            buf.append(" ");
        }
        int z = buf.length();
        
        return buf.toString();
    }

    private String createDYBEIBBlock() {
        
    	StringBuffer buf = new StringBuffer(blockLength);
        buf.append("0100102");
        buf.append("0200301");
        buf.append("0300401");
        buf.append("0400511");
        buf.append("0501602");
        buf.append("0601806");
        buf.append("0702404");
        
        for(int x = buf.length(); x < blockLength; x++) {
            buf.append(" ");
        }

        int z = buf.length();
        return buf.toString();
    }

    private String createEOV() {
        
    	StringBuffer buf = new StringBuffer(1024);
        
    	String dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
        String fileVolID = (new StringBuilder(String.valueOf(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT)))).append(outputFileName.substring(outputFileName.length() - 3, outputFileName.length())).toString();
        
        String year = String.valueOf(c.get(Calendar.YEAR)).substring(2,4);
        String creationDate = (new StringBuilder(String.valueOf(StringFunctions.fixSize(year, 3, '0', StringFunctions.RIGHT)))).append(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT)).toString();
        
        buf.append("EOF1");
        
        buf.append("SYBIL.SE163      ");
        
        buf.append(fileVolID);
        
        buf.append("000100010001");
        
        buf.append("00");
        
        buf.append(creationDate);
        
        c.add(Calendar.DAY_OF_YEAR,7);
        year = String.valueOf(c.get(Calendar.YEAR)).substring(2,4);
        buf.append(StringFunctions.fixSize(year, 3, '0', StringFunctions.RIGHT));
        dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
        buf.append(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT));
        
        buf.append(" ");
        
        buf.append("000000");
        
        buf.append("Time, Inc. SBT");
        
        buf.append(StringFunctions.fixSize(" ", 6, ' ', StringFunctions.LEFT));
        
        buf.append("EOF2");
        
        buf.append("F");
        
        buf.append(StringFunctions.fixSize(String.valueOf(blockLength), 5, '0', StringFunctions.RIGHT));
        
        buf.append(StringFunctions.fixSize(String.valueOf(recordLength), 5, '0', StringFunctions.RIGHT));
        
        buf.append(StringFunctions.fixSize(" ", 35, ' ', StringFunctions.LEFT));
        
        buf.append("00");
        
        buf.append(StringFunctions.fixSize(" ", 28, ' ', StringFunctions.LEFT));
        
        return buf.toString();
    }

    private String createHeader() {
        
    	String PlantID = mag.getPlant();
        String header = null;
        
        if(PlantID.toUpperCase().equals("MIA")) {
            header = createHeaderMIA();
        } else if(PlantID.toUpperCase().equals("DYB")) {
            header = createHeaderDYB();
        } else {
            header = createHeaderDefault();
        }
        
        return header;
    }

    private String createHeaderDefault() {
        
    	StringBuffer buf = new StringBuffer(1024);
        
    	String PlantID = mag.getPlant();
        
    	String oldLL8 = PropertyBroker.getProperty("oldLL8");
        LL8Override = PropertyBroker.getProperty("LL8Override");
        nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
        
        String dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
        String fileVolID = (new StringBuilder(String.valueOf(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT)))).append(outputFileName.substring(outputFileName.length() - 3, outputFileName.length())).toString();
        
        String year = String.valueOf(c.get(Calendar.YEAR)).substring(2,4);
        String creationDate = (new StringBuilder(String.valueOf(StringFunctions.fixSize(year, 3, '0', StringFunctions.RIGHT)))).append(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT)).toString();
        
        int numOfLabelLines = 0;
        magCode = mag.getMagCode();
        LabelLine8 = PropertyBroker.getProperty("LabelLine8");
        
        if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
        {
            numOfLabelLines = 7;
        } else {
            WDK8LLRecordLength = false;
            numOfLabelLines = 6;
        }
        
        numOfLabelLines += (PlantID.equalsIgnoreCase("WAS") || PlantID.equalsIgnoreCase("WDK") || PlantID.equalsIgnoreCase("EGV")) ? 2 : 0;
        
        LogWriter.writeLog((new StringBuilder(" numOfLabelLines  :")).append("  --> ").append(numOfLabelLines).toString());
        
        for(int x = 0; x < 24; x++) {
            if(x >= 0 && x <= numOfLabelLines) {
                lineLengths[x] = trimSize;
            } else if(messageFamilies.size() != 0 && familyNum < messageFamilies.size()) {
                mf = (MessageFamily)messageFamilies.elementAt(familyNum);
                for(int j = 0; j < mf.numLines; j++) {
                    lineLengths[x++] = mf.getLineLength(j);
                }

                x--;
                numMsgLines += mf.numLines;
                familyNum++;
            } else {
                lineLengths[x] = 0;
            }
        }

        if(PlantID.equalsIgnoreCase("WAS") || PlantID.equalsIgnoreCase("WDK") || PlantID.equalsIgnoreCase("EGV")) {
            for(int x = 0; x < 24; x++) {
                if(lineLengths[x] > 0) {
                    numInkjetLines = x + 1;
                    recordLength += numInkjetLines != 2 ? lineLengths[x] : 130;
                    if(WDK8LLRecordLength) {
                        if(numInkjetLines == 10) {
                            recordLength += 24 - lineLengths[x];
                        }
                    } else if(numInkjetLines == 9) {
                        recordLength += 24 - lineLengths[x];
                    }
                    LogWriter.writeLog((new StringBuilder(" lineLengths[x]  :")).append(x).append("  --> ").append(lineLengths[x]).toString());
                }
            }

        } else {
            for(int x = 0; x < 24; x++) {
                if(lineLengths[x] > 0) {
                    numInkjetLines = x + 1;
                }
                recordLength += lineLengths[x];
            }

        }
        
        LogWriter.writeLog((new StringBuilder(" Record Length is : ")).append(recordLength).toString());
        
        if(PlantID.toUpperCase().equals("WAS")) {
            recordLength += EIBSizeWAS;
        } else if(PlantID.toUpperCase().equals("DYB")) {
            recordLength += EIBSizeDYB;
        } else if((PlantID.toUpperCase().equals("WDK") && WDK8LLRecordLength) || (PlantID.equalsIgnoreCase("EGV") && WDK8LLRecordLength)) {
            recordLength += EIBSizeWDK;
        } else {
            recordLength = recordLength + EIBSizeWDK + selectiveBindBarCodeSizeWDK;
        }
        
        blockLength = recordLength;
        
        buf.append("VOL1");
        buf.append(fileVolID);
        buf.append(StringFunctions.fixSize(" ", 27, ' ', StringFunctions.LEFT));
        buf.append("Time, Inc. SBT");
        buf.append(StringFunctions.fixSize(" ", 28, ' ', StringFunctions.LEFT));
        buf.append("3");
        
        buf.append("HDR1");
        buf.append("SYBIL.SE163      ");
        buf.append(fileVolID);
        buf.append("000100010001");
        buf.append("00");
        buf.append(creationDate);
        
        c.add(Calendar.DAY_OF_YEAR,7);
        year = String.valueOf(c.get(Calendar.YEAR)).substring(2,4);
        buf.append(StringFunctions.fixSize(year, 3, '0', StringFunctions.RIGHT));
        
        dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
        buf.append(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT));
        
        buf.append(" ");
        buf.append("000000");
        buf.append("Time, Inc. SBT");
        buf.append(StringFunctions.fixSize(" ", 6, ' ', StringFunctions.LEFT));
        
        buf.append("HDR2");
        buf.append("F");
        buf.append(StringFunctions.fixSize(String.valueOf(blockLength), 5, '0', StringFunctions.RIGHT));
        buf.append(StringFunctions.fixSize(String.valueOf(recordLength), 5, '0', StringFunctions.RIGHT));
        buf.append(StringFunctions.fixSize(" ", 35, ' ', StringFunctions.LEFT));
        buf.append("00");
        buf.append(StringFunctions.fixSize(" ", 28, ' ', StringFunctions.LEFT));
        
        buf.append("UHL1");
        buf.append("01");
        buf.append(StringFunctions.fixSize(String.valueOf(numInkjetLines + 1), 3, '0', StringFunctions.RIGHT));
        buf.append("01");
        buf.append("008");
        buf.append("00");
        buf.append("000");
        buf.append("00");
        buf.append("0000");
        buf.append("000");
        buf.append("000000001");
        buf.append("000000000");
        buf.append("0001");
        buf.append(StringFunctions.fixSize(" ", 29, ' ', StringFunctions.LEFT));
        
        buf.append("J");
        
        buf.append("UHL2");
        buf.append("##");
        buf.append("###");
        buf.append("###");
        buf.append("##");
        buf.append("1");
        buf.append(StringFunctions.fixSize(" ", 65, ' ', StringFunctions.LEFT));
        
        return buf.toString();
    }

    private String createHeaderDYB() {
        
    	StringBuffer buf = new StringBuffer(1024);
        String PlantID = mag.getPlant();
        
        String oldLL8 = PropertyBroker.getProperty("oldLL8");
        LL8Override = PropertyBroker.getProperty("LL8Override");
        nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
        
        String dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
        String fileVolID = (new StringBuilder(String.valueOf(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT)))).append(outputFileName.substring(outputFileName.length() - 3, outputFileName.length())).toString();
        
        String year = String.valueOf(c.get(Calendar.YEAR)).substring(2,4);
        String creationDate = (new StringBuilder(String.valueOf(StringFunctions.fixSize(year, 3, '0', StringFunctions.RIGHT)))).append(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT)).toString();
        
        int numOfLabelLines = 0;
        magCode = mag.getMagCode();
        LabelLine8 = PropertyBroker.getProperty("LabelLine8");
        
        if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
        {
            numOfLabelLines = 8;
        } else {
            WDK8LLRecordLength = false;
            numOfLabelLines = 5;
        }
        
        for(int x = 0; x < 24; x++) {
            if(x >= 0 && x <= numOfLabelLines) {
                lineLengths[x] = trimSize;
            } else if(messageFamilies.size() != 0 && familyNum < messageFamilies.size()) {
                mf = (MessageFamily)messageFamilies.elementAt(familyNum);
                for(int j = 0; j < mf.numLines; j++) {
                    lineLengths[x++] = mf.getLineLength(j);
                }

                x--;
                numMsgLines += mf.numLines;
                familyNum++;
            } else {
                lineLengths[x] = 0;
            }
        }

        for(int x = 1; x < 24; x++) {
            if(lineLengths[x] > 0) {
                numInkjetLines = x + 1;
            }
            if(x==1)
            	recordLength += 65;
            else
            	recordLength += lineLengths[x];
            
            //recordLength += numInkjetLines == 1 ? 65 : lineLengths[x];
            //recordLength += lineLengths[x];
        }

        recordLength += EIBSizeDYB;
        blockLength = recordLength;
        
        buf.append("VOL1");
        buf.append(fileVolID);
        buf.append(StringFunctions.fixSize(" ", 27, ' ', StringFunctions.LEFT));
        buf.append("Time, Inc. SBT");
        buf.append(StringFunctions.fixSize(" ", 28, ' ', StringFunctions.LEFT));
        buf.append("3");
        
        buf.append("HDR1");
        buf.append("SYBIL.SE163      ");
        buf.append(fileVolID);
        buf.append("000100010001");
        buf.append("00");
        buf.append(creationDate);
        
        c.add(Calendar.DAY_OF_YEAR,7);
        year = String.valueOf(c.get(Calendar.YEAR)).substring(2,4);
        buf.append(StringFunctions.fixSize(year, 3, '0', StringFunctions.RIGHT));
        
        dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
        buf.append(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT));
        
        buf.append(" ");
        buf.append("000000");
        buf.append("Time, Inc. SBT");
        buf.append(StringFunctions.fixSize(" ", 6, ' ', StringFunctions.LEFT));
        
        buf.append("HDR2");
        buf.append("F");
        buf.append(StringFunctions.fixSize(String.valueOf(blockLength), 5, '0', StringFunctions.RIGHT));
        buf.append(StringFunctions.fixSize(String.valueOf(recordLength), 5, '0', StringFunctions.RIGHT));
        buf.append(StringFunctions.fixSize(" ", 35, ' ', StringFunctions.LEFT));
        buf.append("00");
        buf.append(StringFunctions.fixSize(" ", 28, ' ', StringFunctions.LEFT));
        
        buf.append("UHL1");
        buf.append("01");
        buf.append(StringFunctions.fixSize(String.valueOf(numInkjetLines), 3, '0', StringFunctions.RIGHT));
        buf.append("01");
        buf.append("007");
        buf.append("00");
        buf.append("000");
        buf.append("00");
        buf.append("0000");
        buf.append("000");
        buf.append("000000001");
        buf.append("000000000");
        buf.append("0001");
        buf.append(StringFunctions.fixSize(" ", 29, ' ', StringFunctions.LEFT));
        buf.append("J");
        
        buf.append("UHL2");
        buf.append("##");
        buf.append("###");
        buf.append("###");
        buf.append("##");
        buf.append("1");
        buf.append(StringFunctions.fixSize(" ", 65, ' ', StringFunctions.LEFT));
        
        return buf.toString();
    }

    private String createHeaderMIA() {
        
    	StringBuffer buf = new StringBuffer(1024);
        String PlantID = mag.getPlant();
        trimSize = 45;
        
        String oldLL8 = PropertyBroker.getProperty("oldLL8");
        LL8Override = PropertyBroker.getProperty("LL8Override");
        nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
        
        String dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
        String fileVolID = (new StringBuilder(String.valueOf(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT)))).append(outputFileName.substring(outputFileName.length() - 3, outputFileName.length())).toString();
        
        String year = String.valueOf(c.get(Calendar.YEAR)).substring(2,4);
        String creationDate = (new StringBuilder(String.valueOf(StringFunctions.fixSize(year, 3, '0', StringFunctions.RIGHT)))).append(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT)).toString();
        int numOfLabelLines = 0;
        
        magCode = mag.getMagCode();
        LabelLine8 = PropertyBroker.getProperty("LabelLine8");
        
        if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
        {
            numOfLabelLines = 7;
        } else {
            numOfLabelLines = 5;
        }
        
        for(int x = 0; x < 24; x++) {
            if(x >= 0 && x <= numOfLabelLines) {
                lineLengths[x] = trimSize;
            } else if(messageFamilies.size() != 0 && familyNum < messageFamilies.size()) {
                mf = (MessageFamily)messageFamilies.elementAt(familyNum);
                for(int j = 0; j < mf.numLines; j++) {
                    lineLengths[x++] = mf.getLineLength(j);
                }

                x--;
                numMsgLines += mf.numLines;
                familyNum++;
            } else {
                lineLengths[x] = 0;
            }
        }

        for(int x = 0; x < 24; x++) {
            if(lineLengths[x] > 0) {
                numInkjetLines = x + 1;
            }
            recordLength += lineLengths[x];
        }

        recordLength += EIBSizeMIA;;
        blockLength = recordLength * 10;
        
        buf.append("VOL1");
        buf.append(fileVolID);
        buf.append(StringFunctions.fixSize(" ", 27, ' ', StringFunctions.LEFT));
        buf.append("Time, Inc. SBT");
        buf.append(StringFunctions.fixSize(" ", 28, ' ', StringFunctions.LEFT));
        buf.append("3");
        
        buf.append("HDR1");
        buf.append("SYBIL.SE163      ");
        buf.append(fileVolID);
        buf.append("000100010001");
        buf.append("00");
        
        buf.append(creationDate);
        
        c.add(Calendar.DAY_OF_YEAR,7);
        year = String.valueOf(c.get(Calendar.YEAR)).substring(2,4);
        buf.append(StringFunctions.fixSize(year, 3, '0', StringFunctions.RIGHT));
        
        dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
        buf.append(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT));
        buf.append(" ");
        buf.append("000000");
        buf.append("Time, Inc. SBT");
        buf.append(StringFunctions.fixSize(" ", 6, ' ', StringFunctions.LEFT));
        
        buf.append("HDR2");
        buf.append("F");
        buf.append(StringFunctions.fixSize(String.valueOf(blockLength), 5, '0', StringFunctions.RIGHT));
        buf.append(StringFunctions.fixSize(String.valueOf(recordLength), 5, '0', StringFunctions.RIGHT));
        buf.append(StringFunctions.fixSize(" ", 35, ' ', StringFunctions.LEFT));
        buf.append("00");
        buf.append(StringFunctions.fixSize(" ", 28, ' ', StringFunctions.LEFT));
        
        buf.append("UHL1");
        buf.append("01");
        buf.append(StringFunctions.fixSize(String.valueOf(numInkjetLines + 1), 3, '0', StringFunctions.RIGHT));
        buf.append("01");
        buf.append("008");
        buf.append("00");
        buf.append("000");
        buf.append("00");
        buf.append("0000");
        buf.append("000");
        buf.append("000000001");
        buf.append("000000000");
        buf.append("0001");
        buf.append(StringFunctions.fixSize(" ", 29, ' ', StringFunctions.LEFT));
        buf.append("J");
        
        buf.append("UHL2");
        buf.append("##");
        buf.append("###");
        buf.append("###");
        buf.append("##");
        buf.append("1");
        buf.append(StringFunctions.fixSize(" ", 65, ' ', StringFunctions.LEFT));
        
        return buf.toString();
    }

    private String createLineBlock() {
        
    	StringBuffer buf = new StringBuffer(blockLength);
        int recSize = 0;
        String PlantID = mag.getPlant();
        for(int x = 0; x < numInkjetLines; x++) {
            buf.append(StringFunctions.fixSize(String.valueOf(x + 1), 3, '0', StringFunctions.RIGHT));
            buf.append("0000000000");
            if(PlantID.equalsIgnoreCase("WAS") || PlantID.equalsIgnoreCase("WDK") || PlantID.equalsIgnoreCase("EGV")) {
                if(WDK8LLRecordLength) {
                    switch(x)
                    {
                    case 1: // '\001'
                        buf.append(StringFunctions.fixSize(String.valueOf(130), 3, '0', StringFunctions.RIGHT));
                        buf.append("000FR");
                        recSize += 21;
                        break;

                    case 9: // '\t'
                        buf.append(StringFunctions.fixSize(String.valueOf(24), 3, '0', StringFunctions.RIGHT));
                        buf.append("000FR");
                        recSize += 21;
                        break;

                    default:
                        buf.append(StringFunctions.fixSize(String.valueOf(lineLengths[x]), 3, '0', StringFunctions.RIGHT));
                        buf.append("000FR");
                        recSize += 21;
                        break;
                    }
                } else {
                    switch(x)
                    {
                    case 1: // '\001'
                        buf.append(StringFunctions.fixSize(String.valueOf(130), 3, '0', StringFunctions.RIGHT));
                        buf.append("000FR");
                        recSize += 21;
                        break;

                    case 8: // '\b'
                        buf.append(StringFunctions.fixSize(String.valueOf(24), 3, '0', StringFunctions.RIGHT));
                        buf.append("000FR");
                        recSize += 21;
                        break;

                    default:
                        buf.append(StringFunctions.fixSize(String.valueOf(lineLengths[x]), 3, '0', StringFunctions.RIGHT));
                        buf.append("000FR");
                        recSize += 21;
                        break;
                    }
                }
            } else {
                buf.append(StringFunctions.fixSize(String.valueOf(lineLengths[x]), 3, '0', StringFunctions.RIGHT));
                buf.append("000FR");
                recSize += 21;
            }
        }

        buf.append("9010000000000");
        
        if(PlantID.toUpperCase().equals("WAS")) {
            buf.append(StringFunctions.fixSize(String.valueOf(EIBSizeWAS), 3, '0', StringFunctions.RIGHT));
        }
        
        if(PlantID.toUpperCase().equals("WDK") || PlantID.equalsIgnoreCase("EGV")){
            buf.append(StringFunctions.fixSize(String.valueOf(EIBSizeWDK), 3, '0', StringFunctions.RIGHT));
        }
        
        if(PlantID.toUpperCase().equals("MIA")) {
            buf.append(StringFunctions.fixSize(String.valueOf(EIBSizeMIA), 3, '0', StringFunctions.RIGHT));
        }
        
        if(PlantID.toUpperCase().equals("DYB")) {
            buf.append(StringFunctions.fixSize(String.valueOf(EIBSizeDYB), 3, '0', StringFunctions.RIGHT));
        }
        
        buf.append("00000");
        
        for(int x = recSize += 21; x < blockLength; x++) {
            buf.append(" ");
        }

        return buf.toString();
    }

    private String createDYBLineBlock() {
        
    	StringBuffer buf = new StringBuffer(blockLength);
        int recSize = 0;
        buf.append("0010000000000065000FR");recSize += 21;
        for(int x = 2; x < numInkjetLines; x++) {
            buf.append(StringFunctions.fixSize(String.valueOf(x), 3, '0', StringFunctions.RIGHT));
            buf.append("0000000000");
            buf.append(StringFunctions.fixSize(String.valueOf(lineLengths[x]), 3, '0', StringFunctions.RIGHT));
            buf.append("000FR");
            recSize += 21;
        }

        buf.append("9010000000000");
        buf.append(StringFunctions.fixSize(String.valueOf(EIBSizeDYB), 3, '0', StringFunctions.RIGHT));
        buf.append("00000");
        
        for(int x = recSize += 21; x < blockLength; x++) {
            buf.append(" ");
        }

        return buf.toString();
    }

    public void createOutputFile(String prop, String outputFileName) {
        
    	this.outputFileName = outputFileName;
        outFileName = outputFileName;
        useShortFileName = PropertyBroker.getProperty("useShortFileName", "false");
        shortFileName = outputFileName.substring(0, outputFileName.lastIndexOf("/") + 1).concat(outputFileName.substring(outputFileName.lastIndexOf(".") + 1, outputFileName.length()));
        plant = mag.getPlant().toUpperCase();
        rec_count = 1;
        
        String FormatterFileConcatText = null;
        FormatterFileConcatText = PropertyBroker.getProperty("FormatterFileConcatText");
        String fileName = null;
        fileName = (new StringBuilder(String.valueOf(PropertyBroker.getProperty("OLDFILEDIR")))).append(mag.getFullPrefix()).append(".RLL5").toString();
        
        File f = new File(fileName);
        BufferedReader fileReader = null;
        
        if(f.exists()) {
            try {
                fileReader = new BufferedReader(new FileReader(fileName));
            } catch(FileNotFoundException fnfe) {
                LogWriter.writeLog(new Exception((new StringBuilder(String.valueOf(mag.getPrefix()))).append(": Error opening RLL5 file: File not found: ").append(fileName).toString()));
                return;
            }
            
            try {
                RLL5value = fileReader.readLine();
                LogWriter.writeLog((new StringBuilder("RLL5value = ")).append(RLL5value).toString());
            } catch(EOFException eofexception) { }
            catch(Exception re) {
                LogWriter.writeLog(re);
            }
        } else {
            RLL5value = "false";
        }
        
        if(FormatterFileConcatText == null) {
            FormatterFileConcatText = "";
        }
        if(useShortFileName.equals("true")) {
            formatShortFileName = true;
        }
        
        if(formatShortFileName) {
            shortOutputFileName = (new StringBuilder(String.valueOf(prop))).append(shortFileName).toString();
            tmpFile = new File((new StringBuilder(String.valueOf(prop))).append(outputFileName).append(FormatterFileConcatText).append(".tmp").toString());
        } else {
            longOutputFileName = (new StringBuilder(String.valueOf(prop))).append(mag.getLongFileName()).append(fileSep).append(shortFileName).toString();
            tmpFile = new File((new StringBuilder(String.valueOf(longOutputFileName))).append(FormatterFileConcatText).append(".tmp").toString());
        }
        
        try {
            outputFile = new OutputStreamWriter(new FileOutputStream(tmpFile), "ISO8859_1");
        } catch(IOException e) {
            LogWriter.writeLog(new SybilWarningException((new StringBuilder(String.valueOf(mag.getPrefix()))).append(": Error creating output file: ").append(e.getMessage()).toString()));
            return;
        }
        
        if(formatShortFileName) {
            shortOutputFileName = (new StringBuilder(String.valueOf(prop))).append(shortFileName).toString();
            newFile = new File((new StringBuilder(String.valueOf(shortOutputFileName))).append(FormatterFileConcatText).append(".DAT").toString());
        } else {
            longOutputFileName = (new StringBuilder(String.valueOf(prop))).append(mag.getLongFileName()).append(fileSep).append(shortFileName).toString();
            newFile = new File((new StringBuilder(String.valueOf(longOutputFileName))).append(FormatterFileConcatText).append(".DAT").toString());
        }
        
        
        if(newFile.exists()) {
            newFile.delete();
        }
        
        String header = createHeader();
        
        try {
            PrintWriter headerFile;
            if(formatShortFileName) {
                headerFile = new PrintWriter(new OutputStreamWriter(new FileOutputStream((new StringBuilder(String.valueOf(shortOutputFileName))).append(FormatterFileConcatText).append(".hdr").toString()), "ISO8859_1"));
            } else {
                headerFile = new PrintWriter(new OutputStreamWriter(new FileOutputStream((new StringBuilder(String.valueOf(longOutputFileName))).append(FormatterFileConcatText).append(".hdr").toString()), "ISO8859_1"));
            }
            headerFile.print(header);
            headerFile.flush();
            headerFile.close();
        }
        catch(IOException e) {
            LogWriter.writeLog((new StringBuilder(String.valueOf(mag.getPrefix()))).append(": Error creating output file: ").append(e.getMessage()).toString());
            return;
        }
        try {
			if (mag.getPlant().toUpperCase().equals("DYB")) {
				outputFile.write(createDYBLineBlock());
				outputFile.write(createDYBEIBBlock());
			} else {
				outputFile.write(createLineBlock());
				outputFile.write(createEIBBlock());
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
    }

    protected String formatData(IssueCustomer ic)
    {
        String PlantID = mag.getPlant();
        String data = null;
        if(PlantID.toUpperCase().equals("MIA")) {
            data = formatDataMIA(ic);
        }
        if(PlantID.toUpperCase().equals("WDK")) {
            data = formatDataWDK(ic);
        }
        if(PlantID.toUpperCase().equals("WAS")) {
            data = formatDataWAS(ic);
        }
        if(PlantID.toUpperCase().equals("EGV")) {
            data = formatDataWDK(ic);
        }
        if(PlantID.toUpperCase().equals("DYB")) {
            data = formatDataDYB(ic);
        }
        return data;
    }

    protected String formatDataMIA(IssueCustomer ic) {
        
    	StringBuffer buf = new StringBuffer(1024);
        String tmpbuf = null;
        
        LabelLine8 = PropertyBroker.getProperty("LabelLine8");
        LL8Override = PropertyBroker.getProperty("LL8Override");
        String oldLL8 = PropertyBroker.getProperty("oldLL8");
        nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
        magCode = mag.getMagCode();
        
        String PlantID = mag.getPlant();
        String labelLine = null;
        
        if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
        {
            for(int i = 1; i <= 8; i++) {
                labelLine = StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(i), 45, ' ', StringFunctions.LEFT);
                buf.append(labelLine);
            }

        } else {
            for(int i = 1; i <= 6; i++) {
                labelLine = StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(i), 45, ' ', StringFunctions.LEFT);
                buf.append(labelLine);
            }

        }
        
        buf.append("00");
        if(ic.getEndPackageIndicator()) {
            buf.append("*");
        } else {
            buf.append(" ");
        }
        
        if(ic.getEndPalletSackIndicator()) {
            buf.append("*");
        } else {
            buf.append(" ");
        }
        
        if(ic.getMagazineLabel().barcode.length() > 0) {
            String barcode = ic.getMagazineLabel().barcode;
            buf.append(StringFunctions.fixSize(barcode, 11, ' ', StringFunctions.LEFT));
        } else {
            buf.append("           ");
        }
        
        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().state, 2, ' ', StringFunctions.LEFT));
        buf.append(StringFunctions.fixSize(String.valueOf(rec_count++), 6, '0', StringFunctions.RIGHT));
        buf.append((new StringBuilder(String.valueOf(StringFunctions.fixSize(ic.getMakeupCode(), 4, '0', StringFunctions.RIGHT)))).append(" ").toString());
        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().palletSackNumber, 6, '0', StringFunctions.RIGHT));
        
        return buf.toString();
    }

    protected String formatDataWAS(IssueCustomer ic) {
        
    	StringBuffer buf = new StringBuffer(1024);
        LabelLine8 = PropertyBroker.getProperty("LabelLine8");
        LL8Override = PropertyBroker.getProperty("LL8Override");
        nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
        String oldLL8 = PropertyBroker.getProperty("oldLL8");
        
        magCode = mag.getMagCode();
        String labelLine = null;
        String BC = null;
        
        char left_bracket = '(';
        char right_bracket = ')';
        
        String barcodeValue = ic.getMagazineLabel().barcode.trim();
        String checkSumDigit = null;
        boolean test = true;
        try {
            test = Float.valueOf(barcodeValue).isNaN();
        } catch(Exception exception) { }
        
        if(!test) {
            if(barcodeValue.equals("")) {
                checkSumDigit = "";
            } else {
                long BCDigit = Long.parseLong(barcodeValue);
                long BCDSum = 0L;
                for(int i = 0; i < ic.getMagazineLabel().barcode.length(); i++) {
                    long digit = BCDigit % 10L;
                    long temp = BCDigit / 10L;
                    BCDigit = temp;
                    BCDSum += digit;
                }

                String CSDigit = Long.toString(BCDSum);
                int checkSumValue;
                if(CSDigit.length() < 2) {
                    int CSTemp = Integer.valueOf(CSDigit).intValue();
                    if(CSTemp == 0) {
                        checkSumValue = 0;
                    } else {
                        checkSumValue = 10 - CSTemp;
                    }
                } else {
                    CSDigit = CSDigit.substring(1, 2);
                    int CSTemp = Integer.valueOf(CSDigit.trim()).intValue();
                    if(CSTemp == 0) {
                        checkSumValue = 0;
                    } else {
                        checkSumValue = 10 - CSTemp;
                    }
                }
                checkSumDigit = Integer.toString(checkSumValue);
            }
        }
        
        if(ic.getMagazineLabel().barcode.length() > 0) {
            if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                BC = StringFunctions.fixSize((new StringBuilder(String.valueOf(left_bracket))).append(ic.getMagazineLabel().barcode).append(checkSumDigit).append(right_bracket).toString(), 24, ' ', StringFunctions.LEFT);
            }
            if(ic.getMagazineLabel().labelJustification == StringFunctions.RIGHT) {
                int barCodeLength = ic.getMagazineLabel().barcode.trim().length();
                if(barCodeLength < 9) {
                    String padding = "            ";
                    BC = StringFunctions.fixSize((new StringBuilder(String.valueOf(padding))).append(left_bracket).append(ic.getMagazineLabel().barcode).append(checkSumDigit).append(right_bracket).toString(), 24, ' ', StringFunctions.LEFT);
                } else {
                    BC = StringFunctions.fixSize((new StringBuilder(String.valueOf(left_bracket))).append(ic.getMagazineLabel().barcode).append(checkSumDigit).append(right_bracket).toString(), 24, ' ', StringFunctions.RIGHT);
                }
            }
        } else {
            BC = StringFunctions.fixSize(" ", 24, ' ', StringFunctions.LEFT);
        }
        
        if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
        {
            if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
            	
            	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
            		buf.append(StringFunctions.fixSize(profileBarData.toUpperCase(), trimSize, ' ', StringFunctions.LEFT));
                    buf.append(StringFunctions.fixSize(profileBar.toUpperCase(), 130, ' ', StringFunctions.LEFT));
            	} else {
            		buf.append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcodeData.toUpperCase(), trimSize, ' ', StringFunctions.LEFT));
                    buf.append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), 130, ' ', StringFunctions.LEFT));
            	}
                
                buf.append(ic.getMagazineLabel().getTextLine(2).substring(0, trimSize));
                buf.append(ic.getMagazineLabel().getTextLine(3).substring(0, trimSize));
                buf.append(ic.getMagazineLabel().getTextLine(4).substring(0, trimSize));
                buf.append(ic.getMagazineLabel().getTextLine(5).substring(0, trimSize));
                buf.append(ic.getMagazineLabel().getTextLine(6).substring(0, trimSize));
                buf.append(ic.getMagazineLabel().getTextLine(7).substring(0, trimSize));
                buf.append(ic.getMagazineLabel().getTextLine(8).substring(0, trimSize));
                buf.append(BC);
            } else {
            	
            	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
            		buf.append(StringFunctions.fixSize(profileBarData.toUpperCase(), trimSize, ' ', StringFunctions.RIGHT));
                    buf.append(StringFunctions.fixSize(profileBar.toUpperCase(), 130, ' ', StringFunctions.RIGHT));
            	} else {
            		buf.append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcodeData.toUpperCase(), trimSize, ' ', StringFunctions.RIGHT));
                    buf.append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), 130, ' ', StringFunctions.RIGHT));
            	}
                
                buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2), trimSize, ' ', StringFunctions.RIGHT));
                buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3), trimSize, ' ', StringFunctions.RIGHT));
                buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4), trimSize, ' ', StringFunctions.RIGHT));
                buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5), trimSize, ' ', StringFunctions.RIGHT));
                buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6), trimSize, ' ', StringFunctions.RIGHT));
                buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(7), trimSize, ' ', StringFunctions.RIGHT));
                buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(8), trimSize, ' ', StringFunctions.RIGHT));
                buf.append(BC);
            }
        } else {
        	if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
        		if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
        			buf.append(StringFunctions.fixSize(profileBarData.toUpperCase(), 100, ' ', StringFunctions.LEFT));
                    buf.append(StringFunctions.fixSize(profileBar.toUpperCase(), 130, ' ', StringFunctions.LEFT));
        		} else {
        			buf.append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcodeData.toUpperCase(), 100, ' ', StringFunctions.LEFT));
                    buf.append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), 130, ' ', StringFunctions.LEFT));
        		}
            } else {
            	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
            		buf.append(StringFunctions.fixSize(profileBarData, trimSize, ' ', StringFunctions.RIGHT));
                    buf.append(StringFunctions.fixSize(profileBar.toUpperCase(), 130, ' ', StringFunctions.RIGHT));
            	} else {
            		buf.append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcodeData, trimSize, ' ', StringFunctions.RIGHT));
                    buf.append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), 130, ' ', StringFunctions.RIGHT));
            	}
            }
            
            for(int i = 1; i <= 6; i++) {
                if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                    labelLine = ic.getMagazineLabel().getTextLine(i).substring(0, trimSize);
                } else {
                    labelLine = StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(i), trimSize, ' ', StringFunctions.RIGHT);
                }
                buf.append(labelLine);
            }

            buf.append(BC);
        }
        
        int numberOfMessages = ic.getNumberOfMessages();
        Vector allMessages = ic.getMessages();
        int numberOfMsgTextLines;
    	Vector m_TextLines;
        Message m = null;
        String msgfamilyNumber = null;
        MessageParameter msgp = null;
        MessageFamily mf = null;
        
        int i = 0;
        for(int j = 0; j < messageFamilies.size(); j++) {
            mf = (MessageFamily)messageFamilies.elementAt(j);
            if(numberOfMessages == 0) {
                buf.append(StringFunctions.fixSize(" ", mf.size, ' ', StringFunctions.LEFT));
            } else if(i >= numberOfMessages) {
                numberOfMessages = 0;
                j--;
            } else {
                m = (Message)allMessages.elementAt(i);
                msgfamilyNumber = (new StringBuilder(String.valueOf(m.getMessageFamily()))).append(m.getMessageNumber()).toString();
                msgp = (MessageParameter)msgparms.get(msgfamilyNumber);
                if(!msgp.isCoverMessage()) {
                    if(m.getMessageFamily().equals(mf.familyNumber)) {
                        numberOfMsgTextLines = m.getNumberOfTextLines();
                        m_TextLines = m.getTextLines();
                        int k = 0;
                        for(k = 0; k < numberOfMsgTextLines; k++) {
                            TextLine tl = (TextLine)m_TextLines.elementAt(k);
                            buf.append(tl.toString());
                        }

                        for(int pad = k; pad < mf.numLines; pad++) {
                            TextLine tl = new TextLine(msgp.getLineLength(pad), StringFunctions.USE_DEFAULT, pad, " ");
                            tl.justify();
                            buf.append(tl.toString());
                        }

                        i++;
                    } else {
                        buf.append(StringFunctions.fixSize(" ", mf.size, ' ', StringFunctions.LEFT));
                    }
                } else {
                    j--;
                    i++;
                }
            }
        }

        buf.append("00");
        if(ic.getEndPackageIndicator()) {
            buf.append("*");
        } else {
            buf.append(" ");
        }
        
        if(ic.getEndPalletSackIndicator()) {
            buf.append("*");
        } else {
            buf.append(" ");
        }
        
        if(ic.getMagazineLabel().barcode.length() > 0) {
            String barcode = ic.getMagazineLabel().barcode;
            buf.append(StringFunctions.fixSize(barcode, 11, ' ', StringFunctions.LEFT));
        } else {
            buf.append("           ");
        }
        
        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().state, 2, ' ', StringFunctions.LEFT));
        buf.append(StringFunctions.fixSize(String.valueOf(rec_count++), 6, '0', StringFunctions.RIGHT));
        buf.append((new StringBuilder(String.valueOf(StringFunctions.fixSize(ic.getMakeupCode(), 4, '0', StringFunctions.RIGHT)))).append(" ").toString());
        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().palletSackNumber, 6, '0', StringFunctions.RIGHT));
        buf.append(StringFunctions.fixSize(ic.getrollID(), 4, '0', StringFunctions.RIGHT));
        
        return buf.toString();
    }

    protected String formatDataWDK(IssueCustomer ic) {
        
    	StringBuffer buf = new StringBuffer(1024);
        LabelLine8 = PropertyBroker.getProperty("LabelLine8");
        LL8Override = PropertyBroker.getProperty("LL8Override");
        nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
        String oldLL8 = PropertyBroker.getProperty("oldLL8");
        
        String BC = null;
        magCode = mag.getMagCode();
        char left_bracket = '(';
        char right_bracket = ')';
        String labelLine = null;
        String barcodeValue = ic.getMagazineLabel().barcode.trim();
        String checkSumDigit = null;
        boolean test = true;
        
        try {
            test = Float.valueOf(barcodeValue).isNaN();
        } catch(Exception exception) { }
        
        if(!test) {
            if(barcodeValue.equals("")) {
                checkSumDigit = "";
            } else {
                long BCDigit = Long.parseLong(barcodeValue);
                long BCDSum = 0L;
                for(int i = 0; i < ic.getMagazineLabel().barcode.length(); i++) {
                    long digit = BCDigit % 10L;
                    long temp = BCDigit / 10L;
                    BCDigit = temp;
                    BCDSum += digit;
                }

                String CSDigit = Long.toString(BCDSum);
                int checkSumValue;
                if(CSDigit.length() < 2) {
                    int CSTemp = Integer.valueOf(CSDigit).intValue();
                    if(CSTemp == 0) {
                        checkSumValue = 0;
                    } else {
                        checkSumValue = 10 - CSTemp;
                    }
                } else {
                    CSDigit = CSDigit.substring(1, 2);
                    int CSTemp = Integer.valueOf(CSDigit.trim()).intValue();
                    if(CSTemp == 0) {
                        checkSumValue = 0;
                    } else {
                        checkSumValue = 10 - CSTemp;
                    }
                }
                checkSumDigit = Integer.toString(checkSumValue);
            }
        }
        
        if(ic.getMagazineLabel().barcode.length() > 0) {
            if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                BC = StringFunctions.fixSize((new StringBuilder(String.valueOf(left_bracket))).append(ic.getMagazineLabel().barcode).append(checkSumDigit).append(right_bracket).toString(), 24, ' ', StringFunctions.LEFT);
            }
            if(ic.getMagazineLabel().labelJustification == StringFunctions.RIGHT) {
                int barCodeLength = ic.getMagazineLabel().barcode.trim().length();
                if(barCodeLength < 9) {
                    String padding = "            ";
                    BC = StringFunctions.fixSize((new StringBuilder(String.valueOf(padding))).append(left_bracket).append(ic.getMagazineLabel().barcode).append(checkSumDigit).append(right_bracket).toString(), 24, ' ', StringFunctions.LEFT);
                } else {
                    BC = StringFunctions.fixSize((new StringBuilder(String.valueOf(left_bracket))).append(ic.getMagazineLabel().barcode).append(checkSumDigit).append(right_bracket).toString(), 24, ' ', StringFunctions.RIGHT);
                }
            }
        } else {
            BC = StringFunctions.fixSize(" ", 24, ' ', StringFunctions.LEFT);
        }
        
        if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
        {
            if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
            	
            	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
            		buf.append(StringFunctions.fixSize(profileBarData.toUpperCase(), 100, ' ', StringFunctions.LEFT));
                    buf.append(StringFunctions.fixSize(profileBar.toUpperCase(), 130, ' ', StringFunctions.LEFT));
            	} else {
            		buf.append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcodeData.toUpperCase(), 100, ' ', StringFunctions.LEFT));
                    buf.append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), 130, ' ', StringFunctions.LEFT));
            	}
                
                buf.append(ic.getMagazineLabel().getTextLine(2).substring(0, trimSize));
                buf.append(ic.getMagazineLabel().getTextLine(3).substring(0, trimSize));
                buf.append(ic.getMagazineLabel().getTextLine(4).substring(0, trimSize));
                buf.append(ic.getMagazineLabel().getTextLine(5).substring(0, trimSize));
                buf.append(ic.getMagazineLabel().getTextLine(6).substring(0, trimSize));
                buf.append(ic.getMagazineLabel().getTextLine(7).substring(0, trimSize));
                buf.append(ic.getMagazineLabel().getTextLine(8).substring(0, trimSize));
                buf.append(BC);
            } else {
            	
            	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
            		buf.append(StringFunctions.fixSize(profileBarData.toUpperCase(), 100, ' ', StringFunctions.RIGHT));
                    buf.append(StringFunctions.fixSize(profileBar.toUpperCase(), 130, ' ', StringFunctions.RIGHT));
            	} else {
            		buf.append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcodeData.toUpperCase(), 100, ' ', StringFunctions.RIGHT));
                    buf.append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), 130, ' ', StringFunctions.RIGHT));
            	}
                
                buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2), trimSize, ' ', StringFunctions.RIGHT));
                buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3), trimSize, ' ', StringFunctions.RIGHT));
                buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4), trimSize, ' ', StringFunctions.RIGHT));
                buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5), trimSize, ' ', StringFunctions.RIGHT));
                buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6), trimSize, ' ', StringFunctions.RIGHT));
                buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(7), trimSize, ' ', StringFunctions.RIGHT));
                buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(8), trimSize, ' ', StringFunctions.RIGHT));
                buf.append(BC);
            }
        } else {
            if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
            	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
            		buf.append(StringFunctions.fixSize(profileBarData.toUpperCase(), 100, ' ', StringFunctions.LEFT));
                    buf.append(StringFunctions.fixSize(profileBar.toUpperCase(), 130, ' ', StringFunctions.LEFT));
            	} else {
            		buf.append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcodeData.toUpperCase(), 100, ' ', StringFunctions.LEFT));
                    buf.append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), 130, ' ', StringFunctions.LEFT));
            	}
            } else {
            	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
            		buf.append(StringFunctions.fixSize(profileBarData, trimSize, ' ', StringFunctions.RIGHT));
                    buf.append(StringFunctions.fixSize(profileBar.toUpperCase(), 130, ' ', StringFunctions.RIGHT));
            	} else {
            		buf.append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcodeData, trimSize, ' ', StringFunctions.RIGHT));
                    buf.append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), 130, ' ', StringFunctions.RIGHT));
            	}
            }
            
            for(int i = 1; i <= 6; i++) {
                if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                    labelLine = ic.getMagazineLabel().getTextLine(i).substring(0, trimSize);
                } else {
                    labelLine = StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(i), trimSize, ' ', StringFunctions.RIGHT);
                }
                buf.append(labelLine);
            }

            buf.append(BC);
        }
        
        int numberOfMessages = ic.getNumberOfMessages();
        Vector allMessages = ic.getMessages();
        
        int numberOfMsgTextLines;
    	Vector m_TextLines;
    	
        Message m = null;
        String msgfamilyNumber = null;
        MessageParameter msgp = null;
        MessageFamily mf = null;
        int i = 0;
        
        for(int j = 0; j < messageFamilies.size(); j++) {
            mf = (MessageFamily)messageFamilies.elementAt(j);
            if(numberOfMessages == 0) {
                buf.append(StringFunctions.fixSize(" ", mf.size, ' ', StringFunctions.LEFT));
            } else if(i >= numberOfMessages) {
                numberOfMessages = 0;
                j--;
            } else {
                m = (Message)allMessages.elementAt(i);
                msgfamilyNumber = (new StringBuilder(String.valueOf(m.getMessageFamily()))).append(m.getMessageNumber()).toString();
                msgp = (MessageParameter)msgparms.get(msgfamilyNumber);
                if(!msgp.isCoverMessage()) {
                    if(m.getMessageFamily().equals(mf.familyNumber)) {
                        numberOfMsgTextLines = m.getNumberOfTextLines();
                        m_TextLines = m.getTextLines();
                        int k = 0;
                        for(k = 0; k < numberOfMsgTextLines; k++) {
                            TextLine tl = (TextLine)m_TextLines.elementAt(k);
                            buf.append(tl.toString());
                        }

                        for(int pad = k; pad < mf.numLines; pad++) {
                            TextLine tl = new TextLine(msgp.getLineLength(pad), StringFunctions.USE_DEFAULT, pad, " ");
                            tl.justify();
                            buf.append(tl.toString());
                        }

                        i++;
                    } else {
                        buf.append(StringFunctions.fixSize(" ", mf.size, ' ', StringFunctions.LEFT));
                    }
                } else {
                    j--;
                    i++;
                }
            }
        }

        buf.append("00");
        
        if(ic.getEndPackageIndicator()) {
            buf.append("*");
        } else {
            buf.append(" ");
        }
        
        if(ic.getEndPalletSackIndicator()) {
            buf.append("*");
        } else {
            buf.append(" ");
        }
        
        if(ic.getMagazineLabel().barcode.length() > 0) {
            String barcode = ic.getMagazineLabel().barcode;
            buf.append(StringFunctions.fixSize(barcode, 11, ' ', StringFunctions.LEFT));
        } else {
            buf.append("           ");
        }
        
        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().state, 2, ' ', StringFunctions.LEFT));
        buf.append(StringFunctions.fixSize(String.valueOf(rec_count++), 6, '0', StringFunctions.RIGHT));
        buf.append((new StringBuilder(String.valueOf(StringFunctions.fixSize(ic.getMakeupCode(), 4, '0', StringFunctions.RIGHT)))).append(" ").toString());
        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().palletSackNumber, 6, '0', StringFunctions.RIGHT));
        buf.append(StringFunctions.fixSize(ic.getrollID(), 4, '0', StringFunctions.RIGHT));
        
        return buf.toString();
    }

    protected String formatDataDYB(IssueCustomer ic) {
        
    	StringBuffer buf = new StringBuffer(1024);
        magCode = mag.getMagCode();
        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), 65, ' ', StringFunctions.LEFT));
        if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
            buf.append(ic.getMagazineLabel().getTextLine(2).substring(0, trimSize));
            buf.append(ic.getMagazineLabel().getTextLine(3).substring(0, trimSize));
            buf.append(ic.getMagazineLabel().getTextLine(4).substring(0, trimSize));
            buf.append(ic.getMagazineLabel().getTextLine(5).substring(0, trimSize));
            buf.append(ic.getMagazineLabel().getTextLine(6).substring(0, trimSize));
            buf.append(ic.getMagazineLabel().getTextLine(7).substring(0, trimSize));
            buf.append(ic.getMagazineLabel().getTextLine(8).substring(0, trimSize));
        } else {
            buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2), trimSize, ' ', StringFunctions.RIGHT));
            buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3), trimSize, ' ', StringFunctions.RIGHT));
            buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4), trimSize, ' ', StringFunctions.RIGHT));
            buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5), trimSize, ' ', StringFunctions.RIGHT));
            buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6), trimSize, ' ', StringFunctions.RIGHT));
            buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(7), trimSize, ' ', StringFunctions.RIGHT));
            buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(8), trimSize, ' ', StringFunctions.RIGHT));
        }
        
        int numberOfMessages = ic.getNumberOfMessages();
        Vector allMessages = ic.getMessages();
        
        int numberOfMsgTextLines;
    	Vector m_TextLines;
    	
        Message m = null;
        String msgfamilyNumber = null;
        MessageParameter msgp = null;
        MessageFamily mf = null;
        int i = 0;
        
        for(int j = 0; j < messageFamilies.size(); j++) {
            mf = (MessageFamily)messageFamilies.elementAt(j);
            if(numberOfMessages == 0) {
                buf.append(StringFunctions.fixSize(" ", mf.size, ' ', StringFunctions.LEFT));
            } else if(i >= numberOfMessages) {
                numberOfMessages = 0;
                j--;
            } else {
                m = (Message)allMessages.elementAt(i);
                msgfamilyNumber = (new StringBuilder(String.valueOf(m.getMessageFamily()))).append(m.getMessageNumber()).toString();
                msgp = (MessageParameter)msgparms.get(msgfamilyNumber);
                if(!msgp.isCoverMessage()) {
                    if(m.getMessageFamily().equals(mf.familyNumber)) {
                        numberOfMsgTextLines = m.getNumberOfTextLines();
                        m_TextLines = m.getTextLines();
                        int k = 0;
                        for(k = 0; k < numberOfMsgTextLines; k++) {
                            TextLine tl = (TextLine)m_TextLines.elementAt(k);
                            buf.append(tl.toString());
                        }

                        for(int pad = k; pad < mf.numLines; pad++) {
                            TextLine tl = new TextLine(msgp.getLineLength(pad), StringFunctions.USE_DEFAULT, pad, " ");
                            tl.justify();
                            buf.append(tl.toString());
                        }

                        i++;
                    } else {
                        buf.append(StringFunctions.fixSize(" ", mf.size, ' ', StringFunctions.LEFT));
                    }
                } else {
                    j--;
                    i++;
                }
            }
        }

        buf.append("00");
        
        if(ic.getEndPackageIndicator()) {
            buf.append("*");
        } else {
            buf.append(" ");
        }
        
        if(ic.getEndPalletSackIndicator()) {
            buf.append("*");
        } else {
            buf.append(" ");
        }
        
        if(ic.getMagazineLabel().barcode.length() > 0) {
            String barcode = ic.getMagazineLabel().barcode;
            buf.append(StringFunctions.fixSize(barcode, 11, ' ', StringFunctions.LEFT));
        } else {
            buf.append("           ");
        }
        
        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().state, 2, ' ', StringFunctions.LEFT));
        buf.append(StringFunctions.fixSize(String.valueOf(rec_count++), 6, '0', StringFunctions.RIGHT));
        buf.append(StringFunctions.fixSize(ic.getMakeupCode(), 4, '0', StringFunctions.RIGHT));
        
        return buf.toString();
    }
}
