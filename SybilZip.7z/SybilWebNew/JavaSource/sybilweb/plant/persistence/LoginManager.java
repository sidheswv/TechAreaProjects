package sybilweb.plant.persistence;


import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.sql.*;
import java.util.*;
import java.text.*;
import com.ibm.ejs.dbm.jdbcext.*;
import javax.naming.*;
import com.ibm.os390.security.*;
import java.net.URLEncoder;
import sun.misc.*;
import sybilweb.plant.controller.*;


public class LoginManager {

  private Hashtable currentLogins;

  	Connection conn=null;
	String dbqual = null;
	private static DataSource ds = null;
	public String errDescription = "Dummy";
	public int errCode =1;
	

  private static final String SELECT_PASSWORD =
	"SELECT password FROM idpassword WHERE userid = ";

  private static final String QUOTE = "'";

  private class LoginProfile extends UserCredentials {
	boolean isLoggedIn = false;

	public LoginProfile(UserCredentials credentials) {
	  setWebID( credentials.getWebID());	
	  setPassword( credentials.getPassword());
	  isLoggedIn = false;
	}
  }


  public LoginManager() {
	  	super();

	
	if ((this.dbqual = sybilweb.plant.controller.PropertyBroker.getProperty("DB2OWNER")) == null) {

	this.dbqual = "DTTPSYUP";
	
	}
	
	try {
		if(System.getProperty("os.name").equalsIgnoreCase("OS/390") || System.getProperty("os.name").equalsIgnoreCase("z/OS")){
			Hashtable parms = new Hashtable();
			parms.put(Context.INITIAL_CONTEXT_FACTORY,"com.ibm.ejs.ns.jndi.CNInitialContextFactory");
			Context ctx = new InitialContext(parms);
			ds = (DataSource)ctx.lookup("jdbc/sybil");
		}else if(System.getProperty("os.name").equalsIgnoreCase("Windows XP")){
			System.out.println("loading Windows drivers");
			javax.naming.InitialContext ctx = new javax.naming.InitialContext();
			ds = (javax.sql.DataSource)ctx.lookup("jdbc/sybil");
	   }else {
			System.out.println("loading wrong drivers");
			Class.forName("COM.ibm.db2.jdbc.app.DB2Driver");
			conn = DriverManager.getConnection("jdbc:db2os390:DTTPSYUP"," "," ");
		}
		
	}catch(ClassNotFoundException e) {
		LogWriter.writeLog("UserDB():Couldn't load the driver : "+e.getMessage());
		e.printStackTrace();
	}
	catch(SQLException e) {
		LogWriter.writeLog("UserDB():SQLException  : Connection "+e.getMessage());
		e.printStackTrace();
	}
	catch(Exception e) {
		LogWriter.writeLog("UserDB():SQLException  : Connection "+e.getMessage());
		e.printStackTrace();
	}
	  }
  public LoginManager(String db,String qual) {
	  	super();

	this.dbqual = qual;
	try {
		
		if(System.getProperty("os.name").equalsIgnoreCase("OS/390") || System.getProperty("os.name").equalsIgnoreCase("z/OS")){
			Hashtable parms = new Hashtable();
			parms.put(Context.INITIAL_CONTEXT_FACTORY,"com.ibm.ejs.ns.jndi.CNInitialContextFactory");
		 	Context ctx = new InitialContext(parms);
			ds = (DataSource)ctx.lookup("sybil");
	  	}else if(System.getProperty("os.name").equalsIgnoreCase("Windows XP")){
			System.out.println("loading Windows drivers");
			Hashtable parms = new Hashtable();
			parms.put(Context.INITIAL_CONTEXT_FACTORY,"com.ibm.ejs.ns.jndi.CNInitialContextFactory");
			Context ctx = new InitialContext(parms);
			ds = (DataSource)ctx.lookup("sybil");
	   }else {
	   		System.out.println("loading wrong drivers");
			Class.forName("COM.ibm.db2.jdbc.app.DB2Driver");
			conn = DriverManager.getConnection("jdbc:db2os390:DTTPSYUP"," "," ");
		}

	}catch(ClassNotFoundException e) {
		LogWriter.writeLog("UserDB():Couldn't load the driver : "+e.getMessage());
		e.printStackTrace();
	}
	catch(SQLException e) {
		LogWriter.writeLog("UserDB():SQLException  : Connection "+e.getMessage());
		e.printStackTrace();
	}
	catch(Exception e) {
		LogWriter.writeLog("UserDB():SQLException  : Connection "+e.getMessage());
		e.printStackTrace();
	}
	  }
  public boolean alreadyLoggedIn(UserCredentials credentials) {
	boolean loggedIn = false;
	String user = credentials.getUser();
	if (currentLogins.containsKey(user)) {
	  LoginProfile aProfile =
		(LoginProfile)currentLogins.get(user);
	  loggedIn = aProfile.isLoggedIn;
	}
	return loggedIn;
  }
public int geterrCode() {
	return errCode;
}
/**
 * Insert the method's description here.
 * Creation date: (11/2/01 9:55:10 AM)
 * @return java.lang.String
 */
public String geterrDescription() {
	return errDescription;
}
public String getRacfID( String name) throws Exception{

	String webID=null;
	String racfID=null;
	String queryString=null;
	ResultSet rs = null;
	Statement stmt = null;

	try {
		if(name!=null) {
		webID = name.toUpperCase().trim();

		if( ds != null) 
		conn = ds.getConnection();

		dbqual = dbqual.trim();
		webID = webID.trim();

		queryString = "select RACF_ID from "+dbqual+".TBA_WEBID_RACFID where WEB_ID='" + webID + "'";
		stmt = conn.createStatement();
		rs = stmt.executeQuery(queryString);

		while(rs.next()) {
				racfID = rs.getString("RACF_ID").trim();
			}
			stmt.close();
			if(racfID==null) racfID = "null";
		}
	} catch (SQLException e) {
		LogWriter.writeLog("SQLException: " + queryString);
		LogWriter.writeLog(" SQLException : Magazine Name Mapping " +e.getMessage());
		 return null;
	} catch (Exception e) {
		e.printStackTrace();
	}
	finally {
		 if(conn != null)
		 {
			   conn.close();
		 }
	 }

	return racfID;
}
/**
 * Insert the method's description here.
 * Creation date: (8/21/01 7:10:24 AM)
 * @return boolean
 */
public boolean getReadonly(String webID, String plantid) throws Exception{

	boolean isReadOnly = true;
	String temp = null;
	String queryString=null;
	ResultSet rs = null;
	Statement stmt = null;

	try {
		if(webID!=null) {
		webID = webID.toUpperCase().trim();

		if( ds != null) 
		conn = ds.getConnection();
		queryString = "select IS_READ_ONLY from "+dbqual+".TBA_WEBID_PLANTID where WEB_ID='" + webID + "' and PLANT_ID='"+ plantid +"'";
		stmt = conn.createStatement();
		rs = stmt.executeQuery(queryString);
		
		while(rs.next()) {
				temp = rs.getString("IS_READ_ONLY").trim();
			}

			stmt.close();
			if(temp.equalsIgnoreCase("N")) isReadOnly = false;
			else 
				if(temp.equalsIgnoreCase("Y")) isReadOnly = true;
	}
	} catch (SQLException e) {
		LogWriter.writeLog("SQLException: " + queryString);
		LogWriter.writeLog(" SQLException : Magazine Name Mapping " +e.getMessage());
		 return false;
	} catch (Exception e) {
		e.printStackTrace();
	}
	finally {
		 if(conn != null)
		 {
			   conn.close();
 		}
	 }

	return isReadOnly;
}
  /**
 * Insert the method's description here.
 * Creation date: (8/21/01 7:10:24 AM)
 * @return boolean
 */
public String getReadOnlyStatus(String webID, String plantid) throws Exception{

	String ReadOnlyStatus = "UNDEFINED";
	String IS_READ_ONLY = "U";
	String queryString=null;
	ResultSet rs = null;
	Statement stmt = null;
	String readOnlyStatusQuery = null;
	String USER_LEVEL = null;

	try {
		if(webID!=null) {
		webID = webID.trim().toUpperCase().trim();

		if( ds != null) 
		conn = ds.getConnection();
		queryString = "select IS_READ_ONLY from "+dbqual+".TBA_WEBID_PLANTID where WEB_ID='" + webID + "' and PLANT_ID='"+ plantid +"'";
		readOnlyStatusQuery = "select USER_LEVEL from "+dbqual+".TBA_WEBID_RACFID where WEB_ID='" + webID +"'";
		
		stmt = conn.createStatement();
		rs = stmt.executeQuery(readOnlyStatusQuery);

		while(rs.next()){
			USER_LEVEL = rs.getString("USER_LEVEL").trim();
		}

		
			if(USER_LEVEL.trim().equalsIgnoreCase("A")){
				IS_READ_ONLY = "N";
			}	

			if(USER_LEVEL.trim().equalsIgnoreCase("R")){
				IS_READ_ONLY = "Y";			
			}	

			if(USER_LEVEL.trim().equalsIgnoreCase("P")){
				rs = stmt.executeQuery(queryString);
				while(rs.next()) {
					IS_READ_ONLY = rs.getString("IS_READ_ONLY").trim();
				}
			}	
			
	
			rs.close();
			stmt.close();

			

			if(IS_READ_ONLY.equalsIgnoreCase("N")) ReadOnlyStatus = "FULLACCESS";
			else 
				if(IS_READ_ONLY.equalsIgnoreCase("Y")) ReadOnlyStatus = "READONLY";
	}
	
	} catch (Exception e) {
		e.printStackTrace();
   		return ReadOnlyStatus;
	}
	finally {
		 if(conn != null)
		 {
		   conn.close();
 	    	return ReadOnlyStatus;
 		}
	 }

	return ReadOnlyStatus;
}
  public String getUserAccessCd( String name) throws Exception{

	String webID=null;
	String racfID=null;
	String queryString=null;
	String userAccessCd = null;
	ResultSet rs = null;
	Statement stmt = null;

	try {
		if(name!=null) {
		webID = name.toUpperCase().trim();

		if( ds != null) 
		conn = ds.getConnection();

		dbqual = dbqual.trim();
		webID = webID.trim();

		queryString = "select USER_ACCESS_CD from "+dbqual+".TBA_WEBID_RACFID where WEB_ID='" + webID + "'";
		stmt = conn.createStatement();
		rs = stmt.executeQuery(queryString);

		while(rs.next()) {
				userAccessCd = rs.getString("USER_ACCESS_CD").trim();
			}
			stmt.close();
			if(userAccessCd==null) userAccessCd = "null";
		}
	} catch (SQLException e) {
		LogWriter.writeLog("SQLException: " + queryString);
		LogWriter.writeLog(" SQLException : Magazine Name Mapping " +e.getMessage());
		 return null;
	} catch (Exception e) {
		e.printStackTrace();
	}
	finally {
		 if(conn != null)
		 {
			   conn.close();
		 }
	 }

	return userAccessCd;
}
  public String getUserName( String name) throws Exception{

	String webID=null;
	String userName=null;
	String queryString=null;
	ResultSet rs = null;
	Statement stmt = null;

	try {
		if(name!=null) {
		webID = name.toUpperCase().trim();

		if( ds != null) 
		conn = ds.getConnection();

		dbqual = dbqual.trim();
		webID = webID.trim();

		queryString = "select USER_NAME from "+dbqual+".TBA_WEBID_RACFID where WEB_ID='" + webID + "'";
		stmt = conn.createStatement();
		rs = stmt.executeQuery(queryString);

		while(rs.next()) {
				userName = rs.getString("USER_NAME").trim();
			}
			stmt.close();
			if(userName==null) userName = "null";
		}
	} catch (SQLException e) {
		LogWriter.writeLog("SQLException: " + queryString);
		LogWriter.writeLog(" SQLException : Magazine Name Mapping " +e.getMessage());
		 return null;
	} catch (Exception e) {
		e.printStackTrace();
	}
	finally {
		 if(conn != null)
		 {
			   conn.close();
		 }
	 }

	return userName;
}
  public boolean login(UserCredentials credentials)
	  throws Exception {

	String racfID = null;
	String readonlyuser = null;

	LoginProfile profile = new LoginProfile(credentials);
	System.out.println(" os name "+ System.getProperty("os.name"));
	
	if (System.getProperty("os.name").equalsIgnoreCase("OS/390") || System.getProperty("os.name").equalsIgnoreCase("z/OS")) {
			racfID = getRacfID(credentials.getWebID());
		}else if(System.getProperty("os.name").equalsIgnoreCase("Windows XP")){
			racfID = getRacfID(credentials.getWebID());
		}


		if (!racfID.trim().equals("null")) {
			PlatformReturned pr = null;
			
			if(System.getProperty("os.name").equalsIgnoreCase("OS/390")|| System.getProperty("os.name").equalsIgnoreCase("z/OS")){
				pr = PlatformUser.authenticate(racfID, credentials.getPassword());
				}else if(System.getProperty("os.name").equalsIgnoreCase("Windows XP")){
				pr = null;
			}
			
			if(System.getProperty("os.name").equalsIgnoreCase("Windows XP")){
				System.out.println("Sucessful login in windows xp");
			}
				

			if(pr == null) { 
				errDescription = "Sucessful Login";
				errCode = 0;
				return true;
			}	

				if (pr.errno == 168){ 
					errDescription = "Password has expired. Select a New Password";
					errCode = 168;
					return false;
				}


				if (pr.errno == 163){
					errCode = 163;					
					errDescription = "Userid has been revoked. Please contact the helpdesk";					
					return false;
				}

				if (pr.errno == 143){
					errCode = 143;					
					errDescription = "Invalid Userid ";
					errDescription = errDescription.concat(credentials.getWebID());
					errDescription = errDescription.concat(". Please check and reenter");					
					return false;
				}

				if (pr.errno == 111){
					errCode = 111;					
					errDescription = "Invalid password. Please check and reenter.";					
					return false;
				}
				
				if (pr.errno == 169){
					errCode = 169;					
					errDescription = "Invalid new password. The new password must be 8 characters and must include at least two numbers.";
					System.out.println("Invaid new password"+errDescription);
					return false;
				}

				else {
				 errCode = pr.errno;
				 errDescription = "Unknown Error"+errCode;
				 return false;
				}
				
		}
	

		else if(racfID.trim().equals("null")) {
					errCode = 1;			
					errDescription = credentials.getWebID();
					errDescription = errDescription.concat(" is an invalid SybilWeb Id. Please check and reenter.");					

		}
			

	return profile.isLoggedIn;
  }  
}
