package sybilweb.plant.persistence;

import java.io.*;
import java.util.*;
import sybilweb.plant.controller.*;


public class SE125USPersistenceIssueCustomer extends PersistenceIssueCustomer {

    public static final String Class_Version_Number = "PR_6.2_REL9.4";
    public static final String profileBar = "TATFTFDTFFFFTTTTTTTTTTDDFADTFDTDTATADFATTFFTTTTTAADDFFATATDADAFTT";
    
    int rec_count = 1;
	String LabelLine8;
	int numInkjetLines = 0;
	

    public SE125USPersistenceIssueCustomer() {
        
    }

    private String createHeader() {
        
    	String PlantID = mag.getPlant();
        String header = null;
        
        if(PlantID.toUpperCase().equals("LIN")) {
            header = createHeaderLIN();
        } else if((PlantID.toUpperCase().equals("MCD"))||(PlantID.toUpperCase().equals("STR"))){
            header = createHeaderMCD();
        } else if(PlantID.toUpperCase().equals("CLK")) {
            header = createHeaderCLK();
        } else if(PlantID.toUpperCase().equals("DYB")) {
        	header = createHeaderDYB();
        } else {
            header = createHeaderDef();
        }
        return header;
    }

    private String createHeaderMCD() {
        
    	StringBuffer buf = new StringBuffer(1024);
        GregorianCalendar c = new GregorianCalendar();
        magCode = mag.getMagCode();
        LabelLine8 = PropertyBroker.getProperty("LabelLine8");
        int numOfLabelLines = 6;
        magCode = mag.getMagCode();
        int lineLengths[] = new int[24];
        int familyNum = 0;
        
     // special trim size for SE125US formatter....
    	trimSize = 65;
    	
        MessageFamily mf = null;
        int recordLength = 0;
        int blockLength = 0;
        int numMsgLines = 0;
        String oldLL8 = PropertyBroker.getProperty("oldLL8");
        LL8Override = PropertyBroker.getProperty("LL8Override");
        nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
        
        if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0){
            numOfLabelLines = 7;
        }
        
        for(int x = 0; x < 24; x++) {
            if(x >= 0 && x <= numOfLabelLines) {
                if(x == 0) {
                    lineLengths[x] = 74;
                } else {
                    lineLengths[x] = trimSize;
                }
            } else if(messageFamilies.size() != 0 && familyNum < messageFamilies.size()) {
                mf = (MessageFamily)messageFamilies.elementAt(familyNum);
                for(int j = 0; j < mf.numLines; j++) {
                    lineLengths[x++] = mf.getLineLength(j);
                }

                x--;
                numMsgLines += mf.numLines;
                familyNum++;
            } else {
                lineLengths[x] = 0;
            }
        }

        for(int x = 0; x < 24; x++) {
            recordLength += lineLengths[x];
        }

        recordLength = recordLength + 26 + barcodeLength;
        blockLength = (16384 / recordLength) * recordLength;
    
        buf.append("VOL1");
        String dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
        buf.append(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT));
        buf.append(outputFileName.substring(outputFileName.length() - 3, outputFileName.length()));
        
        buf.append(StringFunctions.fixSize(" ", 31, ' ', StringFunctions.LEFT));
        buf.append("Time, Inc.");
        buf.append(StringFunctions.fixSize("0", 28, '0', StringFunctions.LEFT));
        
        buf.append("3");
        
   //   HEADER ONE 
        
        buf.append("HDR1");
        buf.append("TCS_SYBIL_SYSTEM ");
        buf.append("SE125 ");
        buf.append("000100010001");
        buf.append("  ");
        
        String year = String.valueOf(c.get(Calendar.YEAR)).substring(2, 4);
        
        buf.append(StringFunctions.fixSize(year, 3, '0', StringFunctions.RIGHT));
        buf.append(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT));
        
        c.add(Calendar.DAY_OF_YEAR, 7);
        year = String.valueOf(c.get(Calendar.YEAR)).substring(2, 4);
        buf.append(StringFunctions.fixSize(year, 3, '0', StringFunctions.RIGHT));
        dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
        buf.append(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT));
        
        buf.append(" ");
        buf.append("000000");
        buf.append(StringFunctions.fixSize(" ", 20, ' ', StringFunctions.LEFT));
        
   //   HEADER TWO
        
        buf.append("HDR2");
        buf.append("F");
        buf.append(StringFunctions.fixSize(String.valueOf(blockLength), 5, '0', StringFunctions.RIGHT));
        buf.append(StringFunctions.fixSize(String.valueOf(recordLength), 5, '0', StringFunctions.RIGHT));
        buf.append(StringFunctions.fixSize(" ", 35, ' ', StringFunctions.LEFT));
        buf.append("00");
        buf.append(StringFunctions.fixSize(" ", 28, ' ', StringFunctions.LEFT));
        
        /*  User Header Label 1  */
        
        buf.append("UHL1");
        String linelength = StringFunctions.fixSize(String.valueOf(lineLengths[0]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("010000000")).append(linelength).append("0010FR").toString());
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[1]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("020000000")).append(linelength).append("0010FR").toString());
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[2]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("030000000")).append(linelength).append("0010FR").toString());
        buf.append("7102502");
        buf.append("7100101");
        buf.append("7100301");
        buf.append(" ");
        
        /*  User Header Label 2  */
        
        buf.append("UHL2");
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[3]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("040000000")).append(linelength).append("0010FR").toString());
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[4]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("050000000")).append(linelength).append("0010FR").toString());
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[5]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("060000000")).append(linelength).append("0010FR").toString());
        buf.append((new StringBuilder("71027")).append(String.valueOf(barcodeLength)).toString());
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label 3  */
        
        buf.append("UHL3");
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[6]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("070000000")).append(linelength).append("0010FR").toString());
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[7]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("080000000")).append(linelength).append("0010FR").toString());
        
        
        if(numMsgLines < 1) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[8]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("090000000")).append(linelength).append("0010FR").toString());
        }
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label 4  */
        
        buf.append("UHL4");
        
        if(numMsgLines < 2) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[9]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("100000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 3) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[10]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("110000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 4) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[11]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("120000000")).append(linelength).append("0010FR").toString());
        }
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label 5  */
        
        buf.append("UHL5");
        if(numMsgLines < 5) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[12]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("130000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 6) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[13]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("140000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 7) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[14]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("150000000")).append(linelength).append("0010FR").toString());
        }
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label 6  */
        
        buf.append("UHL6");
        if(numMsgLines < 8) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[15]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("160000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 9) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[16]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("170000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 10) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[17]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("180000000")).append(linelength).append("0010FR").toString());
        }
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label 7  */
        
        buf.append("UHL7");
        buf.append("##");
        buf.append("###");
        buf.append("###");
        buf.append("##");
        buf.append("1");
        buf.append("7100904");
        buf.append("7101305");
        buf.append("00");
        buf.append("000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(outputFileName.substring(outputFileName.length() - 4, outputFileName.length()));
        
        /*  User Header Label 8  */
        
        buf.append("UHL8");
        buf.append("7100404");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("      ");
        
        /*  User Header Label 9  */
        
        buf.append("UHL9");
        if(numMsgLines < 11) {
            linelength = StringFunctions.fixSize(String.valueOf(26 + barcodeLength), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("710000000")).append(linelength).append("0010FR").toString());
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[18]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("190000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 12) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[19]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("200000000")).append(linelength).append("0010FR").toString());
            linelength = StringFunctions.fixSize(String.valueOf(26 + barcodeLength), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("710000000")).append(linelength).append("0010FR").toString());
        }
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        return buf.toString();
    }
    
    private String createHeaderDYB() {
        
    	StringBuffer buf = new StringBuffer(1024);
        GregorianCalendar c = new GregorianCalendar();
        magCode = mag.getMagCode();
        LabelLine8 = PropertyBroker.getProperty("LabelLine8");
        int numOfLabelLines = 6;
        magCode = mag.getMagCode();
        int lineLengths[] = new int[24];
        int familyNum = 0;
        
        MessageFamily mf = null;
        int recordLength = 0;
        int blockLength = 0;
        int numMsgLines = 0;
        String oldLL8 = PropertyBroker.getProperty("oldLL8");
        LL8Override = PropertyBroker.getProperty("LL8Override");
        nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
        
        if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0){
            numOfLabelLines = 7;
        }
        
        for(int x = 0; x < 24; x++) {
            if(x >= 0 && x <= numOfLabelLines) {
                if(x == 0) {
                    lineLengths[x] = 109;
                } else {
                    lineLengths[x] = trimSize;
                }
            } else if(messageFamilies.size() != 0 && familyNum < messageFamilies.size()) {
                mf = (MessageFamily)messageFamilies.elementAt(familyNum);
                for(int j = 0; j < mf.numLines; j++) {
                    lineLengths[x++] = mf.getLineLength(j);
                }

                x--;
                numMsgLines += mf.numLines;
                familyNum++;
            } else {
                lineLengths[x] = 0;
            }
        }

        for(int x = 0; x < 24; x++) {
            recordLength += lineLengths[x];
        }

        recordLength = recordLength + 26 + barcodeLength;
        blockLength = (16384 / recordLength) * recordLength;
        
        buf.append("VOL1");
        String dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
        buf.append(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT));
        buf.append(outputFileName.substring(outputFileName.length() - 3, outputFileName.length()));
        
        buf.append(StringFunctions.fixSize(" ", 31, ' ', StringFunctions.LEFT));
        buf.append("Time, Inc.");
        buf.append(StringFunctions.fixSize("0", 28, '0', StringFunctions.LEFT));
        
        buf.append("3");
        
   //   HEADER ONE 
        
        buf.append("HDR1");
        buf.append("TCS_SYBIL_SYSTEM ");
        buf.append("HARRIS");
        buf.append("000100010001");
        buf.append("  ");
        
        String year = String.valueOf(c.get(Calendar.YEAR)).substring(2, 4);
        
        buf.append(StringFunctions.fixSize(year, 3, '0', StringFunctions.RIGHT));
        buf.append(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT));
        
        c.add(Calendar.DAY_OF_YEAR, 7);
        year = String.valueOf(c.get(Calendar.YEAR)).substring(2, 4);
        buf.append(StringFunctions.fixSize(year, 3, '0', StringFunctions.RIGHT));
        dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
        buf.append(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT));
        
        buf.append(" ");
        buf.append("000000");
        buf.append(StringFunctions.fixSize(" ", 20, ' ', StringFunctions.LEFT));
        
   //   HEADER TWO
        
        buf.append("HDR2");
        buf.append("F");
        buf.append(StringFunctions.fixSize(String.valueOf(blockLength), 5, '0', StringFunctions.RIGHT));
        buf.append(StringFunctions.fixSize(String.valueOf(recordLength), 5, '0', StringFunctions.RIGHT));
        buf.append(StringFunctions.fixSize(" ", 35, ' ', StringFunctions.LEFT));
        buf.append("00");
        buf.append(StringFunctions.fixSize(" ", 28, ' ', StringFunctions.LEFT));
        
        /*  User Header Label 1  */
        
        buf.append("UHL1");
        String linelength = StringFunctions.fixSize(String.valueOf(lineLengths[0]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("010000000")).append(linelength).append("0010FR").toString());
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[1]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("020000000")).append(linelength).append("0010FR").toString());
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[2]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("030000000")).append(linelength).append("0010FR").toString());
        buf.append("7102502");
        buf.append("7100101");
        buf.append("7100301");
        buf.append(" ");
        
        /*  User Header Label 2  */
        
        buf.append("UHL2");
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[3]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("040000000")).append(linelength).append("0010FR").toString());
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[4]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("050000000")).append(linelength).append("0010FR").toString());
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[5]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("060000000")).append(linelength).append("0010FR").toString());
        buf.append((new StringBuilder("71027")).append(String.valueOf(barcodeLength)).toString());
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label 3  */
        
        buf.append("UHL3");
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[6]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("070000000")).append(linelength).append("0010FR").toString());
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[7]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("080000000")).append(linelength).append("0010FR").toString());
        
        
        if(numMsgLines < 1) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[8]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("090000000")).append(linelength).append("0010FR").toString());
        }
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label 4  */
        
        buf.append("UHL4");
        
        if(numMsgLines < 2) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[9]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("100000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 3) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[10]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("110000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 4) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[11]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("120000000")).append(linelength).append("0010FR").toString());
        }
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label 5  */
        
        buf.append("UHL5");
        if(numMsgLines < 5) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[12]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("130000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 6) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[13]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("140000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 7) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[14]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("150000000")).append(linelength).append("0010FR").toString());
        }
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label 6  */
        
        buf.append("UHL6");
        if(numMsgLines < 8) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[15]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("160000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 9) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[16]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("170000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 10) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[17]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("180000000")).append(linelength).append("0010FR").toString());
        }
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label 7  */
        
        buf.append("UHL7");
        buf.append("##");
        buf.append("###");
        buf.append("###");
        buf.append("##");
        buf.append("1");
        buf.append("7100904");
        buf.append("7101305");
        buf.append("00");
        buf.append("000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(outputFileName.substring(outputFileName.length() - 4, outputFileName.length()));
        
        /*  User Header Label 8  */
        
        buf.append("UHL8");
        buf.append("7100403");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("      ");
        
        /*  User Header Label 9  */
        
        buf.append("UHL9");
        if(numMsgLines < 11) {
            linelength = StringFunctions.fixSize(String.valueOf(26 + barcodeLength), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("710000000")).append(linelength).append("0010FR").toString());
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[18]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("190000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 12) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[19]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("200000000")).append(linelength).append("0010FR").toString());
            linelength = StringFunctions.fixSize(String.valueOf(26 + barcodeLength), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("710000000")).append(linelength).append("0010FR").toString());
        }
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        return buf.toString();
    }

    private String createHeaderDef() {
        
    	StringBuffer buf = new StringBuffer(1024);
        GregorianCalendar c = new GregorianCalendar();
        magCode = mag.getMagCode();
        LabelLine8 = PropertyBroker.getProperty("LabelLine8");
        int numOfLabelLines = 5;
        magCode = mag.getMagCode();
        int lineLengths[] = new int[24];
        int familyNum = 0;
        MessageFamily mf = null;
        int recordLength = 0;
        int blockLength = 0;
        int numMsgLines = 0;
        String oldLL8 = PropertyBroker.getProperty("oldLL8");
        LL8Override = PropertyBroker.getProperty("LL8Override");
        nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
        if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
        {
            numOfLabelLines = 7;
        }
        for(int x = 0; x < 24; x++) {
            if(x >= 0 && x <= numOfLabelLines) {
                lineLengths[x] = trimSize;
            } else if(messageFamilies.size() != 0 && familyNum < messageFamilies.size()) {
                mf = (MessageFamily)messageFamilies.elementAt(familyNum);
                for(int j = 0; j < mf.numLines; j++) {
                    lineLengths[x++] = mf.getLineLength(j);
                }

                x--;
                numMsgLines += mf.numLines;
                familyNum++;
            } else {
                lineLengths[x] = 0;
            }
        }

        for(int x = 0; x < 24; x++) {
            recordLength += lineLengths[x];
        }

        recordLength = recordLength + 26 + barcodeLength;
        blockLength = (16384 / recordLength) * recordLength;
        
        /*  Volume Label  */
        
        buf.append("VOL1");
        String dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
        buf.append(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT));
        buf.append(outputFileName.substring(outputFileName.length() - 3, outputFileName.length()));
        buf.append(StringFunctions.fixSize(" ", 31, ' ', StringFunctions.LEFT));
        buf.append("Time, Inc.");
        buf.append(StringFunctions.fixSize("0", 28, '0', StringFunctions.LEFT));
        buf.append("3");
        
        /*  Header 1  */
        
        buf.append("HDR1");
        buf.append("TCS_SYBIL_SYSTEM ");
        buf.append("HARRIS");
        buf.append("000100010001");
        buf.append("  ");
        String year = String.valueOf(c.get(Calendar.YEAR)).substring(2, 4);
        buf.append(StringFunctions.fixSize(year, 3, '0', StringFunctions.RIGHT));
        buf.append(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT));
        c.add(Calendar.DAY_OF_YEAR, 7);
        
        year = String.valueOf(c.get(Calendar.YEAR)).substring(2, 4);
        buf.append(StringFunctions.fixSize(year, 3, '0', StringFunctions.RIGHT));
        dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
        buf.append(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT));
        buf.append(" ");
        buf.append("000000");
        buf.append(StringFunctions.fixSize(" ", 20, ' ', StringFunctions.LEFT));
        
        /*  Header 2  */
        
        buf.append("HDR2");
        buf.append("F");
        buf.append(StringFunctions.fixSize(String.valueOf(blockLength), 5, '0', StringFunctions.RIGHT));
        buf.append(StringFunctions.fixSize(String.valueOf(recordLength), 5, '0', StringFunctions.RIGHT));
        buf.append(StringFunctions.fixSize(" ", 35, ' ', StringFunctions.LEFT));
        buf.append("00");
        buf.append(StringFunctions.fixSize(" ", 28, ' ', StringFunctions.LEFT));
        
        /*  User Header Label 1  */
        
        buf.append("UHL1");
        String linelength = StringFunctions.fixSize(String.valueOf(lineLengths[0]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("010000000")).append(linelength).append("0010FR").toString());
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[1]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("020000000")).append(linelength).append("0010FR").toString());
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[2]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("030000000")).append(linelength).append("0010FR").toString());
        buf.append("7102502");
        buf.append("7100101");
        buf.append("7100301");
        buf.append(" ");
        
        /*  User Header Label 2  */
        
        buf.append("UHL2");
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[3]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("040000000")).append(linelength).append("0010FR").toString());
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[4]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("050000000")).append(linelength).append("0010FR").toString());
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[5]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("060000000")).append(linelength).append("0010FR").toString());
        buf.append((new StringBuilder("71027")).append(String.valueOf(barcodeLength)).toString());
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label 3  */
        
        
        buf.append("UHL3");
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[6]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("070000000")).append(linelength).append("0010FR").toString());
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[7]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("080000000")).append(linelength).append("0010FR").toString());
        
        if(numMsgLines < 1) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[8]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("090000000")).append(linelength).append("0010FR").toString());
        }
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label 4  */
        
        buf.append("UHL4");
        if(numMsgLines < 2) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[9]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("100000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 3) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[10]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("110000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 4) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[11]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("120000000")).append(linelength).append("0010FR").toString());
        }
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label 5  */
        
        buf.append("UHL5");
        if(numMsgLines < 5) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[12]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("130000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 6) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[13]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("140000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 7) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[14]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("150000000")).append(linelength).append("0010FR").toString());
        }
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label 6  */
        
        buf.append("UHL6");
        if(numMsgLines < 8) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[15]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("160000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 9) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[16]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("170000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 10) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[17]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("180000000")).append(linelength).append("0010FR").toString());
        }
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label 7  */
        
        buf.append("UHL7");
        buf.append("##");
        buf.append("###");
        buf.append("###");
        buf.append("##");
        buf.append("1");
        buf.append("7100904");
        buf.append("7101305");
        buf.append("00");
        buf.append("000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(outputFileName.substring(outputFileName.length() - 4, outputFileName.length()));
        
        /*  User Header Label 8  */
        
        buf.append("UHL8");
        buf.append("7100404");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("      ");
        
        /*  User Header Label 9  */
        
        buf.append("UHL9");
        if(numMsgLines < 11) {
            linelength = StringFunctions.fixSize(String.valueOf(26 + barcodeLength), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("710000000")).append(linelength).append("0010FR").toString());
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[18]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("190000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 12) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[19]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("200000000")).append(linelength).append("0010FR").toString());
            linelength = StringFunctions.fixSize(String.valueOf(26 + barcodeLength), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("710000000")).append(linelength).append("0010FR").toString());
        }
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        return buf.toString();
    }

    private String createHeaderCLK() {
        
    	StringBuffer buf = new StringBuffer(1024);
        GregorianCalendar c = new GregorianCalendar();
        magCode = mag.getMagCode();
        LabelLine8 = PropertyBroker.getProperty("LabelLine8");
        int numOfLabelLines = 5;
        magCode = mag.getMagCode();
        int lineLengths[] = new int[24];
        int familyNum = 0;
        MessageFamily mf = null;
        int recordLength = 0;
        int blockLength = 0;
        int numMsgLines = 0;
        String oldLL8 = PropertyBroker.getProperty("oldLL8");
        LL8Override = PropertyBroker.getProperty("LL8Override");
        nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
        if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
        {
            numOfLabelLines = 7;
        }
        if(mag.getPlant().toUpperCase().equals("CLK")) {
            if(mag.getDeliveryType().toUpperCase().trim().equalsIgnoreCase("USPS")) {
                numOfLabelLines = 7;
            } else {
                numOfLabelLines = 7;
            }
            for(int x = 0; x < 24; x++) {
                if(x >= 0 && x <= numOfLabelLines) {
                    lineLengths[x] = x != 1 || !mag.getDeliveryType().toUpperCase().trim().equalsIgnoreCase("USPS") ? trimSize : trimSize;
                } else if(messageFamilies.size() != 0 && familyNum < messageFamilies.size()) {
                    mf = (MessageFamily)messageFamilies.elementAt(familyNum);
                    for(int j = 0; j < mf.numLines; j++) {
                        lineLengths[x++] = mf.getLineLength(j);
                    }

                    x--;
                    numMsgLines += mf.numLines;
                    familyNum++;
                } else {
                    lineLengths[x] = 0;
                }
            }

        } else {
            for(int x = 0; x < 24; x++) {
                if(x >= 0 && x <= numOfLabelLines) {
                    lineLengths[x] = x != 0 ? trimSize : 315;
                } else if(messageFamilies.size() != 0 && familyNum < messageFamilies.size()) {
                    mf = (MessageFamily)messageFamilies.elementAt(familyNum);
                    for(int j = 0; j < mf.numLines; j++) {
                        lineLengths[x++] = mf.getLineLength(j);
                    }

                    x--;
                    numMsgLines += mf.numLines;
                    familyNum++;
                } else {
                    lineLengths[x] = 0;
                }
            }

        }
        for(int x = 0; x < 24; x++) {
            recordLength += lineLengths[x];
        }

        recordLength = recordLength + 26 + barcodeLength;
        blockLength = (16384 / recordLength) * recordLength;
        
        /*  Volume Label  */
        
        buf.append("VOL1");
        String dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
        buf.append(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT));
        buf.append(outputFileName.substring(outputFileName.length() - 3, outputFileName.length()));
        buf.append(StringFunctions.fixSize(" ", 31, ' ', StringFunctions.LEFT));
        buf.append("Time, Inc.");
        buf.append(StringFunctions.fixSize("0", 28, '0', StringFunctions.LEFT));
        buf.append("3");
        
        /*  Header 1  */
        
        buf.append("HDR1");
        buf.append("TCS_SYBIL_SYSTEM ");
        buf.append("HARRIS");
        buf.append("000100010001");
        buf.append("  ");
        String year = String.valueOf(c.get(Calendar.YEAR)).substring(2, 4);
        buf.append(StringFunctions.fixSize(year, 3, '0', StringFunctions.RIGHT));
        buf.append(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT));
        c.add(Calendar.DAY_OF_YEAR, 7);
        year = String.valueOf(c.get(Calendar.YEAR)).substring(2, 4);
        buf.append(StringFunctions.fixSize(year, 3, '0', StringFunctions.RIGHT));
        dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
        buf.append(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT));
        buf.append(" ");
        buf.append("000000");
        buf.append(StringFunctions.fixSize(" ", 20, ' ', StringFunctions.LEFT));
        
        /*  Header 2  */
        
        buf.append("HDR2");
        buf.append("F");
        buf.append(StringFunctions.fixSize(String.valueOf(blockLength), 5, '0', StringFunctions.RIGHT));
        buf.append(StringFunctions.fixSize(String.valueOf(recordLength), 5, '0', StringFunctions.RIGHT));
        buf.append(StringFunctions.fixSize(" ", 35, ' ', StringFunctions.LEFT));
        buf.append("00");
        buf.append(StringFunctions.fixSize(" ", 28, ' ', StringFunctions.LEFT));
        
        /*  User Header Label 1  */
        
        buf.append("UHL1");
        String linelength = StringFunctions.fixSize(String.valueOf(lineLengths[0]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("010000000")).append(linelength).append("0010FR").toString());
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[1]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("020000000")).append(linelength).append("0010FR").toString());
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[2]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("030000000")).append(linelength).append("0010FR").toString());
        buf.append("7102502");
        buf.append("7100101");
        buf.append("7100301");
        buf.append(" ");
        
        /*  User Header Label 2  */
        
        buf.append("UHL2");
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[3]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("040000000")).append(linelength).append("0010FR").toString());
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[4]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("050000000")).append(linelength).append("0010FR").toString());
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[5]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("060000000")).append(linelength).append("0010FR").toString());
        buf.append((new StringBuilder("71027")).append(String.valueOf(barcodeLength)).toString());
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label 3  */
        
        
        buf.append("UHL3");
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[6]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("070000000")).append(linelength).append("0010FR").toString());
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[7]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("080000000")).append(linelength).append("0010FR").toString());
        if(numMsgLines < 1) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[8]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("090000000")).append(linelength).append("0010FR").toString());
        }
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label 4  */
        
        buf.append("UHL4");
        if(numMsgLines < 2) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[9]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("100000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 3) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[10]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("110000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 4) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[11]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("120000000")).append(linelength).append("0010FR").toString());
        }
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label 5  */
        
        buf.append("UHL5");
        if(numMsgLines < 5) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[12]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("130000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 6) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[13]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("140000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 7) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[14]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("150000000")).append(linelength).append("0010FR").toString());
        }
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label 6  */
        buf.append("UHL6");
        if(numMsgLines < 8) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[15]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("160000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 9) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[16]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("170000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 10) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[17]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("180000000")).append(linelength).append("0010FR").toString());
        }
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label 7  */
        
        
        buf.append("UHL7");
        buf.append("##");
        buf.append("###");
        buf.append("###");
        buf.append("##");
        buf.append("1");
        buf.append("7100904");
        buf.append("7101305");
        buf.append("00");
        buf.append("000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(outputFileName.substring(outputFileName.length() - 4, outputFileName.length()));
        
        /*  User Header Label 8  */
        
        buf.append("UHL8");
        buf.append("7100404");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("      ");
        
        /*  User Header Label 9  */
        
        buf.append("UHL9");
        if(numMsgLines < 11) {
            linelength = StringFunctions.fixSize(String.valueOf(26 + barcodeLength), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("710000000")).append(linelength).append("0010FR").toString());
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[18]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("190000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 12) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[19]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("200000000")).append(linelength).append("0010FR").toString());
            linelength = StringFunctions.fixSize(String.valueOf(26 + barcodeLength), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("710000000")).append(linelength).append("0010FR").toString());
        }
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        return buf.toString();
    }

    private String createHeaderLIN() {
        
    	StringBuffer buf = new StringBuffer(1024);
        GregorianCalendar c = new GregorianCalendar();
        magCode = mag.getMagCode();
        int LNLBarCodeLength = 72;
        int controlDataSize = 26;
        LabelLine8 = PropertyBroker.getProperty("LabelLine8");
        int numOfLabelLines = 5;
        magCode = mag.getMagCode();
        int lineLengths[] = new int[24];
        int familyNum = 0;
        MessageFamily mf = null;
        int recordLength = 0;
        int blockLength = 0;
        int numMsgLines = 0;
        String oldLL8 = PropertyBroker.getProperty("oldLL8");
        LL8Override = PropertyBroker.getProperty("LL8Override");
        nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
        if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
        {
            numOfLabelLines = 7;
        }
        for(int x = 0; x < 24; x++) {
            if(x >= 0 && x <= numOfLabelLines) {
                lineLengths[x] = trimSize;
            } else if(messageFamilies.size() != 0 && familyNum < messageFamilies.size()) {
                mf = (MessageFamily)messageFamilies.elementAt(familyNum);
                for(int j = 0; j < mf.numLines; j++) {
                    lineLengths[x++] = mf.getLineLength(j);
                }

                x--;
                numMsgLines += mf.numLines;
                familyNum++;
            } else {
                lineLengths[x] = 0;
            }
        }

        for(int x = 0; x < 24; x++) {
            recordLength += lineLengths[x];
        }

        recordLength = recordLength + LNLBarCodeLength + controlDataSize;
        blockLength = (numOfLabelLines + 1) * recordLength;
        
        /*  Volume Label  */
        
        buf.append("VOL1");
        String dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
        buf.append(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT));
        buf.append(outputFileName.substring(outputFileName.length() - 3, outputFileName.length()));
        buf.append(StringFunctions.fixSize(" ", 31, ' ', StringFunctions.LEFT));
        buf.append("Time, Inc.");
        buf.append(StringFunctions.fixSize("0", 28, '0', StringFunctions.LEFT));
        buf.append("3");
        
        /*  Header 1  */
        
        buf.append("HDR1");
        buf.append("TCS_SYBIL_SYSTEM ");
        buf.append("HARRIS");
        buf.append("000100010001");
        buf.append("  ");
        String year = String.valueOf(c.get(Calendar.YEAR)).substring(2, 4);
        buf.append(StringFunctions.fixSize(year, 3, '0', StringFunctions.RIGHT));
        buf.append(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT));
        c.add(Calendar.DAY_OF_YEAR, 7);
        year = String.valueOf(c.get(Calendar.YEAR)).substring(2, 4);
        buf.append(StringFunctions.fixSize(year, 3, '0', StringFunctions.RIGHT));
        dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
        buf.append(StringFunctions.fixSize(dayOfYear, 3, '0', StringFunctions.RIGHT));
        buf.append(" ");
        buf.append("000000");
        buf.append(StringFunctions.fixSize(" ", 20, ' ', StringFunctions.LEFT));
        
        /*  Header 2  */
        
        buf.append("HDR2");
        buf.append("F");
        buf.append(StringFunctions.fixSize(String.valueOf(blockLength), 5, '0', StringFunctions.RIGHT));
        buf.append(StringFunctions.fixSize(String.valueOf(recordLength), 5, '0', StringFunctions.RIGHT));
        buf.append(StringFunctions.fixSize(" ", 35, ' ', StringFunctions.LEFT));
        buf.append("00");
        buf.append(StringFunctions.fixSize(" ", 28, ' ', StringFunctions.LEFT));
        
        /*  User Header Label 1  */
        
        buf.append("UHL1");
        String linelength = StringFunctions.fixSize(String.valueOf(lineLengths[0]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("010000000")).append(linelength).append("0010FR").toString());
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[1]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("020000000")).append(linelength).append("0010FR").toString());
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[2]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("030000000")).append(linelength).append("0010FR").toString());
        buf.append("7102502");
        buf.append("7100101");
        buf.append("7100301");
        buf.append(" ");
        
        /*  User Header Label 2  */
        
        buf.append("UHL2");
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[3]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("040000000")).append(linelength).append("0010FR").toString());
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[4]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("050000000")).append(linelength).append("0010FR").toString());
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[5]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("060000000")).append(linelength).append("0010FR").toString());
        buf.append((new StringBuilder("71027")).append(String.valueOf(barcodeLength)).toString());
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label 3  */
        
        buf.append("UHL3");
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[6]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("070000000")).append(linelength).append("0010FR").toString());
        linelength = StringFunctions.fixSize(String.valueOf(lineLengths[7]), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("080000000")).append(linelength).append("0010FR").toString());
        if(numMsgLines < 1) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[8]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("090000000")).append(linelength).append("0010FR").toString());
        }
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label 4  */
        
        
        buf.append("UHL4");
        if(numMsgLines < 2) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[9]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("100000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 3) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[10]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("110000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 4) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[11]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("120000000")).append(linelength).append("0010FR").toString());
        }
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label 5  */
        
        buf.append("UHL5");
        if(numMsgLines < 5) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[12]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("130000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 6) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[13]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("140000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 7) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[14]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("150000000")).append(linelength).append("0010FR").toString());
        }
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label 6  */
        
        
        buf.append("UHL6");
        if(numMsgLines < 8) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[15]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("160000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 9) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[16]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("170000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 10) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[17]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("180000000")).append(linelength).append("0010FR").toString());
        }
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label 7  */
        
        buf.append("UHL7");
        buf.append("##");
        buf.append("###");
        buf.append("###");
        buf.append("##");
        buf.append("1");
        buf.append("7100904");
        buf.append("7101305");
        buf.append("00");
        buf.append("000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(outputFileName.substring(outputFileName.length() - 4, outputFileName.length()));
        
        /*  User Header Label 8  */
        
        buf.append("UHL8");
        buf.append("7100503");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append("      ");
        
        /*  User Header Label 9  */
        
        buf.append("UHL9");
        if(numMsgLines < 11) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[18]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("190000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 12) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[19]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("200000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 13) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[20]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("210000000")).append(linelength).append("0010FR").toString());
        }
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label A  */
        
        buf.append("UHLA");
        if(numMsgLines < 14) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[21]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("220000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 15) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[22]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("230000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 16) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[23]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("240000000")).append(linelength).append("0010FR").toString());
        }
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        /*  User Header Label B  */
        
        buf.append("UHLB");
        if(numMsgLines < 17) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[24]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("250000000")).append(linelength).append("0010FR").toString());
        }
        if(numMsgLines < 18) {
            buf.append("000000000000000000");
        } else {
            linelength = StringFunctions.fixSize(String.valueOf(lineLengths[25]), 3, '0', StringFunctions.RIGHT);
            buf.append((new StringBuilder("260000000")).append(linelength).append("0010FR").toString());
        }
        linelength = StringFunctions.fixSize(String.valueOf(26 + barcodeLength), 3, '0', StringFunctions.RIGHT);
        buf.append((new StringBuilder("710000000")).append(linelength).append("0010FR").toString());
        buf.append("0000000");
        buf.append("0000000");
        buf.append("0000000");
        buf.append(" ");
        
        return buf.toString();
    }

    public void createOutputFile(String prop, String outputFileName) {
        
    	this.outputFileName = outputFileName;
        outFileName = outputFileName;
        useShortFileName = PropertyBroker.getProperty("useShortFileName", "false");
        shortFileName = outputFileName.substring(0, outputFileName.lastIndexOf("/") + 1).concat(outputFileName.substring(outputFileName.lastIndexOf(".") + 1, outputFileName.length()));
        plant = mag.getPlant().toUpperCase();
        rec_count = 1;
        String FormatterFileConcatText = null;
        FormatterFileConcatText = PropertyBroker.getProperty("FormatterFileConcatText");
        
        String fileName = null;
        fileName = (new StringBuilder(String.valueOf(PropertyBroker.getProperty("OLDFILEDIR")))).append(mag.getFullPrefix()).append(".RLL5").toString();
        File f = new File(fileName);
        BufferedReader fileReader = null;
        
        if(f.exists()) {
            try {
                fileReader = new BufferedReader(new FileReader(fileName));
            }
            catch(FileNotFoundException fnfe) {
                LogWriter.writeLog(new Exception((new StringBuilder(String.valueOf(mag.getPrefix()))).append(": Error opening RLL5 file: File not found: ").append(fileName).toString()));
                return;
            }
            try {
                RLL5value = fileReader.readLine();
                LogWriter.writeLog((new StringBuilder("RLL5value = ")).append(RLL5value).toString());
            }
            catch(EOFException eofexception) { }
            catch(Exception re) {
                LogWriter.writeLog(re);
            }
        } else {
            RLL5value = "false";
        }
        
        if(FormatterFileConcatText == null) {
            FormatterFileConcatText = "";
        }
        
        if(useShortFileName.equals("true")) {
            formatShortFileName = true;
        }
        
        if(formatShortFileName) {
            shortOutputFileName = (new StringBuilder(String.valueOf(prop))).append(shortFileName).toString();
            tmpFile = new File((new StringBuilder(String.valueOf(prop))).append(outputFileName).append(FormatterFileConcatText).append(".tmp").toString());
        } else {
            longOutputFileName = (new StringBuilder(String.valueOf(prop))).append(mag.getLongFileName()).append(fileSep).append(shortFileName).toString();
            tmpFile = new File((new StringBuilder(String.valueOf(longOutputFileName))).append(FormatterFileConcatText).append(".tmp").toString());
        }
        
        try {
            outputFile = new OutputStreamWriter(new FileOutputStream(tmpFile), "ISO8859_1");
        }
        catch(IOException e) {
            LogWriter.writeLog(new SybilWarningException((new StringBuilder(String.valueOf(mag.getPrefix()))).append(": Error creating output file: ").append(e.getMessage()).toString()));
            return;
        }
        if(formatShortFileName) {
            shortOutputFileName = (new StringBuilder(String.valueOf(prop))).append(shortFileName).toString();
            newFile = new File((new StringBuilder(String.valueOf(shortOutputFileName))).append(FormatterFileConcatText).append(".DAT").toString());
        } else {
            longOutputFileName = (new StringBuilder(String.valueOf(prop))).append(mag.getLongFileName()).append(fileSep).append(shortFileName).toString();
            newFile = new File((new StringBuilder(String.valueOf(longOutputFileName))).append(FormatterFileConcatText).append(".DAT").toString());
        }
        
        if(newFile.exists()) {
            newFile.delete();
        }
        
        String header = createHeader();
        try {
            PrintWriter headerFile;
            if(formatShortFileName) {
                headerFile = new PrintWriter(new OutputStreamWriter(new FileOutputStream((new StringBuilder(String.valueOf(shortOutputFileName))).append(FormatterFileConcatText).append(".hdr").toString()), "ISO8859_1"));
            } else {
                headerFile = new PrintWriter(new OutputStreamWriter(new FileOutputStream((new StringBuilder(String.valueOf(longOutputFileName))).append(FormatterFileConcatText).append(".hdr").toString()), "ISO8859_1"));
            }
            headerFile.print(header);
            headerFile.flush();
            headerFile.close();
        }
        catch(IOException e) {
            LogWriter.writeLog((new StringBuilder(String.valueOf(mag.getPrefix()))).append(": Error creating output file: ").append(e.getMessage()).toString());
            return;
        }
    }

    protected String formatData(IssueCustomer ic) {
        
    	String PlantID = mag.getPlant().toUpperCase();
        String data = null;
        if ((PlantID.toUpperCase().equals("MCD"))||(PlantID.toUpperCase().equals("STR"))){
        	data = formatDataMCD(ic);
        } else if(PlantID.toUpperCase().equals("CLK")){
        	data = formatDataCLK(ic);
        } else if(PlantID.toUpperCase().equals("DYB")){
        	data = formatDataDYB(ic);
        } else {
            data = formatDataDef(ic);
        }
        return data;
    }

    protected String formatDataCLK(IssueCustomer ic) {
        
    	StringBuffer buf = new StringBuffer(1024);
        try
        {
            LabelLine8 = PropertyBroker.getProperty("LabelLine8");
            LL8Override = PropertyBroker.getProperty("LL8Override");
            nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
            String oldLL8 = PropertyBroker.getProperty("oldLL8");
            magCode = mag.getMagCode();
            String labelLine = null;
            String deliveryType = mag.getDeliveryType().toUpperCase().trim();
            
            if(deliveryType.equalsIgnoreCase("USPS")) {
                if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                    buf.append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), trimSize, ' ', StringFunctions.LEFT));
                    buf.append(StringFunctions.fixSize("", trimSize, ' ', StringFunctions.LEFT));
                } else {
                    buf.append(StringFunctions.fixSize("", trimSize, ' ', StringFunctions.LEFT));
                    buf.append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), trimSize, ' ', StringFunctions.LEFT));
                }
            }
            if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0) {
                if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                    buf.append(ic.getMagazineLabel().getTextLine(1).substring(0, trimSize));
                    buf.append(ic.getMagazineLabel().getTextLine(2).substring(0, trimSize));
                    if(!deliveryType.equalsIgnoreCase("USPS")) {
                        buf.append(ic.getMagazineLabel().getTextLine(3).substring(0, trimSize));
                    }
                    buf.append(ic.getMagazineLabel().getTextLine(4).substring(0, trimSize));
                    buf.append(ic.getMagazineLabel().getTextLine(5).substring(0, trimSize));
                    buf.append(ic.getMagazineLabel().getTextLine(6).substring(0, trimSize));
                    buf.append(ic.getMagazineLabel().getTextLine(7).substring(0, trimSize));
                    if(!deliveryType.equalsIgnoreCase("USPS")) {
                        buf.append(ic.getMagazineLabel().getTextLine(8).substring(0, trimSize));
                    }
                } else {
                    buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1), trimSize, ' ', StringFunctions.RIGHT));
                    buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2), trimSize, ' ', StringFunctions.RIGHT));
                    if(!deliveryType.equalsIgnoreCase("USPS")) {
                        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3), trimSize, ' ', StringFunctions.RIGHT));
                    }
                    buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4), trimSize, ' ', StringFunctions.RIGHT));
                    buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5), trimSize, ' ', StringFunctions.RIGHT));
                    buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6), trimSize, ' ', StringFunctions.RIGHT));
                    buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(7), trimSize, ' ', StringFunctions.RIGHT));
                    if(!deliveryType.equalsIgnoreCase("USPS")) {
                        buf.append(StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(8), trimSize, ' ', StringFunctions.RIGHT));
                    }
                }
            } else {
                for(int i = 1; i <= 6; i++) {
                    if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                        labelLine = ic.getMagazineLabel().getTextLine(i).substring(0, trimSize);
                    } else {
                        labelLine = StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(i), trimSize, ' ', StringFunctions.RIGHT);
                    }
                    buf.append(labelLine);
                }

            }
            
            int numberOfMessages = ic.getNumberOfMessages();
            Vector allMessages = ic.getMessages();
            Message m = null;
            String msgfamilyNumber = null;
            MessageParameter msgp = null;
            MessageFamily mf = null;
            int i3 = 0;
            for(int j = 0; j < messageFamilies.size(); j++) {
                mf = (MessageFamily)messageFamilies.elementAt(j);
                if(numberOfMessages == 0) {
                    buf.append(StringFunctions.fixSize(" ", mf.size, ' ', StringFunctions.LEFT));
                } else if(i3 >= numberOfMessages) {
                    numberOfMessages = 0;
                    j--;
                } else {
                    m = (Message)allMessages.elementAt(i3);
                    msgfamilyNumber = (new StringBuilder(String.valueOf(m.getMessageFamily()))).append(m.getMessageNumber()).toString();
                    msgp = (MessageParameter)msgparms.get(msgfamilyNumber);
                    if(!msgp.isCoverMessage()) {
                        if(m.getMessageFamily().equals(mf.familyNumber)) {
                            int numberOfMsgTextLines = m.getNumberOfTextLines();
                            Vector m_TextLines = m.getTextLines();
                            int k = 0;
                            for(k = 0; k < numberOfMsgTextLines; k++) {
                                TextLine tl = (TextLine)m_TextLines.elementAt(k);
                                buf.append(tl.toString());
                            }

                            for(int pad = k; pad < mf.numLines; pad++) {
                                TextLine tl = new TextLine(msgp.getLineLength(pad), -4, pad, " ");
                                tl.justify();
                                if(LabelLine8.indexOf(magCode) >= 0) {
                                    LogWriter.writeLog((new StringBuilder("buf 0")).append(buf).toString());
                                    buf.append(" ");
                                    LogWriter.writeLog((new StringBuilder("buf 1")).append(buf).toString());
                                    buf.append(m.getTextLine(0));
                                    LogWriter.writeLog((new StringBuilder("buf 2")).append(buf).toString());
                                    buf.append(m.getTextLine(1));
                                    LogWriter.writeLog((new StringBuilder("buf 3")).append(buf).toString());
                                    buf.append(m.getTextLine(2));
                                    LogWriter.writeLog((new StringBuilder("buf 4")).append(buf).toString());
                                    allMessages.addElement(" ");
                                    LogWriter.writeLog((new StringBuilder("buf 5")).append(buf).toString());
                                    buf.append(m.getTextLine(3));
                                    LogWriter.writeLog((new StringBuilder("buf 6")).append(buf).toString());
                                    buf.append(m.getTextLine(4));
                                    buf.append(m.getTextLine(5));
                                    LogWriter.writeLog((new StringBuilder("buf 7")).append(buf).toString());
                                } else {
                                    buf.append(tl.toString());
                                }
                            }

                            i3++;
                        } else {
                            buf.append(StringFunctions.fixSize(" ", mf.size, ' ', StringFunctions.LEFT));
                        }
                    } else {
                        j--;
                        i3++;
                    }
                }
            }

            if(ic.getEndPackageIndicator()) {
                buf.append("1 ");
            } else {
                buf.append("  ");
            }
            if(ic.getEndPalletSackIndicator()) {
                buf.append("1");
            } else {
                buf.append(" ");
            }
            
            buf.append(StringFunctions.fixSize(ic.getMakeupCode(), 4, '0', StringFunctions.RIGHT));
            buf.append(" ");
            buf.append(outputFileName.substring(outputFileName.length() - 4, outputFileName.length()));
            buf.append((new StringBuilder(String.valueOf(StringFunctions.fixSize(String.valueOf(rec_count++), 5, '0', StringFunctions.RIGHT)))).append("   ").toString());
            buf.append(StringFunctions.fixSize(ic.getMagazineLabel().addressLine1, 4, ' ', StringFunctions.RIGHT));
            buf.append("00");
            
            if(ic.getMagazineLabel().barcode.length() > 0) {
                String barcode = ic.getMagazineLabel().barcode;
                if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                    buf.append(StringFunctions.fixSize(barcode, 72, ' ', StringFunctions.LEFT));
                } else {
                    buf.append(StringFunctions.fixSize(barcode, 72, ' ', StringFunctions.RIGHT));
                }
            } else {
                buf.append(StringFunctions.fixSize(" ", 72, ' ', StringFunctions.LEFT));
            }
        }
        catch(Exception ex) {
            LogWriter.writeLog(ex);
        }
        return buf.toString();
    }

    protected String formatDataDef(IssueCustomer ic) {
        
    	StringBuffer buf = new StringBuffer(1024);
        try
        {
            LabelLine8 = PropertyBroker.getProperty("LabelLine8");
            LL8Override = PropertyBroker.getProperty("LL8Override");
            nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
            String oldLL8 = PropertyBroker.getProperty("oldLL8");
            magCode = mag.getMagCode();
            String labelLine = null;
            
            if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
            {
                for(int i = 1; i <= 8; i++) {
                    if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                        labelLine = ic.getMagazineLabel().getTextLine(i).substring(0, trimSize);
                    } else {
                        labelLine = StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(i), trimSize, ' ', StringFunctions.RIGHT);
                    }
                    buf.append(labelLine);
                }

            } else {
                for(int i = 1; i <= 6; i++) {
                    if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                        labelLine = ic.getMagazineLabel().getTextLine(i).substring(0, trimSize);
                    } else {
                        labelLine = StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(i), trimSize, ' ', StringFunctions.RIGHT);
                    }
                    buf.append(labelLine);
                }

            }
            int numberOfMessages = ic.getNumberOfMessages();
            Vector allMessages = ic.getMessages();
            Message m = null;
            String msgfamilyNumber = null;
            MessageParameter msgp = null;
            MessageFamily mf = null;
            int i3 = 0;
            for(int j = 0; j < messageFamilies.size(); j++) {
                mf = (MessageFamily)messageFamilies.elementAt(j);
                if(numberOfMessages == 0) {
                    buf.append(StringFunctions.fixSize(" ", mf.size, ' ', StringFunctions.LEFT));
                } else if(i3 >= numberOfMessages) {
                    numberOfMessages = 0;
                    j--;
                } else {
                    m = (Message)allMessages.elementAt(i3);
                    msgfamilyNumber = (new StringBuilder(String.valueOf(m.getMessageFamily()))).append(m.getMessageNumber()).toString();
                    msgp = (MessageParameter)msgparms.get(msgfamilyNumber);
                    if(!msgp.isCoverMessage()) {
                        if(m.getMessageFamily().equals(mf.familyNumber)) {
                            int numberOfMsgTextLines = m.getNumberOfTextLines();
                            Vector m_TextLines = m.getTextLines();
                            int k = 0;
                            for(k = 0; k < numberOfMsgTextLines; k++) {
                                TextLine tl = (TextLine)m_TextLines.elementAt(k);
                                buf.append(tl.toString());
                            }

                            for(int pad = k; pad < mf.numLines; pad++) {
                                TextLine tl = new TextLine(msgp.getLineLength(pad), -4, pad, " ");
                                tl.justify();
                                if(LabelLine8.indexOf(magCode) >= 0) {
                                    LogWriter.writeLog((new StringBuilder("buf 0")).append(buf).toString());
                                    buf.append(" ");
                                    LogWriter.writeLog((new StringBuilder("buf 1")).append(buf).toString());
                                    buf.append(m.getTextLine(0));
                                    LogWriter.writeLog((new StringBuilder("buf 2")).append(buf).toString());
                                    buf.append(m.getTextLine(1));
                                    LogWriter.writeLog((new StringBuilder("buf 3")).append(buf).toString());
                                    buf.append(m.getTextLine(2));
                                    LogWriter.writeLog((new StringBuilder("buf 4")).append(buf).toString());
                                    allMessages.addElement(" ");
                                    LogWriter.writeLog((new StringBuilder("buf 5")).append(buf).toString());
                                    buf.append(m.getTextLine(3));
                                    LogWriter.writeLog((new StringBuilder("buf 6")).append(buf).toString());
                                    buf.append(m.getTextLine(4));
                                    buf.append(m.getTextLine(5));
                                    LogWriter.writeLog((new StringBuilder("buf 7")).append(buf).toString());
                                } else {
                                    buf.append(tl.toString());
                                }
                            }

                            i3++;
                        } else {
                            buf.append(StringFunctions.fixSize(" ", mf.size, ' ', StringFunctions.LEFT));
                        }
                    } else {
                        j--;
                        i3++;
                    }
                }
            }

            if(ic.getEndPackageIndicator()) {
                buf.append("1 ");
            } else {
                buf.append("  ");
            }
            if(ic.getEndPalletSackIndicator()) {
                buf.append("1");
            } else {
                buf.append(" ");
            }
            buf.append(StringFunctions.fixSize(ic.getMakeupCode(), 4, '0', StringFunctions.RIGHT));
            buf.append(" ");
            buf.append(outputFileName.substring(outputFileName.length() - 4, outputFileName.length()));
            buf.append((new StringBuilder(String.valueOf(StringFunctions.fixSize(String.valueOf(rec_count++), 5, '0', StringFunctions.RIGHT)))).append("   ").toString());
            buf.append(StringFunctions.fixSize(ic.getMagazineLabel().addressLine1, 4, ' ', StringFunctions.RIGHT));
            buf.append("00");
            
            if(ic.getMagazineLabel().barcode.length() > 0) {
                String barcode = ic.getMagazineLabel().barcode;
                if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                    buf.append(StringFunctions.fixSize(barcode, 72, ' ', StringFunctions.LEFT));
                } else {
                    buf.append(StringFunctions.fixSize(barcode, 72, ' ', StringFunctions.RIGHT));
                }
            } else {
                buf.append(StringFunctions.fixSize(" ", 72, ' ', StringFunctions.LEFT));
            }
        }
        catch(Exception ex) {
            LogWriter.writeLog(ex);
        }
        return buf.toString();
    }

    protected String formatDataMCD(IssueCustomer ic) {
        
    	StringBuffer buf = new StringBuffer(1024);
        try
        {
            LabelLine8 = PropertyBroker.getProperty("LabelLine8");
            LL8Override = PropertyBroker.getProperty("LL8Override");
            nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
            String oldLL8 = PropertyBroker.getProperty("oldLL8");
            magCode = mag.getMagCode();
            String labelLine = null;
            
            // special trim size for SE125US formatter....
        	trimSize = 65;
            
            if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
                    buf.append(StringFunctions.fixSize("TATFTFDTFFFFTTTTTTTTTTDDFADTFDTDTATADFATTFFTTTTTAADDFFATATDADAFTT".toUpperCase(), 74, ' ', StringFunctions.LEFT));
                } else {
                    buf.append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), 74, ' ', StringFunctions.LEFT));
                }
                
            } else {
            	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
                    buf.append(StringFunctions.fixSize("TATFTFDTFFFFTTTTTTTTTTDDFADTFDTDTATADFATTFFTTTTTAADDFFATATDADAFTT".toUpperCase(), 74, ' ', StringFunctions.RIGHT));
                } else {
                    buf.append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), 74, ' ', StringFunctions.RIGHT));
                }
            	
            }
            	
            
            
            if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
            {
                for(int i = 2; i <= 8; i++) {
                    if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                        labelLine = ic.getMagazineLabel().getTextLine(i).substring(0, trimSize);
                    } else {
                        labelLine = StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(i), trimSize, ' ', StringFunctions.RIGHT);
                    }
                      buf.append(labelLine);
        			}
            } else {
                for(int i = 1; i <= 6; i++) {
                   String newlLine = null;
                   labelLine = ic.getMagazineLabel().getTextLine(i).substring(0, 100);
                   if (i == 4){
                	   System.out.println("This is line4 of label");
                	   newlLine = labelLine.trim();
                	   if (newlLine.length() < 8){
                		   buf.append("                               ");
                		   labelLine  = StringFunctions.fixSize(newlLine, 34, ' ', StringFunctions.LEFT);
                	   }else {
                	       labelLine  = StringFunctions.fixSize(newlLine, trimSize, ' ', StringFunctions.LEFT);}
                	   }
                   else{
                	   System.out.println("This is not line4 of label");
                	   newlLine = labelLine.trim();
                	   labelLine = StringFunctions.fixSize(newlLine, trimSize, ' ', StringFunctions.LEFT);}
                   buf.append(labelLine);
                }

            }
            
            int numberOfMessages = ic.getNumberOfMessages();
            Vector allMessages = ic.getMessages();
            Message m = null;
            String msgfamilyNumber = null;
            MessageParameter msgp = null;
            MessageFamily mf = null;
            int i3 = 0;
            for(int j = 0; j < messageFamilies.size(); j++) {
                mf = (MessageFamily)messageFamilies.elementAt(j);
                if(numberOfMessages == 0) {
                    buf.append(StringFunctions.fixSize(" ", mf.size, ' ', StringFunctions.LEFT));
                } else if(i3 >= numberOfMessages) {
                    numberOfMessages = 0;
                    j--;
                } else {
                    m = (Message)allMessages.elementAt(i3);
                    msgfamilyNumber = (new StringBuilder(String.valueOf(m.getMessageFamily()))).append(m.getMessageNumber()).toString();
                    msgp = (MessageParameter)msgparms.get(msgfamilyNumber);
                    if(!msgp.isCoverMessage()) {
                        if(m.getMessageFamily().equals(mf.familyNumber)) {
                            int numberOfMsgTextLines = m.getNumberOfTextLines();
                            Vector m_TextLines = m.getTextLines();
                            int k = 0;
                            for(k = 0; k < numberOfMsgTextLines; k++) {
                                TextLine tl = (TextLine)m_TextLines.elementAt(k);
                                buf.append(tl.toString());
                            }

                            for(int pad = k; pad < mf.numLines; pad++) {
                                TextLine tl = new TextLine(msgp.getLineLength(pad), -4, pad, " ");
                                tl.justify();
                                if(LabelLine8.indexOf(magCode) >= 0) {
                                    LogWriter.writeLog((new StringBuilder("buf 0")).append(buf).toString());
                                    buf.append(" ");
                                    LogWriter.writeLog((new StringBuilder("buf 1")).append(buf).toString());
                                    buf.append(m.getTextLine(0));
                                    LogWriter.writeLog((new StringBuilder("buf 2")).append(buf).toString());
                                    buf.append(m.getTextLine(1));
                                    LogWriter.writeLog((new StringBuilder("buf 3")).append(buf).toString());
                                    buf.append(m.getTextLine(2));
                                    LogWriter.writeLog((new StringBuilder("buf 4")).append(buf).toString());
                                    allMessages.addElement(" ");
                                    LogWriter.writeLog((new StringBuilder("buf 5")).append(buf).toString());
                                    buf.append(m.getTextLine(3));
                                    LogWriter.writeLog((new StringBuilder("buf 6")).append(buf).toString());
                                    buf.append(m.getTextLine(4));
                                    buf.append(m.getTextLine(5));
                                    LogWriter.writeLog((new StringBuilder("buf 7")).append(buf).toString());
                                } else {
                                    buf.append(tl.toString());
                                }
                            }

                            i3++;
                        } else {
                            buf.append(StringFunctions.fixSize(" ", mf.size, ' ', StringFunctions.LEFT));
                        }
                    } else {
                        j--;
                        i3++;
                    }
                }
            }

            if(ic.getEndPackageIndicator()) {
                buf.append("1 ");
            } else {
                buf.append("  ");
            }
            if(ic.getEndPalletSackIndicator()) {
                buf.append("1");
            } else {
                buf.append(" ");
            }
            
            buf.append(StringFunctions.fixSize(ic.getMakeupCode(), 4, '0', StringFunctions.RIGHT));
            buf.append(" ");
            buf.append(outputFileName.substring(outputFileName.length() - 4, outputFileName.length()));
            buf.append((new StringBuilder(String.valueOf(StringFunctions.fixSize(String.valueOf(rec_count++), 5, '0', StringFunctions.RIGHT)))).append("   ").toString());
            buf.append(StringFunctions.fixSize(ic.getMagazineLabel().addressLine1, 4, ' ', StringFunctions.RIGHT));
            buf.append("00");
            
            if(ic.getMagazineLabel().barcode.length() > 0) {
                String barcode = ic.getMagazineLabel().barcode;
                if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                    buf.append(StringFunctions.fixSize(barcode, 72, ' ', StringFunctions.LEFT));
                } else {
                    buf.append(StringFunctions.fixSize(barcode, 72, ' ', StringFunctions.RIGHT));
                }
            } else {
                buf.append(StringFunctions.fixSize(" ", 72, ' ', StringFunctions.LEFT));
            }
        }
        catch(Exception ex) {
            LogWriter.writeLog(ex);
        }
        return buf.toString();
    }


    protected String formatDataDYB(IssueCustomer ic) {
        
    	StringBuffer buf = new StringBuffer(1024);
        try
        {
            LabelLine8 = PropertyBroker.getProperty("LabelLine8");
            LL8Override = PropertyBroker.getProperty("LL8Override");
            nonLL8Plant = PropertyBroker.getProperty("nonLL8Plant");
            String oldLL8 = PropertyBroker.getProperty("oldLL8");
            magCode = mag.getMagCode();
            String labelLine = null;
            
            if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
                    buf.append(StringFunctions.fixSize("TATFTFDTFFFFTTTTTTTTTTDDFADTFDTDTATADFATTFFTTTTTAADDFFATATDADAFTT".toUpperCase(), 109, ' ', StringFunctions.LEFT));
                } else {
                    buf.append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), 109, ' ', StringFunctions.LEFT));
                }
                
            } else {
            	if(ic.getMagazineLabel().endorsementLine.equals("PROFILE COPY")) {
                    buf.append(StringFunctions.fixSize("TATFTFDTFFFFTTTTTTTTTTDDFADTFDTDTATADFATTFFTTTTTAADDFFATATDADAFTT".toUpperCase(), 109, ' ', StringFunctions.RIGHT));
                } else {
                    buf.append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), 109, ' ', StringFunctions.RIGHT));
                }
            	
            }
            	
            
            
            if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
            {
                for(int i = 2; i <= 8; i++) {
                    if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                        labelLine = ic.getMagazineLabel().getTextLine(i).substring(0, trimSize);
                    } else {
                        labelLine = StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(i), trimSize, ' ', StringFunctions.RIGHT);
                    }
                    buf.append(labelLine);
                }

            } else {
                for(int i = 1; i <= 6; i++) {
                    if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                        labelLine = ic.getMagazineLabel().getTextLine(i).substring(0, trimSize);
                    } else {
                        labelLine = StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(i), trimSize, ' ', StringFunctions.RIGHT);
                    }
                    buf.append(labelLine);
                }

            }
            
            int numberOfMessages = ic.getNumberOfMessages();
            Vector allMessages = ic.getMessages();
            Message m = null;
            String msgfamilyNumber = null;
            MessageParameter msgp = null;
            MessageFamily mf = null;
            int i3 = 0;
            for(int j = 0; j < messageFamilies.size(); j++) {
                mf = (MessageFamily)messageFamilies.elementAt(j);
                if(numberOfMessages == 0) {
                    buf.append(StringFunctions.fixSize(" ", mf.size, ' ', StringFunctions.LEFT));
                } else if(i3 >= numberOfMessages) {
                    numberOfMessages = 0;
                    j--;
                } else {
                    m = (Message)allMessages.elementAt(i3);
                    msgfamilyNumber = (new StringBuilder(String.valueOf(m.getMessageFamily()))).append(m.getMessageNumber()).toString();
                    msgp = (MessageParameter)msgparms.get(msgfamilyNumber);
                    if(!msgp.isCoverMessage()) {
                        if(m.getMessageFamily().equals(mf.familyNumber)) {
                            int numberOfMsgTextLines = m.getNumberOfTextLines();
                            Vector m_TextLines = m.getTextLines();
                            int k = 0;
                            for(k = 0; k < numberOfMsgTextLines; k++) {
                                TextLine tl = (TextLine)m_TextLines.elementAt(k);
                                buf.append(tl.toString());
                            }

                            for(int pad = k; pad < mf.numLines; pad++) {
                                TextLine tl = new TextLine(msgp.getLineLength(pad), -4, pad, " ");
                                tl.justify();
                                if(LabelLine8.indexOf(magCode) >= 0) {
                                    LogWriter.writeLog((new StringBuilder("buf 0")).append(buf).toString());
                                    buf.append(" ");
                                    LogWriter.writeLog((new StringBuilder("buf 1")).append(buf).toString());
                                    buf.append(m.getTextLine(0));
                                    LogWriter.writeLog((new StringBuilder("buf 2")).append(buf).toString());
                                    buf.append(m.getTextLine(1));
                                    LogWriter.writeLog((new StringBuilder("buf 3")).append(buf).toString());
                                    buf.append(m.getTextLine(2));
                                    LogWriter.writeLog((new StringBuilder("buf 4")).append(buf).toString());
                                    allMessages.addElement(" ");
                                    LogWriter.writeLog((new StringBuilder("buf 5")).append(buf).toString());
                                    buf.append(m.getTextLine(3));
                                    LogWriter.writeLog((new StringBuilder("buf 6")).append(buf).toString());
                                    buf.append(m.getTextLine(4));
                                    buf.append(m.getTextLine(5));
                                    LogWriter.writeLog((new StringBuilder("buf 7")).append(buf).toString());
                                } else {
                                    buf.append(tl.toString());
                                }
                            }

                            i3++;
                        } else {
                            buf.append(StringFunctions.fixSize(" ", mf.size, ' ', StringFunctions.LEFT));
                        }
                    } else {
                        j--;
                        i3++;
                    }
                }
            }

            if(ic.getEndPackageIndicator()) {
                buf.append("1 ");
            } else {
                buf.append("  ");
            }
            if(ic.getEndPalletSackIndicator()) {
                buf.append("1");
            } else {
                buf.append(" ");
            }
            
            buf.append(StringFunctions.fixSize(ic.getMakeupCode().substring(1), 3, '0', StringFunctions.RIGHT));
            buf.append("  ");
            buf.append(outputFileName.substring(outputFileName.length() - 4, outputFileName.length()));
            buf.append((new StringBuilder(String.valueOf(StringFunctions.fixSize(String.valueOf(rec_count++), 5, '0', StringFunctions.RIGHT)))).append("   ").toString());
            buf.append(StringFunctions.fixSize(ic.getMagazineLabel().addressLine1, 4, ' ', StringFunctions.RIGHT));
            buf.append("00");
            
            if(ic.getMagazineLabel().barcode.length() > 0) {
                String barcode = ic.getMagazineLabel().barcode;
                if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
                    buf.append(StringFunctions.fixSize(barcode, 72, ' ', StringFunctions.LEFT));
                } else {
                    buf.append(StringFunctions.fixSize(barcode, 72, ' ', StringFunctions.RIGHT));
                }
            } else {
                buf.append(StringFunctions.fixSize(" ", 72, ' ', StringFunctions.LEFT));
            }
        }
        catch(Exception ex) {
            LogWriter.writeLog(ex);
        }
        return buf.toString();
    }
    
    public static String fixSize(String buffer, int size)
    {
        char buf[] = new char[size];
        int length = buffer.length();
        int pos = length - 1;
        for(int i = size - 1; i >= 0; i--)
        {
            buf[i] = buffer.charAt(pos--);
        }

        return String.valueOf(buf);
    }
}
