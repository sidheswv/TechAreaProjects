package sybilweb.plant.persistence;

/**
 * This type was created in VisualAge.
 */

import java.io.*;
import java.util.*;
import java.lang.*;
import sybilweb.plant.controller.*;

public class PERRYPersistenceIssueCustomer extends PersistenceIssueCustomer {


/// VERSION OF CLASS IN PRODUCTION ////
	public static final String Class_Version_Number = "PR_6.2_REL9.4";

	private static final String profileBar = "TADFDFDAAFFADFDATTDTTTFDATADFDTDTTAATDATATTAAFADFATDDFATAFFDAAFTF";
	private static final String profileBarData = "1003810076600000000095348430709";
	
	GregorianCalendar c = new GregorianCalendar();


	int recordLength = 0;
	int blockLength = 0;
	int numMsgLines = 0;
	int numInkjetLines = 0;
	int rec_count = 1;
	private static char GRP_SEP = '\u001D';
	private static char UNIT_SEP = '\u001F';
	private static char BAR_CODE_SEP = '\u000B';
	private static final int EIBSize = 34;
	char hex_front = '\u0015';
	char hex_rear = '\u0016';
	char left_bracket = '\u005B';
	char right_bracket = '\u005D';


	String linelength;
	int [] lineLengths = new int[24];  // 18 since max is currently 18 lines of print
	int familyNum = 0;
	MessageFamily mf = null;

	private String createHeader() {

	String PlantID = mag.getPlant();
	String header = null;

	if (PlantID.toUpperCase().equals("WTL")) {
		header = createHeaderWTL();
	}
	if (PlantID.toUpperCase().equals("BRB")) {
		header = createHeaderBRB();
	}
	if (PlantID.toUpperCase().equals("STR")) {
		header = createHeaderSTR();
	}
	
	return header;
}
	private String createHeaderBRB() {

	StringBuffer buf = new StringBuffer(1024);

	String linelength;
	int [] lineLengths = new int[24];  // 18 since max is currently 18 lines of print
	int familyNum = 0,j;
	MessageFamily mf = null;
	int recordLength = 0, blockLength = 0, numMsgLines = 0;
	barcodeLength = 12;
	int txtLines = 5;
	LabelLine8 = (String)PropertyBroker.getProperty("LabelLine8");
	magCode = mag.getMagCode();
	String oldLL8 = (String)sybilweb.plant.controller.PropertyBroker.getProperty("oldLL8");
	LL8Override = (String)PropertyBroker.getProperty("LL8Override");
	nonLL8Plant = (String)PropertyBroker.getProperty("nonLL8Plant");

	
//determining the number of text lines to use in the loop
	if ((LabelLine8.indexOf(magCode)>=0) && (LL8Override.equals("false")) && !(nonLL8Plant.indexOf(plant.toUpperCase())>=0) && (RLL5value.equalsIgnoreCase("false")) || (oldLL8.indexOf(magCode)>=0)){
		txtLines = 7;
	}

	
	for (int x = 0; x < 24; x++) {
		if ((x >= 0) && (x <= txtLines)) // label lines
			lineLengths[x] = trimSize;
		else{ // message lines
			if((messageFamilies.size() != 0) && (familyNum < messageFamilies.size())) {
				mf = (MessageFamily)messageFamilies.elementAt(familyNum);
				for (j = 0; j < mf.numLines; j++)
					lineLengths[x++] = mf.getLineLength(j);
				x--;
				numMsgLines += mf.numLines;
				familyNum++;
			}else
				lineLengths[x] = 0;
		}
	}

	for (int x = 0; x < 24; x++)
		recordLength += lineLengths[x];

// increase record length by size of control information for each record
	recordLength = recordLength + 42;
	blockLength = ((16384 / recordLength) * recordLength);


	/*  Volume Label  */

// VOL1 4 characters
	buf.append("VOL1");

// volume id 6 characters
	String dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
	buf.append(StringFunctions.fixSize(dayOfYear,3,'0',StringFunctions.RIGHT));
	buf.append(outputFileName.substring(outputFileName.length()-3,outputFileName.length()));

// filler 27 characters
	buf.append(StringFunctions.fixSize(" ",27,' ',StringFunctions.LEFT));

// owner id 14 characters
	buf.append("Time, Inc. SBT");

// filler 28 characters
	buf.append(StringFunctions.fixSize(" ",28,' ',StringFunctions.LEFT)); // filler

// label standard version 3 characters
	buf.append("3");


	/*  Header 1  */

// HDR1 4 characters
	buf.append("HDR1");

// file id 17 characters
	buf.append("TCS_SYBIL_SYSTEM "); // 17 characters

// file set id 6 characters
	buf.append("PERRY ");

// file section number, file sequence number, generation number all 4 characters
	buf.append("000100010001");

// filler 2 characters
	buf.append("  ");

// creation date
	String year = String.valueOf(c.get(Calendar.YEAR)).substring(2,4);
	buf.append(StringFunctions.fixSize(year,3,'0',StringFunctions.RIGHT));
	buf.append(StringFunctions.fixSize(dayOfYear,3,'0',StringFunctions.RIGHT));
// expire date
	c.add(Calendar.DAY_OF_YEAR,7);
	year = String.valueOf(c.get(Calendar.YEAR)).substring(2,4);
	buf.append(StringFunctions.fixSize(year,3,'0',StringFunctions.RIGHT));
	dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
	buf.append(StringFunctions.fixSize(dayOfYear,3,'0',StringFunctions.RIGHT));

// filler
	buf.append(" ");

// block count 6 characters
	buf.append("000000");

// filler 20 characters
	buf.append(StringFunctions.fixSize(" ",20,' ',StringFunctions.LEFT)); // filler

	/*  Header 2  */
// header 2
	buf.append("HDR2");
// record format
	buf.append("F");
// block length
	buf.append(StringFunctions.fixSize(String.valueOf(blockLength),5,'0',StringFunctions.RIGHT)); // filler
// record Length
	buf.append(StringFunctions.fixSize(String.valueOf(recordLength),5,'0',StringFunctions.RIGHT)); // filler
// filler
	buf.append(StringFunctions.fixSize(" ",35,' ',StringFunctions.LEFT)); // filler

// buffer offset length
	buf.append("00");

// filler
	buf.append(StringFunctions.fixSize(" ",28,' ',StringFunctions.LEFT)); // filler

	/*  User Header Label 1  */

// line descriptors describe the text output

	buf.append("UHL1");
// line desc 1
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[0]),3,'0',StringFunctions.RIGHT);
	buf.append("010000000" + linelength + "0010FR");
// line desc 2
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[1]),3,'0',StringFunctions.RIGHT);
	buf.append("020000000" + linelength + "0010FR");
// line desc 3
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[2]),3,'0',StringFunctions.RIGHT);
	buf.append("030000000" + linelength + "0010FR");

// event indicator 1  consolidation level
	buf.append("7102402");
// event indicator 2  end of pallet
	buf.append("7100101");
// event indicator 3  end of sack
	buf.append("7100201");
// filler
	buf.append(" ");


	/*  User Header Label 2  */

	buf.append("UHL2");
// line desc 4
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[3]),3,'0',StringFunctions.RIGHT);
	buf.append("040000000" + linelength + "0010FR");
// line desc 5
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[4]),3,'0',StringFunctions.RIGHT);
	buf.append("050000000" + linelength + "0010FR");
// line desc 6
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[5]),3,'0',StringFunctions.RIGHT);
	buf.append("060000000" + linelength + "0010FR");

// event indicator 4
	buf.append("71027" + String.valueOf(barcodeLength));
// event indicator 5
	buf.append("0000000");
// event indicator 6
	buf.append("0000000");
// filler
	buf.append(" ");

	/*  User Header Label 3  */

	buf.append("UHL3");
// line desc 7
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[6]),3,'0',StringFunctions.RIGHT);
	buf.append("070000000" + linelength + "0010FR");
	
// line desc 8
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[7]),3,'0',StringFunctions.RIGHT);
	buf.append("080000000" + linelength + "0010FR");

// line desc 9
	if (numMsgLines < 1)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[8]),3,'0',StringFunctions.RIGHT);
		buf.append("090000000" + linelength + "0010FR");
	}

// event indicator 7
	buf.append("0000000");
// event indicator 8
	buf.append("0000000");
// event indicator 9
	buf.append("0000000");
// filler
	buf.append(" ");

   	/*  User Header Label 4  */

	buf.append("UHL4");
// line desc 10
	if (numMsgLines < 2)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[9]),3,'0',StringFunctions.RIGHT);
		buf.append("100000000" + linelength + "0010FR");
	}
// line desc 11
	if (numMsgLines < 3)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[10]),3,'0',StringFunctions.RIGHT);
		buf.append("110000000" + linelength + "0010FR");
	}
// line desc 12
	if (numMsgLines < 4)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[11]),3,'0',StringFunctions.RIGHT);
		buf.append("120000000" + linelength + "0010FR");
	}

// event indicator 10
	buf.append("0000000");
// event indicator 11
	buf.append("0000000");
// event indicator 12
	buf.append("0000000");
// filler
	buf.append(" ");

	/*  User Header Label 5  */

	buf.append("UHL5");
	
// line desc 13
	if (numMsgLines < 5)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[12]),3,'0',StringFunctions.RIGHT);
		buf.append("130000000" + linelength + "0010FR");
	}
// line desc 14
	if (numMsgLines < 6)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[13]),3,'0',StringFunctions.RIGHT);
		buf.append("140000000" + linelength + "0010FR");
	}
// line desc 15
	if (numMsgLines < 7)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[14]),3,'0',StringFunctions.RIGHT);
		buf.append("150000000" + linelength + "0010FR");
	}


// event indicator 13
	buf.append("0000000");
// event indicator 14
	buf.append("0000000");
// event indicator 15
	buf.append("0000000");
// filler
	buf.append(" ");

	/*  User Header Label 6  */

	buf.append("UHL6");
// line desc 16
	if (numMsgLines < 8)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[15]),3,'0',StringFunctions.RIGHT);
		buf.append("160000000" + linelength + "0010FR");
	}
// line desc 17
	if (numMsgLines < 9)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[16]),3,'0',StringFunctions.RIGHT);
		buf.append("170000000" + linelength + "0010FR");
	}
// line desc 18
	if (numMsgLines < 10)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[17]),3,'0',StringFunctions.RIGHT);
		buf.append("180000000" + linelength + "0010FR");
	}

// event indicator 16
	buf.append("0000000");
// event indicator 17
	buf.append("0000000");
// event indicator 18
	buf.append("0000000");
// filler
	buf.append(" ");

	/*  User Header Label 7  */

	buf.append("UHL7");
// miminum stack size
	buf.append("##");
// max stack size
	buf.append("###");
//  over stack limit
	buf.append("###");
// compensate count
	buf.append("##");
// format
	buf.append("1");
// record_id_number1 is location of volumeid in control line
	buf.append("7100802");
// record is number 2 is location of record number
	buf.append("7101006");
//	char    std_msg_blk_count       [2];
	buf.append("00");
//	char    std_msg_count           [3];
	buf.append("000");
//	char    event_ind19             [7];
	buf.append("0000000");
//	char    event_ind20             [7];
	buf.append("0000000");
//	char    event_ind21             [7];
	buf.append("0000000");
//	char    event_ind22             [7];
	buf.append("0000000");
//	char    event_ind23             [7];
	buf.append("0000000");
//	char    event_ind24             [7];
	buf.append("0000000");
//	char    tape_number             [4];  // new for BC1000/2000 compatability
	buf.append(outputFileName.substring(outputFileName.length()-4,outputFileName.length()));

//	char    UHL8                    [4];
	buf.append("UHL8");
//	char    event_ind25             [7]; driver code
	buf.append("7100304");
//	char    event_ind26             [7];
	buf.append("0000000");
//	char    event_ind27             [7];
	buf.append("0000000");
//	char    event_ind28             [7];
	buf.append("0000000");
//	char    event_ind29             [7];  stacker kick
	buf.append("0000000");
//	char    event_ind30             [7];
	buf.append("0000000");
//	char    event_ind31             [7];
	buf.append("0000000");
//	char    event_ind32             [7];
	buf.append("0000000");
//	char    event_ind33             [7];
	buf.append("0000000");
//	char    event_ind34             [7];
	buf.append("0000000");
//	char    filler15                [6];
	buf.append("      ");

	/*  User Header Label 9  */
	buf.append("UHL9");

// line desc 19
	linelength = StringFunctions.fixSize(String.valueOf(30 + barcodeLength),3,'0',StringFunctions.RIGHT);
	buf.append("710000000" + linelength + "0010FR");

// line desc 20
	if (numMsgLines < 11)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[18]),3,'0',StringFunctions.RIGHT);
		buf.append("190000000" + linelength + "0010FR");
	}

// line desc 21
	if (numMsgLines < 12)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[19]),3,'0',StringFunctions.RIGHT);
		buf.append("200000000" + linelength + "0010FR");
	}


//	char    event_ind35             [7];
	buf.append("0000000");
//	char    event_ind36             [7];
	buf.append("0000000");
//	char    event_ind37             [7];
	buf.append("0000000");
//	char    filler16                [1];
	buf.append(" ");

 /***************CURRENTLY NOT USED**********************/
/*  User Header Label A  */

//	char    UHLA                    [4];
	buf.append("UHLA");
//	char    line_desc22             [18];
if (numMsgLines < 13)
	buf.append("000000000000000000");
else {
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[20]),3,'0',StringFunctions.RIGHT);
	buf.append("210000000" + linelength + "0010FR");
}

//	char    line_desc23             [18];
if (numMsgLines < 13)
	buf.append("000000000000000000");
else {
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[21]),3,'0',StringFunctions.RIGHT);
	buf.append("220000000" + linelength + "0010FR");
}

//	char    line_desc24             [18];
if (numMsgLines < 13)
	buf.append("000000000000000000");
else {
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[22]),3,'0',StringFunctions.RIGHT);
	buf.append("230000000" + linelength + "0010FR");
}

//	char    event_ind38             [7];
	buf.append("0000000");
//	char    event_ind39             [7];
	buf.append("0000000");
//	char    event_ind40             [7];
	buf.append("0000000");
//	char    filler17                [1];
	buf.append(" ");

 /***************THE ABOVE IS CURRENTLY NOT USED**********************/

	return buf.toString();

}
	private String createHeaderSTR() {

	StringBuffer buf = new StringBuffer(1024);

	String linelength;
	int [] lineLengths = new int[24];  // 18 since max is currently 18 lines of print
	int familyNum = 0,j;
	MessageFamily mf = null;
	int recordLength = 0, blockLength = 0, numMsgLines = 0;
	barcodeLength = 12;
	int txtLines = 5;
	LabelLine8 = (String)PropertyBroker.getProperty("LabelLine8");
	magCode = mag.getMagCode();
	String oldLL8 = (String)sybilweb.plant.controller.PropertyBroker.getProperty("oldLL8");
	LL8Override = (String)PropertyBroker.getProperty("LL8Override");
	nonLL8Plant = (String)PropertyBroker.getProperty("nonLL8Plant");
		
//determining the number of text lines to use in the loop
	if ((LabelLine8.indexOf(magCode)>=0) && (LL8Override.equals("false")) && !(nonLL8Plant.indexOf(plant.toUpperCase())>=0) && (RLL5value.equalsIgnoreCase("false")) || (oldLL8.indexOf(magCode)>=0)){
		txtLines = 7;
	}

	
	for (int x = 0; x < 24; x++) {
		if ((x >= 0) && (x <= txtLines)) // label lines
			lineLengths[x] = trimSize;
		else{ // message lines
			if((messageFamilies.size() != 0) && (familyNum < messageFamilies.size())) {
				mf = (MessageFamily)messageFamilies.elementAt(familyNum);
				for (j = 0; j < mf.numLines; j++)
					lineLengths[x++] = mf.getLineLength(j);
				x--;
				numMsgLines += mf.numLines;
				familyNum++;
			}else
				lineLengths[x] = 0;
		}
	}

	for (int x = 0; x < 24; x++)
		recordLength += lineLengths[x];

// increase record length by size of control information for each record
	recordLength = recordLength + 42;
//	blockLength = ((16384 / recordLength) * recordLength);
	blockLength = (recordLength * 5);

	/*  Volume Label  */

// VOL1 4 characters
	buf.append("VOL1");

// volume id 6 characters
	String dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
	buf.append(StringFunctions.fixSize(dayOfYear,3,'0',StringFunctions.RIGHT));
	buf.append(outputFileName.substring(outputFileName.length()-3,outputFileName.length()));

// filler 27 characters
	buf.append(StringFunctions.fixSize(" ",27,' ',StringFunctions.LEFT));

// owner id 14 characters
	buf.append("Time, Inc. SBT");

// filler 28 characters
	buf.append(StringFunctions.fixSize(" ",28,' ',StringFunctions.LEFT)); // filler

// label standard version 3 characters
	buf.append("3");


	/*  Header 1  */

// HDR1 4 characters
	buf.append("HDR1");

// file id 17 characters
	buf.append("TCS_SYBIL_SYSTEM "); // 17 characters

// file set id 6 characters
	buf.append("PERRY ");

// file section number, file sequence number, generation number all 4 characters
	buf.append("000100010001");

// filler 2 characters
	buf.append("  ");

// creation date
	String year = String.valueOf(c.get(Calendar.YEAR)).substring(2,4);
	buf.append(StringFunctions.fixSize(year,3,'0',StringFunctions.RIGHT));
	buf.append(StringFunctions.fixSize(dayOfYear,3,'0',StringFunctions.RIGHT));
// expire date
	c.add(Calendar.DAY_OF_YEAR,7);
	year = String.valueOf(c.get(Calendar.YEAR)).substring(2,4);
	buf.append(StringFunctions.fixSize(year,3,'0',StringFunctions.RIGHT));
	dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
	buf.append(StringFunctions.fixSize(dayOfYear,3,'0',StringFunctions.RIGHT));

// filler
	buf.append(" ");

// block count 6 characters
	buf.append("000000");

// filler 20 characters
	buf.append(StringFunctions.fixSize(" ",20,' ',StringFunctions.LEFT)); // filler

	/*  Header 2  */
// header 2
	buf.append("HDR2");
// record format
	buf.append("F");
// block length
	buf.append(StringFunctions.fixSize(String.valueOf(blockLength),5,'0',StringFunctions.RIGHT)); // filler
// record Length
	buf.append(StringFunctions.fixSize(String.valueOf(recordLength),5,'0',StringFunctions.RIGHT)); // filler
// filler
	buf.append(StringFunctions.fixSize(" ",35,' ',StringFunctions.LEFT)); // filler

// buffer offset length
	buf.append("00");

// filler
	buf.append(StringFunctions.fixSize(" ",28,' ',StringFunctions.LEFT)); // filler

	/*  User Header Label 1  */

// line descriptors describe the text output

	buf.append("UHL1");
// line desc 1
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[0]),3,'0',StringFunctions.RIGHT);
	buf.append("010000000" + linelength + "0010FR");
// line desc 2
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[1]),3,'0',StringFunctions.RIGHT);
	buf.append("020000000" + linelength + "0010FR");
// line desc 3
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[2]),3,'0',StringFunctions.RIGHT);
	buf.append("030000000" + linelength + "0010FR");

// event indicator 1  consolidation level
	buf.append("7102402");
// event indicator 2  end of pallet
	buf.append("7100101");
// event indicator 3  end of sack
	buf.append("7100201");
// filler
	buf.append(" ");


	/*  User Header Label 2  */

	buf.append("UHL2");
// line desc 4
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[3]),3,'0',StringFunctions.RIGHT);
	buf.append("040000000" + linelength + "0010FR");
// line desc 5
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[4]),3,'0',StringFunctions.RIGHT);
	buf.append("050000000" + linelength + "0010FR");
// line desc 6
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[5]),3,'0',StringFunctions.RIGHT);
	buf.append("060000000" + linelength + "0010FR");

// event indicator 4
	buf.append("71029" + String.valueOf(barcodeLength));
// event indicator 5
	buf.append("0000000");
// event indicator 6
	buf.append("0000000");
// filler
	buf.append(" ");

	/*  User Header Label 3  */

	buf.append("UHL3");
// line desc 7

	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[6]),3,'0',StringFunctions.RIGHT);
	buf.append("070000000" + linelength + "0010FR");

// line desc 8
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[7]),3,'0',StringFunctions.RIGHT);
	buf.append("080000000" + linelength + "0010FR");

// line desc 9
	if (numMsgLines <1)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[8]),3,'0',StringFunctions.RIGHT);
		buf.append("090000000" + linelength + "0010FR");
	}

// event indicator 7
	buf.append("0000000");
// event indicator 8
	buf.append("0000000");
// event indicator 9
	buf.append("0000000");
// filler
	buf.append(" ");

   	/*  User Header Label 4  */

	buf.append("UHL4");
// line desc 10
	if (numMsgLines < 2)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[9]),3,'0',StringFunctions.RIGHT);
		buf.append("100000000" + linelength + "0010FR");
	}
// line desc 11
	if (numMsgLines < 3)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[10]),3,'0',StringFunctions.RIGHT);
		buf.append("110000000" + linelength + "0010FR");
	}
// line desc 12
	if (numMsgLines < 4)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[11]),3,'0',StringFunctions.RIGHT);
		buf.append("120000000" + linelength + "0010FR");
	}

// event indicator 10
	buf.append("0000000");
// event indicator 11
	buf.append("0000000");
// event indicator 12
	buf.append("0000000");
// filler
	buf.append(" ");

	/*  User Header Label 5  */

	buf.append("UHL5");
	
// line desc 13
	if (numMsgLines < 5)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[12]),3,'0',StringFunctions.RIGHT);
		buf.append("130000000" + linelength + "0010FR");
	}
// line desc 14
	if (numMsgLines < 6)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[13]),3,'0',StringFunctions.RIGHT);
		buf.append("140000000" + linelength + "0010FR");
	}
// line desc 15
	if (numMsgLines < 7)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[14]),3,'0',StringFunctions.RIGHT);
		buf.append("150000000" + linelength + "0010FR");
	}


// event indicator 13
	buf.append("0000000");
// event indicator 14
	buf.append("0000000");
// event indicator 15
	buf.append("0000000");
// filler
	buf.append(" ");

	/*  User Header Label 6  */

	buf.append("UHL6");
// line desc 16
	if (numMsgLines < 8)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[15]),3,'0',StringFunctions.RIGHT);
		buf.append("160000000" + linelength + "0010FR");
	}
// line desc 17
	if (numMsgLines < 9)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[16]),3,'0',StringFunctions.RIGHT);
		buf.append("170000000" + linelength + "0010FR");
	}
// line desc 18
	if (numMsgLines < 10)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[17]),3,'0',StringFunctions.RIGHT);
		buf.append("180000000" + linelength + "0010FR");
	}

// event indicator 16
	buf.append("0000000");
// event indicator 17
	buf.append("0000000");
// event indicator 18
	buf.append("0000000");
// filler
	buf.append(" ");

	/*  User Header Label 7  */

	buf.append("UHL7");
// miminum stack size
	buf.append("##");
// max stack size
	buf.append("###");
//  over stack limit
	buf.append("###");
// compensate count
	buf.append("##");
// format
	buf.append("1");
// record_id_number1 is location of volumeid in control line
	buf.append("7100802");
// record is number 2 is location of record number
	buf.append("7101006");
//	char    std_msg_blk_count       [2];
	buf.append("00");
//	char    std_msg_count           [3];
	buf.append("000");
//	char    event_ind19             [7];
	buf.append("0000000");
//	char    event_ind20             [7];
	buf.append("0000000");
//	char    event_ind21             [7];
	buf.append("0000000");
//	char    event_ind22             [7];
	buf.append("0000000");
//	char    event_ind23             [7];
	buf.append("0000000");
//	char    event_ind24             [7];
	buf.append("0000000");
//	char    tape_number             [4];  // new for BC1000/2000 compatability
	buf.append(outputFileName.substring(outputFileName.length()-4,outputFileName.length()));

//	char    UHL8                    [4];
	buf.append("UHL8");
//	char    event_ind25             [7]; driver code
	buf.append("7100304");
//	char    event_ind26             [7];
	buf.append("0000000");
//	char    event_ind27             [7];
	buf.append("0000000");
//	char    event_ind28             [7];
	buf.append("0000000");
//	char    event_ind29             [7];  stacker kick
	buf.append("0000000");
//	char    event_ind30             [7];
	buf.append("0000000");
//	char    event_ind31             [7];
	buf.append("0000000");
//	char    event_ind32             [7];
	buf.append("0000000");
//	char    event_ind33             [7];
	buf.append("0000000");
//	char    event_ind34             [7];
	buf.append("0000000");
//	char    filler15                [6];
	buf.append("      ");

	/*  User Header Label 9  */
	buf.append("UHL9");

// line desc 19
	linelength = StringFunctions.fixSize(String.valueOf(30 + barcodeLength),3,'0',StringFunctions.RIGHT);
	buf.append("710000000" + linelength + "0010FR");

// line desc 20
	if (numMsgLines < 11)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[18]),3,'0',StringFunctions.RIGHT);
		buf.append("190000000" + linelength + "0010FR");
	}

// line desc 21
	if (numMsgLines < 12)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[19]),3,'0',StringFunctions.RIGHT);
		buf.append("200000000" + linelength + "0010FR");
	}


//	char    event_ind35             [7];
	buf.append("0000000");
//	char    event_ind36             [7];
	buf.append("0000000");
//	char    event_ind37             [7];
	buf.append("0000000");
//	char    filler16                [1];
	buf.append(" ");

 /***************CURRENTLY NOT USED**********************/
/*  User Header Label A  */

//	char    UHLA                    [4];
	buf.append("UHLA");
//	char    line_desc22             [18];
if (numMsgLines < 13)
	buf.append("000000000000000000");
else {
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[20]),3,'0',StringFunctions.RIGHT);
	buf.append("210000000" + linelength + "0010FR");
}

//	char    line_desc23             [18];
if (numMsgLines < 13)
	buf.append("000000000000000000");
else {
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[21]),3,'0',StringFunctions.RIGHT);
	buf.append("220000000" + linelength + "0010FR");
}

//	char    line_desc24             [18];
if (numMsgLines < 13)
	buf.append("000000000000000000");
else {
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[22]),3,'0',StringFunctions.RIGHT);
	buf.append("230000000" + linelength + "0010FR");
}

//	char    event_ind38             [7];
	buf.append("0000000");
//	char    event_ind39             [7];
	buf.append("0000000");
//	char    event_ind40             [7];
	buf.append("0000000");
//	char    filler17                [1];
	buf.append(" ");

 /***************THE ABOVE IS CURRENTLY NOT USED**********************/

	return buf.toString();

}
	private String createHeaderWTL() {

	StringBuffer buf = new StringBuffer(1024);

	String linelength;
	int [] lineLengths = new int[18];  // 18 since max is currently 18 lines of print
	int familyNum = 0,j;
	MessageFamily mf = null;
	int recordLength = 0, blockLength = 0, numMsgLines = 0;
	int txtLines = 5;
	LabelLine8 = (String)PropertyBroker.getProperty("LabelLine8");
	magCode = mag.getMagCode();
	String oldLL8 = (String)sybilweb.plant.controller.PropertyBroker.getProperty("oldLL8");
	LL8Override = (String)PropertyBroker.getProperty("LL8Override");
	nonLL8Plant = (String)PropertyBroker.getProperty("nonLL8Plant");
	
//determining the number of text lines to use in the loop
	if ((LabelLine8.indexOf(magCode)>=0) && (LL8Override.equals("false")) && !(nonLL8Plant.indexOf(plant.toUpperCase())>=0) && (RLL5value.equalsIgnoreCase("false")) || (oldLL8.indexOf(magCode)>=0)){
		txtLines = 7;
	}

	
	for (int x = 0; x < 24; x++) {
		if ((x >= 0) && (x <= txtLines)) // label lines
			lineLengths[x] = trimSize;
		else{ // message lines
			if((messageFamilies.size() != 0) && (familyNum < messageFamilies.size())) {
				mf = (MessageFamily)messageFamilies.elementAt(familyNum);
				for (j = 0; j < mf.numLines; j++)
					lineLengths[x++] = mf.getLineLength(j);
				x--;
				numMsgLines += mf.numLines;
				familyNum++;
			}else
				lineLengths[x] = 0;
		}
	}

	for (int x = 0; x < 24; x++)
		recordLength += lineLengths[x];

// increase record length by size of control information for each record
	recordLength = recordLength + 102;
	blockLength = ((16384 / recordLength) * recordLength);


	/*  Volume Label  */

// VOL1 4 characters
	buf.append("VOL1");

// volume id 6 characters
	String dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
	buf.append(StringFunctions.fixSize(dayOfYear,3,'0',StringFunctions.RIGHT));
	buf.append(outputFileName.substring(outputFileName.length()-3,outputFileName.length()));

// filler 27 characters
	buf.append(StringFunctions.fixSize(" ",27,' ',StringFunctions.LEFT));

// owner id 14 characters
	buf.append("Time, Inc. SBT");

// filler 28 characters
	buf.append(StringFunctions.fixSize(" ",28,' ',StringFunctions.LEFT)); // filler

// label standard version 3 characters
	buf.append("3");


	/*  Header 1  */

// HDR1 4 characters
	buf.append("HDR1");

// file id 17 characters
	buf.append("TCS_SYBIL_SYSTEM "); // 17 characters

// file set id 6 characters
	buf.append("PERRY ");

// file section number, file sequence number, generation number all 4 characters
	buf.append("000100010001");

// filler 2 characters
	buf.append("  ");

// creation date
	String year = String.valueOf(c.get(Calendar.YEAR)).substring(2,4);
	buf.append(StringFunctions.fixSize(year,3,'0',StringFunctions.RIGHT));
	buf.append(StringFunctions.fixSize(dayOfYear,3,'0',StringFunctions.RIGHT));
// expire date
	c.add(Calendar.DAY_OF_YEAR,7);
	year = String.valueOf(c.get(Calendar.YEAR)).substring(2,4);
	buf.append(StringFunctions.fixSize(year,3,'0',StringFunctions.RIGHT));
	dayOfYear = String.valueOf(c.get(Calendar.DAY_OF_YEAR));
	buf.append(StringFunctions.fixSize(dayOfYear,3,'0',StringFunctions.RIGHT));

// filler
	buf.append(" ");

// block count 6 characters
	buf.append("000000");

// filler 20 characters
	buf.append(StringFunctions.fixSize(" ",20,' ',StringFunctions.LEFT)); // filler

	/*  Header 2  */
// header 2
	buf.append("HDR2");
// record format
	buf.append("F");
// block length
	buf.append(StringFunctions.fixSize(String.valueOf(blockLength),5,'0',StringFunctions.RIGHT)); // filler
// record Length
	buf.append(StringFunctions.fixSize(String.valueOf(recordLength),5,'0',StringFunctions.RIGHT)); // filler
// filler
	buf.append(StringFunctions.fixSize(" ",35,' ',StringFunctions.LEFT)); // filler

// buffer offset length
	buf.append("00");

// filler
	buf.append(StringFunctions.fixSize(" ",28,' ',StringFunctions.LEFT)); // filler

	/*  User Header Label 1  */

// line descriptors describe the text output

	buf.append("UHL1");
// line desc 1
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[0]),3,'0',StringFunctions.RIGHT);
	buf.append("010000000" + linelength + "0010FR");
// line desc 2
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[1]),3,'0',StringFunctions.RIGHT);
	buf.append("020000000" + linelength + "0010FR");
// line desc 3
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[2]),3,'0',StringFunctions.RIGHT);
	buf.append("030000000" + linelength + "0010FR");

// event indicator 1  consolidation level
	buf.append("7102402");
// event indicator 2  end of pallet
	buf.append("7100101");
// event indicator 3  end of sack
	buf.append("7100201");
// filler
	buf.append(" ");


	/*  User Header Label 2  */

	buf.append("UHL2");
// line desc 4
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[3]),3,'0',StringFunctions.RIGHT);
	buf.append("040000000" + linelength + "0010FR");
// line desc 5
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[4]),3,'0',StringFunctions.RIGHT);
	buf.append("050000000" + linelength + "0010FR");
// line desc 6
	linelength = StringFunctions.fixSize(String.valueOf(lineLengths[5]),3,'0',StringFunctions.RIGHT);
	buf.append("060000000" + linelength + "0010FR");

// event indicator 4
	buf.append("71027" + String.valueOf(barcodeLength));
// event indicator 5
	buf.append("0000000");
// event indicator 6
	buf.append("0000000");
// filler
	buf.append(" ");

	/*  User Header Label 3  */

	buf.append("UHL3");
// line desc 7
	if (numMsgLines < 1)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[6]),3,'0',StringFunctions.RIGHT);
		buf.append("070000000" + linelength + "0010FR");
	}
// line desc 8
	if (numMsgLines < 2)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[7]),3,'0',StringFunctions.RIGHT);
		buf.append("080000000" + linelength + "0010FR");
	}
// line desc 9
	if (numMsgLines < 3)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[8]),3,'0',StringFunctions.RIGHT);
		buf.append("090000000" + linelength + "0010FR");
	}

// event indicator 7
	buf.append("0000000");
// event indicator 8
	buf.append("0000000");
// event indicator 9
	buf.append("0000000");
// filler
	buf.append(" ");

   	/*  User Header Label 4  */

	buf.append("UHL4");
// line desc 10
	if (numMsgLines < 4)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[9]),3,'0',StringFunctions.RIGHT);
		buf.append("100000000" + linelength + "0010FR");
	}
// line desc 11
	if (numMsgLines < 5)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[10]),3,'0',StringFunctions.RIGHT);
		buf.append("110000000" + linelength + "0010FR");
	}
// line desc 12
	if (numMsgLines < 6)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[11]),3,'0',StringFunctions.RIGHT);
		buf.append("120000000" + linelength + "0010FR");
	}

// event indicator 10
	buf.append("0000000");
// event indicator 11
	buf.append("0000000");
// event indicator 12
	buf.append("0000000");
// filler
	buf.append(" ");

	/*  User Header Label 5  */

	buf.append("UHL5");
	
// line desc 13
	if (numMsgLines < 7)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[12]),3,'0',StringFunctions.RIGHT);
		buf.append("130000000" + linelength + "0010FR");
	}
// line desc 14
	if (numMsgLines < 8)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[13]),3,'0',StringFunctions.RIGHT);
		buf.append("140000000" + linelength + "0010FR");
	}
// line desc 15
	if (numMsgLines < 9)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[14]),3,'0',StringFunctions.RIGHT);
		buf.append("150000000" + linelength + "0010FR");
	}


// event indicator 13
	buf.append("0000000");
// event indicator 14
	buf.append("0000000");
// event indicator 15
	buf.append("0000000");
// filler
	buf.append(" ");

	/*  User Header Label 6  */

	buf.append("UHL6");
// line desc 16
	if (numMsgLines < 10)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[15]),3,'0',StringFunctions.RIGHT);
		buf.append("160000000" + linelength + "0010FR");
	}
// line desc 17
	if (numMsgLines < 11)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[16]),3,'0',StringFunctions.RIGHT);
		buf.append("170000000" + linelength + "0010FR");
	}
// line desc 18
	if (numMsgLines < 12)
		buf.append("000000000000000000");
	else {
		linelength = StringFunctions.fixSize(String.valueOf(lineLengths[17]),3,'0',StringFunctions.RIGHT);
		buf.append("180000000" + linelength + "0010FR");
	}

// event indicator 16
	buf.append("0000000");
// event indicator 17
	buf.append("0000000");
// event indicator 18
	buf.append("0000000");
// filler
	buf.append(" ");

	/*  User Header Label 7  */

	buf.append("UHL7");
// miminum stack size
	buf.append("##");
// max stack size
	buf.append("###");
//  over stack limit
	buf.append("###");
// compensate count
	buf.append("##");
// format
	buf.append("1");
// record_id_number1 is location of volumeid in control line
	buf.append("7100802");
// record is number 2 is location of record number
	buf.append("7101006");
//	char    std_msg_blk_count       [2];
	buf.append("00");
//	char    std_msg_count           [3];
	buf.append("000");
//	char    event_ind19             [7];
	buf.append("0000000");
//	char    event_ind20             [7];
	buf.append("0000000");
//	char    event_ind21             [7];
	buf.append("0000000");
//	char    event_ind22             [7];
	buf.append("0000000");
//	char    event_ind23             [7];
	buf.append("0000000");
//	char    event_ind24             [7];
	buf.append("0000000");
//	char    tape_number             [4];  // new for BC1000/2000 compatability
	buf.append(outputFileName.substring(outputFileName.length()-4,outputFileName.length()));

//	char    UHL8                    [4];
	buf.append("UHL8");
//	char    event_ind25             [7]; driver code
	buf.append("7100304");
//	char    event_ind26             [7];
	buf.append("0000000");
//	char    event_ind27             [7];
	buf.append("0000000");
//	char    event_ind28             [7];
	buf.append("0000000");
//	char    event_ind29             [7];  stacker kick
	buf.append("0000000");
//	char    event_ind30             [7];
	buf.append("0000000");
//	char    event_ind31             [7];
	buf.append("0000000");
//	char    event_ind32             [7];
	buf.append("0000000");
//	char    event_ind33             [7];
	buf.append("0000000");
//	char    event_ind34             [7];
	buf.append("0000000");
//	char    filler15                [6];
	buf.append("      ");

	/*  User Header Label 9  */
	buf.append("UHL9");

// line desc 19
	linelength = StringFunctions.fixSize(String.valueOf(30 + barcodeLength),3,'0',StringFunctions.RIGHT);
	buf.append("710000000" + linelength + "0010FR");

// line desc 20
	buf.append(StringFunctions.fixSize("0",18,'0',StringFunctions.RIGHT));
// line desc 21
	buf.append(StringFunctions.fixSize("0",18,'0',StringFunctions.RIGHT));

//	char    event_ind35             [7];
	buf.append("0000000");
//	char    event_ind36             [7];
	buf.append("0000000");
//	char    event_ind37             [7];
	buf.append("0000000");
//	char    filler16                [1];
	buf.append(" ");

 /***************CURRENTLY NOT USED**********************/
/*  User Header Label A  */
/*
//	char    UHLA                    [4];
	buf.append("UHLA");
//	char    line_desc22             [18];
	buf.append(StringFunctions.fixSize("0",18,'0',StringFunctions.RIGHT));
//	char    line_desc23             [18];
	buf.append(StringFunctions.fixSize("0",18,'0',StringFunctions.RIGHT));
//	char    line_desc24             [18];
	buf.append(StringFunctions.fixSize("0",18,'0',StringFunctions.RIGHT));
//	char    event_ind38             [7];
	buf.append("0000000");
//	char    event_ind39             [7];
	buf.append("0000000");
//	char    event_ind40             [7];
	buf.append("0000000");
//	char    filler17                [1];
	buf.append(" ");
*/
 /***************THE ABOVE IS CURRENTLY NOT USED**********************/

	return buf.toString();

}
public void createOutputFile(String prop, String outputFileName ) {
	this.outputFileName = outputFileName;
	outFileName = outputFileName;

	useShortFileName = PropertyBroker.getProperty("useShortFileName","false");
	shortFileName = outputFileName.substring(0,outputFileName.lastIndexOf("/")+1).concat(outputFileName.substring(outputFileName.lastIndexOf(".")+1, outputFileName.length()));
	plant = mag.getPlant().toUpperCase();
	rec_count = 1;
	String FormatterFileConcatText = null;
	FormatterFileConcatText = PropertyBroker.getProperty("FormatterFileConcatText");

	// get value from RLL5 file in input data
	String fileName = null;	
	fileName = sybilweb.plant.controller.PropertyBroker.getProperty("OLDFILEDIR") + mag.getFullPrefix() + ".RLL5";
	File f = new File(fileName);
	BufferedReader fileReader = null;
	if (f.exists()){
		try {
			fileReader = new BufferedReader(new FileReader(fileName));
		} catch (java.io.FileNotFoundException fnfe) {
			sybilweb.plant.controller.LogWriter.writeLog(new Exception(mag.getPrefix() + ": Error opening RLL5 file: File not found: " + fileName));
			return;
		}
	
		try{
			RLL5value = fileReader.readLine();
			sybilweb.plant.controller.LogWriter.writeLog("RLL5value = "+RLL5value);
		}catch(EOFException ee) {
		}	catch(Exception re) {
			sybilweb.plant.controller.LogWriter.writeLog(re);
		}
	}else {
		RLL5value = "false";
	}
// end of RLL5 file code


	if(FormatterFileConcatText == null)
		FormatterFileConcatText = "";
	if (useShortFileName.equals("true"))
		formatShortFileName = true;

		// sets file name based upon whether short or long file name
	if (formatShortFileName){
		shortOutputFileName = prop+shortFileName;

	}else {
		longOutputFileName = prop+mag.getLongFileName()+fileSep+shortFileName;
	}

	//creates temp file based on short or long file name	
	if (formatShortFileName){
			tmpFile = new File(prop + outputFileName + FormatterFileConcatText +".tmp");
	}else {
			tmpFile = new File(longOutputFileName + FormatterFileConcatText +".tmp");
	}


			
	try {
		outputFile = new OutputStreamWriter(new FileOutputStream(tmpFile),"ISO8859_1");				
	}catch (IOException e){
		LogWriter.writeLog(new SybilWarningException(mag.getPrefix() + ": Error creating output file: " + e.getMessage()));
		return;
	}


	// This change is for creating file FileName.add 
	// The outputFileName passed is Mag_name.Group_Num.FileName for handling ReRun
	// for ex: which was passed as TD1884uspsstripcust01.00020.TUS41233 for Rerun changes
	// the output File is created as TUS41233.add for the short name or in.i022104.brb.usps.strip.IUS14347 for the loing name


	if (formatShortFileName){
		shortOutputFileName = prop+shortFileName;

	}else {
		longOutputFileName = prop+mag.getLongFileName()+fileSep+shortFileName;
	}

	
	// Uses different file extension that the WTL plant
	
	if (mag.getPlant().toUpperCase().equals("BRB")) {
		if (formatShortFileName){
			newFile = new File(shortOutputFileName + FormatterFileConcatText +".dat");

		}else{
			newFile = new File(longOutputFileName + FormatterFileConcatText +".dat");
		}
	}
	
	else {
		if (formatShortFileName){
			newFile = new File(shortOutputFileName + FormatterFileConcatText +".dta");
		}else {
			newFile = new File(longOutputFileName + FormatterFileConcatText +".dta");
		}
	}
	
	if (newFile.exists())
		newFile.delete(); 

//	LogWriter.writeLog("I",mag.getPlant().toUpperCase() , newoutputFileName, "Started Formatting");		
		
	String header = createHeader();
	PrintWriter headerFile;
	try {
		if (formatShortFileName){
			headerFile = new PrintWriter(new OutputStreamWriter(new FileOutputStream(shortOutputFileName + FormatterFileConcatText + ".hdr"), "ISO8859_1"));
		}else{
			headerFile = new PrintWriter(new OutputStreamWriter(new FileOutputStream(longOutputFileName + FormatterFileConcatText + ".hdr"), "ISO8859_1"));
		}
		headerFile.print(header);
		headerFile.flush();
		headerFile.close();
	}catch (IOException e){
		LogWriter.writeLog(mag.getPrefix() + ": Error creating output file: " + e.getMessage());
		return;
	}


	return;
}
/**
 * formatData method comment.
 */
protected String formatData(sybilweb.plant.controller.IssueCustomer ic) {

String PlantID = mag.getPlant();
	String data = null;

	if (PlantID.toUpperCase().equals("WTL")) {
		data = formatDataWTL(ic);
	}
	if (PlantID.toUpperCase().equals("BRB")) {
		data = formatDataBRB(ic);
	}
	if (PlantID.toUpperCase().equals("STR")) {
		data = formatDataSTR(ic);
	}

	return data;
}
/**
 * formatData method comment.
 */
protected String formatDataBRB(sybilweb.plant.controller.IssueCustomer ic) {


	StringBuffer buf = new StringBuffer(1024);
	try {
	String tmpbuf = null;
	LabelLine8 = (String)PropertyBroker.getProperty("LabelLine8");
	LL8Override = (String)PropertyBroker.getProperty("LL8Override");
	nonLL8Plant = (String)PropertyBroker.getProperty("nonLL8Plant");
	String oldLL8 = (String)PropertyBroker.getProperty("oldLL8");

	magCode = mag.getMagCode();
	String labelLine = null;
	//***********   Start of label data   *************//
	if ((LabelLine8.indexOf(magCode)>=0) && (LL8Override.equals("false")) && !(nonLL8Plant.indexOf(plant.toUpperCase())>=0) && (RLL5value.equalsIgnoreCase("false")) || (oldLL8.indexOf(magCode)>=0)){
		for (int i = 1; i <= 8; i++) {
			if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT)
				labelLine = ic.getMagazineLabel().getTextLine(i).substring(0,trimSize);
			else {
				labelLine = (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(i),trimSize,' ',StringFunctions.RIGHT));
			}
			buf.append(labelLine);
		}
	}else {
		for (int i = 1; i <= 6; i++) {
			if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT)
				labelLine = ic.getMagazineLabel().getTextLine(i).substring(0,MagazineLabel.MAGAZINELABELSIZE);
			else {
				labelLine = (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(i),trimSize,' ',StringFunctions.LEFT));
			}
			buf.append(labelLine);
		}
	}
		

// message data
		int numberOfMessages = ic.getNumberOfMessages();

		Vector allMessages = ic.getMessages();

		int numberOfMsgTextLines;
		Vector m_TextLines;
		Message m = null;
		String msgfamilyNumber = null;
		MessageParameter msgp = null;
		MessageFamily mf = null;
		int i = 0;

		for (int j = 0; j < messageFamilies.size(); j++) {

			mf = (MessageFamily)messageFamilies.elementAt(j);

			if (numberOfMessages == 0)
				buf.append(StringFunctions.fixSize(" ",mf.size,' ',StringFunctions.LEFT));
			else {

				if (i >= numberOfMessages ) {
					numberOfMessages = 0;
					j--;
				} else{

					m = ((Message)allMessages.elementAt(i));
					msgfamilyNumber = m.getMessageFamily() + m.getMessageNumber();
					msgp = (MessageParameter)msgparms.get(msgfamilyNumber);

					if (!msgp.isCoverMessage()) {

						if (m.getMessageFamily().equals(mf.familyNumber)) {

							numberOfMsgTextLines = m.getNumberOfTextLines();

							m_TextLines = m.getTextLines();

							int k = 0;

							for (k = 0; k < numberOfMsgTextLines; k++) {
								TextLine tl = (TextLine) m_TextLines.elementAt(k);
								buf.append(tl.toString());
							}

					// pad out text lines to maximum for family

							for (int pad = k; pad < mf.numLines; pad++) {
								TextLine tl = new TextLine(msgp.getLineLength(pad),StringFunctions.USE_DEFAULT,pad," ");
								tl.justify();
								buf.append(tl.toString());
							}
							i++;
						} else
							buf.append(StringFunctions.fixSize(" ",mf.size,' ',StringFunctions.LEFT));
					}else{
						j--;
						i++;
					}
				}
			}
		}

//*************RECORD CONTROL INFORMATION***********************//

// end of package and one-up indicators
		if (ic.getEndPackageIndicator())
			buf.append("1");
		else
			buf.append(" ");

		if (ic.getEndPalletSackIndicator())
			buf.append("1");
		else
			buf.append(" ");

// book version
		buf.append(StringFunctions.fixSize(ic.getMakeupCode(),4,'0',StringFunctions.RIGHT));

// stacker kick
		buf.append(" ");  //currently not used.

// constant Filler
		buf.append("01");

// rec_count
		buf.append(StringFunctions.fixSize(String.valueOf(rec_count++),6,'0',StringFunctions.RIGHT));


// First four Characters of the Subscribers name //
		buf.append(StringFunctions.fixSize(ic.getMagazineLabel().customerName,
			4,' ',StringFunctions.RIGHT));

// First four Characters of the address line 1 //
		buf.append(StringFunctions.fixSize(ic.getMagazineLabel().addressLine1,
			4,' ',StringFunctions.RIGHT));

// consolidation level
		buf.append ("00");

// Barcode Position
	//	if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT){
			if (ic.getMagazineLabel().barcode.length() > 0) {
				String barcode = ic.getMagazineLabel().barcode;
				buf.append(StringFunctions.fixSize(""+left_bracket+hex_front+BAR_CODE_SEP+barcode+BAR_CODE_SEP+hex_rear,16,' ',StringFunctions.LEFT));
				buf.append(right_bracket);
			}else{
				buf.append(left_bracket);
				buf.append(StringFunctions.fixSize(" ",15,' ',StringFunctions.LEFT));
				buf.append(right_bracket);
			}
	//	}
/*		if (ic.getMagazineLabel().labelJustification == StringFunctions.RIGHT){
			if (ic.getMagazineLabel().barcode.length() > 0) {
				String barcode = ic.getMagazineLabel().barcode;
				buf.append(StringFunctions.fixSize(""+left_bracket+hex_front+BAR_CODE_SEP+barcode+BAR_CODE_SEP+hex_rear,17,' ',StringFunctions.RIGHT));
				buf.append(right_bracket);
			}else{
				buf.append(left_bracket);
				buf.append(StringFunctions.fixSize(" ",17,' ',StringFunctions.RIGHT));
				buf.append(right_bracket);
			}
		}
*/
		}catch(Exception ex){ LogWriter.writeLog(ex); }
		return buf.toString();
		}
/**
 * formatData method comment.
 */
protected String formatDataSTR(sybilweb.plant.controller.IssueCustomer ic) {


	StringBuffer buf = new StringBuffer(1024);
	try {
	String tmpbuf = null;
	LabelLine8 = (String)PropertyBroker.getProperty("LabelLine8");
	LL8Override = (String)PropertyBroker.getProperty("LL8Override");
	nonLL8Plant = (String)PropertyBroker.getProperty("nonLL8Plant");
	String oldLL8 = (String)PropertyBroker.getProperty("oldLL8");

	magCode = mag.getMagCode();
	String labelLine = null;
//		int num_lines = customer.getMagazineLabel().getNumberOfTextLines();

	if ((LabelLine8.indexOf(magCode)>=0) && (LL8Override.equals("false")) && !(nonLL8Plant.indexOf(plant.toUpperCase())>=0) && (RLL5value.equalsIgnoreCase("false")) || (oldLL8.indexOf(magCode)>=0)){
		for (int i = 1; i <= 8; i++) {
			if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT)
				labelLine = ic.getMagazineLabel().getTextLine(i).substring(0,trimSize);
			else {
				labelLine = (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(i),trimSize,' ',StringFunctions.RIGHT));
			}
			buf.append(labelLine);
		}
	}else {
		for (int i = 1; i <= 6; i++) {
			if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT)
				labelLine = ic.getMagazineLabel().getTextLine(i).substring(0,MagazineLabel.MAGAZINELABELSIZE);
			else {
				labelLine = (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(i),trimSize,' ',StringFunctions.LEFT));
			}
			buf.append(labelLine);
		}
	}
		

// message data
		int numberOfMessages = ic.getNumberOfMessages();

		Vector allMessages = ic.getMessages();

		int numberOfMsgTextLines;
		Vector m_TextLines;
		Message m = null;
		String msgfamilyNumber = null;
		MessageParameter msgp = null;
		MessageFamily mf = null;
		int i = 0;

		for (int j = 0; j < messageFamilies.size(); j++) {

			mf = (MessageFamily)messageFamilies.elementAt(j);

			if (numberOfMessages == 0)
				buf.append(StringFunctions.fixSize(" ",mf.size,' ',StringFunctions.LEFT));
			else {

				if (i >= numberOfMessages ) {
					numberOfMessages = 0;
					j--;
				} else{

					m = ((Message)allMessages.elementAt(i));
					msgfamilyNumber = m.getMessageFamily() + m.getMessageNumber();
					msgp = (MessageParameter)msgparms.get(msgfamilyNumber);

					if (!msgp.isCoverMessage()) {

						if (m.getMessageFamily().equals(mf.familyNumber)) {

							numberOfMsgTextLines = m.getNumberOfTextLines();

							m_TextLines = m.getTextLines();

							int k = 0;

							for (k = 0; k < numberOfMsgTextLines; k++) {
								TextLine tl = (TextLine) m_TextLines.elementAt(k);
								buf.append(tl.toString());
							}

					// pad out text lines to maximum for family

							for (int pad = k; pad < mf.numLines; pad++) {
								TextLine tl = new TextLine(msgp.getLineLength(pad),StringFunctions.USE_DEFAULT,pad," ");
								tl.justify();
								buf.append(tl.toString());
							}
							i++;
						} else
							buf.append(StringFunctions.fixSize(" ",mf.size,' ',StringFunctions.LEFT));
					}else{
						j--;
						i++;
					}
				}
			}
		}

//*************RECORD CONTROL INFORMATION***********************//

// end of package and one-up indicators
		if (ic.getEndPackageIndicator())
			buf.append("1");
		else
			buf.append(" ");

		if (ic.getEndPalletSackIndicator())
			buf.append("1");
		else
			buf.append(" ");

// book version
		buf.append(StringFunctions.fixSize(ic.getMakeupCode(),4,'0',StringFunctions.RIGHT));

// stacker kick
		buf.append(" ");  //currently not used.

// constant Filler
		buf.append("01");

//tape number
//		buf.append(outputFileName.substring(outputFileName.length()-4,outputFileName.length()));
// rec_count
		buf.append(StringFunctions.fixSize(String.valueOf(rec_count++),6,'0',StringFunctions.RIGHT));


// First four Characters of the Subscribers name //
		buf.append(StringFunctions.fixSize(ic.getMagazineLabel().customerName,
			4,' ',StringFunctions.RIGHT));

// First four Characters of the address line 1 //
		buf.append(StringFunctions.fixSize(ic.getMagazineLabel().addressLine1,
			4,' ',StringFunctions.RIGHT));

// consolidation level
		buf.append ("00");

// Barcode Position
// add IMB barcode after the postnet barcode 		
	    if(LabelLine8.indexOf(magCode) >= 0 && LL8Override.equals("false") && nonLL8Plant.indexOf(plant.toUpperCase()) < 0 && RLL5value.equalsIgnoreCase("false") || oldLL8.indexOf(magCode) >= 0)
        {
            if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
            	
            	buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcodeData, trimSize, ' ', StringFunctions.LEFT)).toString());
                buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), trimSize, ' ', StringFunctions.LEFT)).toString());
                buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", trimSize, ' ', StringFunctions.LEFT)).toString());
            } else {
            	
            	buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcodeData, trimSize, ' ', StringFunctions.RIGHT)).toString());
                buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", trimSize, ' ', StringFunctions.LEFT)).toString());
                buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), trimSize, ' ', StringFunctions.LEFT)).toString());
            }
        } else {
        	if(ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
        		
        			buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcodeData, trimSize, ' ', StringFunctions.LEFT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), trimSize, ' ', StringFunctions.LEFT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", trimSize, ' ', StringFunctions.LEFT)).toString());
                
            } else {
            	
            		buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcodeData, trimSize, ' ', StringFunctions.RIGHT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(" ", trimSize, ' ', StringFunctions.LEFT)).toString());
                    buf.append((new StringBuilder(String.valueOf(GRP_SEP))).append(StringFunctions.fixSize(ic.getMagazineLabel().imbBarcode.toUpperCase(), trimSize, ' ', StringFunctions.LEFT)).toString());
        }}
	//	if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT){
	 		if (ic.getMagazineLabel().barcode.length() > 0) {
				String barcode = ic.getMagazineLabel().barcode;
				buf.append(StringFunctions.fixSize(""+left_bracket+hex_front+BAR_CODE_SEP+barcode+BAR_CODE_SEP+hex_rear,16,' ',StringFunctions.LEFT));
				buf.append(right_bracket);
			}else{
				buf.append(left_bracket);
				buf.append(StringFunctions.fixSize(" ",15,' ',StringFunctions.LEFT));
				buf.append(right_bracket);
			}
	//	} 
		
/*		if (ic.getMagazineLabel().labelJustification == StringFunctions.RIGHT){
			if (ic.getMagazineLabel().barcode.length() > 0) {
				String barcode = ic.getMagazineLabel().barcode;
				buf.append(StringFunctions.fixSize(""+left_bracket+hex_front+BAR_CODE_SEP+barcode+BAR_CODE_SEP+hex_rear,17,' ',StringFunctions.RIGHT));
				buf.append(right_bracket);
			}else{
				buf.append(left_bracket);
				buf.append(StringFunctions.fixSize(" ",17,' ',StringFunctions.RIGHT));
				buf.append(right_bracket);
			}
		}
*/
		}catch(Exception ex){ LogWriter.writeLog(ex); }
		return buf.toString();
		}
/**
 * formatData method comment.
 */
protected String formatDataWTL(sybilweb.plant.controller.IssueCustomer ic) {


	StringBuffer buf = new StringBuffer(1024);
	try{
	String tmpbuf = null;
	LabelLine8 = (String)PropertyBroker.getProperty("LabelLine8");
	LL8Override = (String)PropertyBroker.getProperty("LL8Override");
	nonLL8Plant = (String)PropertyBroker.getProperty("nonLL8Plant");
	String oldLL8 = (String)PropertyBroker.getProperty("oldLL8");

	magCode = mag.getMagCode();
	String labelLine = null;

/*	if (LabelLine8.indexOf(magCode)>=0){
		for (int i = 1; i <= 8; i++)
			buf.append(ic.getMagazineLabel().getTextLine(i));
	}
	else {
		for (int i = 1; i <= 6; i++)
		buf.append(ic.getMagazineLabel().getTextLine(i));
	}
*/
//***********   Start of label data   *************//
	if ((LabelLine8.indexOf(magCode)>=0) && (LL8Override.equals("false")) && !(nonLL8Plant.indexOf(plant.toUpperCase())>=0) && (RLL5value.equalsIgnoreCase("false")) || (oldLL8.indexOf(magCode)>=0)){
		for (int i = 1; i <= 8; i++) {
			if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT)
				labelLine = ic.getMagazineLabel().getTextLine(i).substring(0,trimSize);
			else {
				labelLine = (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(i),trimSize,' ',StringFunctions.RIGHT));
			}
			buf.append(labelLine);
		}
	}else {
		for (int i = 1; i <= 6; i++) {
			if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT)
				labelLine = ic.getMagazineLabel().getTextLine(i).substring(0,MagazineLabel.MAGAZINELABELSIZE);
			else {
				labelLine = (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(i),trimSize,' ',StringFunctions.LEFT));
			}
			buf.append(labelLine);
		}
	}


// message data
		int numberOfMessages = ic.getNumberOfMessages();

		Vector allMessages = ic.getMessages();

		int numberOfMsgTextLines;
		Vector m_TextLines;
		Message m = null;
		String msgfamilyNumber = null;
		MessageParameter msgp = null;
		MessageFamily mf = null;
		int i = 0;

		for (int j = 0; j < messageFamilies.size(); j++) {

			mf = (MessageFamily)messageFamilies.elementAt(j);

			if (numberOfMessages == 0)
				buf.append(StringFunctions.fixSize(" ",mf.size,' ',StringFunctions.LEFT));
			else {

				if (i >= numberOfMessages ) {
					numberOfMessages = 0;
					j--;
				} else{

					m = ((Message)allMessages.elementAt(i));
					msgfamilyNumber = m.getMessageFamily() + m.getMessageNumber();
					msgp = (MessageParameter)msgparms.get(msgfamilyNumber);

					if (!msgp.isCoverMessage()) {

						if (m.getMessageFamily().equals(mf.familyNumber)) {

							numberOfMsgTextLines = m.getNumberOfTextLines();

							m_TextLines = m.getTextLines();

							int k = 0;

							for (k = 0; k < numberOfMsgTextLines; k++) {
								TextLine tl = (TextLine) m_TextLines.elementAt(k);
								buf.append(tl.toString());
							}

					// pad out text lines to maximum for family

							for (int pad = k; pad < mf.numLines; pad++) {
								TextLine tl = new TextLine(msgp.getLineLength(pad),StringFunctions.USE_DEFAULT,pad," ");
								tl.justify();
								buf.append(tl.toString());
							}
							i++;
						} else
							buf.append(StringFunctions.fixSize(" ",mf.size,' ',StringFunctions.LEFT));
					}else{
						j--;
						i++;
					}
				}
			}
		}

//*************RECORD CONTROL INFORMATION***********************//

// end of package and one-up indicators
		if (ic.getEndPackageIndicator())
			buf.append("1");
		else
			buf.append(" ");

		if (ic.getEndPalletSackIndicator())
			buf.append("1");
		else
			buf.append(" ");

// book version
		buf.append(StringFunctions.fixSize(ic.getMakeupCode(),4,'0',StringFunctions.RIGHT));

// stacker kick
		buf.append(" ");  //currently not used.

// constant Filler
		buf.append("01");

// rec_count
		buf.append(StringFunctions.fixSize(String.valueOf(rec_count++),6,'0',StringFunctions.RIGHT));


// First four Characters of the Subscribers name //
		buf.append(StringFunctions.fixSize(ic.getMagazineLabel().customerName,
			4,' ',StringFunctions.RIGHT));

// First four Characters of the address line 1 //
		buf.append(StringFunctions.fixSize(ic.getMagazineLabel().addressLine1,
			4,' ',StringFunctions.RIGHT));

// consolidation level
		buf.append ("00");

// Barcode Position
		if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT){
			if (ic.getMagazineLabel().barcode.length() > 0) {
				String barcode = ic.getMagazineLabel().barcode;
				buf.append(left_bracket);
				buf.append(StringFunctions.fixSize(""+hex_front+BAR_CODE_SEP+barcode+BAR_CODE_SEP+hex_rear,75,' ',StringFunctions.LEFT));
				buf.append(right_bracket);
			}else{
				buf.append(left_bracket);
				buf.append(StringFunctions.fixSize(" ",75,' ',StringFunctions.LEFT));
				buf.append(right_bracket);
			}
		}
		if (ic.getMagazineLabel().labelJustification == StringFunctions.RIGHT){
			if (ic.getMagazineLabel().barcode.length() > 0) {
				String barcode = ic.getMagazineLabel().barcode;
				buf.append(left_bracket);
				buf.append(StringFunctions.fixSize(""+hex_front+BAR_CODE_SEP+barcode+BAR_CODE_SEP+hex_rear,75,' ',StringFunctions.RIGHT));
				buf.append(right_bracket);
			}else{
				buf.append(left_bracket);
				buf.append(StringFunctions.fixSize(" ",75,' ',StringFunctions.RIGHT));
				buf.append(right_bracket);
			}
		}

		}catch(Exception ex){ LogWriter.writeLog(ex); }
		return buf.toString();
		}
}
