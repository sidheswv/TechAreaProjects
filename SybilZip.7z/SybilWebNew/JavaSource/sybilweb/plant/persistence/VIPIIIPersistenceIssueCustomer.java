package sybilweb.plant.persistence;

/*

Fld	Field Name		Length	Start	End		Comments

1	type				2	2		3		tapeformat type
2	record number		9	4		12		record number
3	zipcode				10	14		23		Zip code; Canadian or Foreign or USPS
4	group,stacker		2	24		25		sort group,stacker/EndPalletSackIndicator
5	list_id				1	26		26		Blank space.
6	makeupcode			4	27		30		MakeUP code
7	Zeros				31	32		62		padded with zeros
	quality buzzer		1	63		63		quality buzzer = 0
8	Data Line 1			100	65		164		Address Text line 1 (endorsement line)
9	Data Line 2			100	166		265		Address Text line 2 (ACS and edition info)
	bundle number		7	267		273		bundle number
10	Data Line 3			100	275		374		Address Text Line 3 (cust name)
11	Data Line 4			100	376		475		Address Text Line 4 (Address line 1)
12	Data Line 5			100	477		576		Address Text Line 5 (address line 2)
13	Data Line 6			100	578		677		Address Text Line 6 (city / province / fsa)
14	Barcode					679				Barcode  Length depends on size of barcode
15	Message Data	depends on size of BC	Mesage line 1-12 varies based on barcode

**** if data uses 8 lines for the label FLDs 8 and above will be as follows *****

8	Data Line 1			100	65		164		Barcode for label
9	Data Line 2			100	166		265		Address Text line 1 (endorsement line)
	Data Line 3			100	267		366		Address Text line 2 (ACS and edition info)
10	bundle number		7	268		374		bundle number
11	Data Line 4			100	376		475		Address Text Line 3 (cust name)
12	Data Line 5			100	477		576		Label Drop In
13	Data Line 6			100	578		677		Address Text Line 4 (Address line 1)
14 	Data Line 7			100	679		778		Address Text Line 5 (address line 2)
15	Data Line 8			100	780		879		Address Text Line 6 (city / province / fsa)
16	Barcode					881				Barcode  Length depends on size of barcode
17	Message Data	depends on size of BC	Mesage line 1-12 varies based on barcode

 */
import java.io.*;
import java.util.*;
import sybilweb.plant.controller.*;
import sybilweb.plant.controller.*;


public class VIPIIIPersistenceIssueCustomer extends PersistenceIssueCustomer {
	
/// VERSION OF CLASS IN PRODUCTION ////
	public static final String Class_Version_Number = "PR_5.7";
	
	
	int rec_count = 1;

	private static char REC_SEP = '\u001E';
	private static char GRP_SEP = '\u001D';
	private static char AUX_SEP = '\u001F';
	private static char UNIT_SEP = '\u001F';
	private static char BAR_CODE_SEP = '\u000B';
	private static final int MESSAGE_SIZE = 77;

/**
 * This method was created by a SmartGuide.
 * @param outputFileName java.lang.String
 */
public void createOutputFile(String prop, String outputFileName ) {
	this.outputFileName = outputFileName;
	outFileName = outputFileName;
	useShortFileName = PropertyBroker.getProperty("useShortFileName","false");
	shortFileName = outputFileName.substring(0,outputFileName.lastIndexOf("/")+1).concat(outputFileName.substring(outputFileName.lastIndexOf(".")+1, outputFileName.length()));
	plant = mag.getPlant().toUpperCase();
	rec_count = 1;
	String FormatterFileConcatText = null;
	
	FormatterFileConcatText = PropertyBroker.getProperty("FormatterFileConcatText");

	if(FormatterFileConcatText == null)
		FormatterFileConcatText = "";
	if (useShortFileName.equals("true"))
		formatShortFileName = true;

		// sets file name based upon whether short or long file name
	if (formatShortFileName){
		shortOutputFileName = prop+shortFileName;

	}else {
		longOutputFileName = prop+mag.getLongFileName()+fileSep+shortFileName;
	}

		
	//creates temp file based on short or long file name	
	if (formatShortFileName){
			tmpFile = new File(prop + outputFileName + FormatterFileConcatText +".tmp");
	}else {
			tmpFile = new File(longOutputFileName + FormatterFileConcatText +".tmp");
	}


	try {
		outputFile = new OutputStreamWriter(new FileOutputStream(tmpFile),"ISO8859_1");		
	}catch (IOException e){
		LogWriter.writeLog(new SybilWarningException(mag.getPrefix() + ": Error creating output file: " + e.getMessage()));
		return;
	}

	// This change is for creating file FileName.add 
	// The outputFileName passed is Mag_name.Group_Num.FileName for handling ReRun
	// for ex: which was passed as TD1884uspsstripcust01.00020.TUS41233 for Rerun changes
	// the output File is created as TUS41233.add for the short name or in.i022104.brb.usps.strip.IUS14347 for the loing name
	

	if (formatShortFileName){
		shortOutputFileName = prop+shortFileName;

	}else {
		longOutputFileName = prop+mag.getLongFileName()+fileSep+shortFileName;
	}

	
	if (formatShortFileName){
		newFile = new File(shortOutputFileName + FormatterFileConcatText +".dat");
	}else {
		newFile = new File(longOutputFileName + FormatterFileConcatText +".dat");
	}

	if (newFile.exists())
		newFile.delete(); 

	LogWriter.writeLog("I", mag.getPlant().toUpperCase(), mag.getPrefix(), outputFileName +" Started Formatting");



	return;
}
/**
 * formatData method comment.
 */
protected String formatData(sybilweb.plant.controller.IssueCustomer ic) {

String PlantID = mag.getPlant();
	String data = null;

	if (PlantID.toUpperCase().equals("CLK")) {
		data = formatDataCLK(ic);
	}
	if (PlantID.toUpperCase().equals("EGV")) {
		data = formatDataEGV(ic);
	}
	if (PlantID.toUpperCase().equals("TOR")) {
		data = formatDataTOR(ic);
	}
	if (PlantID.toUpperCase().equals("DAL")) {
		data = formatDataDAL(ic);
	}
	if (PlantID.toUpperCase().equals("WAS")) {
		data = formatDataWAS(ic);
	}
	if (PlantID.toUpperCase().equals("FLA")) {
		data = formatDataFLA(ic);
	}
	if (PlantID.toUpperCase().equals("EFF")) {
		data = formatDataEFF(ic);
	}
	if (PlantID.toUpperCase().equals("GLG")) {
		data = formatDataGLG(ic);
	}

	return data;
}
/**
 * formatData method comment.
 */
protected String formatDataCLK(sybilweb.plant.controller.IssueCustomer ic) {

/*	private static char REC_SEP = '\u001E';
	private static char GRP_SEP = '\u001D';
	private static char AUX_SEP = '\u001F';
	private static char UNIT_SEP = '\u001F';
*/

	StringBuffer buf = new StringBuffer(1024);
	try{
	LabelLine8 = (String)PropertyBroker.getProperty("LabelLine8");
	magCode = mag.getMagCode();

	buf.append(REC_SEP);
//tapeformat, type
	buf.append("10");
//record number
	buf.append(StringFunctions.fixSize(String.valueOf(rec_count++),9,'0',StringFunctions.RIGHT));
	buf.append(UNIT_SEP);
// search_code
	String zipcode = (StringFunctions.fixSize(ic.getAddress().getZipCode(),6,' ',StringFunctions.LEFT));

	if(!ic.getcontinentCode().equals("")){
		if ((ic.getcontinentCode().charAt(0) >= 'A') && (ic.getcontinentCode().charAt(0) <= 'Y'))
			buf.append(StringFunctions.fixSize(zipcode,10,' ',StringFunctions.LEFT));
		else
			buf.append(StringFunctions.fixSize(zipcode.substring(0,5),10,' ',StringFunctions.LEFT));
	}else{
		
		buf.append(StringFunctions.fixSize(zipcode.substring(0,5),10,' ',StringFunctions.LEFT));
	}	

// sort group,stacker
	String sort_stacker = null;

	if (!ic.getEndPackageIndicator() && !ic.getEndPalletSackIndicator())
		sort_stacker = "00";
	else {
		if (ic.getEndPalletSackIndicator())
			sort_stacker = "21";
		else
			sort_stacker = "11";
	}

	buf.append(sort_stacker);
//list_id
	buf.append(" ");
// makeupcode
	buf.append(StringFunctions.fixSize(ic.getMakeupCode(),4,'0',StringFunctions.RIGHT));
	buf.append(AUX_SEP);
	buf.append(StringFunctions.fixSize("0",31,'0',StringFunctions.LEFT));
// quality buzzer
	buf.append("0");




// label data
/************************************************************************************/
//***** This is used if there is 8 labels lines, otherwise it uses 6 (see below)****//
/***********************************************************************************/
	if (LabelLine8.indexOf(magCode)>=0){

		if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT){
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(1).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(2).substring(0,trimSize));
	// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000)
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			else
				buff = String.valueOf(packageNumber);	

			buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));


			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(3).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(4).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(5).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(6).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(7).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(8).substring(0,trimSize));
	/**** Barcode  justification is left  ****************/

			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(GRP_SEP);
				buf.append(BAR_CODE_SEP);
				buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode,14,' ',StringFunctions.LEFT));
				buf.append(BAR_CODE_SEP);
				}
			else {
				buf.append(GRP_SEP);
				buf.append(BAR_CODE_SEP);
				buf.append("              ");
				buf.append(BAR_CODE_SEP);
			}
	/******************  	 End of Barcode        ****************/

	/******************  	Label Right Justified       ****************/
		}else {
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2),trimSize,' ',StringFunctions.RIGHT)));
	// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000)
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			else
				buff = String.valueOf(packageNumber);	

			buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));


			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(7),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(8),trimSize,' ',StringFunctions.RIGHT)));


			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(GRP_SEP);
				buf.append(BAR_CODE_SEP);
				buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode,14,' ',StringFunctions.RIGHT));
				buf.append(BAR_CODE_SEP);}
			else {
				buf.append(GRP_SEP);
				buf.append(BAR_CODE_SEP);
				buf.append("              ");
				buf.append(BAR_CODE_SEP);
			}
		}
	
/************************************************************************************/
//************************END OF 8 LINE LABEL DATA***************************************//
/***********************************************************************************/

/************************************************************************************/
//***** This is used if there is 6 labels lines, otherwise it uses 6 (see below)****//
/***********************************************************************************/

	}else {

		if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT){
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(1).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(2).substring(0,trimSize));
	// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000)
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			else
				buff = String.valueOf(packageNumber);	

			buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));


			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(3).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(4).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(5).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(6).substring(0,trimSize));
	/**** Barcode  justification is left  ****************/
			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(GRP_SEP);
				buf.append(BAR_CODE_SEP);
				buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode,14,' ',StringFunctions.LEFT));
				buf.append(BAR_CODE_SEP);
				}
			else {
				buf.append(GRP_SEP);
				buf.append(BAR_CODE_SEP);
				buf.append("              ");
				buf.append(BAR_CODE_SEP);
			}
	/******************  	Label Right Justified       ****************/
		}else {
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2),trimSize,' ',StringFunctions.RIGHT)));
	// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000)
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			else
				buff = String.valueOf(packageNumber);	

			buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));


			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6),trimSize,' ',StringFunctions.RIGHT)));


			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(GRP_SEP);
				buf.append(BAR_CODE_SEP);
				buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode,14,' ',StringFunctions.RIGHT));
				buf.append(BAR_CODE_SEP);}
			else {
				buf.append(GRP_SEP);
				buf.append(BAR_CODE_SEP);
				buf.append("              ");
				buf.append(BAR_CODE_SEP);
			}
		}
	}
/************************************************************************************/
//************************END OF 6 LINE LABEL DATA***************************************//
/***********************************************************************************/


// message data
	int numberOfMessages = ic.getNumberOfMessages();

	Vector allMessages = ic.getMessages();

	int numberOfMsgTextLines;
	Vector m_TextLines;
	Message m = null;
	String msgfamilyNumber = null;
	MessageParameter msgp = null;
	MessageFamily mf = null;
	int i = 0;

	for (int j = 0; j < messageFamilies.size(); j++) {
		mf = (MessageFamily)messageFamilies.elementAt(j);

		if (numberOfMessages == 0) {
			for (int padding = 0; padding < mf.numLines; padding++){
				buf.append(GRP_SEP);
				buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
			}
		}else {
			if (i >= numberOfMessages ) {
			   for (int padding = 0; padding < mf.numLines; padding++){
				   	buf.append(GRP_SEP);
					buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
			   }
			}else{
				m = ((Message)allMessages.elementAt(i));
				msgfamilyNumber = m.getMessageFamily() + m.getMessageNumber();
				msgp = (MessageParameter)msgparms.get(msgfamilyNumber);

				if (!msgp.isCoverMessage()) {
					
					if (m.getMessageFamily().equals(mf.familyNumber)) {
						numberOfMsgTextLines = m.getNumberOfTextLines();
						m_TextLines = m.getTextLines();
						int k = 0;
					for (k = 0; k < numberOfMsgTextLines; k++) {
							TextLine tl = (TextLine) m_TextLines.elementAt(k);
							buf.append(GRP_SEP);
							buf.append(StringFunctions.fixSize(tl.toString(),MESSAGE_SIZE,' ',StringFunctions.LEFT));
					}
					// pad out text lines to maximum for family
					for (int pad = k; pad < mf.numLines; pad++) {
						int z= 0;
						buf.append(GRP_SEP);
						buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
						z++;
					}
						i++;
					} else{    // doesn't have this family? insert a blank one
						for (int lineNum = 0; lineNum < mf.numLines; lineNum++) {
							buf.append(GRP_SEP);
							buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
				  		}
					}
				}else{
					j--;
					i++;
				}
			}
		}
	}


	}catch(Exception ex){ LogWriter.writeLog(ex); }	
	return buf.toString();
}
/**
 * formatData method comment.
 */
protected String formatDataDAL(sybilweb.plant.controller.IssueCustomer ic) {

/*	private static char REC_SEP = '\u001E';
	private static char GRP_SEP = '\u001D';
	private static char AUX_SEP = '\u001F';
	private static char UNIT_SEP = '\u001F';
*/
	
	StringBuffer buf = new StringBuffer(1024);
	try{
	String schoolBundling = (String)PropertyBroker.getProperty("schoolBundling","false");
	LabelLine8 = (String)PropertyBroker.getProperty("LabelLine8");
	magCode = mag.getMagCode();
	

	buf.append(REC_SEP);
//tapeformat, type
	buf.append("10");
//record number
	buf.append(StringFunctions.fixSize(String.valueOf(rec_count++),9,'0',StringFunctions.RIGHT));
	buf.append(UNIT_SEP);
// search_code

	String zipcode = (StringFunctions.fixSize(ic.getAddress().getZipCode(),6,' ',StringFunctions.LEFT));

	if(!ic.getcontinentCode().equals("")){
		if ((ic.getcontinentCode().charAt(0) >= 'A') && (ic.getcontinentCode().charAt(0) <= 'Y'))
			buf.append(StringFunctions.fixSize(zipcode,10,' ',StringFunctions.LEFT));
		else
			buf.append(StringFunctions.fixSize(zipcode.substring(0,5),10,' ',StringFunctions.LEFT));
	}else{
		
		buf.append(StringFunctions.fixSize(zipcode.substring(0,5),10,' ',StringFunctions.LEFT));
	}	
	
// sort group,stacker
	String sort_stacker = null;

	if (!ic.getEndPackageIndicator() && !ic.getEndPalletSackIndicator())
		sort_stacker = "00";
	else {
		if (ic.getEndPalletSackIndicator())
			sort_stacker = "21";
		else
			sort_stacker = "11";
	}

	buf.append(sort_stacker);
//list_id
	buf.append(" ");
// makeupcode
	buf.append(StringFunctions.fixSize(ic.getMakeupCode(),4,'0',StringFunctions.RIGHT));
	buf.append(AUX_SEP);
	buf.append(StringFunctions.fixSize("0",31,'0',StringFunctions.LEFT));
// quality buzzer
	buf.append("0");




// label data
/************************************************************************************/
//***** This is used if there is 8 labels lines, otherwise it uses 6 (see below)****//
/***********************************************************************************/

	if (LabelLine8.indexOf(magCode)>=0){

		if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT){
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(1).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(2).substring(0,trimSize));
		// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000){
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			}
			else{
				buff = String.valueOf(packageNumber);
			}
			if ((ic.getMagazineLabel().magCode.equalsIgnoreCase("TK")) && (schoolBundling.equalsIgnoreCase("true"))){
				buf.append(UNIT_SEP + StringFunctions.fixSize(ic.getMagazineLabel().classSeqNumber,9,' ',StringFunctions.RIGHT));
				buf.append("/");
				buf.append(StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));
			}else {
				buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));
			}

	//end of classroom seq number and bundle number


			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(3).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(4).substring(0,trimSize));
		
			/**** Barcode  justification is left it goes on line 4 segment 2   ****************/

			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(UNIT_SEP);
				buf.append(ic.getMagazineLabel().barcode);
			}else {
				buf.append(UNIT_SEP);
				buf.append("              ");
			}

			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(5).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(6).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(7).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(8).substring(0,trimSize));

		}else{

			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2),trimSize,' ',StringFunctions.RIGHT)));

		// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000){
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			}
			else{
				buff = String.valueOf(packageNumber);
			}
			if ((ic.getMagazineLabel().magCode.equalsIgnoreCase("TK")) && (schoolBundling.equalsIgnoreCase("true"))){
				buf.append(UNIT_SEP + StringFunctions.fixSize(ic.getMagazineLabel().classSeqNumber,9,' ',StringFunctions.RIGHT));
				buf.append("/");
				buf.append(StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));
			}else {
				buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));
			}

	//end of classroom seq number and bundle number

			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3),trimSize,' ',StringFunctions.RIGHT)));
	
			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(UNIT_SEP);
				buf.append(ic.getMagazineLabel().barcode);
			}
			else {
				buf.append(UNIT_SEP);
				buf.append("              ");
			}
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(7),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(8),trimSize,' ',StringFunctions.RIGHT)));
		}
/************************************************************************************/
//************************END OF 8 LINE LABEL DATA***************************************//
/***********************************************************************************/

	
/************************************************************************************/
//***** This is used if there is 6 labels lines, otherwise it uses 6 (see below)****//
/***********************************************************************************/

	}else {

		if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT){
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(1).substring(0,trimSize));
		
		// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000){
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			}
			else{
				buff = String.valueOf(packageNumber);
			}
			if ((ic.getMagazineLabel().magCode.equalsIgnoreCase("TK")) && (schoolBundling.equalsIgnoreCase("true"))){
				buf.append(UNIT_SEP);
				buf.append(StringFunctions.fixSize(ic.getMagazineLabel().classSeqNumber,9,' ',StringFunctions.RIGHT));
				buf.append("/");
				buf.append(StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));
			}else {
				buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));
			}

	//end of classroom seq number and bundle number

			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(2).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(3).substring(0,trimSize));
		/**** Barcode  justification is left it goes on line 3 segment 2   ****************/
			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(UNIT_SEP);
				buf.append(ic.getMagazineLabel().barcode);
				}
			else {
				buf.append(UNIT_SEP);
				buf.append("              ");
			}
		
		
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(4).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(5).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(6).substring(0,trimSize));
		}else {
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1),trimSize,' ',StringFunctions.RIGHT)));
	// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000){
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			}
			else{
				buff = String.valueOf(packageNumber);
			}
		
			if ((ic.getMagazineLabel().magCode.equalsIgnoreCase("TK")) && (schoolBundling.equalsIgnoreCase("true"))){
				buf.append(UNIT_SEP);
				buf.append(StringFunctions.fixSize(ic.getMagazineLabel().classSeqNumber,9,' ',StringFunctions.RIGHT));
				buf.append("/");
				buf.append(StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));
			}else {
				buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));
			}
	//end of classroom seq number and bundle number
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2),trimSize,' ',StringFunctions.RIGHT)));
	/**** Barcode  justification is right it goes on line line 2 segment 2   ****************/
			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(UNIT_SEP);
				buf.append(ic.getMagazineLabel().barcode);
			}
			else {
				buf.append(UNIT_SEP);
				buf.append("              ");
			}

			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6),trimSize,' ',StringFunctions.RIGHT)));
		}

	}
/************************************************************************************/
//************************END OF 6 LINE LABEL DATA***************************************//
/***********************************************************************************/


// message data
	int numberOfMessages = ic.getNumberOfMessages();

	Vector allMessages = ic.getMessages();

	int numberOfMsgTextLines;
	Vector m_TextLines;
	Message m = null;
	String msgfamilyNumber = null;
	MessageParameter msgp = null;
	MessageFamily mf = null;
	int i = 0;

	for (int j = 0; j < messageFamilies.size(); j++) {
		mf = (MessageFamily)messageFamilies.elementAt(j);

		if (numberOfMessages == 0) {
			for (int padding = 0; padding < mf.numLines; padding++){
				buf.append(GRP_SEP);
				buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
			}
		}else {
			if (i >= numberOfMessages ) {
			   for (int padding = 0; padding < mf.numLines; padding++){
				   	buf.append(GRP_SEP);
					buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
			   }
			}else{
				m = ((Message)allMessages.elementAt(i));
				msgfamilyNumber = m.getMessageFamily() + m.getMessageNumber();
				msgp = (MessageParameter)msgparms.get(msgfamilyNumber);

				if (!msgp.isCoverMessage()) {
					
					if (m.getMessageFamily().equals(mf.familyNumber)) {
						numberOfMsgTextLines = m.getNumberOfTextLines();
						m_TextLines = m.getTextLines();
						int k = 0;
					for (k = 0; k < numberOfMsgTextLines; k++) {
							TextLine tl = (TextLine) m_TextLines.elementAt(k);
							buf.append(GRP_SEP);
							buf.append(StringFunctions.fixSize(tl.toString(),MESSAGE_SIZE,' ',StringFunctions.LEFT));
					}
					// pad out text lines to maximum for family
					for (int pad = k; pad < mf.numLines; pad++) {
						int z= 0;
						buf.append(GRP_SEP);
						buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
						z++;
					}
						i++;
					} else{    // doesn't have this family? insert a blank one
						for (int lineNum = 0; lineNum < mf.numLines; lineNum++) {
							buf.append(GRP_SEP);
							buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
				  		}
					}
				}else{
					j--;
					i++;
				}
			}
		}
	}

}catch(Exception ex){ LogWriter.writeLog(ex); }

	return buf.toString();
	
}
/**
 * formatData method comment.
 */
protected String formatDataEFF(sybilweb.plant.controller.IssueCustomer ic) {

/*	private static char REC_SEP = '\u001E';
	private static char GRP_SEP = '\u001D';
	private static char AUX_SEP = '\u001F';
	private static char UNIT_SEP = '\u001F';
*/

	StringBuffer buf = new StringBuffer(1024);
	try{
	LabelLine8 = (String)PropertyBroker.getProperty("LabelLine8");
	magCode = mag.getMagCode();

	buf.append(REC_SEP);
//tapeformat, type
	buf.append("10");
//record number
	buf.append(StringFunctions.fixSize(String.valueOf(rec_count++),9,'0',StringFunctions.RIGHT));
	buf.append(UNIT_SEP);
// search_code
	String zipcode = (StringFunctions.fixSize(ic.getAddress().getZipCode(),6,' ',StringFunctions.LEFT));

	if(!ic.getcontinentCode().equals("")){
		if ((ic.getcontinentCode().charAt(0) >= 'A') && (ic.getcontinentCode().charAt(0) <= 'Y'))
			buf.append(StringFunctions.fixSize(zipcode,10,' ',StringFunctions.LEFT));
		else
			buf.append(StringFunctions.fixSize(zipcode.substring(0,5),10,' ',StringFunctions.LEFT));
	}else{
		
		buf.append(StringFunctions.fixSize(zipcode.substring(0,5),10,' ',StringFunctions.LEFT));
	}	

// sort group,stacker
	String sort_stacker = null;

	if (!ic.getEndPackageIndicator() && !ic.getEndPalletSackIndicator())
		sort_stacker = "00";
	else {
		if (ic.getEndPalletSackIndicator())
			sort_stacker = "21";
		else
			sort_stacker = "11";
	}

	buf.append(sort_stacker);
//list_id
	buf.append(" ");
// makeupcode
	buf.append(StringFunctions.fixSize(ic.getMakeupCode(),4,'0',StringFunctions.RIGHT));
	buf.append(AUX_SEP);
	buf.append(StringFunctions.fixSize("0",31,'0',StringFunctions.LEFT));
// quality buzzer
	buf.append("0");




// label data
/************************************************************************************/
//***** This is used if there is 8 labels lines, otherwise it uses 6 (see below)****//
/***********************************************************************************/

	if (LabelLine8.indexOf(magCode)>=0){
		if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT){
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(1).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(2).substring(0,trimSize));
	// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000)
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			else
				buff = String.valueOf(packageNumber);

			buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));


			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(3).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(4).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(5).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(6).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(7).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(8).substring(0,trimSize));

	/**** Barcode  justification is left    ****************/
			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(GRP_SEP);
				buf.append(BAR_CODE_SEP);
				buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode,14,' ',StringFunctions.LEFT));
				buf.append(BAR_CODE_SEP);
				}
			else {
				buf.append(GRP_SEP);
				buf.append(BAR_CODE_SEP);
				buf.append("              ");
				buf.append(BAR_CODE_SEP);
			}

	/******************  	 End of Barcode        ****************/
		}else {
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2),trimSize,' ',StringFunctions.RIGHT)));
	// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000)
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			else
				buff = String.valueOf(packageNumber);

			buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));
	// end of bundle number
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(7),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(8),trimSize,' ',StringFunctions.RIGHT)));

			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(GRP_SEP);
				buf.append(BAR_CODE_SEP);
				buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode,14,' ',StringFunctions.RIGHT));
				buf.append(BAR_CODE_SEP);}
			else {
				buf.append(GRP_SEP);
				buf.append(BAR_CODE_SEP);
				buf.append("              ");
				buf.append(BAR_CODE_SEP);
			}
		}
/************************************************************************************/
//************************END OF 8 LINE LABEL DATA***************************************//
/***********************************************************************************/

/************************************************************************************/
//***** This is used if there is 6 labels lines, otherwise it uses 6 (see below)****//
/***********************************************************************************/

	}else {
		if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT){
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(1).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(2).substring(0,trimSize));
// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000)
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			else
				buff = String.valueOf(packageNumber);		

			buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));

			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(3).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(4).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(5).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(6).substring(0,trimSize));

/**** Barcode  justification is left   ****************/

			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(GRP_SEP);
				buf.append(BAR_CODE_SEP);
				buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode,14,' ',StringFunctions.LEFT));
				buf.append(BAR_CODE_SEP);
				}
			else {
				buf.append(GRP_SEP);
				buf.append(BAR_CODE_SEP);
				buf.append("              ");
				buf.append(BAR_CODE_SEP);
			}

		}else{
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2),trimSize,' ',StringFunctions.RIGHT)));
	// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000)
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			else
				buff = String.valueOf(packageNumber);		

			buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));
	//end of bundle number
	
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6),trimSize,' ',StringFunctions.RIGHT)));
	
			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(GRP_SEP);
				buf.append(BAR_CODE_SEP);
				buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode,14,' ',StringFunctions.RIGHT));
				buf.append(BAR_CODE_SEP);}
			else {
				buf.append(GRP_SEP);
				buf.append(BAR_CODE_SEP);
				buf.append("              ");
				buf.append(BAR_CODE_SEP);
			}
		}
	}
/************************************************************************************/
//************************END OF 6 LINE LABEL DATA***************************************//
/***********************************************************************************/
// message data
	int numberOfMessages = ic.getNumberOfMessages();

	Vector allMessages = ic.getMessages();

	int numberOfMsgTextLines;
	Vector m_TextLines;
	Message m = null;
	String msgfamilyNumber = null;
	MessageParameter msgp = null;
	MessageFamily mf = null;
	int i = 0;

	for (int j = 0; j < messageFamilies.size(); j++) {
		mf = (MessageFamily)messageFamilies.elementAt(j);

		if (numberOfMessages == 0) {
			for (int padding = 0; padding < mf.numLines; padding++){
				buf.append(GRP_SEP);
				buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
			}
		}else {
			if (i >= numberOfMessages ) {
			   for (int padding = 0; padding < mf.numLines; padding++){
				   	buf.append(GRP_SEP);
					buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
			   }
			}else{
				m = ((Message)allMessages.elementAt(i));
				msgfamilyNumber = m.getMessageFamily() + m.getMessageNumber();
				msgp = (MessageParameter)msgparms.get(msgfamilyNumber);

				if (!msgp.isCoverMessage()) {
					
					if (m.getMessageFamily().equals(mf.familyNumber)) {
						numberOfMsgTextLines = m.getNumberOfTextLines();
						m_TextLines = m.getTextLines();
						int k = 0;
					for (k = 0; k < numberOfMsgTextLines; k++) {
							TextLine tl = (TextLine) m_TextLines.elementAt(k);
							buf.append(GRP_SEP);
							buf.append(StringFunctions.fixSize(tl.toString(),MESSAGE_SIZE,' ',StringFunctions.LEFT));
					}
					// pad out text lines to maximum for family
					for (int pad = k; pad < mf.numLines; pad++) {
						int z= 0;
						buf.append(GRP_SEP);
						buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
						z++;
					}
						i++;
					} else{    // doesn't have this family? insert a blank one
						for (int lineNum = 0; lineNum < mf.numLines; lineNum++) {
							buf.append(GRP_SEP);
							buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
				  		}
					}
				}else{
					j--;
					i++;
				}
			}
		}
	}

	}catch(Exception ex){ LogWriter.writeLog(ex); }	
	return buf.toString();
}
/**
 * formatData method comment.
 */
protected String formatDataEGV(sybilweb.plant.controller.IssueCustomer ic) {

/*	private static char REC_SEP = '\u001E';
	private static char GRP_SEP = '\u001D';
	private static char AUX_SEP = '\u001F';
	private static char UNIT_SEP = '\u001F';
*/

	StringBuffer buf = new StringBuffer(1024);
	
	try{
	LabelLine8 = (String)PropertyBroker.getProperty("LabelLine8");
	magCode = mag.getMagCode();

	buf.append(REC_SEP);
//tapeformat, type
	buf.append("10");
//record number
	buf.append(StringFunctions.fixSize(String.valueOf(rec_count++),9,'0',StringFunctions.RIGHT));
	buf.append(UNIT_SEP);
// search_code
	String zipcode = (StringFunctions.fixSize(ic.getAddress().getZipCode(),6,' ',StringFunctions.LEFT));

	if(!ic.getcontinentCode().equals("")){
		if ((ic.getcontinentCode().charAt(0) >= 'A') && (ic.getcontinentCode().charAt(0) <= 'Y'))
			buf.append(StringFunctions.fixSize(zipcode,10,' ',StringFunctions.LEFT));
		else
			buf.append(StringFunctions.fixSize(zipcode.substring(0,5),10,' ',StringFunctions.LEFT));
	}else{
		
		buf.append(StringFunctions.fixSize(zipcode.substring(0,5),10,' ',StringFunctions.LEFT));
	}	
// sort group,stacker
	String sort_stacker = null;

	if (!ic.getEndPackageIndicator() && !ic.getEndPalletSackIndicator())
		sort_stacker = "00";
	else {
		if (ic.getEndPalletSackIndicator())
			sort_stacker = "21";
		else
			sort_stacker = "11";
	}

	buf.append(sort_stacker);
//list_id
	buf.append(" ");
// makeupcode
	buf.append(StringFunctions.fixSize(ic.getMakeupCode(),4,'0',StringFunctions.RIGHT));
	buf.append(AUX_SEP);
	buf.append(StringFunctions.fixSize("0",31,'0',StringFunctions.LEFT));
// quality buzzer
	buf.append("0");




// label data
/************************************************************************************/
//***** This is used if there is 8 labels lines, otherwise it uses 6 (see below)****//
/***********************************************************************************/
	if (LabelLine8.indexOf(magCode)>=0){
		if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT){
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(1).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(2).substring(0,trimSize));
	// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000)
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			else
				buff = String.valueOf(packageNumber);

			buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));


			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(3).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(4).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(5).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(6).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(7).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(8).substring(0,trimSize));

	/**** Barcode  justification is left    ****************/
			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(GRP_SEP);
				buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode,14,' ',StringFunctions.LEFT));
				}
			else {
				buf.append(GRP_SEP);
				buf.append("              ");
			}

		
	/******************  	 End of Barcode        ****************/
		}else {
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2),trimSize,' ',StringFunctions.RIGHT)));

	// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000)
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			else
				buff = String.valueOf(packageNumber);

			buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));
	// end of bundle number
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(7),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(8),trimSize,' ',StringFunctions.RIGHT)));
			
			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(GRP_SEP);
				buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode,14,' ',StringFunctions.RIGHT));
				}
			else {
				buf.append(GRP_SEP);
				buf.append("              ");
				}
		}
/************************************************************************************/
//************************END OF 8 LINE LABEL DATA***************************************//
/***********************************************************************************/
	}else {
/************************************************************************************/
//***** This is used if there is 6 labels lines, otherwise it uses 6 (see below)****//
/***********************************************************************************/
		if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT){
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(1).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(2).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(3).substring(0,trimSize));
			buf.append(UNIT_SEP);
			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(ic.getMagazineLabel().barcode);
				}
			else {
				buf.append(" ");
			}
			
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(4).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(5).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(6).substring(0,trimSize));

		}else {
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(UNIT_SEP);
			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(ic.getMagazineLabel().barcode);
			}
			else {
				buf.append(" ");
			}
			
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6),trimSize,' ',StringFunctions.RIGHT)));
		}
	}

/************************************************************************************/
//************************END OF 6 LINE LABEL DATA***************************************//
/***********************************************************************************/
// message data
	int numberOfMessages = ic.getNumberOfMessages();

	Vector allMessages = ic.getMessages();

	int numberOfMsgTextLines;
	Vector m_TextLines;
	Message m = null;
	String msgfamilyNumber = null;
	MessageParameter msgp = null;
	MessageFamily mf = null;
	int i = 0;

	for (int j = 0; j < messageFamilies.size(); j++) {
		mf = (MessageFamily)messageFamilies.elementAt(j);

		if (numberOfMessages == 0) {
			for (int padding = 0; padding < mf.numLines; padding++){
				buf.append(GRP_SEP);
				buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
			}
		}else {
			if (i >= numberOfMessages ) {
			   for (int padding = 0; padding < mf.numLines; padding++){
				   	buf.append(GRP_SEP);
					buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
			   }
			}else{
				m = ((Message)allMessages.elementAt(i));
				msgfamilyNumber = m.getMessageFamily() + m.getMessageNumber();
				msgp = (MessageParameter)msgparms.get(msgfamilyNumber);

				if (!msgp.isCoverMessage()) {
					
					if (m.getMessageFamily().equals(mf.familyNumber)) {
						numberOfMsgTextLines = m.getNumberOfTextLines();
						m_TextLines = m.getTextLines();
						int k = 0;
					for (k = 0; k < numberOfMsgTextLines; k++) {
							TextLine tl = (TextLine) m_TextLines.elementAt(k);
							buf.append(GRP_SEP);
							buf.append(StringFunctions.fixSize(tl.toString(),MESSAGE_SIZE,' ',StringFunctions.LEFT));
					}
					// pad out text lines to maximum for family
					for (int pad = k; pad < mf.numLines; pad++) {
						int z= 0;
						buf.append(GRP_SEP);
						buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
						z++;
					}
						i++;
					} else{    // doesn't have this family? insert a blank one
						for (int lineNum = 0; lineNum < mf.numLines; lineNum++) {
							buf.append(GRP_SEP);
							buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
				  		}
					}
				}else{
					j--;
					i++;
				}
			}
		}
	}

	}catch(Exception ex){ LogWriter.writeLog(ex); }
	return buf.toString();
}
/**
 * formatData method comment.
 */
protected String formatDataFLA(sybilweb.plant.controller.IssueCustomer ic) {

/*	private static char REC_SEP = '\u001E';
	private static char GRP_SEP = '\u001D';
	private static char AUX_SEP = '\u001F';
	private static char UNIT_SEP = '\u001F';
*/

	StringBuffer buf = new StringBuffer(1024);
	try{
	LabelLine8 = (String)PropertyBroker.getProperty("LabelLine8");
	magCode = mag.getMagCode();

	buf.append(REC_SEP);
//tapeformat, type
	buf.append("10");
//record number
	buf.append(StringFunctions.fixSize(String.valueOf(rec_count++),9,'0',StringFunctions.RIGHT));
	buf.append(UNIT_SEP);
// search_code
	String zipcode = (StringFunctions.fixSize(ic.getAddress().getZipCode(),6,' ',StringFunctions.LEFT));

	if(!ic.getcontinentCode().equals("")){
		if ((ic.getcontinentCode().charAt(0) >= 'A') && (ic.getcontinentCode().charAt(0) <= 'Y'))
			buf.append(StringFunctions.fixSize(zipcode,10,' ',StringFunctions.LEFT));
		else
			buf.append(StringFunctions.fixSize(zipcode.substring(0,5),10,' ',StringFunctions.LEFT));
	}else{
		
		buf.append(StringFunctions.fixSize(zipcode.substring(0,5),10,' ',StringFunctions.LEFT));
	}	

// sort group,stacker
	String sort_stacker = null;

	if (!ic.getEndPackageIndicator() && !ic.getEndPalletSackIndicator())
		sort_stacker = "00";
	else {
		if (ic.getEndPalletSackIndicator())
			sort_stacker = "21";
		else
			sort_stacker = "11";
	}

	buf.append(sort_stacker);
//list_id
	buf.append(" ");
// makeupcode
	buf.append(StringFunctions.fixSize(ic.getMakeupCode(),4,'0',StringFunctions.RIGHT));
	buf.append(AUX_SEP);
	buf.append(StringFunctions.fixSize("0",31,'0',StringFunctions.LEFT));
// quality buzzer
	buf.append("0");




// label data
/************************************************************************************/
//***** This is used if there is 8 labels lines, otherwise it uses 6 (see below)****//
/***********************************************************************************/
	if (LabelLine8.indexOf(magCode)>=0){
		if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT){
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(1).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(2).substring(0,trimSize));
	// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000)
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			else
				buff = String.valueOf(packageNumber);	

			buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));


			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(3).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(4).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(5).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(6).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(7).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(8).substring(0,trimSize));

	/**** Barcode  justification is either left or right    ****************/

			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(GRP_SEP);
				buf.append(BAR_CODE_SEP);
				buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode,14,' ',StringFunctions.LEFT));
				buf.append(BAR_CODE_SEP);
				}
			else {
				buf.append(GRP_SEP);
				buf.append(BAR_CODE_SEP);
				buf.append("              ");
				buf.append(BAR_CODE_SEP);
			}

	/******************  	 End of Barcode        ****************/
		}else {
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2),trimSize,' ',StringFunctions.RIGHT)));
	// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000)
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			else
				buff = String.valueOf(packageNumber);	

			buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));

	// end of bundle number
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(7),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(8),trimSize,' ',StringFunctions.RIGHT)));

			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(GRP_SEP);
				buf.append(BAR_CODE_SEP);
				buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode,14,' ',StringFunctions.RIGHT));
				buf.append(BAR_CODE_SEP);}
			else {
				buf.append(GRP_SEP);
				buf.append(BAR_CODE_SEP);
				buf.append("              ");
				buf.append(BAR_CODE_SEP);
			}
		}
/************************************************************************************/
//************************END OF 8 LINE LABEL DATA***************************************//
/***********************************************************************************/

/************************************************************************************/
//***** This is used if there is 6 labels lines, otherwise it uses 6 (see below)****//
/***********************************************************************************/

	}else {
		if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT){
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(1).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(2).substring(0,trimSize));
	// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000)
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			else
				buff = String.valueOf(packageNumber);

			buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));

			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(3).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(4).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(5).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(6).substring(0,trimSize));

/**** Barcode  justification is left    ****************/
			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(GRP_SEP);
				buf.append(BAR_CODE_SEP);
				buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode,14,' ',StringFunctions.LEFT));
				buf.append(BAR_CODE_SEP);
				}
			else {
				buf.append(GRP_SEP);
				buf.append(BAR_CODE_SEP);
				buf.append("              ");
				buf.append(BAR_CODE_SEP);
			}

		}else {
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2),trimSize,' ',StringFunctions.RIGHT)));

	// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000)
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			else
				buff = String.valueOf(packageNumber);

			buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));

			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6),trimSize,' ',StringFunctions.RIGHT)));
		
			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(GRP_SEP);
				buf.append(BAR_CODE_SEP);
				buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode,14,' ',StringFunctions.RIGHT));
				buf.append(BAR_CODE_SEP);}
			else {
				buf.append(GRP_SEP);
				buf.append(BAR_CODE_SEP);
				buf.append("              ");
				buf.append(BAR_CODE_SEP);
			}
		}
	}
/************************************************************************************/
//************************END OF 6 LINE LABEL DATA***************************************//
/***********************************************************************************/
// message data
	int numberOfMessages = ic.getNumberOfMessages();

	Vector allMessages = ic.getMessages();

	int numberOfMsgTextLines;
	Vector m_TextLines;
	Message m = null;
	String msgfamilyNumber = null;
	MessageParameter msgp = null;
	MessageFamily mf = null;
	int i = 0;

	for (int j = 0; j < messageFamilies.size(); j++) {
		mf = (MessageFamily)messageFamilies.elementAt(j);

		if (numberOfMessages == 0) {
			for (int padding = 0; padding < mf.numLines; padding++){
				buf.append(GRP_SEP);
				buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
			}
		}else {
			if (i >= numberOfMessages ) {
			   for (int padding = 0; padding < mf.numLines; padding++){
				   	buf.append(GRP_SEP);
					buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
			   }
			}else{
				m = ((Message)allMessages.elementAt(i));
				msgfamilyNumber = m.getMessageFamily() + m.getMessageNumber();
				msgp = (MessageParameter)msgparms.get(msgfamilyNumber);

				if (!msgp.isCoverMessage()) {
					
					if (m.getMessageFamily().equals(mf.familyNumber)) {
						numberOfMsgTextLines = m.getNumberOfTextLines();
						m_TextLines = m.getTextLines();
						int k = 0;
					for (k = 0; k < numberOfMsgTextLines; k++) {
							TextLine tl = (TextLine) m_TextLines.elementAt(k);
							buf.append(GRP_SEP);
							buf.append(StringFunctions.fixSize(tl.toString(),MESSAGE_SIZE,' ',StringFunctions.LEFT));
					}
					// pad out text lines to maximum for family
					for (int pad = k; pad < mf.numLines; pad++) {
						int z= 0;
						buf.append(GRP_SEP);
						buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
						z++;
					}
						i++;
					} else{    // doesn't have this family? insert a blank one
						for (int lineNum = 0; lineNum < mf.numLines; lineNum++) {
							buf.append(GRP_SEP);
							buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
				  		}
					}
				}else{
					j--;
					i++;
				}
			}
		}
	}

	}catch(Exception ex){ LogWriter.writeLog(ex); }	
	return buf.toString();
}
/**
 * formatData method comment.
 */
protected String formatDataGLG(sybilweb.plant.controller.IssueCustomer ic) {

/*	private static char REC_SEP = '\u001E';
	private static char GRP_SEP = '\u001D';
	private static char AUX_SEP = '\u001F';
	private static char UNIT_SEP = '\u001F';
*/

	StringBuffer buf = new StringBuffer(1024);
	try{
	trimSize = 45;
	LabelLine8 = (String)PropertyBroker.getProperty("LabelLine8");
	magCode = mag.getMagCode();

/*	buf.append(REC_SEP);
//2 identifies VIP-NT formatter
	buf.append("2");
//P identifies as production record
	buf.append("P");
//record number
	buf.append(StringFunctions.fixSize(String.valueOf(rec_count++),9,'0',StringFunctions.RIGHT));
	buf.append(UNIT_SEP);
// search_code
	String zipcode = (StringFunctions.fixSize(ic.getAddress().getZipCode(),6,' ',StringFunctions.LEFT));

	if(!ic.getcontinentCode().equals("")){
		if ((ic.getcontinentCode().charAt(0) >= 'A') && (ic.getcontinentCode().charAt(0) <= 'Y'))
			buf.append(StringFunctions.fixSize(zipcode,10,' ',StringFunctions.LEFT));
		else
			buf.append(StringFunctions.fixSize(zipcode.substring(0,5),10,' ',StringFunctions.LEFT));
	}else{
		
		buf.append(StringFunctions.fixSize(zipcode.substring(0,5),10,' ',StringFunctions.LEFT));
	}	

// sort group,stacker
	String sort_stacker = null;

	if (!ic.getEndPackageIndicator() && !ic.getEndPalletSackIndicator())
		sort_stacker = "00";
	else {
		if (ic.getEndPalletSackIndicator())
			sort_stacker = "21";
		else
			sort_stacker = "11";
	}

	buf.append(sort_stacker);
//list_id
	buf.append(" ");
// makeupcode
	buf.append(StringFunctions.fixSize(ic.getMakeupCode(),4,'0',StringFunctions.RIGHT));
	buf.append(AUX_SEP);
	buf.append(StringFunctions.fixSize("0",31,'0',StringFunctions.LEFT));
// quality buzzer
	buf.append("0");


*/

// label data
/************************************************************************************/
//***** This is used if there is 8 labels lines, otherwise it uses 6 (see below)****//
/***********************************************************************************/

	if (LabelLine8.indexOf(magCode)>=0){
		if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT){
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(1).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(2).substring(0,trimSize));
/*	// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000)
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			else
				buff = String.valueOf(packageNumber);

			buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));
// end of Bundle number
*/			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(3).substring(0,trimSize));
/*
			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(UNIT_SEP);
				buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode,14,' ',StringFunctions.LEFT));
				}
			else {
				buf.append(UNIT_SEP);
				buf.append("              ");
			}
		
*/			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(4).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(5).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(6).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(7).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(8).substring(0,trimSize));

		}else {
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2),trimSize,' ',StringFunctions.RIGHT)));
/*	// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000)
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			else
				buff = String.valueOf(packageNumber);

			buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));
// end of Bundle number
	
			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(UNIT_SEP);
				buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode,14,' ',StringFunctions.RIGHT));
				}
			else {
				buf.append(UNIT_SEP);
				buf.append("              ");
				}

*/			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(7),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(8),trimSize,' ',StringFunctions.RIGHT)));
		}
/************************************************************************************/
//************************END OF 8 LINE LABEL DATA***************************************//
/***********************************************************************************/
		
	/************************************************************************************/
//***** This is used if there is 6 labels lines, otherwise it uses 6 (see below)****//
/***********************************************************************************/

	}else {
		if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT){
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(1).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(2).substring(0,trimSize));
/*	// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000)
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			else
				buff = String.valueOf(packageNumber);

			buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));

*/			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(3).substring(0,trimSize));
/*
			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(UNIT_SEP);
				buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode,14,' ',StringFunctions.LEFT));
				}
			else {
				buf.append(UNIT_SEP);
				buf.append("              ");
			}

*/			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(4).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(5).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(6).substring(0,trimSize));


		}else{
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2),trimSize,' ',StringFunctions.RIGHT)));
/*	// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000)
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			else
				buff = String.valueOf(packageNumber);

			buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));
//barcode
			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(UNIT_SEP);
				buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode,14,' ',StringFunctions.LEFT));
			}
			else {
				buf.append(UNIT_SEP);
				buf.append("              ");
			}
*/			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6),trimSize,' ',StringFunctions.RIGHT)));
		}
	}
/************************************************************************************/
//************************END OF 6 LINE LABEL DATA***************************************//
/***********************************************************************************/
// message data
/*	int numberOfMessages = ic.getNumberOfMessages();

	Vector allMessages = ic.getMessages();

	int numberOfMsgTextLines;
	Vector m_TextLines;
	Message m = null;
	String msgfamilyNumber = null;
	MessageParameter msgp = null;
	MessageFamily mf = null;
	int i = 0;

	for (int j = 0; j < messageFamilies.size(); j++) {
		mf = (MessageFamily)messageFamilies.elementAt(j);

		if (numberOfMessages == 0) {
			for (int padding = 0; padding < mf.numLines; padding++){
				buf.append(GRP_SEP);
				buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
			}
		}else {
			if (i >= numberOfMessages ) {
			   for (int padding = 0; padding < mf.numLines; padding++){
				   	buf.append(GRP_SEP);
					buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
			   }
			}else{
				m = ((Message)allMessages.elementAt(i));
				msgfamilyNumber = m.getMessageFamily() + m.getMessageNumber();
				msgp = (MessageParameter)msgparms.get(msgfamilyNumber);

				if (!msgp.isCoverMessage()) {
					
					if (m.getMessageFamily().equals(mf.familyNumber)) {
						numberOfMsgTextLines = m.getNumberOfTextLines();
						m_TextLines = m.getTextLines();
						int k = 0;
					for (k = 0; k < numberOfMsgTextLines; k++) {
							TextLine tl = (TextLine) m_TextLines.elementAt(k);
							buf.append(GRP_SEP);
							buf.append(StringFunctions.fixSize(tl.toString(),MESSAGE_SIZE,' ',StringFunctions.LEFT));
					}
					// pad out text lines to maximum for family
					for (int pad = k; pad < mf.numLines; pad++) {
						int z= 0;
						buf.append(GRP_SEP);
						buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
						z++;
					}
						i++;
					} else{    // doesn't have this family? insert a blank one
						for (int lineNum = 0; lineNum < mf.numLines; lineNum++) {
							buf.append(GRP_SEP);
							buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
				  		}
					}
				}else{
					j--;
					i++;
				}
			}
		}
	}
*/
	}catch(Exception ex){ LogWriter.writeLog(ex); }
	buf.append("\n");
	return buf.toString();
}
/**
 * formatData method comment.
 */
protected String formatDataTOR(sybilweb.plant.controller.IssueCustomer ic) {

/*	private static char REC_SEP = '\u001E';
	private static char GRP_SEP = '\u001D';
	private static char AUX_SEP = '\u001F';
	private static char UNIT_SEP = '\u001F';
*/

	StringBuffer buf = new StringBuffer(1024);
	try{
	LabelLine8 = (String)PropertyBroker.getProperty("LabelLine8");
	magCode = mag.getMagCode();

	buf.append(REC_SEP);
//tapeformat, type
	buf.append("10");
//record number
	buf.append(StringFunctions.fixSize(String.valueOf(rec_count++),9,'0',StringFunctions.RIGHT));
	buf.append(UNIT_SEP);
// search_code
	String zipcode = (StringFunctions.fixSize(ic.getAddress().getZipCode(),6,' ',StringFunctions.LEFT));

	if(!ic.getcontinentCode().equals("")){
		if ((ic.getcontinentCode().charAt(0) >= 'A') && (ic.getcontinentCode().charAt(0) <= 'Y'))
			buf.append(StringFunctions.fixSize(zipcode,10,' ',StringFunctions.LEFT));
		else
			buf.append(StringFunctions.fixSize(zipcode.substring(0,5),10,' ',StringFunctions.LEFT));
	}else{
		
		buf.append(StringFunctions.fixSize(zipcode.substring(0,5),10,' ',StringFunctions.LEFT));
	}	

// sort group,stacker
	String sort_stacker = null;

	if (!ic.getEndPackageIndicator() && !ic.getEndPalletSackIndicator())
		sort_stacker = "00";
	else {
		if (ic.getEndPalletSackIndicator())
			sort_stacker = "21";
		else
			sort_stacker = "11";
	}

	buf.append(sort_stacker);
//list_id
	buf.append(" ");
// makeupcode
	buf.append(StringFunctions.fixSize(ic.getMakeupCode(),4,'0',StringFunctions.RIGHT));
	buf.append(AUX_SEP);
	buf.append(StringFunctions.fixSize("0",31,'0',StringFunctions.LEFT));
// quality buzzer
	buf.append("0");




// label data
/************************************************************************************/
//***** This is used if there is 8 labels lines, otherwise it uses 6 (see below)****//
/***********************************************************************************/

	if (LabelLine8.indexOf(magCode)>=0){
		if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT){
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(1).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(2).substring(0,trimSize));
	// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000)
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			else
				buff = String.valueOf(packageNumber);

			buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));
// end of Bundle number
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(3).substring(0,trimSize));

			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(UNIT_SEP);
				buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode,14,' ',StringFunctions.LEFT));
				}
			else {
				buf.append(UNIT_SEP);
				buf.append("              ");
			}
		
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(4).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(5).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(6).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(7).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(8).substring(0,trimSize));

		}else {
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2),trimSize,' ',StringFunctions.RIGHT)));
	// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000)
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			else
				buff = String.valueOf(packageNumber);

			buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));
// end of Bundle number
	
			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(UNIT_SEP);
				buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode,14,' ',StringFunctions.RIGHT));
				}
			else {
				buf.append(UNIT_SEP);
				buf.append("              ");
				}

			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(7),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(8),trimSize,' ',StringFunctions.RIGHT)));
		}
/************************************************************************************/
//************************END OF 8 LINE LABEL DATA***************************************//
/***********************************************************************************/
		
	/************************************************************************************/
//***** This is used if there is 6 labels lines, otherwise it uses 6 (see below)****//
/***********************************************************************************/

	}else {
		if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT){
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(1).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(2).substring(0,trimSize));
	// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000)
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			else
				buff = String.valueOf(packageNumber);

			buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));

			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(3).substring(0,trimSize));

			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(UNIT_SEP);
				buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode,14,' ',StringFunctions.LEFT));
				}
			else {
				buf.append(UNIT_SEP);
				buf.append("              ");
			}

			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(4).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(5).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(6).substring(0,trimSize));


		}else{
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2),trimSize,' ',StringFunctions.RIGHT)));
	// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000)
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			else
				buff = String.valueOf(packageNumber);

			buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));
//barcode
			if (ic.getMagazineLabel().barcode.length() > 0) {
				buf.append(UNIT_SEP);
				buf.append(StringFunctions.fixSize(ic.getMagazineLabel().barcode,14,' ',StringFunctions.LEFT));
			}
			else {
				buf.append(UNIT_SEP);
				buf.append("              ");
			}
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6),trimSize,' ',StringFunctions.RIGHT)));
		}
	}
/************************************************************************************/
//************************END OF 6 LINE LABEL DATA***************************************//
/***********************************************************************************/
// message data
	int numberOfMessages = ic.getNumberOfMessages();

	Vector allMessages = ic.getMessages();

	int numberOfMsgTextLines;
	Vector m_TextLines;
	Message m = null;
	String msgfamilyNumber = null;
	MessageParameter msgp = null;
	MessageFamily mf = null;
	int i = 0;

	for (int j = 0; j < messageFamilies.size(); j++) {
		mf = (MessageFamily)messageFamilies.elementAt(j);

		if (numberOfMessages == 0) {
			for (int padding = 0; padding < mf.numLines; padding++){
				buf.append(GRP_SEP);
				buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
			}
		}else {
			if (i >= numberOfMessages ) {
			   for (int padding = 0; padding < mf.numLines; padding++){
				   	buf.append(GRP_SEP);
					buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
			   }
			}else{
				m = ((Message)allMessages.elementAt(i));
				msgfamilyNumber = m.getMessageFamily() + m.getMessageNumber();
				msgp = (MessageParameter)msgparms.get(msgfamilyNumber);

				if (!msgp.isCoverMessage()) {
					
					if (m.getMessageFamily().equals(mf.familyNumber)) {
						numberOfMsgTextLines = m.getNumberOfTextLines();
						m_TextLines = m.getTextLines();
						int k = 0;
					for (k = 0; k < numberOfMsgTextLines; k++) {
							TextLine tl = (TextLine) m_TextLines.elementAt(k);
							buf.append(GRP_SEP);
							buf.append(StringFunctions.fixSize(tl.toString(),MESSAGE_SIZE,' ',StringFunctions.LEFT));
					}
					// pad out text lines to maximum for family
					for (int pad = k; pad < mf.numLines; pad++) {
						int z= 0;
						buf.append(GRP_SEP);
						buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
						z++;
					}
						i++;
					} else{    // doesn't have this family? insert a blank one
						for (int lineNum = 0; lineNum < mf.numLines; lineNum++) {
							buf.append(GRP_SEP);
							buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
				  		}
					}
				}else{
					j--;
					i++;
				}
			}
		}
	}

	}catch(Exception ex){ LogWriter.writeLog(ex); }
	return buf.toString();
}
/**
 * formatData method comment.
 */
protected String formatDataWAS(sybilweb.plant.controller.IssueCustomer ic) {

/*	private static char REC_SEP = '\u001E';
	private static char GRP_SEP = '\u001D';
	private static char AUX_SEP = '\u001F';
	private static char UNIT_SEP = '\u001F';
*/

	StringBuffer buf = new StringBuffer(1024);
	try{
	LabelLine8 = (String)PropertyBroker.getProperty("LabelLine8");
	magCode = mag.getMagCode();

/**********  calculation of check sum digit for barcode  ****////////
	String barcodeValue = ic.getMagazineLabel().barcode.trim();
	String checkSumDigit = null;
	int checkSumValue;
	boolean test = true;
	String LL8BC = null;

	
	try {
		test = Float.valueOf(barcodeValue).isNaN();
	    }
	catch(Exception ex) {
  
	  
	}

	if (!test){
		if (barcodeValue.equals("")) {
			checkSumDigit = "";
		}
		else {
			int BCDigit = Integer.valueOf(barcodeValue).intValue();
			int BCDSum = 0;
			String checkSum;
		
			for(int i=0; i < ic.getMagazineLabel().barcode.length(); i++){
				int digit = BCDigit%10;
				int temp = BCDigit/10;
				BCDigit = temp;
				BCDSum = BCDSum + digit;
			}	

			String CSDigit = (String)Integer.toString(BCDSum);
			if (CSDigit.length() < 2) {
				int CSTemp = Integer.valueOf(CSDigit).intValue();
				checkSumValue = (10 - CSTemp);
			}
			else{		
				CSDigit = CSDigit.substring(1,2);
				int CSTemp = Integer.valueOf(CSDigit.trim()).intValue();
					checkSumValue = (10 - CSTemp);
			}
			if (checkSumValue == 10) {
				checkSumValue = 0;
			}
			checkSumDigit = Integer.toString(checkSumValue);
			
		}
	}
	
/**********  end of calculation of check sum digit for barcode  ****////////

	

	buf.append(REC_SEP);
//tapeformat, type
	buf.append("10");
//record number
	buf.append(StringFunctions.fixSize(String.valueOf(rec_count++),9,'0',StringFunctions.RIGHT));
	buf.append(UNIT_SEP);
// search_code
	String zipcode = (StringFunctions.fixSize(ic.getAddress().getZipCode(),6,' ',StringFunctions.LEFT));

	if(!ic.getcontinentCode().equals("")){
		if ((ic.getcontinentCode().charAt(0) >= 'A') && (ic.getcontinentCode().charAt(0) <= 'Y'))
			buf.append(StringFunctions.fixSize(zipcode,10,' ',StringFunctions.LEFT));
		else
			buf.append(StringFunctions.fixSize(zipcode.substring(0,5),10,' ',StringFunctions.LEFT));
	}else{
		
		buf.append(StringFunctions.fixSize(zipcode.substring(0,5),10,' ',StringFunctions.LEFT));
	}	

// sort group,stacker
	String sort_stacker = null;

	if (!ic.getEndPackageIndicator() && !ic.getEndPalletSackIndicator())
		sort_stacker = "00";
	else {
		if (ic.getEndPalletSackIndicator())
			sort_stacker = "21";
		else
			sort_stacker = "11";
	}

	buf.append(sort_stacker);
//list_id
	buf.append(" ");
// makeupcode
	buf.append(StringFunctions.fixSize(ic.getMakeupCode(),4,'0',StringFunctions.RIGHT));
	buf.append(AUX_SEP);
	buf.append(StringFunctions.fixSize("0",31,'0',StringFunctions.LEFT));
// quality buzzer
	buf.append("0");




// label data
/************************************************************************************/
//***** This is used if there is 8 labels lines, otherwise it uses 6 (see below)****//
/***********************************************************************************/

	if (LabelLine8.indexOf(magCode)>=0){
		if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT){
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(1).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(2).substring(0,trimSize));
	// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000)
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			else
				buff = String.valueOf(packageNumber);

			buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));

			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(3).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(4).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(5).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(6).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(7).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(8).substring(0,trimSize));

/**** Barcode  justification is either left or right    ****************/

			buf.append(GRP_SEP);
			if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
				if (ic.getMagazineLabel().barcode.length() > 0) {
					buf.append("*"+ ic.getMagazineLabel().barcode + checkSumDigit + "*");
				}
				
			}
			buf.append(GRP_SEP);
			if (ic.getMagazineLabel().labelJustification == StringFunctions.RIGHT) {
				if (ic.getMagazineLabel().barcode.length() > 0) {
					buf.append("*"+ ic.getMagazineLabel().barcode +  checkSumDigit + "*");
				}
			
			}
		}else{
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2),trimSize,' ',StringFunctions.RIGHT)));
	// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000)
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			else
				buff = String.valueOf(packageNumber);

			buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));

			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(7),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(8),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP);
			if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
				if (ic.getMagazineLabel().barcode.length() > 0) {
					buf.append("*"+ ic.getMagazineLabel().barcode + checkSumDigit + "*");
				}
				
			}
			buf.append(GRP_SEP);
			if (ic.getMagazineLabel().labelJustification == StringFunctions.RIGHT) {
				if (ic.getMagazineLabel().barcode.length() > 0) {
					buf.append("*"+ ic.getMagazineLabel().barcode +  checkSumDigit + "*");
				}
				
			}
		}
		}

/************************************************************************************/
//************************END OF 8 LINE LABEL DATA***************************************//
/***********************************************************************************/


/************************************************************************************/
//***** This is used if there is 6 labels lines, otherwise it uses 6 (see below)****//
/***********************************************************************************/

	else {
		if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT){
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(1).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(2).substring(0,trimSize));
// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000)
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			else
				buff = String.valueOf(packageNumber);

			buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));

			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(3).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(4).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(5).substring(0,trimSize));
			buf.append(GRP_SEP + ic.getMagazineLabel().getTextLine(6).substring(0,trimSize));



			buf.append(GRP_SEP);
			if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
				if (ic.getMagazineLabel().barcode.length() > 0) {
					buf.append("*"+ ic.getMagazineLabel().barcode + checkSumDigit + "*");
				}
				
			}
			buf.append(GRP_SEP);
			if (ic.getMagazineLabel().labelJustification == StringFunctions.RIGHT) {
				if (ic.getMagazineLabel().barcode.length() > 0) {
						buf.append("*"+ ic.getMagazineLabel().barcode +  checkSumDigit + "*");
				}
			
			}
		}else {
//
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(1),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(2),trimSize,' ',StringFunctions.RIGHT)));
// bundle number
			int packageNumber = ic.getPackageNumber();
			String buff = null;
			if (packageNumber < 1000)
				buff = StringFunctions.fixSize(String.valueOf(packageNumber),4,'0',StringFunctions.RIGHT);
			else
				buff = String.valueOf(packageNumber);

			buf.append(UNIT_SEP + StringFunctions.fixSize(buff,7,' ',StringFunctions.RIGHT));

			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(3),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(4),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(5),trimSize,' ',StringFunctions.RIGHT)));
			buf.append(GRP_SEP + (StringFunctions.fixSize(ic.getMagazineLabel().getTextLine(6),trimSize,' ',StringFunctions.RIGHT)));
	

			buf.append(GRP_SEP);
			if (ic.getMagazineLabel().labelJustification == StringFunctions.LEFT) {
				if (ic.getMagazineLabel().barcode.length() > 0) {
					buf.append("*"+ ic.getMagazineLabel().barcode + checkSumDigit + "*");
				}
				
			}
			buf.append(GRP_SEP);
			if (ic.getMagazineLabel().labelJustification == StringFunctions.RIGHT) {
				if (ic.getMagazineLabel().barcode.length() > 0) {
					buf.append("*"+ ic.getMagazineLabel().barcode +  checkSumDigit + "*");
				}
				
			}
			}
		}
	
/************************************************************************************/
//************************END OF 6 LINE LABEL DATA***************************************//
/***********************************************************************************/
// message data
	int numberOfMessages = ic.getNumberOfMessages();

	Vector allMessages = ic.getMessages();

	int numberOfMsgTextLines;
	Vector m_TextLines;
	Message m = null;
	String msgfamilyNumber = null;
	MessageParameter msgp = null;
	MessageFamily mf = null;
	int i = 0;

	for (int j = 0; j < messageFamilies.size(); j++) {
		mf = (MessageFamily)messageFamilies.elementAt(j);

		if (numberOfMessages == 0) {
			for (int padding = 0; padding < mf.numLines; padding++){
				buf.append(GRP_SEP);
				buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
			}
		}else {
			if (i >= numberOfMessages ) {
			   for (int padding = 0; padding < mf.numLines; padding++){
				   	buf.append(GRP_SEP);
					buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
			   }
			}else{
				m = ((Message)allMessages.elementAt(i));
				msgfamilyNumber = m.getMessageFamily() + m.getMessageNumber();
				msgp = (MessageParameter)msgparms.get(msgfamilyNumber);

				if (!msgp.isCoverMessage()) {
					
					if (m.getMessageFamily().equals(mf.familyNumber)) {
						numberOfMsgTextLines = m.getNumberOfTextLines();
						m_TextLines = m.getTextLines();
						int k = 0;
					for (k = 0; k < numberOfMsgTextLines; k++) {
							TextLine tl = (TextLine) m_TextLines.elementAt(k);
							buf.append(GRP_SEP);
							buf.append(StringFunctions.fixSize(tl.toString(),MESSAGE_SIZE,' ',StringFunctions.LEFT));
					}
					// pad out text lines to maximum for family
					for (int pad = k; pad < mf.numLines; pad++) {
						int z= 0;
						buf.append(GRP_SEP);
						buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
						z++;
					}
						i++;
					} else{    // doesn't have this family? insert a blank one
						for (int lineNum = 0; lineNum < mf.numLines; lineNum++) {
							buf.append(GRP_SEP);
							buf.append(StringFunctions.fixSize(" ",MESSAGE_SIZE,' ',StringFunctions.LEFT));
				  		}
					}
				}else{
					j--;
					i++;
				}
			}
		}
	}

	}catch(Exception ex){ LogWriter.writeLog(ex); }
	return buf.toString();
}
}
