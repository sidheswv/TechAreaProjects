package sybilweb.plant.persistence;

/**
 * Insert the type's description here.
 * Creation date: (2/12/02 4:33:17 PM)
 * @author: Srikanth Bapanapalli
 */
import java.io.*;
import sybilweb.plant.controller.*;

public class PersistentDefaultLabelPosition {

/**
 * This method was created by a SmartGuide.
 * @return int
 * @param mag sybil.common.model.Magazine
 */
public int loadDefaultLabelPosition (Magazine mag ) {
	//FileInputStream fr = null;
	FileInputStream fis = null;
	InputStreamReader isr = null;
	BufferedReader br = null;
	
	String filename = null;
	char labelPosition = '0';
	String labelLine = null;

	String plant = mag.getPlant().trim();


	String CTLFilePath = PropertyBroker.getProperty("OLDFILEDIR");
	CTLFilePath = CTLFilePath.substring(0,CTLFilePath.lastIndexOf("/"));
	CTLFilePath = CTLFilePath.substring(0,CTLFilePath.lastIndexOf("/"));
	CTLFilePath = CTLFilePath.substring(0,CTLFilePath.lastIndexOf("/")+1);
	CTLFilePath = CTLFilePath.concat(plant.toUpperCase());
	CTLFilePath = CTLFilePath.concat("/InputData/");	

	
	filename = CTLFilePath + mag.getFullPrefix()  + ".DEFAULTLABEL";
	LogWriter.writeLog("filename in PDLP.lDLP  "+filename);
	System.out.println("filename in PDLP.lDLP  "+filename);
	try {
		fis = new FileInputStream(filename);
		isr = new InputStreamReader(fis);
		br = new BufferedReader(isr);
	}
	catch (java.io.FileNotFoundException fnfe) {
		return StringFunctions.USE_DEFAULT;
	}
	
	try {
		labelLine = br.readLine();
		br.close();
		isr.close();
		fis.close();
	}
	catch (Exception e) {
  		LogWriter.writeLog(e);
  	}		

	if (labelLine != null) {
		labelPosition = labelLine.charAt(0);
		if (labelPosition == 'L') {
			return StringFunctions.LEFT;
		}
		else {
			return StringFunctions.RIGHT;
		}
	}
	else {
		return StringFunctions.USE_DEFAULT;
	}
}
/**
 * This method was created by a SmartGuide.
 * @param mag Magazine
 * @param labelPosition int
 */
public void saveDefaultLabelPosition (Magazine mag, int labelPosition) {

	String filename = null;

	String plant = mag.getPlant().trim();


	String CTLFilePath = PropertyBroker.getProperty("OLDFILEDIR");
	CTLFilePath = CTLFilePath.substring(0,CTLFilePath.lastIndexOf("/"));
	CTLFilePath = CTLFilePath.substring(0,CTLFilePath.lastIndexOf("/"));
	CTLFilePath = CTLFilePath.substring(0,CTLFilePath.lastIndexOf("/")+1);
	CTLFilePath = CTLFilePath.concat(plant.toUpperCase());
	CTLFilePath = CTLFilePath.concat("/InputData/");	
	
	filename = CTLFilePath + mag.getFullPrefix()  + ".DEFAULTLABEL";
	
	try {

		FileOutputStream fos = new FileOutputStream(filename);
		OutputStreamWriter osw = new OutputStreamWriter(fos);
		BufferedWriter bw = new BufferedWriter(osw);
		
		if (labelPosition == StringFunctions.LEFT) {
			bw.write("L", 0, 1);
		}
		else {
			bw.write("R", 0, 1);
		}
		bw.newLine();
		bw.close();
		osw.close();
		fos.close();
 	}
	catch (Exception e) {
//  		LogWriter.writeLog(e);
  	}		

	
	return;
}
}
