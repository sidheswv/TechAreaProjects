package sybilweb.plant.controller;

import java.io.*;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.zip.ZipFile;


public class SybilIssueCustomerFileParser extends InputFileParser
{

    public static final String Class_Version_Number = "STM_Jay_PSBULK";
    
    private FileReader fr = null;
	private BufferedReader br = null;
	private IssueCustomer ic = null;
	private String custRec = null;
	private String dName;
	private String fName;
	private int tkSchoolCopyCount = 0;
	

    public SybilIssueCustomerFileParser() {
        
    }

    public BufferedReader getBR() {
        return br;
    }

    public String getIC() {
        return custRec;
    }

    public String getToken(String custLine, int tokenNumber) throws Exception {
    	
    	StringTokenizer st = null;
    	String reqToken = null;
    	if (custLine == null) {
    		return null;
    	} else {
    		try {
    			st = new StringTokenizer(custLine, String.valueOf(sybilweb.plant.controller.IssueCustomer.TOSTRING_DELIMITER));
    			if (st.countTokens() < 22) {
    				LogWriter.writeLog("E", "", "", "Error reading record. Expected 22 fields, found " + st.countTokens() + ":" + custLine);
    				return null;
    			}

    		int tokenCount = 0;

    		while(tokenCount<=tokenNumber){
    			
    			if(tokenCount == tokenNumber){
    				reqToken = st.nextToken();
    				break;
    			}
    			String temp = st.nextToken();
    			tokenCount++;
    		}
    			
    		} catch (Exception e) {
    			LogWriter.writeLog(e);
    			SybilWarningException warning = new SybilWarningException("Error reading customer.");
    			System.out.println(" Customer "+custLine);
    			throw warning;
    		}
    		
    		//		issueCust.setMessages(msgs);
    		//		System.out.println(issueCust.getMagazineLabel().customerName);
    		return reqToken;
    	}
    }


    public static void main(String args[]) {
    	String s;
    	IssueCustomer ic = new IssueCustomer();
    	SybilIssueCustomerFileParser parser = new SybilIssueCustomerFileParser();
    	try {
    		java.util.zip.ZipFile zf = new java.util.zip.ZipFile(args[0]);
    		InputStream zis = zf.getInputStream(zf.getEntry(args[1]));
    		BufferedInputStream bis = new BufferedInputStream(zis);
    		DataInputStream dis = new DataInputStream(bis);
    		java.io.BufferedReader br = new java.io.BufferedReader(new InputStreamReader(zis));
    		try {
    		while (dis.available() > 0) {
    			parser.parseFile(dis, ic,true,true);
    		}
    	} catch (SybilWarningException warning) {
    		System.out.println("readLine has problem.  " + warning.getMessage());
    	}	
    	} catch (Exception e) {
    		e.printStackTrace();
    	}	
    	return;
    }


    public boolean openCustomerFile(String dirName, String fileName) {
        dName = dirName;
        fName = fileName;
        if(dirName != null && fileName != null) {
            try {
                fr = new FileReader((new StringBuilder(String.valueOf(dirName))).append(fileName).toString());
                br = new BufferedReader(fr);
            } catch(IOException e) {
                System.err.println((new StringBuilder("IO exception opening To-Do File ")).append(dirName).append(fileName).toString());
                return false;  }
        } else {
            return false;
        }
        return true;
    }

    public boolean parseFile(BufferedReader bfr, StoragePostalBook storPostBook) throws Exception, IOException {
        
    	StringTokenizer st = null;
        String recLine = null;
        try {
            recLine = bfr.readLine();
        }
        catch(EOFException eofexception) { }
        catch(Exception e) {
            LogWriter.writeLog(e);
        }
        
        if(recLine == null) {
            return false;
        } else {
        	st = new StringTokenizer(recLine, String.valueOf(sybilweb.plant.controller.IssueCustomer.TOSTRING_DELIMITER));
        	if(st.countTokens() < 5){
        		LogWriter.writeLog("E", " ", " ", (new StringBuilder("Error reading record. Expected 5 fields, found ")).append(st.countTokens()).append(":").append(recLine).toString());
                return false;
        	}
        	String recType = st.nextToken().trim();
        	if(recType.equals("P")){
        		storPostBook.setStoragePostalBookFlag("postal");
        	} else {
        		storPostBook.setStoragePostalBookFlag("storage");
        	}
        	storPostBook.setEditionCode(st.nextToken().trim());
            storPostBook.setTCSDriverCode(st.nextToken().trim());
            storPostBook.setRollNumber(st.nextToken().trim());
            storPostBook.setPostalBookNumber(st.nextToken().trim());
            try {
            	storPostBook.setCopyCount(Integer.parseInt(st.nextToken().trim()));
            }catch(Exception exception) { }
        }
        return true;
    }

    public boolean parseFile(DataInputStream in, sybilweb.plant.controller.IssueCustomer issueCust, boolean skipExtraLabeltokens, boolean RLL5fileExists)
        throws Exception  {
        
    	StringTokenizer st = null;
        String custLine = null;
        
        if(lastIn != in) {
            br = new BufferedReader(new InputStreamReader(in,"ISO8859_1"));
            lastIn = in;
        }
        try {
            custLine = br.readLine();
        } catch(EOFException eofexception) { 
    	} catch(Exception e) {
            e.printStackTrace();
        }
        
    	if(custLine == null) {
            return false;
        } else {
            return parseString(custLine, issueCust, skipExtraLabeltokens, RLL5fileExists);
        }
    }

    public boolean parseString(String custLine, sybilweb.plant.controller.IssueCustomer issueCust, boolean skipExtraLabeltokens, boolean RLL5fileExists)
        throws Exception {
        
    	StringTokenizer st = null;
    	String flag = null;
    	String test = null;
    	
        if(custLine == null) {
            return false;
        }
        st = new StringTokenizer(custLine, String.valueOf(sybilweb.plant.controller.IssueCustomer.TOSTRING_DELIMITER));
        if(st.countTokens() < 22) {
        	LogWriter.writeLog("E", "", "", "Error reading record. Expected 22 fields, found " + st.countTokens() + ":" + custLine);
        	return false;
        }
        
        try
        {
            issueCust.setcontinentCode(st.nextToken().trim());
            issueCust.setMakeupCode(st.nextToken().trim());
            issueCust.setEditionCode(st.nextToken().trim());
            issueCust.setBookVersion(st.nextToken());
            issueCust.setNumberCopies(Integer.parseInt(st.nextToken().trim()));
            issueCust.setPalletSackIndicator(st.nextToken().trim());
            issueCust.setPalletSackNumber(Integer.parseInt(st.nextToken()));
            issueCust.setPackageNumber(Integer.parseInt(st.nextToken()));
            String s = st.nextToken();
            if(s.equals("true")) {
                issueCust.setEndPackageIndicator(true);
            } else {
                issueCust.setEndPackageIndicator(false);
            }
            s = st.nextToken();
            if(s.equals("true")) {
                issueCust.setEndPalletSackIndicator(true);
            } else {
                issueCust.setEndPalletSackIndicator(false);
            }
            issueCust.setAlphaExpireDate(st.nextToken().trim());
			issueCust.setBindingGroupName(st.nextToken().trim());
            issueCust.setCustomerName(st.nextToken().trim());
            issueCust.setbraceID(st.nextToken().trim());
            issueCust.setdopID(st.nextToken().trim());
            issueCust.setrollID(st.nextToken().trim());
            issueCust.setalphaPlantCode(st.nextToken().trim());
            issueCust.settrafficCode(st.nextToken().trim());
            issueCust.setTCSKeyline(st.nextToken().trim());
            issueCust.setNumberOfMessages(Integer.parseInt(st.nextToken().trim()));
            
            sybilweb.plant.controller.Address addr = issueCust.getAddress();
            addr.setLine1(st.nextToken().trim());
            addr.setLine2(st.nextToken().trim());
            addr.setCounty(st.nextToken().trim());
            addr.setCity(st.nextToken().trim());
            addr.setState(st.nextToken().trim());
            addr.setZipCode(st.nextToken().trim());
            addr.setCountry(st.nextToken().trim());
            addr.setBarcode(Integer.parseInt(st.nextToken()));
            
            String labelType = st.nextToken().trim();
			boolean isLabelTypePS = false;
			boolean isLabelTypePS_US = false;
			boolean isLabelTypePS_CA = false;
			if(labelType.length() == 8) {
				isLabelTypePS = labelType.toUpperCase().substring(6).equals("PS");
				isLabelTypePS_US  = ((labelType.toUpperCase().substring(2,4).equals("US")) && isLabelTypePS);
				isLabelTypePS_CA  = ((labelType.toUpperCase().substring(2,4).equals("CA")) && isLabelTypePS);
			}

            MagazineLabel magLabel = null;
            String boolValue = null;
            String plant_ID = PropertyBroker.getProperty("PLANTID");
            
            if(labelType.equals("BLKCAN") || labelType.equals("CAN") || labelType.equals("AMCAN") || labelType.equals("MMCAN") || labelType.equals("PSCAN")
            		 || labelType.equals("SUCASCPS") 
     				|| isLabelTypePS_CA) {
                issueCust.setMagazineLabel(new CanadianMagazineLabel());
            } else if(labelType.equals("BLKFORGN") || labelType.equals("FOREIGN") || labelType.equals("PSFORGN") || labelType.equals("AMFORGN") || labelType.equals("MMFORGN")) {
                issueCust.setMagazineLabel(new ForeignMagazineLabel());
            } else if(labelType.equals("BLKUSPS") || labelType.equals("USPS") || labelType.equals("AMUSPS") || labelType.equals("MMUSPS")|| labelType.equals("SUUSSCPS")|| labelType.equals("PSUSPS")
					|| isLabelTypePS_US) {
                issueCust.setMagazineLabel(new USMagazineLabel());
            } else {
                issueCust.setMagazineLabel(new OCCMagazineLabel());
            }
            
            magLabel = issueCust.getMagazineLabel();
            magLabel.setLabelType(labelType);
            
            if(issueCust.getPalletSackIndicator().trim().equals("")) {
                boolValue = st.nextToken().trim();
                if(boolValue.equals("true")) {
                    magLabel.suppressSequenceNumber = true;
                } else {
                    magLabel.suppressSequenceNumber = true;
                }
                
                magLabel.acsKeyline = "";
                magLabel.continentID = "";
                magLabel.editionCode = "";
                magLabel.alphaExpireDate = "";
                magLabel.bindingGroupName = "";
                magLabel.customerName = "";
                st.nextToken();
                st.nextToken();
                st.nextToken();
                st.nextToken();
                st.nextToken();
                st.nextToken();
                magLabel.magCode = st.nextToken().trim();
                magLabel.labelMagCode = "";
                magLabel.makeupCode = "";
                st.nextToken();
                boolValue = st.nextToken().trim();
                if(boolValue.equals("true")) {
                    magLabel.endOfPackageIndicator = false;
                } else {
                    magLabel.endOfPackageIndicator = false;
                }
                boolValue = st.nextToken().trim();
                if(boolValue.equals("true")) {
                    magLabel.endofPalletSackIndicator = false;
                } else {
                    magLabel.endofPalletSackIndicator = false;
                }
                magLabel.palletSackIndicator = "";
                //6/2/2012 TK student copies should have the palletsacknumber as well -- Jona Guiang  
                if (magLabel.magCode.equalsIgnoreCase("TK") && (plant_ID.toUpperCase().equals("ROK") || plant_ID.toUpperCase().equals("MCD"))){
                    magLabel.palletSackNumber = String.valueOf(issueCust.getPalletSackNumber());
                } else {
                    magLabel.palletSackNumber = "-1";}
                magLabel.packageNumber = "";
                magLabel.addressLine1 = "";
                magLabel.addressLine2 = "";
                magLabel.city = "";
                magLabel.state = "";
                magLabel.barcode = "";
                magLabel.barcodeCheckDigit = "";
                magLabel.Plant_ID = "";
                String LabelLine8 = PropertyBroker.getProperty("LabelLine8");
                boolean LL8MagCode = false;
                if(LabelLine8.indexOf(magLabel.magCode) >= 0) {
                    LL8MagCode = true;
                }
                if(LL8MagCode && RLL5fileExists) {
                    magLabel.LabelDropIn = "";
                }
                if(LL8MagCode && !RLL5fileExists) {
                    magLabel.LabelDropIn = "";
                }
                if(!LL8MagCode && RLL5fileExists) {
                    st.nextToken();
                }
                magLabel.publicationCode = "";
                magLabel.endorsementLine = "";
                magLabel.USzipCode = "";
                magLabel.zipPlus4 = "";
                magLabel.canadianCarrierLiteral = "";
                magLabel.canadianNonDirect = "";
                magLabel.carrierRouteNumber = "";
                magLabel.canadianMonthCode = "";
                magLabel.canadianZipCode = "";
                magLabel.canadianOEL = "";
                magLabel.imbBarcode = "";
                magLabel.imbBarcodeData = "";
                if(magLabel.magCode.length() > 1) {
                    magLabel.line2Type = "a";
                } else {
                    magLabel.line2Type = "k";
                }
                if(skipExtraLabeltokens) {
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                }
                magLabel.GeoComboName = "";
                magLabel.rideAlongIND = "";
                magLabel.sigNameOrientation = "";
                magLabel.signatureName = "";
                st.nextToken();
                st.nextToken();
                st.nextToken();
                st.nextToken();
                st.nextToken();
                st.nextToken();
                st.nextToken();
                st.nextToken();
                st.nextToken();
                st.nextToken();
                st.nextToken();
                st.nextToken();
                st.nextToken();
                st.nextToken();
                st.nextToken();
                st.nextToken();
                st.nextToken();
                st.nextToken();
                st.nextToken();
                st.nextToken();
                st.nextToken();
                st.nextToken();
                st.nextToken();
                st.nextToken();
                st.nextToken();
                st.nextToken();
                magLabel.endSchoolFlag = false;
                magLabel.classSeqNumber = st.nextToken().trim();
                try {
                    test = st.nextToken();
                    if(test.trim().length() < 3) {
                        magLabel.copyCnt = test;
                    } else {
                        flag = test;
                    }
                }
                catch(Exception e) {
                    LogWriter.writeLog("This is pre PSBULK Data");
                }
                tkSchoolCopyCount += Integer.parseInt(st.nextToken().trim());
            } else {
            	
                boolValue = st.nextToken().trim();
                if(boolValue.equals("true")) {
                    magLabel.suppressSequenceNumber = true;
                } else {
                    magLabel.suppressSequenceNumber = false;
                }
                magLabel.acsKeyline = st.nextToken().trim();
                magLabel.continentID = st.nextToken().trim();
                magLabel.editionCode = st.nextToken().trim();
                magLabel.alphaExpireDate = st.nextToken().trim();
    			magLabel.bindingGroupName = st.nextToken().trim();
                magLabel.customerName = st.nextToken().trim();
                magLabel.magCode = st.nextToken().trim();
                magLabel.labelMagCode = magLabel.magCode;
                magLabel.makeupCode = st.nextToken().trim();
                boolValue = st.nextToken().trim();
                
                if(boolValue.equals("true")) {
                    magLabel.endOfPackageIndicator = true;
                } else {
                    magLabel.endOfPackageIndicator = false;
                }
                boolValue = st.nextToken().trim();
                if(boolValue.equals("true")) {
                    magLabel.endofPalletSackIndicator = true;
                } else {
                    magLabel.endofPalletSackIndicator = false;
                }
                magLabel.palletSackIndicator = st.nextToken().trim();
                magLabel.palletSackNumber = st.nextToken().trim();
                magLabel.packageNumber = st.nextToken().trim();
                magLabel.addressLine1 = st.nextToken().trim();
                magLabel.addressLine2 = st.nextToken().trim();
                magLabel.city = st.nextToken().trim();
                magLabel.state = st.nextToken().trim();
                magLabel.barcode = st.nextToken().trim();
                magLabel.barcodeCheckDigit = st.nextToken().trim();
                magLabel.Plant_ID = issueCust.getalphaPlantCode();
                String LabelLine8 = PropertyBroker.getProperty("LabelLine8");
                boolean LL8MagCode = false;
                
                if(LabelLine8.indexOf(magLabel.magCode) >= 0) {
                    LL8MagCode = true;
                }
                if(LL8MagCode && RLL5fileExists) {
                    magLabel.LabelDropIn = st.nextToken().trim();
                }
                if(LL8MagCode && !RLL5fileExists) {
                    magLabel.LabelDropIn = st.nextToken().trim();
                }
                if(!LL8MagCode && RLL5fileExists) {
                    st.nextToken();
                }
                magLabel.publicationCode = st.nextToken().trim();
                magLabel.endorsementLine = st.nextToken().trim();
                magLabel.USzipCode = st.nextToken().trim();
                magLabel.zipPlus4 = st.nextToken().trim();
                magLabel.canadianCarrierLiteral = st.nextToken().trim();
                magLabel.canadianNonDirect = st.nextToken().trim();
                magLabel.carrierRouteNumber = st.nextToken().trim();
                magLabel.canadianMonthCode = st.nextToken().trim();
                magLabel.canadianZipCode = st.nextToken().trim();
                magLabel.canadianOEL = st.nextToken().trim();
                magLabel.imbBarcode = st.nextToken().trim();
                magLabel.imbBarcodeData = st.nextToken().trim();
                if(magLabel.magCode.length() > 1) {
                    magLabel.line2Type = "a";
                } else {
                    magLabel.line2Type = "k";
                }
                if(skipExtraLabeltokens) {
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                }
                magLabel.rideAlongIND = st.nextToken().trim();
                magLabel.GeoComboName = st.nextToken().trim();
                magLabel.sigNameOrientation = st.nextToken().trim();
                magLabel.signatureName = st.nextToken().trim();
                
                try {
                    flag = st.nextToken();
                    if(flag.equals("true")) {
                        magLabel.endSchoolFlag = true;
                        magLabel.classSeqNumber = st.nextToken().trim();
                    } else if(flag.equals("false")) {
                        magLabel.endSchoolFlag = false;
                        magLabel.classSeqNumber = st.nextToken().trim();
                    }
                }
                catch(Exception e) {
                    magLabel.endSchoolFlag = false;
                    magLabel.classSeqNumber = "00000000";
                }
                
                try {
                    test = st.nextToken();
                    if(test.trim().length() < 3) {
                        magLabel.copyCnt = test;
                    } else {
                        flag = test;
                    }
                }
                catch(Exception e) {
                    LogWriter.writeLog("This is pre PSBULK Data");
                }
                String tkCopyValue = st.nextToken().trim();
                if(tkCopyValue.equals("")) {
                    tkSchoolCopyCount = 0;
                } else {
                    tkSchoolCopyCount += Integer.parseInt(tkCopyValue.trim());
                }
                magLabel.SchoolCopyCount = String.valueOf(tkSchoolCopyCount);
                tkSchoolCopyCount = 0;
            }
            
            int numOfMsg = issueCust.getNumberOfMessages();
            Vector msgs = issueCust.getMessages();
            int lineSkipCnt = 0;
            if(numOfMsg > 0) {
                for(int i = 0; i < numOfMsg; i++) {
                    Message m = new Message();
                    Vector tls = m.getTextLines();
                    if(i == 0) {
                        if(flag.length() > 3) {
                            m.setMessageFamily(st.nextToken());
                        } else {
                            m.setMessageFamily(flag);
                        }
                    } else {
                        m.setMessageFamily(st.nextToken());
                    }
                    m.setMessageNumber(st.nextToken());
                    int numOfTL = Integer.parseInt(st.nextToken());
                    m.setNumberOfTextLines(numOfTL);
                    for(int j = 0; j < numOfTL; j++) {
                        TextLine tl = new TextLine();
                        tl.setText(st.nextToken());
                        tls.addElement(tl);
                    }

                    msgs.addElement(m);
                }

            }
        } catch(Exception e) {
            LogWriter.writeLog(e);
            SybilWarningException warning = new SybilWarningException("Error reading customer.");
            System.out.println((new StringBuilder(" Customer ")).append(custLine).toString());
            throw warning;
        }
        Vector origList = (Vector)issueCust.getMessages().clone();
        issueCust.setOrigMessages(origList);
        return true;
    }

    public boolean readCustomerRecord() {
        
    	try {
    		custRec = br.readLine();
    		if (custRec == null) return false;
    		else return true;
    	}catch (IOException e) {
    		//LogWriter.writeLog("IO exception reading IssueCustomer File.");
    	}
    	return false;
    }
}
