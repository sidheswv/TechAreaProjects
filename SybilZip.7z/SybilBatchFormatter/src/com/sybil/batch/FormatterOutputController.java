package com.sybil.batch;

import java.io.*;
import sybil.common.event.DataArrivedEvent;
import sybil.common.persistence.ZipFilePersistent;
import sybil.common.util.*;



public class FormatterOutputController
{

    private static PrintWriter outputFile = null;
    private static String outputFileName = null;
    private static String fileName = null;
    private static String fileNameOnly = null;
    private static String formattedFilePath = null;
    private static File f = null;
    public static VideoJetFormatter vjF = new VideoJetFormatter();

    public FormatterOutputController() {
    }

    public void createOutputFile(String magCode, String issueNum, String plantId) {
        formattedFilePath = PropertyBroker.getProperty("FORMATER_FILE_PATH", "Not found");
        fileNameOnly = magCode + "_" + issueNum + "_" + plantId + "_TCS.Zip";
        fileName = formattedFilePath.concat("/" + magCode + "_" + issueNum + "_" + plantId + "_TCS");
        try
        {
            outputFileName = fileName.trim() + ".txt";
            f = new File(outputFileName);
            outputFile = new PrintWriter(new OutputStreamWriter(new FileOutputStream(f), "ASCII"));
        } catch(Exception e) {
            e.printStackTrace();
            LogWriter.writeLog(e);
        }
    }

    public void processData(GtrfFileds CustomerRec) {
        String formatdata = null;
        formatdata = vjF.bathFormatData(CustomerRec);
        try
        {
            outputFile.print(formatdata);
            outputFile.flush();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public void processVirtualData(GtrfFileds CustomerRec) {
        String formatdata = null;
        CustomerRec.setEndorsementLine(fileNameOnly);
        formatdata = vjF.virtualFormatData(CustomerRec);
        try
        {
            outputFile.print(formatdata);
            outputFile.flush();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public void processbathAlignmentRecordData(String driverCode, String zipCode, String recCount) {
        String formatdata = null;
        formatdata = vjF.bathAlignmentRecord(driverCode, zipCode, recCount);
        try
        {
            outputFile.print(formatdata);
            outputFile.flush();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public void closefile() {
        try
        {
            outputFile.close();
            ZipFilePersistent zp = new ZipFilePersistent(outputFileName.substring(0, outputFileName.length() - 3).concat("zip"));
            zp.addFile(f);
            zp.closeZipfile();
        } catch(Exception e) {
            e.printStackTrace();
            LogWriter.writeLog(e);
        }
        if(f.exists()) {
            f.delete();
        }
    }

    public void ftpZipfile() {
        DataArrivedEvent dae = new DataArrivedEvent(this, fileName + ".zip", formattedFilePath, "zip");
        LogWriter.writeLog(" File Dir is : " + dae.getFileDir() + " File Extension : " + dae.getFileExt());
        FileMover1Exec fme = new FileMover1Exec(dae);
        fme.start();
        fme = null;
    }

}
