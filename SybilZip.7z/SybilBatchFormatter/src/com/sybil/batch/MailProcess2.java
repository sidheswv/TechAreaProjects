package com.sybil.batch;

import java.util.Date;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.*;

public class MailProcess2 {

    public MailProcess2()
    {
    }

    public static void EmailAMessage(String to, String from, String subject, String msgText, String mainfile, String mainfile2) {
        String allAddress[] = to.split(";");
        Properties props = System.getProperties();
        props.put("mail.smtp.host", "SMTPMAIL.TCS.TIMEINC.COM");
        Session session = Session.getInstance(props, null);
        try
        {
            MimeMessage msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(from));
            InternetAddress address[] = new InternetAddress[allAddress.length];
            for(int i = 0; i <= allAddress.length - 1; i++) {
                address[i] = new InternetAddress(allAddress[i]);
            }

            msg.setRecipients(javax.mail.Message.RecipientType.TO, address);
            msg.setSubject(subject);
            MimeBodyPart mbp1 = new MimeBodyPart();
            mbp1.setText(msgText);
            MimeBodyPart mbp2 = new MimeBodyPart();
            FileDataSource fds = new FileDataSource(mainfile);
            mbp2.setDataHandler(new DataHandler(fds));
            mbp2.setFileName(fds.getName());
            Multipart mp = new MimeMultipart();
            mp.addBodyPart(mbp1);
            mp.addBodyPart(mbp2);
            MimeBodyPart mbp3 = new MimeBodyPart();
            FileDataSource fds2 = new FileDataSource(mainfile2);
            mbp3.setDataHandler(new DataHandler(fds2));
            mbp3.setFileName(fds2.getName());
            mp.addBodyPart(mbp3);
            msg.setContent(mp);
            msg.setSentDate(new Date());
            Transport.send(msg);
        } catch(MessagingException mex) {
            mex.printStackTrace();
            Exception ex = null;
            if((ex = mex.getNextException()) != null) {
                ex.printStackTrace();
            }
        }
    }
}
