package com.sybil.batch;

import com.ibm.recordio.FileInputRecordStream;
import com.ibm.recordio.IFileInputRecordStream;
import com.report.text.*;
import com.report.text.pdf.*;
import java.awt.Color;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;



public class DriverCodeReport extends PdfPageEventHelper {

    protected PdfTemplate total;
    protected BaseFont helv;

    public DriverCodeReport() {
    }

    public void onOpenDocument(PdfWriter writer, Document document) {
        
    	total = writer.getDirectContent().createTemplate(100F, 100F);
        total.setBoundingBox(new Rectangle(-20F, -20F, 100F, 100F));
        try
        {
            helv = BaseFont.createFont("Helvetica", "Cp1252", false);
        } catch(Exception e) {
            throw new ExceptionConverter(e);
        }
    }

    public void onEndPage(PdfWriter writer, Document document) {
        PdfContentByte cb = writer.getDirectContent();
        cb.saveState();
        String text = "Page " + writer.getPageNumber() + " of  ";
        float textBase = document.bottom() - 15F;
        float textSize = helv.getWidthPoint(text, 9F);
        float textCenter = document.right() / 2.0F;
        cb.beginText();
        cb.setFontAndSize(helv, 10F);
        cb.setTextMatrix(textCenter, textBase);
        cb.showText(text);
        cb.endText();
        cb.addTemplate(total, textCenter + textSize, textBase);
        cb.restoreState();
    }

    public void onCloseDocument(PdfWriter writer, Document document) {
        total.beginText();
        total.setFontAndSize(helv, 10F);
        total.setTextMatrix(0.0F, 0.0F);
        total.showText(String.valueOf(writer.getPageNumber() - 1));
        total.endText();
    }

    public static void CreateDriverCode(String magCode, String issueNum, String reportFile, Vector<MakeUpCode> mc) {
        Document defDvrCdeDoc = new Document(PageSize.LETTER, -50F, -50F, 36F, 36F);
        IFileInputRecordStream firs = null;
        byte buffer[] = new byte[1024];
        int bytesRead = 0;
        String rec = null;
        boolean firstRow = true;
        boolean firstTime = true;
        String saveRollNum = "  ";
        int rptTotal = 0;
        int rollNumTotal = 0;
        int recCount = 0;
        int triang[][] = new int[50][mc.size()];
        String RptPath = PropertyBroker.getProperty("PDFReportsPath", "Not found");
        String fileName = magCode.toLowerCase() + ".i" + issueNum + ".OMS_Driver_Code";
        
        try
        {
            PdfWriter writer = PdfWriter.getInstance(defDvrCdeDoc, new FileOutputStream(RptPath + fileName + ".pdf"));
            writer.setViewerPreferences(512);
            writer.setPageEvent(new DriverCodeReport());
            defDvrCdeDoc.open();
            Date toDay = new Date();
            SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, MMM d, yyyy, HH:mm a ");
            PdfPTable outertable = new PdfPTable(1);
            outertable.setHeaderRows(9);
            PdfPCell header0 = new PdfPCell(new Phrase(String.valueOf(dateFormat.format(toDay)), FontFactory.getFont("Courier", 9F, 0, Color.black)));
            header0.setBorderWidth(0.0F);
            outertable.addCell(header0);
            String issueHdr = "Issue :" + issueNum;
            PdfPCell issueCell = new PdfPCell(new Phrase(issueHdr, FontFactory.getFont("Courier", 9F, 0, Color.black)));
            issueCell.setBorderWidth(0.0F);
            outertable.addCell(issueCell);
            PdfPCell cell1 = new PdfPCell(new Phrase("Driver Code Report", FontFactory.getFont("Courier", 15F, 1, Color.BLACK)));
            cell1.setHorizontalAlignment(1);
            cell1.setBorderWidth(0.0F);
            outertable.addCell(cell1);
            PdfPCell dummyCell = new PdfPCell(new Phrase("", FontFactory.getFont("Courier", 10F, 1, Color.black)));
            dummyCell.setBorderWidth(0.0F);
            outertable.addCell(dummyCell);
            firs = new FileInputRecordStream(reportFile);
            
            for(bytesRead = firs.read(buffer); bytesRead > 0;) {
                recCount++;
                rec = new String(buffer);
                String rollNum = rec.substring(2, 6);
                String driverCode = rec.substring(10, 14);
                String editionCode = rec.substring(20, 24);
                String marketId = rec.substring(30, 34);
                String copyCount = rec.substring(40, 48).trim();
                LogWriter.writeLog(" rollNum " + rollNum + " driverCode  " + driverCode + " editionCode  " + editionCode + "marketId  " + marketId + " copyCount " + copyCount);
                triang[recCount][0] = Integer.valueOf(driverCode).intValue();
                triang[recCount][1] = Integer.valueOf(copyCount).intValue();
                if(firstRow) {
                    String header1 = "Magazine :  Foreign Affairs                    Plant : Mechanicsburg                         Issue :" +  issueNum;
                    PdfPCell magCell = new PdfPCell(new Phrase(header1, FontFactory.getFont("Times-Roman", 12F, 1, Color.black)));
                    magCell.setBorderWidth(0.0F);
                    outertable.addCell(magCell);
                    for(int G = 0; G <= 2; G++) {
                        PdfPCell dummyCell1 = new PdfPCell(new Phrase("", FontFactory.getFont("Courier", 10F, 1, Color.black)));
                        dummyCell1.setBorderWidth(0.0F);
                        outertable.addCell(dummyCell1);
                    }

                    PdfPTable inertable = new PdfPTable(5);
                    inertable.addCell("Roll Id");
                    inertable.addCell("Market Id");
                    inertable.addCell("Book Version");
                    inertable.addCell("Make up Code");
                    inertable.addCell("Total Copies");
                    PdfPCell cell9 = new PdfPCell(inertable);
                    cell9.setBorderWidth(0.0F);
                    cell9.setBackgroundColor(new Color(108, 253, 206));
                    outertable.addCell(cell9);
                    firstRow = false;
                }
                if(rollNum.compareTo(saveRollNum) == 0) {
                    rollNum = " ";
                    marketId = " ";
                    String detailInfo = AddSpace.addSpace(rollNum, 3, ' ') + "           " + AddSpace.addSpace(marketId, 5, ' ') + "            " + editionCode + "            " + AddSpace.addSpace(driverCode, 4, ' ') + "         " + AddSpace.addSpace(PlaceComma.placeComma(Integer.valueOf(copyCount).intValue()), 6);
                    PdfPCell detailType = new PdfPCell(new Phrase(detailInfo, FontFactory.getFont("Courier", 12F, 0, Color.black)));
                    detailType.setBorderWidth(0.0F);
                    outertable.addCell(detailType);
                    rollNumTotal += Integer.valueOf(copyCount).intValue();
                } else {
                    if(firstTime)
                        firstTime = false;
                    else {
                        for(int G = 0; G < 2; G++) {
                            outertable.addCell(dummyCell);
                        }

                        String totalRoll = AddSpace.addSpace("Roll Id  ", 1, ' ') + "  " + AddSpace.addSpace(saveRollNum, 4, '0') + "  Total : " + AddSpace.addSpace(PlaceComma.placeComma(rollNumTotal), 9);
                        PdfPCell rollTotType = new PdfPCell(new Phrase(totalRoll, FontFactory.getFont("Courier", 10F, 1, Color.black)));
                        rollTotType.setBorderWidth(0.0F);
                        rollTotType.setHorizontalAlignment(2);
                        outertable.addCell(rollTotType);
                        rptTotal += rollNumTotal;
                        rollNumTotal = 0;
                        for(int G = 0; G < 2; G++) {
                            outertable.addCell(dummyCell);
                        }

                    }
                    saveRollNum = rollNum;
                    String detailInfo = AddSpace.addSpace(rollNum, 3, ' ') + "           " + AddSpace.addSpace(marketId, 5, ' ') + "            " + editionCode + "            " + AddSpace.addSpace(driverCode, 4, ' ') + "         " + AddSpace.addSpace(PlaceComma.placeComma(Integer.valueOf(copyCount).intValue()), 6);
                    PdfPCell detailType = new PdfPCell(new Phrase(detailInfo, FontFactory.getFont("Courier", 12F, 0, Color.black)));
                    detailType.setBorderWidth(0.0F);
                    rollNumTotal += Integer.valueOf(copyCount).intValue();
                    outertable.addCell(detailType);
                }
                bytesRead = firs.read(buffer);
                rec = new String(buffer);
            }

            int makeCount[] = new int[mc.size()];
            for(int i = 0; i < mc.size(); i++) {
                MakeUpCode mUc = (MakeUpCode)mc.get(i);
                for(int row = 1; row <= recCount; row++) {
                    if(Integer.valueOf(mUc.getMakeUpCode()).intValue() == triang[row][0]) {
                        for(int col = 1; col < 2; col++) {
                            makeCount[i] += triang[row][col];
                        }
                    }
                }
            }

            for(int G = 0; G < 2; G++) {
                outertable.addCell(dummyCell);
            }

            String totalRoll = AddSpace.addSpace("Roll Id ", 1, ' ') + "  " + AddSpace.addSpace(saveRollNum, 4, '0') + "  Total : " + AddSpace.addSpace(PlaceComma.placeComma(rollNumTotal), 9);
            PdfPCell rollTotType = new PdfPCell(new Phrase(totalRoll, FontFactory.getFont("Courier", 10F, 1, Color.black)));
            rollTotType.setBorderWidth(0.0F);
            rollTotType.setHorizontalAlignment(2);
            outertable.addCell(rollTotType);
            rptTotal += rollNumTotal;
            for(int G = 0; G < 4; G++) {
                outertable.addCell(dummyCell);
            }

            for(int row = 0; row < makeCount.length; row++) {
                MakeUpCode mUc = (MakeUpCode)mc.get(row);
                String totalDC = AddSpace.addSpace("Makeup Code ", 1, ' ') + "  " + AddSpace.addSpace(mUc.getMakeUpCode(), 4, '0') + "  Total : " + AddSpace.addSpace(PlaceComma.placeComma(makeCount[row]), 9);
                PdfPCell dcTotType = new PdfPCell(new Phrase(totalDC, FontFactory.getFont("Courier", 10F, 1, Color.black)));
                dcTotType.setBorderWidth(0.0F);
                dcTotType.setHorizontalAlignment(2);
                outertable.addCell(dcTotType);
            }

            for(int G = 0; G < 4; G++) {
                outertable.addCell(dummyCell);
            }

            String rptTotalRoll = AddSpace.addSpace("Report Total : ", 1, ' ') + "              " + AddSpace.addSpace(PlaceComma.placeComma(rptTotal), 9);
            PdfPCell rptRollTotType = new PdfPCell(new Phrase(rptTotalRoll, FontFactory.getFont("Courier", 10F, 1, Color.black)));
            rptRollTotType.setBorderWidth(0.0F);
            rptRollTotType.setHorizontalAlignment(2);
            outertable.addCell(rptRollTotType);
            defDvrCdeDoc.add(outertable);
        } catch(DocumentException de) {
            System.err.println(de.getMessage());
        } catch(IOException ioe) {
            System.err.println(ioe.getMessage());
        } catch(Exception e) {
            LogWriter.writeLog("Driver Code process: Exception on <" + reportFile + ">.");
            LogWriter.writeLog(e);
            e.printStackTrace();
            System.exit(-1);
        }
        defDvrCdeDoc.close();
    }
}
