package com.sybil.batch;

import com.ibm.recordio.FileInputRecordStream;
import com.ibm.recordio.IFileInputRecordStream;
import java.io.IOException;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;



public class SybilBatchEmail{

    private static String jobFileName = null;
    private static String fileName = null;
    private static String fileName2 = null;
    private static String fname2 = null;

    private static String magCode;
	private static String issue;
	private static String plant;
	private static String issdt;
	private static String processType;
	private static String dataType;
	private static String week;
	private String ext;

	private boolean invalidFileName = false;
	
    public SybilBatchEmail()
    {
    }

    public static void getFileName() {
        String rec = null;
        int counter = 0;
        byte buffer[] = new byte[1024];
        try
        {
            IFileInputRecordStream firs = new FileInputRecordStream(jobFileName);
            int bytesRead = firs.read(buffer);
            if(bytesRead > 0) {
                rec = new String(buffer);
                counter++;
            } else {
                LogWriter.writeLog("getMailParm: <" + jobFileName + "> is empty.");
                System.exit(-1);
            }
            while(bytesRead > 0) {
                if(counter == 9) {
                    fileName = rec.trim();
                    LogWriter.writeLog(" The Mail Dat file name1 is : " + fileName);
                }
                if(counter == 14) {
                    fileName2 = rec.trim();
                    LogWriter.writeLog(" The Mail Dat file name2 is : " + fileName2);    
                }
                bytesRead = firs.read(buffer);
                rec = new String(buffer);
                counter++;
            }
            firs.close();
        } catch(Exception e) {
            LogWriter.writeLog("getMailParm: Exception on <" + jobFileName + ">.");
            LogWriter.writeLog(e);
            e.printStackTrace();
            System.exit(-1);
        }
    }

    private static void initializeLogFile() {
        String prop = null;
        boolean writeLog = false;
        long maxFileSize = 0x186a0L;
        String fPath = null;
        String fName = null;
        if((prop = PropertyBroker.getProperty("LogMessagesToFile")) != null) {
            prop.toLowerCase();
            if(prop.equals("true")) {
                writeLog = true;
            }
        }
        if((prop = PropertyBroker.getProperty("LogFileDirectory")) != null) {
            fPath = prop;
        } else {
            System.out.println("Error: Log File Path not specified.  Assuming none");
            writeLog = false;
        }
        if((prop = PropertyBroker.getProperty("LogFileName")) != null) {
            fName = prop;
        } else {
            System.out.println("Error: Log File Name not specified.  Assuming none");
            writeLog = false;
        }
        if((prop = PropertyBroker.getProperty("LogFileMaxSize")) != null) {
            maxFileSize = Integer.parseInt(prop);
        }
        LogWriter.initialize(writeLog, maxFileSize, fPath, fName);
    }

    public static void main(String args[]) {
        
    	if(args.length < 2) {
            System.out.println("Sybil Batch Email: Error. Arg[0] must supply ini path and filename. Arg[1] must supply Email a mailparm path and filename.");
            System.exit(-1);
        }
        System.out.println("Sybil Batch Email.main: Arg[0]=" + args[0]);
        System.out.println("Sybil Batch Email.main: Arg[1]=" + args[1]);
        try
        {
            PropertyBroker.load(args[0]);
        } catch(IOException ex) {
            System.out.println("Sybil Batch Email.main: IOException on " + args[0]);
            System.out.println(ex);
            System.exit(-1);
        }
        
        initializeLogFile();
        jobFileName = args[1];
        getFileName();
        String emailFilePath = PropertyBroker.getProperty("EmailFilePath", "Not found");
        String mainFile = emailFilePath.concat(fileName);
        
        java.util.StringTokenizer st = new java.util.StringTokenizer(mainFile, ".");
    	magCode = st.nextToken().trim();
    	issue = st.nextToken().substring(1, 5);
    	plant = st.nextToken().trim();
    	issdt = st.nextToken().trim();
    	processType = st.nextToken().trim();
    	dataType = st.nextToken().trim();
    	week = st.nextToken().trim();
        
        String issueNum = issue.substring(1, 4);
        String issueWeek = week;
        LogWriter.writeLog("Issue Num : " + issueNum + "-" + issueWeek);
        String to = PropertyBroker.getProperty("EmailTo", "Not found");
        String from = PropertyBroker.getProperty("EmailFrom", "Not found");
        String msgText1 = "This is a system generated/automated email. The Foreign Affairs issue " + issueNum + "-" + issueWeek + " Mail dat file attached to this Email.\n";
        String subject = "Foreign Affairs Mail dat file";
        if(fileName2 != null){
        	String mainFile2 = emailFilePath.concat(fileName2);
        	MailProcess2.EmailAMessage(to, from, subject, msgText1, mainFile, mainFile2);
        }else {
        MailProcess.EmailAMessage(to, from, subject, msgText1, mainFile);
        }
    }
}
    
