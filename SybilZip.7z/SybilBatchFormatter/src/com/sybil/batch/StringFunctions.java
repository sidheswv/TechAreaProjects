package com.sybil.batch;


public class StringFunctions
{

    public static final String Class_Version_Number = "SYB_BTH_1.1";
    public static final int LEFT = -1;
    public static final int RIGHT = -2;
    public static final int CENTER = -3;
    public static final int USE_DEFAULT = -4;
    public static final int OFF = -5;

    public StringFunctions()
    {
    }

    public static String fixSize(String buffer, int size, char fillChar, int justification) {
        char buf[] = new char[size];
        int length = buffer.length();
        int num_fill_chars = size - length;
        int pos = 0;
        for(int i = 0; i < size; i++) {
            if(justification == RIGHT) {
                if(i < num_fill_chars) {
                    buf[i] = fillChar;
                } else {
                    buf[i] = buffer.charAt(pos++);
                }
            } else{
            	if(i < length) 
                    buf[i] = buffer.charAt(pos++);
                else 
                    buf[i] = fillChar;
            }
        }

        return String.valueOf(buf);
    }

    public static String fixSize6(String buffer, int size, char fillChar, int justification) {
        char buf[] = new char[size];
        int length = buffer.length();
        int num_fill_chars = size - length;
        int pos = 0;
        if(length > size) {
            pos++;
            for(int i = 0; i < size; i++) {
                buf[i] = buffer.charAt(pos++);
            }

        } else {
            for(int i = 0; i < size; i++) {
                if(justification == RIGHT) {
                    if(i < num_fill_chars) {
                        buf[i] = fillChar;
                    } else {
                        buf[i] = buffer.charAt(pos++);
                    }
                } else {
                	if(i < length)
                        buf[i] = buffer.charAt(pos++);
                    else                
                        buf[i] = fillChar;
                }
            }

        }
        return String.valueOf(buf);
    }

    public static String removeLeadingChars(String str, char chr) {
        int len = str.length();
        for(int i = 0; i < len; i++) {
            if(str.charAt(i) != chr) {
                return str.substring(i, len);
            }
        }

        return " ";
    }

    public static String trimRight(String str) {
        int len = str.length();
        for(int i = len - 1; i >= 0; i--) {
            if(str.charAt(i) != ' ') {
                return str.substring(0, i + 1);
            }
        }

        return " ";
    }
}
