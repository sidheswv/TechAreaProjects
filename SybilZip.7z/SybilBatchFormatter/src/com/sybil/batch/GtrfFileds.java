package com.sybil.batch;

import java.util.Vector;


public class GtrfFileds {

    private String recordType;
    private String plantId;
    private String demoId;
    private String braceId;
    private String stateId;
    private String marketId;
    private String demoSubsetId;
    private String rollId;
    private String continentCode;
    private String dopId;
    private String issueDate;
    private String magazineCode;
    private String editionCode;
    private String issueNum;
    private String pubCode;
    private String makeupCode;
    private String alphaPlantCode;
    private String canadaDelModeType;
    private String canadaDelivMonth;
    private String canadaCarrCode;
    private String canadaNonDirect;
    private String palletSackIndicator;
    private String palletSackNumber;
    private String packageNumber;
    private String endPackageIndicator;
    private String endSackIndicator;
    private String endStgdPalletIndicator;
    private String endPalletIndicator;
    private String seqNumFlag;
    private String consolidationLevel;
    private String customerName;
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String state;
    private String zipCode;
    private String zipPlus;
    private String numberOfMessages;
    private String endorsementLine;
    private String acsKeyline;
    private String alphaExpireDate;
    private String ctrlTraffic;
    private String ctrlBarCode;
    private String ctrlBarCodeFlag;
    private String imbBarcode;
    private String zipDeliveryPoint;
    private Message messageInfo;
    private Vector<Message> messageVector;
    private int recCcount;
    public static final int barcodeTrimSize = 14;

    public GtrfFileds() {
        recordType = null;
        plantId = null;
        demoId = null;
        braceId = null;
        stateId = null;
        marketId = null;
        demoSubsetId = null;
        rollId = null;
        continentCode = null;
        dopId = null;
        issueDate = null;
        magazineCode = null;
        editionCode = null;
        issueNum = null;
        pubCode = null;
        makeupCode = null;
        alphaPlantCode = null;
        canadaDelModeType = null;
        canadaDelivMonth = null;
        canadaCarrCode = null;
        canadaNonDirect = null;
        palletSackIndicator = null;
        palletSackNumber = null;
        packageNumber = null;
        endPackageIndicator = null;
        endSackIndicator = null;
        endStgdPalletIndicator = null;
        endPalletIndicator = null;
        seqNumFlag = null;
        consolidationLevel = null;
        customerName = null;
        addressLine1 = null;
        addressLine2 = null;
        city = null;
        state = null;
        zipCode = null;
        zipPlus = null;
        numberOfMessages = null;
        endorsementLine = null;
        acsKeyline = null;
        alphaExpireDate = null;
        ctrlTraffic = null;
        ctrlBarCode = null;
        ctrlBarCodeFlag = null;
        imbBarcode = null;
        zipDeliveryPoint = null;
        messageInfo = null;
        messageVector = null;
        recCcount = 0;
    }

    public String getAcsKeyline()
    {
        return acsKeyline;
    }

    public void setAcsKeyline(String acsKeyline)
    {
        this.acsKeyline = acsKeyline;
    }

    public String getAddressLine1()
    {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1)
    {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2()
    {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2)
    {
        this.addressLine2 = addressLine2;
    }

    public String getAlphaExpireDate()
    {
        return alphaExpireDate;
    }

    public void setAlphaExpireDate(String alphaExpireDate)
    {
        this.alphaExpireDate = alphaExpireDate;
    }

    public String getAlphaPlantCode()
    {
        return alphaPlantCode;
    }

    public void setAlphaPlantCode(String alphaPlantCode)
    {
        this.alphaPlantCode = alphaPlantCode;
    }

    public String getBraceId()
    {
        return braceId;
    }

    public void setBraceId(String braceId)
    {
        this.braceId = braceId;
    }

    public String getCanadaCarrCode()
    {
        return canadaCarrCode;
    }

    public void setCanadaCarrCode(String canadaCarrCode)
    {
        this.canadaCarrCode = canadaCarrCode;
    }

    public String getCanadaDelivMonth()
    {
        return canadaDelivMonth;
    }

    public void setCanadaDelivMonth(String canadaDelivMonth)
    {
        this.canadaDelivMonth = canadaDelivMonth;
    }

    public String getCanadaDelModeType()
    {
        return canadaDelModeType;
    }

    public void setCanadaDelModeType(String canadaDelModeType)
    {
        this.canadaDelModeType = canadaDelModeType;
    }

    public String getCanadaNonDirect()
    {
        return canadaNonDirect;
    }

    public void setCanadaNonDirect(String canadaNonDirect)
    {
        this.canadaNonDirect = canadaNonDirect;
    }

    public String getCity()
    {
        return city;
    }

    public void setCity(String city)
    {
        this.city = city;
    }

    public String getConsolidationLevel()
    {
        return consolidationLevel;
    }

    public void setConsolidationLevel(String consolidationLevel)
    {
        this.consolidationLevel = consolidationLevel;
    }

    public String getContinentCode()
    {
        return continentCode;
    }

    public void setContinentCode(String continentCode)
    {
        this.continentCode = continentCode;
    }

    public String getCtrlBarCode()
    {
        return ctrlBarCode;
    }

    public void setCtrlBarCode(String ctrlBarCode)
    {
        this.ctrlBarCode = ctrlBarCode;
    }

    public String getCtrlTraffic()
    {
        return ctrlTraffic;
    }

    public void setCtrlTraffic(String ctrlTraffic)
    {
        this.ctrlTraffic = ctrlTraffic;
    }

    public String getCustomerName()
    {
        return customerName;
    }

    public void setCustomerName(String customerName)
    {
        this.customerName = customerName;
    }

    public String getDemoId()
    {
        return demoId;
    }

    public void setDemoId(String demoId)
    {
        this.demoId = demoId;
    }

    public String getDemoSubsetId()
    {
        return demoSubsetId;
    }

    public void setDemoSubsetId(String demoSubsetId)
    {
        this.demoSubsetId = demoSubsetId;
    }

    public String getDopId()
    {
        return dopId;
    }

    public void setDopId(String dopId)
    {
        this.dopId = dopId;
    }

    public String getEditionCode()
    {
        return editionCode;
    }

    public void setEditionCode(String editionCode)
    {
        this.editionCode = editionCode;
    }

    public String getEndorsementLine()
    {
        return endorsementLine;
    }

    public void setEndorsementLine(String endorsementLine)
    {
        this.endorsementLine = endorsementLine;
    }

    public String getEndPackageIndicator()
    {
        return endPackageIndicator;
    }

    public void setEndPackageIndicator(String endPackageIndicator)
    {
        this.endPackageIndicator = endPackageIndicator;
    }

    public String getEndPalletIndicator()
    {
        return endPalletIndicator;
    }

    public void setEndPalletIndicator(String endPalletIndicator)
    {
        this.endPalletIndicator = endPalletIndicator;
    }

    public String getEndSackIndicator()
    {
        return endSackIndicator;
    }

    public void setEndSackIndicator(String endSackIndicator)
    {
        this.endSackIndicator = endSackIndicator;
    }

    public String getEndStgdPalletIndicator()
    {
        return endStgdPalletIndicator;
    }

    public void setEndStgdPalletIndicator(String endStgdPalletIndicator)
    {
        this.endStgdPalletIndicator = endStgdPalletIndicator;
    }

    public String getIssueDate()
    {
        return issueDate;
    }

    public void setIssueDate(String issueDate)
    {
        this.issueDate = issueDate;
    }

    public String getIssueNum()
    {
        return issueNum;
    }

    public void setIssueNum(String issueNum)
    {
        this.issueNum = issueNum;
    }

    public String getMagazineCode()
    {
        return magazineCode;
    }

    public void setMagazineCode(String magazineCode)
    {
        this.magazineCode = magazineCode;
    }

    public String getMakeupCode()
    {
        return makeupCode;
    }

    public void setMakeupCode(String makeupCode)
    {
        this.makeupCode = makeupCode;
    }

    public String getMarketId()
    {
        return marketId;
    }

    public void setMarketId(String marketId)
    {
        this.marketId = marketId;
    }

    public String getNumberOfMessages()
    {
        return numberOfMessages;
    }

    public void setNumberOfMessages(String numberOfMessages)
    {
        this.numberOfMessages = numberOfMessages;
    }

    public String getPackageNumber()
    {
        return packageNumber;
    }

    public void setPackageNumber(String packageNumber)
    {
        this.packageNumber = packageNumber;
    }

    public String getPalletSackIndicator()
    {
        return palletSackIndicator;
    }

    public void setPalletSackIndicator(String palletSackIndicator)
    {
        this.palletSackIndicator = palletSackIndicator;
    }

    public String getPalletSackNumber()
    {
        return palletSackNumber;
    }

    public void setPalletSackNumber(String palletSackNumber)
    {
        this.palletSackNumber = palletSackNumber;
    }

    public String getPlantId()
    {
        return plantId;
    }

    public void setPlantId(String plantId)
    {
        this.plantId = plantId;
    }

    public String getPubCode()
    {
        return pubCode;
    }

    public void setPubCode(String pubCode)
    {
        this.pubCode = pubCode;
    }

    public String getRecordType()
    {
        return recordType;
    }

    public void setRecordType(String recordType)
    {
        this.recordType = recordType;
    }

    public String getRollId()
    {
        return rollId;
    }

    public void setRollId(String rollId)
    {
        this.rollId = rollId;
    }

    public String getSeqNumFlag()
    {
        return seqNumFlag;
    }

    public void setSeqNumFlag(String seqNumFlag)
    {
        this.seqNumFlag = seqNumFlag;
    }

    public String getState()
    {
        return state;
    }

    public void setState(String state)
    {
        this.state = state;
    }

    public String getStateId()
    {
        return stateId;
    }

    public void setStateId(String stateId)
    {
        this.stateId = stateId;
    }

    public String getZipCode()
    {
        return zipCode;
    }

    public void setZipCode(String zipCode)
    {
        this.zipCode = zipCode;
    }

    public String getZipPlus()
    {
        return zipPlus;
    }

    public void setZipPlus(String zipPlus)
    {
        this.zipPlus = zipPlus;
    }

    public String getImbBarcode()
    {
        return imbBarcode;
    }

    public void setImbBarcode(String imbBarcode)
    {
        this.imbBarcode = imbBarcode;
    }

    public String getCtrlBarCodeFlag()
    {
        return ctrlBarCodeFlag;
    }

    public void setCtrlBarCodeFlag(String ctrlBarCodeFlag)
    {
        this.ctrlBarCodeFlag = ctrlBarCodeFlag;
    }

    public String getZipDeliveryPoint()
    {
        return zipDeliveryPoint;
    }

    public void setZipDeliveryPoint(String zipDeliveryPoint)
    {
        this.zipDeliveryPoint = zipDeliveryPoint;
    }

    public Message getMessageInfo()
    {
        return messageInfo;
    }

    public void setMessageInfo(Message messageInfo)
    {
        this.messageInfo = messageInfo;
    }

    public Vector<Message> getMessageVector()
    {
        return messageVector;
    }

    public void setMessageVector(Vector<Message> messageVector)
    {
        this.messageVector = messageVector;
    }

    public int getRecCcount()
    {
        return recCcount;
    }

    public void setRecCcount(int recCcount)
    {
        this.recCcount = recCcount;
    }

    protected String formatLine1()
    {
        StringBuffer labelLine = new StringBuffer();
        
        if(pubCode.equals("")) 
            labelLine.append("        ");
        else {
        	if(pubCode.length() != 8)
                labelLine.append(StringFunctions.fixSize(pubCode, 8, ' ', -1));
            else
                labelLine.append(pubCode);
        }
                
        if(endorsementLine.equals(""))
            labelLine.append("                             ");
        else {
            labelLine.append(" ");
            labelLine.append(StringFunctions.fixSize(endorsementLine, 28, '*', -2));
        }
        labelLine.append(" ");
        return labelLine.toString();
    }

    protected String formatLine2()
    {
        StringBuffer labelLine = new StringBuffer();
        
        if(acsKeyline.equals(""))
            labelLine.append("                   ");
        else {
        	if(acsKeyline.length() != 15) 
                labelLine.append(StringFunctions.fixSize(acsKeyline, 15, ' ', -1));
            else 
            	labelLine.append(acsKeyline);
        }
        
        if(magazineCode.equals(""))
            labelLine.append("  ");
        else
            labelLine.append(magazineCode);
        
        labelLine.append("  ");
        
        if(editionCode.equals(""))        
            labelLine.append("         ");
        else        
            labelLine.append(StringFunctions.fixSize(editionCode, 9, ' ', -2));
        
        labelLine.append("  ");
        
        if(alphaExpireDate.equals(""))     
            labelLine.append("     ");
        else {
        	if(alphaExpireDate.length() != 5)        
                labelLine.append(StringFunctions.fixSize(alphaExpireDate, 5, ' ', -1));
            else        
                labelLine.append(alphaExpireDate);
        }
        
        labelLine.append(" ");
        return labelLine.toString();
    }

    protected String formatLine3()
    {
        StringBuffer labelLine = new StringBuffer();
        if(customerName.equals(""))
            labelLine.append("                              ");
        else {
        	if(customerName.length() != 30)        
                labelLine.append(StringFunctions.fixSize(customerName, 30, ' ', -1));
            else        
                labelLine.append(customerName);
        }
        
        labelLine.append("     ");
        if(makeupCode.equals(""))
            labelLine.append("    ");
        else {
        	if(makeupCode.length() != 4)
                labelLine.append(StringFunctions.fixSize(makeupCode, 4, '0', -2));
            else        
                labelLine.append(makeupCode);
        }
        
        labelLine.append(" ");
        if(endPalletIndicator.equalsIgnoreCase("1") || endSackIndicator.equalsIgnoreCase("1")) {
            labelLine.append("##");
        } else {
            labelLine.append("  ");
        }
        return labelLine.toString();
    }

    protected String formatLine4()
    {
        StringBuffer labelLine = new StringBuffer();
        if(addressLine2.equals(""))
            labelLine.append("                              ");
        else {
        	if(addressLine2.length() != 30)       
                labelLine.append(StringFunctions.fixSize(addressLine2, 30, ' ', -1));
            else       
                labelLine.append(addressLine2);
        }
        
        labelLine.append("   ");
        labelLine.append("#");
        labelLine.append(StringFunctions.fixSize6(String.valueOf(recCcount), 5, '0', -2));
        labelLine.append(" ");
        
        if(endPackageIndicator.equalsIgnoreCase("1")) {
            labelLine.append("##");
        } else {
            labelLine.append("  ");
        }
        return labelLine.toString();
    }

    protected String formatLine5()
    {
        StringBuffer labelLine = new StringBuffer();
        if(addressLine1.equals(""))
            labelLine.append("                              ");
        else {
        	if(addressLine1.length() != 30)                
                labelLine.append(StringFunctions.fixSize(addressLine1, 30, ' ', -1));
            else            
                labelLine.append(addressLine1);
        }
        
        labelLine.append(" ");
        if(palletSackIndicator.equals("")) {
            labelLine.append(" ");
        } else {
            labelLine.append(palletSackIndicator.charAt(0));
        }
        
        if(palletSackNumber.equals("-1")) {
            labelLine.append("     ");
        } else {
        	if(palletSackNumber.length() != 7)                
                labelLine.append(StringFunctions.fixSize(palletSackNumber.substring(2, 7), 7, '0', -2));
            else            
                labelLine.append(palletSackNumber.substring(2, 7));
        }
        
        
        labelLine.append(" ");
        return labelLine.toString();
    }

    protected String formatLine6()
    {
        StringBuffer labelLine = new StringBuffer();
        String cityStateZip = null;
        String nCity = null;
        String nZip = null;
        String City = city.equals("") ? "               " : city;
        String State = state.equals("") ? "  " : state;
        String ZipCode = zipCode.equals("") ? "     " : zipCode;
        String ZipPlus = zipPlus.equals("") ? "    " : zipPlus;
        if(City.equals("               ")) {
            nCity = City.concat("  ");
        } else {
            nCity = City.concat(" .");
        }
        
        if(ZipPlus.trim().length() > 0) {
            nZip = ZipCode.concat("-");
        } else {
            nZip = ZipCode.concat(" ");
        }
        
        if(ctrlBarCode != null && ctrlBarCode.length() > 0) {
            cityStateZip = City.trim() + "  " + State.trim() + "  " + nZip + ZipPlus;
        } else {
            cityStateZip = nCity.trim() + State + "  " + nZip + ZipPlus;
        }
        labelLine.append(StringFunctions.fixSize(cityStateZip, 35, ' ', -1));
        labelLine.append("        ");
        return labelLine.toString();
    }

    protected String formatBarcodeLine()
    {
        StringBuffer labelLine = new StringBuffer();
        String barCodeWithCheckDigit = null;
        String barCode = null;
        String ZipCode = zipCode.equals("") ? "     " : zipCode;
        String ZipPlus = zipPlus.equals("") ? "    " : zipPlus;
        if(ZipPlus.trim().length() > 0) {
            barCode = ZipCode.concat(ZipPlus).trim().concat(zipDeliveryPoint).trim();
        } else {
            barCode = ZipCode.trim();
        }
        barCodeWithCheckDigit = "b" + barCode + getCheckdigit(barCode) + "e";
        labelLine.append(StringFunctions.fixSize(barCodeWithCheckDigit, 14, ' ', -1));
        return labelLine.toString();
    }

    private String getCheckdigit(String barCode)
    {
        String checkSumDigit = null;
        boolean test = true;
        try
        {
            test = Float.valueOf(barCode).isNaN();
        } catch(Exception exception) { }
        
        if(!test) {
            if(barCode.equals("")) {
                checkSumDigit = "";
            } else {
                long BCDigit = Long.parseLong(barCode);
                long BCDSum = 0L;
                for(int i = 0; i < barCode.length(); i++) {
                    long digit = BCDigit % 10L;
                    long temp = BCDigit / 10L;
                    BCDigit = temp;
                    BCDSum += digit;
                }

                String CSDigit = Long.toString(BCDSum);
                int checkSumValue;
                if(CSDigit.length() < 2) {
                    int CSTemp = Integer.valueOf(CSDigit).intValue();
                    checkSumValue = 10 - CSTemp;
                } else {
                    CSDigit = CSDigit.substring(1, 2);
                    int CSTemp = Integer.valueOf(CSDigit.trim()).intValue();
                    checkSumValue = 10 - CSTemp;
                }
                if(checkSumValue == 10) {
                    checkSumValue = 0;
                }
                checkSumDigit = Integer.toString(checkSumValue);
            }
        }
        return checkSumDigit;
    }
}
