package com.sybil.batch;

import com.ibm.recordio.FileInputRecordStream;
import com.ibm.recordio.IFileInputRecordStream;
import java.io.IOException;
import java.util.Vector;
import sybil.common.util.LogWriter;
import sybil.common.util.PropertyBroker;


public class TampaFormatter{

    private static String jobFileName = null;
    private static String fileName = null;
    private static String reportFile = null;
    private static String magCode = null;
    private static String issueNum = null;
    private static String plantId = null;
    private static Vector<MakeUpCode> driverCode = new Vector<MakeUpCode>();
    private static final int POS_RECORD_TYPE = 0;
//    private static final char CHAR_1D = 29;
    private static final char DATA_REC = 68;
    private static final char MSG_TYPE = 77;
    

    public TampaFormatter()
    {
    }

    private static void getFileName() {
        
    	String rec = null;
        char recType = ' ';
        MakeUpCode mc = null;
        byte buffer[] = new byte[1024];
        
        try
        {
            IFileInputRecordStream firs = new FileInputRecordStream(jobFileName);
            int bytesRead = firs.read(buffer);
            if(bytesRead > 0) {
                rec = new String(buffer);
                recType = rec.charAt(POS_RECORD_TYPE);
            } else {
                LogWriter.writeLog("getMailParm: <" + jobFileName + "> is empty.");
                System.exit(-1);
            }
            while(bytesRead > 0){
                switch(recType)
                {
                case 'H' :
                    mc = new MakeUpCode(rec.substring(1, 5));
                    driverCode.addElement(mc);
                    break;

                case 'R' :
                    reportFile = rec.substring(1).trim();
                    break;

                default:
                    fileName = rec.trim();
                    break;
                }
                bytesRead = firs.read(buffer);
                rec = new String(buffer);
                recType = rec.charAt(POS_RECORD_TYPE);
            }
            firs.close();
        } catch(Exception e) {
            LogWriter.writeLog("getMailParm: Exception on <" + jobFileName + ">.");
            LogWriter.writeLog(e);
            e.printStackTrace();
            System.exit(-1);
        }
    }

    private static void initializeLogFile() {
        
    	String prop = null;
        boolean writeLog = false;
        long maxFileSize = 100000;
        String fPath = null;
        String fName = null;
        if((prop = PropertyBroker.getProperty("LogMessagesToFile")) != null) {
            prop.toLowerCase();
            if(prop.equals("true")) {
                writeLog = true;
            }
        }
        if((prop = PropertyBroker.getProperty("LogFileDirectory")) != null) {
            fPath = prop;
        } else {
            System.out.println("Error: Log File Path not specified.  Assuming none");
            writeLog = false;
        }
        if((prop = PropertyBroker.getProperty("LogFileName")) != null) {
            fName = prop;
        } else {
            System.out.println("Error: Log File Name not specified.  Assuming none");
            writeLog = false;
        }
        if((prop = PropertyBroker.getProperty("LogFileMaxSize")) != null) {
            maxFileSize = Integer.parseInt(prop);
        }
        LogWriter.initialize(writeLog, maxFileSize, fPath, fName);
    }

    public static void main(String args[])
    {
        if(args.length < 2) {
            System.out.println("TampaFormatter.main: Error. Arg[0] must supply ini path and filename. Arg[1] must supply mailparm path and filename.");
            System.exit(-1);
        }
        System.out.println("TampaFormatter.main: Arg[0]=" + args[0]);
        System.out.println("TampaFormatter.main: Arg[1]=" + args[1]);
        try
        {
            PropertyBroker.load(args[0]);
        } catch(IOException ex) {
            System.out.println("TampaFormatter.main: IOException on " + args[0]);
            System.out.println(ex);
            System.exit(-1);
        }
        initializeLogFile();
        LogWriter.writeLog("TampaFormatter.main: LogWriter initialized");
        LogWriter.writeLog("SybilBatchFormatter : Release 1 GTRF Ver 1.0");
        jobFileName = args[1];
        process();
    }

    private static void process()
    {
        getFileName();
        LogWriter.writeLog("TampaFormatter.main: GTRF file is <" + fileName + ">");
        processGtrfRecord();
        if(reportFile != null) {
            String to = PropertyBroker.getProperty("VIPEmailTo", "Not found");
            String from = PropertyBroker.getProperty("EmailFrom", "Not found");
            String msgText1 = "This is a system generated/automated email. \nThis Email has a MakeUp Code Report attachement. The Foreign Affairs issue # issueNum Video jet file has been generated and the file is posted to https://transit.customersvc.com.\n";
            String subject = magCode.toUpperCase() + " Video Jet File";
            String rptPath = PropertyBroker.getProperty("PDFReportsPath", "Not found");
            LogWriter.writeLog("Mag Code :" + magCode + " Issue Num : " + issueNum);
            String mainFile = rptPath.concat(magCode.toLowerCase() + ".i" + issueNum + ".OMS_Driver_Code.pdf");
            DriverCodeReport.CreateDriverCode(magCode, issueNum, reportFile, driverCode);
            MailProcess.EmailAMessage(to, from, subject, msgText1, mainFile);
        }
    }

    private static void processGtrfRecord()
    {
        GtrfFileds subscriberGtrfRec = null;
        FormatterOutputController foc = new FormatterOutputController();
        String rec = null;
        char recType = ' ';
        byte buffer[] = new byte[1024];
        Vector<Message> messageVector = new Vector<Message>();
        IFileInputRecordStream firs = null;
        int bytesRead = 0;
        int recCcount = 0;
        try
        {
            firs = new FileInputRecordStream(fileName);
            bytesRead = firs.read(buffer);
            if(bytesRead > 0) {
                subscriberGtrfRec = new GtrfFileds();
                rec = new String(buffer);
                recType = rec.charAt(POS_RECORD_TYPE);
                magCode = rec.substring(ReleaseOneGtrf.POS_MAG_CODE_START, ReleaseOneGtrf.POS_MAG_CODE_END);
                issueNum = rec.substring(ReleaseOneGtrf.POS_ISSUE_NUM_START, ReleaseOneGtrf.POS_ISSUE_NUM_END);
                plantId = rec.substring(ReleaseOneGtrf.POS_ALPHA_PLANT_CODE_START, ReleaseOneGtrf.POS_ALPHA_PLANT_CODE_END);
                String searchZip = rec.substring(ReleaseOneGtrf.POS_ADDRESS_ZIP_CODE_START, ReleaseOneGtrf.POS_ADDRESS_ZIP_CODE_END);
                foc.createOutputFile(magCode, issueNum, plantId);
                for(int i = 0; i < driverCode.size(); i++) {
                    MakeUpCode mc = (MakeUpCode)driverCode.get(i);
                    recCcount = i + 1;
                    foc.processbathAlignmentRecordData(mc.getMakeUpCode(), searchZip, Integer.toString(recCcount));
                }

                LogWriter.writeLog("Processing Gtrf File : <" + fileName + "> ");
            } else {
                LogWriter.writeLog("processGtrfRecord: <" + fileName + "> is empty.");
                System.exit(-1);
            }
            while(bytesRead > 0) 
            {
                if(recType != DATA_REC) {
                    LogWriter.writeLog("processGtrfRecord: Unknown rec type <" + recType + "> in <" + fileName + ">.");
                    System.exit(-1);
                } else {
                    recCcount++;
                    subscriberGtrfRec.setRecCcount(recCcount);
                    subscriberGtrfRec.setPlantId(rec.substring(ReleaseOneGtrf.POS_DEMO_ID_START, ReleaseOneGtrf.POS_DEMO_ID_END));
                    subscriberGtrfRec.setBraceId(rec.substring(ReleaseOneGtrf.POS_BRACE_ID_START, ReleaseOneGtrf.POS_BRACE_ID_END));
                    subscriberGtrfRec.setStateId(rec.substring(ReleaseOneGtrf.POS_STATE_ID_START, ReleaseOneGtrf.POS_STATE_ID_END));
                    subscriberGtrfRec.setMarketId(rec.substring(ReleaseOneGtrf.POS_MARKET_ID_START, ReleaseOneGtrf.POS_MARKET_ID_END));
                    subscriberGtrfRec.setDemoSubsetId(rec.substring(ReleaseOneGtrf.POS_DEMO_SUBSET_ID_START, ReleaseOneGtrf.POS_DEMO_SUBSET_ID_END));
                    subscriberGtrfRec.setRollId(rec.substring(ReleaseOneGtrf.POS_ROLL_ID_START, ReleaseOneGtrf.POS_ROLL_ID_END));
                    subscriberGtrfRec.setContinentCode(rec.substring(ReleaseOneGtrf.POS_CONTINENT_CODE_START, ReleaseOneGtrf.POS_CONTINENT_CODE_END));
                    subscriberGtrfRec.setDopId(rec.substring(ReleaseOneGtrf.POS_DOP_ID_START, ReleaseOneGtrf.POS_DOP_ID_END));
                    subscriberGtrfRec.setMagazineCode(rec.substring(ReleaseOneGtrf.POS_MAG_CODE_START, ReleaseOneGtrf.POS_MAG_CODE_END));
                    subscriberGtrfRec.setIssueDate(rec.substring(ReleaseOneGtrf.POS_ISSUE_DATE_START, ReleaseOneGtrf.POS_ISSUE_DATE_END));
                    subscriberGtrfRec.setEditionCode(rec.substring(ReleaseOneGtrf.POS_EDITION_START, ReleaseOneGtrf.POS_EDITION_END));
                    subscriberGtrfRec.setIssueNum(rec.substring(ReleaseOneGtrf.POS_ISSUE_NUM_START, ReleaseOneGtrf.POS_ISSUE_NUM_END));
                    subscriberGtrfRec.setPubCode(rec.substring(ReleaseOneGtrf.POS_PUB_CODE_START, ReleaseOneGtrf.POS_PUB_CODE_END));
                    subscriberGtrfRec.setMakeupCode(rec.substring(ReleaseOneGtrf.POS_MAKEUP_CODE_START, ReleaseOneGtrf.POS_MAKEUP_CODE_END));
                    subscriberGtrfRec.setAlphaPlantCode(rec.substring(ReleaseOneGtrf.POS_ALPHA_PLANT_CODE_START, ReleaseOneGtrf.POS_ALPHA_PLANT_CODE_END));
                    subscriberGtrfRec.setCanadaDelModeType(rec.substring(ReleaseOneGtrf.POS_CANADA_DEL_MODE_TYPE_START, ReleaseOneGtrf.POS_CANADA_DEL_MODE_TYPE_END));
                    subscriberGtrfRec.setCanadaDelivMonth(rec.substring(ReleaseOneGtrf.POS_CANADA_DELIV_MONTH_START, ReleaseOneGtrf.POS_CANADA_DELIV_MONTH_END));
                    subscriberGtrfRec.setCanadaCarrCode(rec.substring(ReleaseOneGtrf.POS_CANADA_CARR_CODE_START, ReleaseOneGtrf.POS_CANADA_CARR_CODE_END));
                    subscriberGtrfRec.setCanadaNonDirect(rec.substring(ReleaseOneGtrf.POS_CANADA_NON_DIRECT_START, ReleaseOneGtrf.POS_CANADA_NON_DIRECT_END));
                    subscriberGtrfRec.setPalletSackIndicator(rec.substring(ReleaseOneGtrf.POS_PALLET_SACK_INDICATOR_START, ReleaseOneGtrf.POS_PALLET_SACK_INDICATOR_END));
                    subscriberGtrfRec.setPalletSackNumber(rec.substring(ReleaseOneGtrf.POS_PALLET_SACK_NUMBER_START, ReleaseOneGtrf.POS_PALLET_SACK_NUMBER_END));
                    subscriberGtrfRec.setPackageNumber(rec.substring(ReleaseOneGtrf.POS_PACKAGE_NUMBER_START, ReleaseOneGtrf.POS_PACKAGE_NUMBER_END));
                    subscriberGtrfRec.setEndPackageIndicator(rec.substring(ReleaseOneGtrf.POS_END_PACKAGE_INDICATOR_START, ReleaseOneGtrf.POS_END_PACKAGE_INDICATOR_END));
                    subscriberGtrfRec.setEndSackIndicator(rec.substring(ReleaseOneGtrf.POS_END_SACK_INDICATOR_START, ReleaseOneGtrf.POS_END_SACK_INDICATOR_END));
                    subscriberGtrfRec.setEndStgdPalletIndicator(rec.substring(ReleaseOneGtrf.POS_END_STGD_PALLET_INDICATOR_START, ReleaseOneGtrf.POS_END_STGD_PALLET_INDICATOR_END));
                    subscriberGtrfRec.setEndPalletIndicator(rec.substring(ReleaseOneGtrf.POS_END_PALLET_INDICATOR_START, ReleaseOneGtrf.POS_END_PALLET_INDICATOR_END));
                    subscriberGtrfRec.setSeqNumFlag(rec.substring(ReleaseOneGtrf.POS_SEQ_NUM_FLG_START, ReleaseOneGtrf.POS_SEQ_NUM_FLG_END));
                    subscriberGtrfRec.setConsolidationLevel(rec.substring(ReleaseOneGtrf.POS_CONSOLIDATION_LEVEL_START, ReleaseOneGtrf.POS_CONSOLIDATION_LEVEL_END));
                    subscriberGtrfRec.setCustomerName(rec.substring(ReleaseOneGtrf.POS_CUSTOMER_NAME_START, ReleaseOneGtrf.POS_CUSTOMER_NAME_END));
                    subscriberGtrfRec.setAddressLine1(rec.substring(ReleaseOneGtrf.POS_ADDRESS_LINE1_START, ReleaseOneGtrf.POS_ADDRESS_LINE1_END));
                    subscriberGtrfRec.setAddressLine2(rec.substring(ReleaseOneGtrf.POS_ADDRESS_LINE2_START, ReleaseOneGtrf.POS_ADDRESS_LINE2_END));
                    subscriberGtrfRec.setCity(rec.substring(ReleaseOneGtrf.POS_ADDRESS_CITY_START, ReleaseOneGtrf.POS_ADDRESS_CITY_END));
                    subscriberGtrfRec.setState(rec.substring(ReleaseOneGtrf.POS_ADDRESS_STATE_START, ReleaseOneGtrf.POS_ADDRESS_STATE_END));
                    subscriberGtrfRec.setZipCode(rec.substring(ReleaseOneGtrf.POS_ADDRESS_ZIP_CODE_START, ReleaseOneGtrf.POS_ADDRESS_ZIP_CODE_END));
                    subscriberGtrfRec.setZipPlus(rec.substring(ReleaseOneGtrf.POS_ADDRESS_ZIP_CODE_EXTENDED_START, ReleaseOneGtrf.POS_ADDRESS_ZIP_CODE_EXTENDED_END));
                    subscriberGtrfRec.setNumberOfMessages(rec.substring(ReleaseOneGtrf.POS_NUMBER_OF_MESSAGES_START, ReleaseOneGtrf.POS_NUMBER_OF_MESSAGES_END));
                    subscriberGtrfRec.setEndorsementLine(rec.substring(ReleaseOneGtrf.POS_ENDORSEMENT_LINE_START, ReleaseOneGtrf.POS_ENDORSEMENT_LINE_END));
                    subscriberGtrfRec.setAcsKeyline(rec.substring(ReleaseOneGtrf.POS_ACS_KEYLINE_START, ReleaseOneGtrf.POS_ACS_KEYLINE_END));
                    subscriberGtrfRec.setAlphaExpireDate(rec.substring(ReleaseOneGtrf.POS_ALPHA_EXPIRE_DATE_START, ReleaseOneGtrf.POS_ALPHA_EXPIRE_DATE_END));
                    subscriberGtrfRec.setCtrlTraffic(rec.substring(ReleaseOneGtrf.POS_CTRL_TRAFFIC_START, ReleaseOneGtrf.POS_CTRL_TRAFFIC_END));
                    subscriberGtrfRec.setCtrlBarCode(rec.substring(ReleaseOneGtrf.POS_CTRL_BARCODE_START, ReleaseOneGtrf.POS_CTRL_BARCODE_END));
                    subscriberGtrfRec.setCtrlBarCodeFlag(rec.substring(ReleaseOneGtrf.POS_CTRL_BARCODE_FLAG_START, ReleaseOneGtrf.POS_CTRL_BARCODE_FLAG_END));
                    String zipCode = rec.substring(ReleaseOneGtrf.POS_ADDRESS_ZIP_CODE_START, ReleaseOneGtrf.POS_ADDRESS_ZIP_CODE_END);
                    String zipPlus4 = rec.substring(ReleaseOneGtrf.POS_ADDRESS_ZIP_CODE_EXTENDED_START, ReleaseOneGtrf.POS_ADDRESS_ZIP_CODE_EXTENDED_END);
                    String zipDeliveryPoint = rec.substring(ReleaseOneGtrf.POS_ZIP_DELIVERY_POINT_START, ReleaseOneGtrf.POS_ZIP_DELIVERY_POINT_END);
                    String barCode = rec.substring(ReleaseOneGtrf.POS_IMB_BARCODE_START, ReleaseOneGtrf.POS_IMB_BARCODE_END);
                    subscriberGtrfRec.setZipDeliveryPoint(zipDeliveryPoint);
                    subscriberGtrfRec.setImbBarcode(barCode.concat(zipCode).concat(zipPlus4).concat(zipDeliveryPoint));
                    int numberOfMessages = Integer.parseInt(rec.substring(ReleaseOneGtrf.POS_NUMBER_OF_MESSAGES_START, ReleaseOneGtrf.POS_NUMBER_OF_MESSAGES_END));
                    if(numberOfMessages > 0) {
                        for(int i = 0; i < numberOfMessages; i++) {
                            String messageFamily = null;
                            String messageNumber = null;
                            String messagesPerFamily = null;
                            String allMessages[] = (String[])null;
                            bytesRead = firs.read(buffer);
                            rec = new String(buffer);
                            recType = rec.charAt(POS_RECORD_TYPE);
                            if(bytesRead > 0 && recType == MSG_TYPE) {
                                int messageLength = (bytesRead - ReleaseOneGtrf.POS_FIRST_TEXT_LINE_START) + 1;
                                messageFamily = rec.substring(ReleaseOneGtrf.POS_MESSAGE_FAMILY_START, ReleaseOneGtrf.POS_MESSAGE_FAMILY_END);
                                messageNumber = rec.substring(ReleaseOneGtrf.POS_MESSAGE_NUMBER_START, ReleaseOneGtrf.POS_MESSAGE_NUMBER_END);
                                messagesPerFamily = rec.substring(ReleaseOneGtrf.POS_FIRST_TEXT_LINE_START, messageLength);
                                allMessages = messagesPerFamily.split(String.valueOf('\035'));
                                Message messageInfo = new Message(messageFamily, messageNumber, allMessages);
                                messageVector.add(messageInfo);
                            }
                        }

                        subscriberGtrfRec.setMessageVector(messageVector);
                    }
                    bytesRead = firs.read(buffer);
                    if(bytesRead > 0) {
                        rec = new String(buffer);
                        recType = rec.charAt(POS_RECORD_TYPE);
                    }
                    foc.processData(subscriberGtrfRec);
                    /*if(recCcount % 2000 == 0) {
                        recCcount++;
                        subscriberGtrfRec.setRecCcount(recCcount);
                        foc.processVirtualData(subscriberGtrfRec);
                    }*/
                    messageVector.clear();
                    subscriberGtrfRec = new GtrfFileds();
                }
            }
            firs.close();
        } catch(Exception e) {
            LogWriter.writeLog("processGtrfRecord: Exception on <" + fileName + ">.");
            LogWriter.writeLog(e);
            e.printStackTrace();
            System.exit(-1);
        }
        foc.closefile();
        foc.ftpZipfile();
    }

}
