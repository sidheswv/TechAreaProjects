package com.sybil.batch;


public class PlaceComma
{

    public PlaceComma()
    {
    }

    protected static StringBuffer placeComma(int arg_num)
    {
        StringBuffer str = new StringBuffer(String.valueOf(arg_num));
        for(int i = str.length() - 3; i > 0; i -= 3)
        {
            str = str.insert(i, ',');
        }

        return str;
    }

    protected static StringBuffer placeStringComma(String arg_num)
    {
        StringBuffer str = new StringBuffer(String.valueOf(arg_num));
        for(int i = str.length() - 5; i > 0; i -= 5)
        {
            str = str.insert(i, ',');
        }

        return str;
    }

    protected static StringBuffer placeDoubleComma(double arg_num)
    {
        StringBuffer str = new StringBuffer(String.valueOf(arg_num));
        for(int i = str.length() - 5; i > 0; i -= 5)
        {
            str = str.insert(i, ',');
        }

        return str;
    }
}
