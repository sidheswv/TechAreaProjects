package com.sybil.batch;


public class Message
{

    private String messageFamily;
    private String messageNumber;
    private String allMessages[];

    public Message(String messageFamily, String messageNumber, String allMessages[])
    {
        this.messageFamily = null;
        this.messageNumber = null;
        this.allMessages = null;
        this.messageFamily = messageFamily;
        this.messageNumber = messageNumber;
        this.allMessages = allMessages;
    }

    public String[] getAllMessages()
    {
        return allMessages;
    }

    public void setAllMessages(String allMessages[])
    {
        this.allMessages = allMessages;
    }

    public String getMessageFamily()
    {
        return messageFamily;
    }

    public void setMessageFamily(String messageFamily)
    {
        this.messageFamily = messageFamily;
    }

    public String getMessageNumber()
    {
        return messageNumber;
    }

    public void setMessageNumber(String messageNumber)
    {
        this.messageNumber = messageNumber;
    }
}
