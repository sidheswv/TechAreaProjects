package com.sybil.batch;

import java.util.Vector;
import sybil.common.util.LogWriter;



public class VideoJetFormatter {

    public static final String Class_Version_Number = "SYB_BATCH_1.0";
    
    int QC_Book = 0;
    private static char REC_SEP = '\u001E';
	private static char GRP_SEP = '\u001D';
	private static char UNIT_SEP = '\u001F';
    private static final int trimSize = 42;
    private static final int numLines = 6;

    public VideoJetFormatter() {
        
    }

    protected String bathAlignmentRecord(String driverCode, String zipCode, String recCount) {
        
    	StringBuffer buf = new StringBuffer(1024);
        String lineNum = null;
        try
        {
            buf.append(REC_SEP);
            buf.append("10");
            buf.append(StringFunctions.fixSize(String.valueOf(recCount), 9, '0', StringFunctions.RIGHT));
            buf.append(UNIT_SEP);
            String searchCode = zipCode + "TCSAL";
            buf.append(StringFunctions.fixSize(searchCode, 10, ' ', StringFunctions.LEFT));
            buf.append("02 ");
            buf.append(StringFunctions.fixSize(driverCode, 4, '0', StringFunctions.RIGHT));
            for(int i = 1; i <= 15; i++) {
                if(i == 9) {
                    buf.append(GRP_SEP + "b999999999991e");
                } else {
                	if(i <= 8){
                		lineNum = "LINE0" + Integer.toString(i);
                        buf.append(GRP_SEP + StringFunctions.fixSize(lineNum.concat("*8901234567890123456789012345678901*"), trimSize, ' ', StringFunctions.LEFT));
                	} else {
                		lineNum = "LINE" + Integer.toString(i);
                        buf.append(GRP_SEP + StringFunctions.fixSize(lineNum.concat("*8901234567890123456789012345678901*"), trimSize, ' ', StringFunctions.LEFT));
                	}
                }
            }

            buf.append(GRP_SEP);
            buf.append('\n');
        } catch(Exception ex) {
            LogWriter.writeLog(ex);
        }
        return buf.toString();
    }

    protected String bathFormatData(GtrfFileds ic) {
        
    	StringBuffer buf = new StringBuffer(1024);
        try
        {
            buf.append(REC_SEP);
            buf.append("10");
            buf.append(StringFunctions.fixSize(String.valueOf(ic.getRecCcount()), 9, '0', StringFunctions.RIGHT));
            buf.append(UNIT_SEP);
            String zipcode = ic.getZipCode();
            String subscriberName = ic.getCustomerName();
            String searchCode = zipcode.concat(subscriberName.substring(0, 5));
            if(!ic.getContinentCode().equals("")) {
                if(ic.getContinentCode().charAt(0) >= 'A' && ic.getContinentCode().charAt(0) <= 'Y') 
                    buf.append(StringFunctions.fixSize(zipcode, 10, ' ', StringFunctions.LEFT));
                else 
                    buf.append(StringFunctions.fixSize(searchCode, 10, ' ', StringFunctions.LEFT));
            } else 
                buf.append(StringFunctions.fixSize(searchCode, 10, ' ', StringFunctions.LEFT));
            
            String sort_stacker = null;
            
            if ((ic.getEndPackageIndicator().compareTo("1") != 0) && (ic.getEndPalletIndicator().compareTo("1") != 0)) 
                sort_stacker = "00";
            else {
            	if(ic.getEndPalletIndicator().compareTo("1") == 0)
            		sort_stacker = "21";
            	else
            		sort_stacker = "11";
            }
            
            buf.append(sort_stacker);
            buf.append(" ");
            buf.append(StringFunctions.fixSize(ic.getMakeupCode(), 4, '0', StringFunctions.RIGHT));
            
            buf.append(GRP_SEP + StringFunctions.fixSize(ic.formatLine1(), trimSize, ' ', StringFunctions.LEFT));
            buf.append(GRP_SEP + StringFunctions.fixSize(ic.formatLine2(), trimSize, ' ', StringFunctions.LEFT));
            buf.append(GRP_SEP + StringFunctions.fixSize(ic.formatLine3(), trimSize, ' ', StringFunctions.LEFT));
            buf.append(GRP_SEP + StringFunctions.fixSize(ic.formatLine4(), trimSize, ' ', StringFunctions.LEFT));
            buf.append(GRP_SEP + StringFunctions.fixSize(ic.formatLine5(), trimSize, ' ', StringFunctions.LEFT));
            buf.append(GRP_SEP + StringFunctions.fixSize(ic.formatLine6(), trimSize, ' ', StringFunctions.LEFT));
            buf.append(GRP_SEP + StringFunctions.fixSize("", trimSize, ' ', StringFunctions.LEFT));
            buf.append(GRP_SEP + StringFunctions.fixSize("", trimSize, ' ', StringFunctions.LEFT));
            buf.append(GRP_SEP + StringFunctions.fixSize(ic.formatBarcodeLine(), 14, ' ', StringFunctions.LEFT));
            
            int numberOfMessages = Integer.parseInt(ic.getNumberOfMessages());
            Message mf = null;
            
            if(numberOfMessages == 0) {
                for(int padding = 0; padding < 6; padding++) {
                    buf.append(GRP_SEP + StringFunctions.fixSize("", trimSize, ' ', StringFunctions.LEFT));
                }

            } else {
                Vector<Message> allMessages = ic.getMessageVector();
                for(int j = 0; j < allMessages.size(); j++) {
                    mf = (Message)allMessages.elementAt(j);
                    if(numberOfMessages != 0) {
                        int numberOfMsgTextLines = mf.getAllMessages().length;
                        for(int k = 0; k < numberOfMsgTextLines; k++) {
                            buf.append(GRP_SEP);
                            buf.append(StringFunctions.fixSize(mf.getAllMessages()[k], trimSize, ' ', StringFunctions.LEFT));
                        }

                    }
                }

            }
            buf.append(GRP_SEP);
            buf.append('\n');
        } catch(Exception ex) {
            LogWriter.writeLog(ex);
        }
        return buf.toString();
    }

    protected String virtualFormatData(GtrfFileds ic) {
        
    	StringBuffer buf = new StringBuffer(1024);
        try
        {
            buf.append(REC_SEP);
            buf.append("10");
            buf.append(StringFunctions.fixSize(String.valueOf(ic.getRecCcount()), 9, '0', StringFunctions.RIGHT));
            buf.append(UNIT_SEP);
            String zipcode = ic.getZipCode();
            String subscriberName = ic.getCustomerName();
            String searchCode = zipcode.concat(subscriberName.substring(0, 5));
            if(!ic.getContinentCode().equals("")) {
                if(ic.getContinentCode().charAt(0) >= 'A' && ic.getContinentCode().charAt(0) <= 'Y')
                    buf.append(StringFunctions.fixSize(zipcode, 10, ' ', StringFunctions.LEFT));
                else
                    buf.append(StringFunctions.fixSize(searchCode, 10, ' ', StringFunctions.LEFT));
            } else
                buf.append(StringFunctions.fixSize(searchCode, 10, ' ', StringFunctions.LEFT));
            
            buf.append("02");
            buf.append(" ");
            buf.append(StringFunctions.fixSize(ic.getMakeupCode(), 4, '0', StringFunctions.RIGHT));
            
            buf.append(GRP_SEP + StringFunctions.fixSize(ic.formatLine1().replaceAll(" ", "*"), trimSize, '*', StringFunctions.LEFT));
            buf.append(GRP_SEP + StringFunctions.fixSize(ic.formatLine2().replaceAll(" ", "*"), trimSize, '*', StringFunctions.LEFT));
            buf.append(GRP_SEP + StringFunctions.fixSize(ic.formatLine3().replaceAll(" ", "*"), trimSize, '*', StringFunctions.LEFT));
            buf.append(GRP_SEP + StringFunctions.fixSize(ic.formatLine4().replaceAll(" ", "*"), trimSize, '*', StringFunctions.LEFT));
            buf.append(GRP_SEP + StringFunctions.fixSize(ic.formatLine5().replaceAll(" ", "*"), trimSize, '*', StringFunctions.LEFT));
            buf.append(GRP_SEP + StringFunctions.fixSize(ic.formatLine6().replaceAll(" ", "*"), trimSize, '*', StringFunctions.LEFT));
            buf.append(GRP_SEP + StringFunctions.fixSize("LINE07*" + ic.getMakeupCode().concat("-*-VER.BK**"), trimSize, '*', StringFunctions.LEFT));
            buf.append(GRP_SEP + StringFunctions.fixSize("LINE08*" + ic.getMakeupCode(), trimSize, '*', StringFunctions.LEFT));
            buf.append(GRP_SEP + StringFunctions.fixSize(ic.formatBarcodeLine(), 14, ' ', StringFunctions.LEFT));
            
            int numberOfMessages = Integer.parseInt(ic.getNumberOfMessages());
            Message mf = null;
            if(numberOfMessages == 0) {
                for(int padding = 0; padding < numLines; padding++) {
                    buf.append(GRP_SEP + StringFunctions.fixSize("Line1" + padding, trimSize, '*', StringFunctions.LEFT));
                }

            } else {
                Vector<Message> allMessages = ic.getMessageVector();
                for(int j = 0; j < allMessages.size(); j++) {
                    mf = (Message)allMessages.elementAt(j);
                    if(numberOfMessages != 0) {
                        int numberOfMsgTextLines = mf.getAllMessages().length;
                        for(int k = 0; k < numberOfMsgTextLines; k++) {
                            buf.append(GRP_SEP);
                            buf.append(StringFunctions.fixSize(mf.getAllMessages()[k], trimSize, '*', StringFunctions.LEFT));
                        }
                    }
                }
            }
            buf.append(GRP_SEP);
            buf.append('\n');
        } catch(Exception ex) {
            LogWriter.writeLog(ex);
        }
        return buf.toString();
    }

}
