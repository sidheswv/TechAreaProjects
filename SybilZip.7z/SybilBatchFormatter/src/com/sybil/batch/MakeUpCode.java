package com.sybil.batch;


public class MakeUpCode
{

    private String makeUpCode;

    public MakeUpCode()
    {
        makeUpCode = null;
    }

    public MakeUpCode(String makeUpCode)
    {
        this.makeUpCode = null;
        this.makeUpCode = makeUpCode;
    }

    public String getMakeUpCode()
    {
        return makeUpCode;
    }

    public void setMakeUpCode(String makeUpCode)
    {
        this.makeUpCode = makeUpCode;
    }
}
